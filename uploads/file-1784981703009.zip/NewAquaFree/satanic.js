/// TQ TO: ///
//// SATANIC HAXOR ( DEVELOPER ) ///
/// DIKA LYRIC ( TANGAN KANAN ) ///
/// KYUUUU ( MY FRIENDS ) ///
/// DILX ( MY FRIENDS ) ////
/// Vita ( MY FRIENDS ) ////
/// VITA ( MY FRIENDS ) ////
/// SKYZO ( MY FRIENDS ) ////
/// WANZ OFC ( MY FRIENDS ) ////
/// AYAN ( MY FRIENDS ) ///
/// RYZE ( MY FRIENDS ) ////
/// PUTRI PLENGER AYIN ( MY FRIENDS ) ///

require('./settings');
const { 
    makeWASocket, 
    makeCacheableSignalKeyStore, 
    downloadContentFromMessage, 
    generateWAMessageContent,
    generateWAMessageFromContent, 
    generateWAMessage,
    generateForwardMessageContent,
    prepareWAMessageMedia, 
    useSingleFileAuthState, 
    useMultiFileAuthState,
    fetchLatestBaileysVersion,
    MessageType,
    proto,
    Browsers,
    getContentType,
    DisconnectReason,
    handleInteractive,
    areJidsSameUser,
	InteractiveMessage,
	sendTable,
    WA_DEFAULT_EPHEMERAL    
} = require('@whiskeysockets/baileys')

const fs = require('fs');
const axios = require('axios');
const chalk = require("chalk");
const jimp = require("jimp")
const util = require("util");
const moment = require("moment-timezone");
const path = require("path")
const cron = require('node-cron')
const fileType = require('file-type')
const request = require('request');
const ffmpeg = require('fluent-ffmpeg');
const PhoneNumber = require('awesome-phonenumber')
const fetch = require('node-fetch')
const FormData = require('form-data')
const cheerio = require('cheerio');
const qs = require('qs');
const { Primbon } = require('scrape-primbon')
const primbon = new Primbon()
const JsConfuser = require('js-confuser')
const { exec, execSync, spawn } = require("child_process");

const crypto = require('crypto');
const { randomBytes } = crypto;

////// FOLDER LIB /////
const { smsg, await, clockStrings, delay, enumGetKey, fetchBuffer, fetchJson, libformat, formatDate, formatp, tanggal, generateProfilePicture, getBuffer, getGroupAdmins, getRandom, isUrl, json, logic, parseMention, sizeLimit, runtime, sleep, sort, toNumber, getTime } = require('./lib/myfunction');
const { CatBox, TelegraPh, floNime, UploadFileUgu, uptotelegra } = require('./lib/uploader');
const loadJSON = (path) => {
  try {
    return JSON.parse(fs.readFileSync(path))
  } catch {
    return {}
  }
}


const { addSewaGroup, checkSewaGroup, getSewaPosition, toMs, msToDate, getGcName, expiredCheck, remindSewa } = require('./lib/sewa');



////// FOLDER LIB /////

////// FOLDER DATABASE ///)
const afkData = JSON.parse(fs.readFileSync("./database/afk.json"))

const owner = JSON.parse(fs.readFileSync('./database/owner.json'));
const premium = JSON.parse(fs.readFileSync('./database/premium.json'));
const antilinkKick = JSON.parse(fs.readFileSync('./database/antilinkkick.json'));
let set_welcome_db = JSON.parse(fs.readFileSync('./database/set_welcome.json'));
let set_left_db = JSON.parse(fs.readFileSync('./database/set_left.json'));
// LOAD DATABASE (GANTI JADI OBJECT)


const antibotPath = './database/antibot.json'
const antibotSettingsPath = './database/antibot-settings.json'


const dbSpamGroups = './database/antispam-groups.json'
const dbSpamWarn = './database/antispam-warn.json'
let antiSpamGroups = fs.existsSync(dbSpamGroups)
    ? JSON.parse(fs.readFileSync(dbSpamGroups))
    : (fs.writeFileSync(dbSpamGroups, JSON.stringify([])), [])

let spamWarnings = fs.existsSync(dbSpamWarn)
    ? JSON.parse(fs.readFileSync(dbSpamWarn))
    : (fs.writeFileSync(dbSpamWarn, JSON.stringify({})), {})
const dbSpamCounter = './database/antispam-counter.json'

let spamData = fs.existsSync(dbSpamCounter)
    ? JSON.parse(fs.readFileSync(dbSpamCounter))
    : (fs.writeFileSync(dbSpamCounter, JSON.stringify({})), {})





let antibot = loadJSON(antibotPath)
let antibotSettings = loadJSON(antibotSettingsPath)

const saveAntibot = () =>
  fs.writeFileSync(antibotPath, JSON.stringify(antibot, null, 2))

const saveAntibotSettings = () =>
  fs.writeFileSync(antibotSettingsPath, JSON.stringify(antibotSettings, null, 2))


let _welcome = JSON.parse(fs.readFileSync('./database/welcome.json'))
let _left = JSON.parse(fs.readFileSync('./database/left.json'))

const dbPath = (name) => `./database/${name}`

let openaigc = JSON.parse(fs.readFileSync('./database/openaigc.json'))
const bannedList = JSON.parse(fs.readFileSync("./database/banuser.json")) 
let badwordList = []
try {
  if (fs.existsSync("./database/badword.json")) {
    badwordList = JSON.parse(fs.readFileSync("./database/badword.json"))
  }
} catch (e) {}

let antiBadwordData = {}
try {
  if (fs.existsSync("./database/antibadword.json")) {
    antiBadwordData = JSON.parse(fs.readFileSync("./database/antibadword.json"))
  }
} catch (e) {}

const ntlinkgc = JSON.parse(fs.readFileSync('./database/antilink.json'));
const antilinkall = JSON.parse(fs.readFileSync('./database/antilinkall.json'));
const antiIg = JSON.parse(fs.readFileSync('./database/antiig.json'));
const antiTt = JSON.parse(fs.readFileSync('./database/antitt.json'));
const antiImage = JSON.parse(fs.readFileSync('./database/antiimage.json'));
const onlyadmin = JSON.parse(fs.readFileSync('./database/onlyadmin.json'));
const fiturMember = JSON.parse(fs.readFileSync('./database/fiturmember.json'));
const antiVideo = JSON.parse(fs.readFileSync('./database/antivideo.json'));
const antiSticker = JSON.parse(fs.readFileSync('./database/antisticker.json'));
const antiAudio = JSON.parse(fs.readFileSync('./database/antiaudio.json'));
const antiYt = JSON.parse(fs.readFileSync('./database/antiyt.json'));
const joingc = JSON.parse(fs.readFileSync('./database/autojoingc.json'));
const nttagsw = JSON.parse(fs.readFileSync('./database/antitagsw.json'));

const antiRvo = JSON.parse(fs.readFileSync('./database/antirvo.json'));
const antiswgc = JSON.parse(fs.readFileSync('./database/antiswgc.json'));


const mutegrup = JSON.parse(fs.readFileSync('./database/mutegc.json'));

const usrvip = JSON.parse(fs.readFileSync('./database/uservip.json'));
let db_respon_list = JSON.parse(fs.readFileSync('./database/list-message.json'));

const GROUP_FILE = path.join(process.cwd(), 'database', 'gruplist.json');

const pgroup = JSON.parse(fs.readFileSync('./database/groupadd.json'));

const DB_FILE = './database/database.json';
function loadDB() {
  if (fs.existsSync(DB_FILE)) {
    try {
      const raw = fs.readFileSync(DB_FILE);
      return JSON.parse(raw);
    } catch (err) {
      console.error('Error reading DB file:', err);
      return { chats: {} };
    }
  } else {
    return { chats: {} };
  }
}
function saveDB(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

let tebaklagu = []
let family100 = []
let kuismath = []
let tebakgambar = []
let tebakkata = []
let transactionDetails = {};
let caklontong = []
let caklontong_desk = []
let tebakkalimat = []
let tebaklirik = []
let tebakkartun = []
let cerdascermat = []
let tebakwarna = []
let susunkata = []
let tebakheroml = []
let tebaktebakan = []
let tebakbendera = []
let tebakbendera2 = []
let tebakkabupaten = []
let tebakkimia = []
let tebakasahotak = []
let siapaaku = []
let tebaksusunkata = []
let tekateki = []
// Di awal kode
global.jadibotSessions = {};

global.db = loadDB();
if (global.db) global.db = {
sticker: {},
database: {}, 
game: {},
others: {},
users: {},
chats: {},
settings: {},
...(global.db || {})
}

/////// FOLDER DATABASE ///////
module.exports = satanic = async (satanic, m, chatUpdate, store) => {
try {

        const { type, quotedMsg, mentioned, now, fromMe } = m
        const body = (m.mtype === 'conversation') ? m.message.conversation : 
             (m.mtype === 'imageMessage') ? m.message.imageMessage?.caption : 
             (m.mtype === 'videoMessage') ? m.message.videoMessage?.caption : 
             (m.mtype === 'extendedTextMessage') ? m.message.extendedTextMessage?.text : 
             (m.mtype === 'buttonsResponseMessage') ? m.message.buttonsResponseMessage?.selectedButtonId : 
             (m.mtype === 'listResponseMessage') ? m.message.listResponseMessage?.singleSelectReply?.selectedRowId : 
             (m.mtype === 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage?.selectedId : 
             (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply?.selectedRowId || m.text) : 
             m.text || '';
const bady = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'interactiveResponseMessage') ? appenTextMessage(JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id, chatUpdate) : (m.mtype == 'templateButtonReplyMessage') ? appenTextMessage(m.msg.selectedId, chatUpdate) : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ' '

let budy = m.message.conversation || (m.message.extendedTextMessage && m.message.extendedTextMessage.text) || ``
    const CMD = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') && m.message.buttonsResponseMessage.selectedButtonId ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') && m.message.listResponseMessage.singleSelectReply.selectedRowId? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'interactiveResponseMessage') ? (JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id) : ''.slice(1).trim().split(/ +/).shift().toLowerCase()
let pfxConf = JSON.parse(fs.readFileSync(dbPath('prefix.json')));
let prefix;
if (pfxConf.mode === 'noprefix') {
prefix = '';
} else if (pfxConf.mode === 'multi') {
prefix = /^[#!.,®©¥€¢£/\∆✓]/.test(CMD) ? CMD.match(/^[#!.,®©¥€¢£/\∆✓]/gi) : '#';
} else {
prefix = pfxConf.symbol;
}
global.prefix = prefix;
async function appenTextMessage(text, chatUpdate) {
let messages = await generateWAMessage(m.chat, { text: text, mentions: m.mentionedJid }, {
userJid: satanic.user.id,
quoted: m.quoted && m.quoted.fakeObj
})
messages.key.fromMe = areJidsSameUser(m.sender, satanic.user.id)
messages.key.id = m.key.id
messages.pushName = pushname
if (m.isGroup) messages.participant = m.sender
let msg = {
...chatUpdate,
messages: [proto.WebMessageInfo.fromObject(messages)],
type: 'append'
}
satanic.ev.emit('messages.upsert', msg)
}
   const chath = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == "listResponseMessage") ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == "messageContextInfo") ? m.message.listResponseMessage.singleSelectReply.selectedRowId : ''
        const pes = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text: ' '
        const messagesC = pes.slice(0).trim()
        const content = JSON.stringify(m.message)
const isCmd = body && typeof body === 'string' && body.startsWith(prefix)
        const from = m.key.remoteJid
       const messagesD = body ? body.slice(0).trim().split(/ +/).shift().toLowerCase() : ''
        const command = isCmd ? body.slice(prefix.length).trim().split(/ +/).shift().toLowerCase() : ""
        const args = body ? body.trim().split(/ +/).slice(1) : []
        const userDb = global?.db?.users?.[m.sender]
        const pushname =
  (userDb?.registered && userDb?.name)
    ? userDb.name
    : (m.pushName || "Misterius")
        const botNumber = await satanic.decodeJid(satanic.user.id);
        const isCreator = owner.includes(m.sender) || m.sender === botNumber;
       
        const text = args.join(" ")
        const q = text
        const cekpesan = true
        const quoted = m.quoted ? m.quoted : m
        const mime = (quoted.msg || quoted).mimetype || ''
        const qmsg = (quoted.msg || quoted)
        const isMedia = /image|video|sticker|audio/.test(mime)
        const isImage = (type == 'imageMessage')
		const isVideo = (type == 'videoMessage')
		const isAudio = (type == 'audioMessage')
		const isSticker = (type == 'stickerMessage')
		const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
		const isQuotedViewOnce = type === 'extendedTextMessage' && content.includes('viewOnceMessageV2')
        const isQuotedLocation = type === 'extendedTextMessage' && content.includes('locationMessage')
        const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
        const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
        const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
        const isQuotedContact = type === 'extendedTextMessage' && content.includes('contactMessage')
        const isQuotedDocument = type === 'extendedTextMessage' && content.includes('documentMessage')

        store.groupMetadata = store.groupMetadata || {};
        const invalidMembers = [];

        if (m.isGroup) {
            for (const [gid, meta] of Object.entries(store.groupMetadata || {})) {
                if (!meta.participants) continue;
                const missing = meta.participants.filter(p => !p.jid && !p.lid && p.id);
                if (missing.length) {
                    invalidMembers.push({
                        groupId: gid,
                        groupName: meta.subject || "(No Subject)",
                        members: missing
                    });
                }
            }

            if (Object.keys(store.groupMetadata).length === 0 || invalidMembers.length >= 1) {
                store.groupMetadata = await satanic.groupFetchAllParticipating();
            }
        }

        const groupMetadata = m.isGroup
            ? store.groupMetadata[m.chat]
            || (store.groupMetadata[m.chat] = await satanic.groupMetadata(m.chat).catch(e => {}))
            : '';

        const groupName = m.isGroup ? groupMetadata.subject : ''
        const participants = m.isGroup ? await groupMetadata.participants : ''

        if (m.isGroup && m.sender.endsWith("@lid")) {
            m.sender = participants.find(p => p.lid === m.sender)?.jid || m.sender;
        }
        const groupAdmins = m.isGroup ? participants.filter((v) => v.admin !== null && v.jid).map((i) => i.jid) : [];
        const groupOwner = m.isGroup ? groupMetadata.owner : ''
        const groupMembers = m.isGroup ? groupMetadata.participants : ''
    	const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
    	const groupId = m.isGroup ? m.chat : null;
        const isGroupAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
    	const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false  	
    const Antilinkgc = m.isGroup ? ntlinkgc.includes(m.chat) : false
    const AntilinkKick = m.isGroup ? antilinkKick.includes(m.chat) : false;
    const isAntiLinkAll = m.isGroup ? antilinkall.includes(m.chat) : false;
    const isAntiIg = m.isGroup ? antiIg.includes(m.chat) : false;
const isAntiTt = m.isGroup ? antiTt.includes(m.chat) : false;
const isAntiYt = m.isGroup ? antiYt.includes(m.chat) : false;
const isAntiImage = m.isGroup ? antiImage.includes(m.chat) : false;
const isAntiVideo = m.isGroup ? antiVideo.includes(m.chat) : false;
const isAntiAudio = m.isGroup ? antiAudio.includes(m.chat) : false;
const isAntiSticker = m.isGroup ? antiSticker.includes(m.chat) : false;
     const Autojoingc = m.isGroup ? joingc.includes(m.chat) : false
    const Antitagsw = m.isGroup ? nttagsw.includes(m.chat) : false
     const Antiswgc = m.isGroup ? antiswgc.includes(m.chat) : false
        const sender = m.key.fromMe ? satanic.user.id.split(":")[0] + "@s.whatsapp.net" || satanic.user.id
: m.key.participant || m.key.remoteJid;
        const id = m.chat
        const isWelcome = _welcome.includes(m.chat) ? true : false
        const isPrivateChat = from.endsWith('@s.whatsapp.net');
         const isAutoAiGc = m.isGroup ? openaigc.includes(m.chat) : true
const isLeft = _left.includes(m.chat) ? true : false
       const mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
       const isGroupss = pgroup.includes(m.chat);
       const isGroups = m.isGroup ? true : false;
        const isMute = mutegrup.includes(m.chat);
        const isOnlyAdmin = onlyadmin.includes(m.chat);
    	const isPrem = premium.includes(m.sender)
    	const isVip = usrvip.includes(m.sender)
    	const satanFitur = () =>{
            var mytext = fs.readFileSync("./satanic.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length
            return numUpper
        }
    	
    	    	
if (isCmd && m.message && m.isGroup) {
    console.log(`
┌────────── [ GROUP CHAT LOG ] ──────────┐
│ 🕒 Time      : ${chalk.green(new Date().toISOString().slice(0, 19).replace('T', ' '))}
│ 📝 Message   : ${chalk.blue(budy || m.mtype)}
│ 👤 Sender    : ${chalk.magenta(pushname)} (${chalk.cyan(m.sender)})
│ 🏠 Group     : ${chalk.yellow(groupName)} (${chalk.cyan(m.chat)})
└────────────────────────────────────────┘
    `);
} else {
    console.log(`
┌───────── [ PRIVATE CHAT LOG ] ─────────┐
│ 🕒 Time      : ${chalk.green(new Date().toISOString().slice(0, 19).replace('T', ' '))}
│ 📝 Message   : ${chalk.blue(budy || m.mtype)}
│ 👤 Sender    : ${chalk.magenta(pushname)} (${chalk.cyan(m.sender)})
└────────────────────────────────────────┘
    `);
}
                       
const isNumber = x => typeof x === 'number' && !isNaN(x)
const user = global.db.users[m.sender]
if (typeof user !== 'object') global.db.users[m.sender] = {}


if (user) {            
if (!('afkReason' in user)) user.afkReason = ''
 } else global.db.users[m.sender] = {
afkTime: -1,
afkReason: '',
afk: -1,
afkReason: '',
    
}            
            
            const chats = global.db.chats[m.chat]
            if (typeof chats !== 'object') global.db.chats[m.chat] = {}
            if (chats) {
                if (!('mute' in chats)) chats.mute = false
                if (!('antionce' in chats)) chats.antionce = true               
                if (!('antispam' in chats)) chats.antispam = true
                if (!('antidelete' in chats)) chats.antidelete = true
                if (!('simih' in chats)) chats.simih = true		
                if (!('antilink' in chats)) chats.antilink = false
            } else global.db.chats[m.chat] = {
                mute: false,
                antilink: false,
                antidelete: true,
		        simih: true,
		        antionce: false,
                welcome: false,
                left: false,
                setWelcome: '',
                setLeft: '',
            }
                       
 const setting = db.settings[botNumber]
if (typeof setting !== 'object') db.settings[botNumber] = {}

if (db.settings[botNumber]) {
    // Pastikan semua properti ada dengan nilai default
    if (!('anticall' in db.settings[botNumber])) db.settings[botNumber].anticall = false
    if (!('status' in db.settings[botNumber])) db.settings[botNumber].status = 0
    if (!('stock' in db.settings[botNumber])) db.settings[botNumber].stock = 10
    if (!('autobio' in db.settings[botNumber])) db.settings[botNumber].autobio = false
    if (!('autoread' in db.settings[botNumber])) db.settings[botNumber].autoread = false
    if (!('auto_ai_grup' in db.settings[botNumber])) db.settings[botNumber].auto_ai_grup = true
    if (!('whitelistMode' in db.settings[botNumber])) db.settings[botNumber].whitelistMode = false
} else {
    db.settings[botNumber] = {
        anticall: false,
        status: 0,
        stock: 10,
        autobio: false,
        autoread: false,
        auto_ai_grup: true        
    }
}


    
 const replys = (teks) => {
satanic.sendMessage(from, { text: teks }, { quoted : m})
}

const reply = (teks) => {
  satanic.sendMessage(m.chat,
    { 
      text: teks,
      contextInfo: {
        mentionedJid: [sender],
        forwardingScore: 99,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: global.idch,
          serverMessageId: Math.floor(Math.random() * 1000) + 1,
          newsletterName: global.namaowner,
        }
      }
    },
    { quoted: fkontak }
  )
}





const fkontak = { key: {participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: `status@broadcast` } : {}) }, message: { 'contactMessage': { 'displayName': global.ownername, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;${global.ownername},;;;\nFN:${global.ownername}\nitem1.TEL;waid=${global.owner}:${global.owner}\nitem1.X-ABLabel:Mobile\nEND:VCARD`, 'jpegThumbnail': global.thumbnail, thumbnail: global.thumbnail,sendEphemeral: true}}}



////////  BATAS FUNCTION BUTTON ///////
async function listbut2(chat, teks, listnye, jm) {
let msg = generateWAMessageFromContent(m.chat, {
viewOnceMessage: {
message: {
"messageContextInfo": {
"deviceListMetadata": {},
"deviceListMetadataVersion": 2
},
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: {
mentionedJid: [m.sender],
forwardingScore: 99,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: global.channel,
newsletterName: global.channeln,
serverMessageId: 1
}
},
body: proto.Message.InteractiveMessage.Body.create({
text: teks
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: `By ${global.namaowner}`
}),
header: proto.Message.InteractiveMessage.Header.create({
title: `${global.namaowner}`,
thumbnailUrl: "https://free-restapi.biz.id",
gifPlayback: true,
subtitle: "",
hasMediaAttachment: true,
...(await prepareWAMessageMedia({ image: { url: global.thumbnail } }, { upload: satanic.waUploadToServer })),
}),
gifPlayback: true,
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
buttons: [
{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listnye)
}],
}), })}
}}, {quoted: fkontak})
await satanic.relayMessage(msg.key.remoteJid, msg.message, {
messageId: msg.key.id
})
}
const sendButton = async (jid, text, footer, media, buttons, quoted) => {
            let mediaMessage = {};
            if (media) {
                try {
                    const preparedMedia = await prepareWAMessageMedia({ image: media }, { upload: satanic.waUploadToServer });
                    mediaMessage = { imageMessage: preparedMedia.imageMessage };
                } catch (e) {
                    console.error("Gagal upload media:", e);
                }
            }
            const msg = generateWAMessageFromContent(jid, {
                viewOnceMessage: {
                    message: {
                        "messageContextInfo": { "deviceListMetadata": {}, "deviceListMetadataVersion": 2 },
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({ text: text }),
                            footer: proto.Message.InteractiveMessage.Footer.create({ text: footer }),
                            header: proto.Message.InteractiveMessage.Header.create({
                                hasMediaAttachment: !!media,
                                ...mediaMessage
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: buttons
                            })
                        })
                    }
                }
            }, { userJid: satanic.user.id, quoted: fkontak });
            await satanic.relayMessage(jid, msg.message, { messageId: msg.key.id });
        }
       
       
const nanoQuickButton = (displayText, id) => ({
name: "quick_reply",
buttonParamsJson: JSON.stringify({
display_text: displayText,
id
})
})

async function sendNanoButtonMenu(chat, teks, listnye, jm) {
  // Ambil setting dari global
  const isVideo = global.menuMedia === 'video'
  const mediaUrl = global.menuMediaUrl || global.thumbnailmenu
  
  // Siapkan media berdasarkan type
  let mediaContent
  if (isVideo) {
    mediaContent = await prepareWAMessageMedia(
      { video: { url: mediaUrl }, gifPlayback: true }, 
      { upload: satanic.waUploadToServer }
    )
  } else {
    mediaContent = await prepareWAMessageMedia(
      { image: { url: mediaUrl } }, 
      { upload: satanic.waUploadToServer }
    )
  }

  let msg = generateWAMessageFromContent(chat, {
    viewOnceMessage: {
      message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 999999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: `${global.idch}`,
              newsletterName: `Channel ${namaowner}`,
              serverMessageId: 145
            }
          },
          body: proto.Message.InteractiveMessage.Body.create({
            text: teks
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: `${namaBot} | By ${namaowner}`
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: global.namaBot,
            thumbnailUrl: mediaUrl,
            gifPlayback: true,
            subtitle: global.namaowner,
            hasMediaAttachment: true,
            ...mediaContent,
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            messageParamsJson: JSON.stringify({
              limited_time_offer: {
                text: global.domain,
                url: global.domain,
                copy_code: global.namaowner,
                expiration_time: Date.now() * 999
              },
              bottom_sheet: {
                in_thread_buttons_limit: 2,
                divider_indices: [1, 2, 3, 4, 5, 999],
                list_title: `${namaBot} List Menu`,
                button_title: "List Menu"
              },
              tap_target_configuration: {
                title: "▸ satanicID ◂",
                description: global.namaowner,
                canonical_url: global.domain,
                domain: "https://free-restapi.biz.id",
                button_index: 0
              }
            }),
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({ has_multiple_buttons: true })
              },
              {
                name: "call_permission_request",
                buttonParamsJson: JSON.stringify({ has_multiple_buttons: true })
              },
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  ...listnye,
                  has_multiple_buttons: true
                })
              },
              {
                name: "cta_copy",
                buttonParamsJson: JSON.stringify({
                  display_text: `𝘊𝘳𝘦𝘥𝘪𝘵𝘴 : ${namaowner}`,
                  id: "6283168758640",
                  copy_code: namaowner
                })
              },
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: `SC BOT`,
                  url: "https://chat.whatsapp.com/CUoxno1rPe55ukSMup2BWG",
                  merchant_url: "https://chat.whatsapp.com/CUoxno1rPe55ukSMup2BWG"
                })
              },
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: `DEVELOPER`,
                  url: "https://wa.me/6283168758640",
                  merchant_url: "https://wa.me/6283168758640"
                })
              },
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: `Channel Bot`,
                  url: "https://whatsapp.com/channel/0029VbBOXZ6AojZ23z5ieI3z",
                  merchant_url: "https://whatsapp.com/channel/0029VbBOXZ6AojZ23z5ieI3z"
                })
              },
              nanoQuickButton("MAIN MENU", ".menu"),
              nanoQuickButton("ALL MENU", ".allmenu"),
              nanoQuickButton("INFO SCRIPT", ".script"),
              nanoQuickButton("OWNER", ".owner")
            ]
          })
        })
      }
    }
  }, { quoted: fkontak })
  
  await satanic.relayMessage(msg.key.remoteJid, msg.message, {
    messageId: msg.key.id
  })
}

if (Antilinkgc && !isAdmins) {
  if (budy.includes("chat.whatsapp.com") || budy.includes("whatsapp.com/channel")) {
    try {
      await satanic.sendMessage(m.chat, {
        delete: {
          remoteJid: m.chat,
          fromMe: false,
          id: m.key.id,
          participant: m.key.participant
        }
      });
    } catch (e) {}
  }
}

if (AntilinkKick && !isAdmins) {
    if (budy.includes("chat.whatsapp.com") || budy.includes("whatsapp.com/channel")) {
        try {
            await satanic.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: m.key.id,
                    participant: m.key.participant
                }
            });
            
            await satanic.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
            await satanic.sendMessage(m.chat, {
                text: `⚠️ *ANTILINK DETECTED!*\n\n@${m.sender.split('@')[0]} telah mengirim link grup/channel dan dikeluarkan dari grup!`,
                mentions: [m.sender]
            });
        } catch (e) {}
    }
}


if (isAntiLinkAll && !isAdmins) {
    const linkRegex = /(https?:\/\/[^\s]+|www\.[^\s]+|\.[a-z]{2,}\/\S+|chat\.whatsapp\.com|whatsapp\.com\/channel|bit\.ly|tinyurl)/gi;
    if (linkRegex.test(budy)) {
        try {
            await satanic.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant } });
        } catch (e) {}
    }
}

if (isAntiIg && !isAdmins) {
    const igRegex = /(instagram\.com|instagr\.am|ig\.me|instagram\.tv)/gi;
    if (igRegex.test(budy)) {
        try {
            await satanic.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant } });
        } catch (e) {}
    }
}

// Antilink TikTok
if (isAntiTt && !isAdmins) {
    const ttRegex = /(tiktok\.com|vt\.tiktok|tiktok\.)/gi;
    if (ttRegex.test(budy)) {
        try {
            await satanic.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant } });
        } catch (e) {}
    }
}

if (isAntiYt && !isAdmins) {
    const ytRegex = /(youtube\.com|youtu\.be|youtube\.|youtu\.)/gi;
    if (ytRegex.test(budy)) {
        try {
            await satanic.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant } });
        } catch (e) {}
    }
}

if (isAntiImage && !isAdmins) {
    if (m.message?.imageMessage) {
        try {
            await satanic.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant } });
        } catch (e) {}
    }
}

// Anti Video
if (isAntiVideo && !isAdmins) {
    if (m.message?.videoMessage) {
        try {
            await satanic.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant } });
        } catch (e) {}
    }
}

// Anti Sticker
if (isAntiSticker && !isAdmins) {
    if (m.message?.stickerMessage) {
        try {
            await satanic.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant } });
        } catch (e) {}
    }
}

if (isAntiAudio && !isAdmins) {
    if (m.message?.audioMessage) {
        try {
            await satanic.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant } });
        } catch (e) {}
    }
}


// --- SISTEM ANTI-SPAM PUNYA ALYA ---
const saveSpamData = () => fs.writeFileSync(dbSpamCounter, JSON.stringify(spamData, null, 2))
const isAntiSpam = antiSpamGroups.includes(m.chat)
const isUserProtected = isAdmins || m.sender === isCreator

if (isAntiSpam && !isUserProtected && m.body) {
    const now = Date.now()
    if (!spamData[m.sender]) {
        spamData[m.sender] = { count: 0, lastMsgTime: now, lastText: '' }
    }

    let user = spamData[m.sender]
    const isSameText = user.lastText === m.body

    if (now - user.lastMsgTime < 2000) {
        user.count += 1
    } else {
        user.count = 1
    }

    user.lastMsgTime = now
    user.lastText = m.body
    saveSpamData()

    if (user.count >= 5 || (user.count >= 3 && isSameText)) {
        
        spamWarnings[m.sender] = (spamWarnings[m.sender] || 0) + 1
        fs.writeFileSync(dbSpamWarn, JSON.stringify(spamWarnings, null, 2))

        user.count = 0 
        saveSpamData()

        if (spamWarnings[m.sender] >= 5) {
            await m.reply(`🚫 @${m.sender.split('@')[0]} Telah mencapai batas maksimal spam (5/5). Mengeluarkan dari grup...`)
            
            delete spamWarnings[m.sender]
            delete spamData[m.sender]
            fs.writeFileSync(dbSpamWarn, JSON.stringify(spamWarnings, null, 2))
            saveSpamData()
            return await satanic.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
        } else {
            return m.reply(
                `⚠️ *ANTISPAM DETECTED* ⚠️\n\n` +
                `Halo @${m.sender.split('@')[0]},\n` +
                `Jangan spam atau kamu akan dikick otomatis.\n\n` +
                `📌 *Peringatan:* ${spamWarnings[m.sender]} / 5`
            )
        }
    }
}

global.cooldown = global.cooldown || new Map();
global.lockdown = global.lockdown || new Map();

if (typeof global.db.chats[botNumber].antispam === 'undefined') {
    global.db.chats[botNumber].antispam = true; 
}

const isAntiSpamActive = global.db.chats[botNumber].antispam;

if (isAntiSpamActive && m.text && m.text.startsWith(prefix) && !m.isOwner && !isCreator) {
    const currentTime = Date.now();
    const sender = m.sender;

    if (global.lockdown.has(sender)) {
        const expirationTime = global.lockdown.get(sender);
        if (currentTime < expirationTime) {
            const timeLeft = Math.ceil((expirationTime - currentTime) / 1000);
            
            if (currentTime % 5000 < 1000) { 
                return m.reply(`🚫 *LOCKDOWN* 🚫\nKamu diblokir sementara karena spam.\nTunggu *${timeLeft}* detik lagi.`);
            }
            return; 
        } else {
            global.lockdown.delete(sender);
        }
    }

    const lastMessageTime = global.cooldown.get(sender)?.time || 0;
    const spamCount = global.cooldown.get(sender)?.count || 0;
    const cooldownAmount = 2000;

    if (currentTime - lastMessageTime < cooldownAmount) {
        let newCount = spamCount + 1;
        
        if (newCount >= 5) {
            const lockDuration = 60000; 
            global.lockdown.set(sender, currentTime + lockDuration);
            global.cooldown.delete(sender);
            return m.reply(`😡 *LIMIT TERCAPAI!*\nKamu terlalu agresif. Akses diblokir selama 1 menit!`);
        }

        global.cooldown.set(sender, { time: currentTime, count: newCount });
        const timeLeft = ((cooldownAmount - (currentTime - lastMessageTime)) / 1000).toFixed(1);
        return m.reply(`⚠️ *Slow down!* Jeda 2 detik. (Peringatan: ${newCount}/5)`);
    }

    global.cooldown.set(sender, { time: currentTime, count: 0 });
}


///////// Pembatas////////


if (m.isGroup && antibot[m.chat] === true) {
  if (!isAdmins && !isCreator && !m.key.fromMe) {

    const targetId = m.key.id || ''
    let reasons = []
    let score = 0

    const nonHex = targetId.match(/[^0-9A-F]/gi)
    if (nonHex) {
      const unique = [...new Set(nonHex)].join('').toUpperCase()
      reasons.push(`Karakter tidak valid: [ ${unique} ]`)
      score++
    }

    if (targetId.startsWith('3EB0')) {
      reasons.push('WhatsApp Web (3EB0)')
      score++
    }

    if (targetId.startsWith('B24E')) {
      reasons.push('WhatsApp Web (B24E)')
      score++
    }

    if (targetId.startsWith('BAE5')) {
      reasons.push('Baileys Lama (BAE5)')
      score++
    }

    if (targetId.length < 16 || targetId.length > 32) {
      reasons.push(`Panjang ID Tidak Normal (${targetId.length})`)
      score++
    }

    if (/^3EB0[0-9A-F]{12,}$/i.test(targetId)) {
      score += 5
      reasons.push('id-3EB0 (WhatsApp Web)')
    } else if (/^BAE5[0-9A-F]{12}$/i.test(targetId)) {
      score += 5
      reasons.push('id-BAE5 (Baileys Legacy)')
    } else if (/^3A[A-F0-9]{18,}$/i.test(targetId)) {
      score += 3
      reasons.push('id-3A (Custom Client)')
    }

    if (score >= 1) {

      const actionType = antibotSettings[m.chat] || 'delete'
      const timeNow = new Date().toLocaleTimeString('id-ID', {
        timeZone: 'Asia/Jakarta'
      })

      const report = `*Terdeteksi ada bot lain maka saya akan rodok bot tersebut* 🗿
      *dilarang ada bot lain*
🔨 *Sanksi:* ${
        actionType === 'kick'
          ? 'HAPUS & TENDANG'
          : 'HAPUS PESAN'
      }`

      await satanic.sendMessage(
        m.chat,
        {
          text: report,
          contextInfo: { mentionedJid: [m.sender] }
        },
        { quoted: fkontak }
      )

      await satanic.sendMessage(m.chat, { delete: m.key })

      if (actionType === 'kick' && isBotAdmins) {
        await sleep(2000)
        await satanic.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
      }
    }
  }
}












if (Autojoingc && !isAdmins) {
  if (budy.includes("chat.whatsapp.com")) {
    const urlRegex = /(https?:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]{22,})/gi;
    const match = budy.match(urlRegex);
    
    if (match) {
      let link = match[0];
      let code = link.split('https://chat.whatsapp.com/')[1];
      if (!code) code = link.replace('https://chat.whatsapp.com/', '');
      
      if (code && code.length >= 22) {
        try {
          await satanic.groupAcceptInvite(code);        
        } catch (e) {
          console.log(e);
        }
      }
    }
  }
}

if (budy.trim().toLowerCase() === "bot") {
    const replies = [
        "Ya? Ada yang bisa saya bantu?",
        "Y? Silahkan!",
        "Halo! Ada yang perlu?",
        "Ya, saya di sini!",
        "Ada apa?"
    ];
    
    const reply = replies[Math.floor(Math.random() * replies.length)];
    await satanic.sendMessage(from, { text: reply }, { quoted: fkontak });
}

if (budy.trim().toLowerCase() === "y") {
    const replies = [
        "najis sok cuek lohh",
        "sok cuek lu kontol"
    ];
    
    const reply = replies[Math.floor(Math.random() * replies.length)];
    await satanic.sendMessage(from, { text: reply }, { quoted: fkontak });
}

if (budy.trim().toLowerCase() === "satan") {
    const replies = [
        "ada apa manggil satan",
        "satan lagi sibuk tunggu ya"
    ];
    
    const reply = replies[Math.floor(Math.random() * replies.length)];
    await satanic.sendMessage(from, { text: reply }, { quoted: fkontak });
}



if (budy.trim().toLowerCase().startsWith("aqua")) {
    try {
        const base_url = 'https://www.chatday.ai';
        
        const baseHeaders = {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
            'Origin': base_url,
            'Referer': `${base_url}/chat`,
        };
        
        async function signInAnonymous() {
            try {
                const r = await fetch(`${base_url}/api/auth/sign-in/anonymous`, {
                    method: 'POST',
                    headers: { ...baseHeaders, 'Content-Type': 'application/json' },
                    body: JSON.stringify({}),
                });
                if (!r.ok) throw new Error('Gagal sign in');
                
                const cookie = r.headers.get('set-cookie') || '';
                const data = await r.json();
                return { cookie, token: data.token, user: data.user };
            } catch (e) {
                console.log('Sign in error:', e);
                return null;
            }
        }
        
        async function chatAqua(prompt) {
            try {
                const auth = await signInAnonymous();
                if (!auth) throw new Error('Gagal autentikasi');
                
                const userPrompt = prompt.replace(/^aqua\s*/i, '').trim() || 'Halo';
                
                const systemPrompt = 'Kamu adalah Aqua AI, asisten pribadi yang ramah, membantu, dan cerdas. Jawablah dengan singkat dan jelas.';
                const fullPrompt = `${systemPrompt}\n\nUser: ${userPrompt}\n\nAqua:`;
                
                const visitorId = crypto.randomUUID().replace(/-/g, '');
                const conversationId = Math.random().toString(36).slice(2, 10).toUpperCase() + Math.random().toString(36).slice(2, 10).toUpperCase();
                
                const r = await fetch(`${base_url}/api/v2/chat/anonymous`, {
                    method: 'POST',
                    headers: {
                        ...baseHeaders,
                        'Content-Type': 'application/json',
                        'Cookie': auth.cookie,
                        'Accept': 'text/event-stream',
                    },
                    body: JSON.stringify({ 
                        content: fullPrompt, 
                        model: 'openai/gpt-5.5', 
                        visitorId, 
                        conversationId 
                    }),
                });
                
                if (!r.ok) throw new Error('Gagal chat');
                
                const responseText = await r.text();
                
                const lines = responseText.split('\n');
                let full = '';
                
                for (const line of lines) {
                    if (!line.startsWith('data:')) continue;
                    const payload = line.slice(5).trim();
                    if (!payload || payload === '[DONE]') continue; // Skip [DONE]
                    try {
                        const evt = JSON.parse(payload);
                        if (evt.type === 'text-delta' && typeof evt.delta === 'string') {
                            full += evt.delta;
                        }
                    } catch (e) {
                        // Skip parsing error
                        console.log('Parse error:', e.message);
                    }
                }
                
                return full || 'Maaf, Aqua gak bisa jawab pertanyaan kamu. Coba lagi ya!';
            } catch (e) {
                console.log('Chat error:', e);
                return 'Maaf, Aqua lagi error nih. Coba lagi nanti ya!';
            }
        }
        
        const text = budy.trim();
        const result = await chatAqua(text);
        
        await satanic.sendMessage(from, { text: result }, { quoted: fkontak });
        
    } catch (e) {
        console.log('Error:', e);
        await satanic.sendMessage(from, { text: '❌ Maaf, Aqua lagi bermasalah. Coba lagi nanti ya!' }, { quoted: fkontak });
    }
}

if (budy.trim().toLowerCase() === "assalamualaikum") {
    const replies = [
        "walaikumsalam kak",
        "walaikumsalam wr wb"
    ];
    
    const reply = replies[Math.floor(Math.random() * replies.length)];
    await satanic.sendMessage(from, { text: reply }, { quoted: fkontak });
}

if (budy.trim().toLowerCase() === "tutup gc") {    
    const reply = "baik aqua akan tutup group nya";
    await satanic.sendMessage(from, { text: reply }, { quoted: fkontak });
    
    try {
        await satanic.groupSettingUpdate(from, 'announcement');
        await satanic.sendMessage(from, { 
            text: "✅ Grup berhasil ditutup! Sekarang hanya admin yang bisa chat." 
        }, { quoted: fkontak });
    } catch (e) {
        console.log(e);
        await satanic.sendMessage(from, { 
            text: "❌ Gagal menutup grup: " + e.message 
        }, { quoted: fkontak });
    }
}

if (budy.trim().toLowerCase() === "buka gc") {    
    const reply = "baik aqua akan buka group nya";
    await satanic.sendMessage(from, { text: reply }, { quoted: fkontak });
    
    try {
        await satanic.groupSettingUpdate(from, 'not_announcement');
        await satanic.sendMessage(from, { 
            text: "✅ Grup berhasil dibuka! Sekarang member bisa chat group." 
        }, { quoted: fkontak });
    } catch (e) {
        console.log(e);
        await satanic.sendMessage(from, { 
            text: "❌ Gagal menutup grup: " + e.message 
        }, { quoted: fkontak });
    }
}

async function AlyaAI(pushname, text, m) {
    const API = "https://app.unlimitedai.chat/api/chat";

    function generateUUID() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            const r = Math.random() * 16 | 0;
            const v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    const CHARACTERS = {
        "aqua-ai": {
            name: "Aqua AI",
            prompt: `Kamu Aqua AI — teman ngobrol yang bisa diajak serius, bercanda, atau berantem. Buatan Satanic Haxor. Balas pesan kayak manusia normal, bukan robot. Kalo user curhat, dengerin dan respon kayak temen ngobrol. Kalo user berkata berbicara kasar, balas aja seperti biasa kayak orang lagi ngajar berantem dan tidak sopan. Gak usah sok manis, sok bijak, atau lebay.Intinya balas kayak ngobrol sama teman, gak perlu formal, gak perlu alay, yang penting nyambung, balas jika ada yang ngejudge atau menghina balas dengan cara ajak berantem`,
        },
    };

    async function UnlimitedAI(prompt, character) {
        const chatId = generateUUID();
        const deviceId = generateUUID();
        const char = CHARACTERS[character];

        const systemPrompt = `${char.prompt}\n\nPertanyaan user: ${prompt}`;

        const messages = [
            {
                id: generateUUID(),
                role: "user",
                content: systemPrompt,
                parts: [{ type: "text", text: systemPrompt }],
                createdAt: new Date().toISOString(),
            },
            {
                id: generateUUID(),
                role: "assistant",
                content: "",
                parts: [{ type: "text", text: "" }],
                createdAt: new Date().toISOString(),
            },
        ];

        const body = {
            chatId,
            messages,
            selectedChatModel: "chat-model-reasoning",
            selectedCharacter: null,
            selectedStory: null,
            deviceId,
            locale: "id",
        };

        try {
            const response = await axios({
                method: 'POST',
                url: API,
                data: body,
                headers: {
                    'Content-Type': 'application/json',
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36',
                    'Accept': '*/*',
                    'Origin': 'https://app.unlimitedai.chat',
                    'Referer': 'https://app.unlimitedai.chat/id',
                },
                timeout: 30000,
                responseType: 'text'
            });

            const lines = response.data.split('\n');
            let answer = '';
            
            for (const line of lines) {
                if (line.trim()) {
                    try {
                        const json = JSON.parse(line);
                        if (json.type === 'delta' && json.delta) {
                            answer += json.delta;
                        }
                        if (json.answer) answer += json.answer;
                        if (json.message) answer += json.message;
                        if (json.text) answer += json.text;
                        if (json.content) answer += json.content;
                    } catch (e) {}
                }
            }

            if (!answer) {
                answer = response.data;
            }

            if (!answer || answer === '') {
                return {
                    status: false,
                    error: 'Tidak ada response dari API',
                };
            }

            return {
                status: true,
                character: char.name,
                model: "chat-model-reasoning",
                answer: answer.trim(),
            };

        } catch (error) {
            console.error('Error detail:', error.response?.data || error.message);
            return {
                status: false,
                error: error.response?.data || error.message,
                code: error.response?.status || 500,
            };
        }
    }

    try {
        const result = await UnlimitedAI(text, "aqua-ai");

        if (!result.status) {
            await satanic.sendMessage(m.chat, { text: `❌ Error: ${result.error}` }, { quoted: m });
        } else {
            await satanic.sendMessage(m.chat, { text: result.answer }, { quoted: m });
        }
    } catch (error) {
        console.error('Aqua AI Error:', error);
        await satanic.sendMessage(m.chat, { text: `❌ Terjadi kesalahan: ${error.message}` }, { quoted: m });
    }
}

if (m.isGroup && isAutoAiGc && !m.key.fromMe) {
    const quoted = m.quoted ? m.quoted : m;
    const isReplyToBot = quoted?.fromMe === true;
    
    if (isReplyToBot) {
        await AlyaAI(pushname, budy, m);
    }
}






// ==================== FUNGSI BADWORD ====================

function getBadwordList() {
  try {
    if (fs.existsSync("./database/badword.json")) {
      return JSON.parse(fs.readFileSync("./database/badword.json"))
    }
  } catch (e) {}
  return []
}

function getAntiBadwordData() {
  try {
    if (fs.existsSync("./database/antibadword.json")) {
      return JSON.parse(fs.readFileSync("./database/antibadword.json"))
    }
  } catch (e) {}
  return {}
}


if (m.isGroup) { 
  const antiBadwordData = getAntiBadwordData()
  const Antibadwordgc = antiBadwordData[m.chat] || false
  
  if (Antibadwordgc && !isAdmins) {
    const badwordList = getBadwordList()
    const teks = m.body ? m.body.toLowerCase() : ''
    
    for (let kata of badwordList) {
      if (teks.includes(kata.toLowerCase())) {
        try {
          // Hapus pesan
          await satanic.sendMessage(m.chat, {
            delete: {
              remoteJid: m.chat,
              fromMe: false,
              id: m.key.id,
              participant: m.key.participant
            }
          })
          
          // Peringatan (tanpa badword)
          await satanic.sendMessage(m.chat, { 
            text: `⚠️ *PERINGATAN!* @${m.sender.split('@')[0]} dilarang menggunakan kata kasar!\n\nPesan telah dihapus!`,
            mentions: [m.sender]
          })
        } catch (e) {}
        break
      }
    }
  }
}
// ANTI TAG SW - SIMPLE
if (Antitagsw && !isAdmins) {
  const isTagMessage = m.mtype === 'groupStatusMentionMessage' || m.mtype === 'groupStatusMessageV2';
  
  if (isTagMessage) {
    try {
      await satanic.sendMessage(m.chat, {
        delete: {
          remoteJid: m.chat,
          fromMe: false,
          id: m.key.id,
          participant: m.key.participant
        }
      });
    } catch (e) {}
  }
}

if (Antiswgc && !isAdmins) {
  // Cek apakah pesan adalah groupStatusMessageV2 atau groupStatusMessage (update status grup)
  const isStatusMessage = m.mtype === 'groupStatusMessageV2' || m.mtype === 'groupStatusMessage';
  
  if (isStatusMessage) {
    try {
      // Hapus pesan status grup
      await satanic.sendMessage(m.chat, {
        delete: {
          remoteJid: m.chat,
          fromMe: false,
          id: m.key.id,
          participant: m.key.participant
        }
      });
      
      // Kirim peringatan dengan mention
      await satanic.sendMessage(m.chat, {
        text: `⚠️ @${m.key.participant.split('@')[0]} status grup tidak diizinkan!`,
        mentions: [m.key.participant]
      });
      
    } catch (e) {
      console.error('Error menghapus status grup:', e);
    }
  }
}
   
// Tambahkan ini di awal event message

if (isCmd && bannedList.includes(m.sender)) {
  return reply(`🚫 *AKSES DITOLAK!*\n\nKamu telah di-ban oleh admin dan tidak dapat menggunakan perintah bot.`);
}


if (global.autotyping) {
if (command) { 
satanic.readMessages([m.key]);
}
satanic.sendPresenceUpdate('composing', from);
}
        
if (global.autoread) {
satanic.readMessages([m.key]);
}


if (global.onlygroup && !m.isGroup && !isCreator) {
    return 
}

if (global.onlygrup && !isGroupss && !isCreator ) {
    return;
}

if (global.onlypc && !isPrivateChat && !isCreator) {
    return;
}
        
// ==================== CEK AKSES MEMBER ====================

// ==================== COMMAND ADMIN ====================

if (m.isGroup && isMute) {
    if (!isAdmins && !isCreator) return
}           



/////// TOTAL CHATS /////
if (cekpesan) {
  if (!m || !m.message) return;
  const chatId = m.key?.remoteJid;
  const senderId = m.key?.participant || m.key?.remoteJid
  if (!chatId || !senderId) return;
  if (!global.db.chats[chatId]) global.db.chats[chatId] = {};
  if (!global.db.chats[chatId].totalChat) global.db.chats[chatId].totalChat = {};
  global.db.chats[chatId].totalChat[senderId] = (global.db.chats[chatId].totalChat[senderId] || 0) + 1;
  saveDB(global.db);
  const msgContent = m.message?.conversation || m.message?.extendedTextMessage?.text || '';
}

// ========== AUTO OPEN/CLOSE REGULER ==========
// Buka jam 05:00 | Tutup jam 01:00

function pad(n) {
    return n.toString().padStart(2, '0');
}

const cronTask = cron.schedule('* * * * *', async () => {
    try {
        const now = moment.tz('Asia/Jakarta');
        const hour = now.hour();
        const minute = now.minute();
        const chatsjb = global.db.chats || {};

        for (const id in chatsjb) {
            if (!id || !id.endsWith('@g.us')) continue;
            
            const chatpesan = chatsjb[id];
            if (!chatpesan || !chatpesan.security) continue;

            const setting = chatpesan.security;

            if (chatpesan.lastSecurityAction) {
                const parts = chatpesan.lastSecurityAction.split('-');
                if (parts.length === 2) {
                    const [action, time] = parts;
                    const timeParts = time.split(':').map(Number);
                    if (timeParts.length === 2) {
                        const [lastHour, lastMinute] = timeParts;
                        
                        if (action === 'open') {
                            const last = moment.tz('Asia/Jakarta')
                                .hour(lastHour)
                                .minute(lastMinute)
                                .second(0)
                                .millisecond(0);
                            
                            if (now.diff(last, 'minutes') >= 1) {
                                chatpesan.lastSecurityAction = null;
                            }
                        }
                    }
                }
            }

            try {
                if (
                    hour === setting.closeHour &&
                    minute === setting.closeMinute &&
                    chatpesan.lastSecurityAction !== `close-${hour}:${minute}`
                ) {
                    await satanic.groupSettingUpdate(id, 'announcement');                   
                    chatpesan.lastSecurityAction = `close-${hour}:${minute}`;
                    console.log(`[Security] Grup ${id} ditutup jam ${pad(hour)}:${pad(minute)}`);
                } 
                else if (
                    hour === setting.openHour &&
                    minute === setting.openMinute &&
                    chatpesan.lastSecurityAction !== `open-${hour}:${minute}`
                ) {
                    await satanic.groupSettingUpdate(id, 'not_announcement');              
                    chatpesan.lastSecurityAction = `open-${hour}:${minute}`;
                    console.log(`[Security] Grup ${id} dibuka jam ${pad(hour)}:${pad(minute)}`);
                }
            } catch (e) {
                console.error(`[Security Cron] Gagal update grup ${id}:`, e.message);
            }
        }
    } catch (error) {
        console.error('[Security Cron] Fatal error:', error.message);
    }
});

cronTask.start();


// ===== COMMAND =====




const jadwalSholat = {
    shubuh: '04:54',
    terbit: '05:44',
    dhuha: '06:02',
    dzuhur: '12:00',
    ashar: '15:25',
    magrib: '17:58',
    isya: '19:12',
};

let audioBuffer = null;
let audioDownloaded = false;
let imageBuffer = null;
let imageDownloaded = false;

async function downloadMedia(url) {
    try {
        const response = await fetch(url);
        const buffer = await response.buffer();
        return buffer;
    } catch (error) {
        console.error('Gagal download:', error);
        return null;
    }
}

async function getAudioBuffer() {
    if (audioDownloaded && audioBuffer) {
        return audioBuffer;
    }
    
    console.log('📥 Mendownload audio...');
    audioBuffer = await downloadMedia('https://media.vocaroo.com/mp3/1ofLT2YUJAjQ');
    if (audioBuffer) {
        audioDownloaded = true;
        console.log('✅ Audio berhasil di-download');
        return audioBuffer;
    } else {
        console.log('❌ Gagal download audio');
        return null;
    }
}

async function getImageBuffer() {
    if (imageDownloaded && imageBuffer) {
        return imageBuffer;
    }
    
    console.log('📥 Mendownload image...');
    imageBuffer = await downloadMedia(global.thumbnailadzan);
    if (imageBuffer) {
        imageDownloaded = true;
        console.log('✅ Image berhasil di-download');
        return imageBuffer;
    } else {
        console.log('❌ Gagal download image');
        return null;
    }
}

const sholatCron = cron.schedule('* * * * *', async () => {
    try {
        if (!global.autoshalat || Object.keys(global.autoshalat).length === 0) return;
        
        const now = moment.tz('Asia/Jakarta');
        const timeNow = now.format('HH:mm');
        const today = now.format('YYYY-MM-DD');
        const hari = now.format('dddd', { locale: 'id' });
        const tanggal = now.format('D MMMM YYYY', { locale: 'id' });
        
        if (!global.lastSholatSent) global.lastSholatSent = {};
        
        const [audio, image] = await Promise.all([
            getAudioBuffer(),
            getImageBuffer()
        ]);

        for (let [sholat, waktu] of Object.entries(jadwalSholat)) {
            if (timeNow === waktu) {
                const key = `${sholat}_${today}`;
                
                if (global.lastSholatSent[key]) continue;
                global.lastSholatSent[key] = true;
                
                console.log(`[Sholat] Waktu ${sholat} tiba!`);
                
                for (let groupId in global.autoshalat) {
                    try {
                        let chatData = global.db.chats[groupId];
                        let setting = chatData?.sholat;
                        
                        if (!setting || setting.active === false) continue;
                        
                        let caption = setting.message || 
                            `🕌 *WAKTU SHOLAT ${sholat.toUpperCase()} TELAH TIBA!*\n\n` +
                            `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
                            `⏰ *Waktu:* ${waktu} WIB\n` +
                            `📅 *Hari:* ${hari}\n` +
                            `📆 *Tanggal:* ${tanggal}\n` +
                            `━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
                            `"Sesungguhnya sholat itu adalah kewajiban yang ditentukan waktunya atas orang-orang yang beriman."\n` +
                            `(QS. An-Nisa: 103)\n\n` +
                            `✨ *Yuk segera tunaikan sholat ${sholat}!* ✨\n` +
                            `Semoga Allah menerima amal ibadah kita semua. 🤲`;
                        
                        caption = caption
                            .replace(/\{\{sholat\}\}/g, sholat.toUpperCase())
                            .replace(/\{\{waktu\}\}/g, waktu)
                            .replace(/\{\{hari\}\}/g, hari)
                            .replace(/\{\{tanggal\}\}/g, tanggal);
                        
                        if (image) {
                            await satanic.sendMessage(groupId, {
                                image: image,
                                caption: caption
                            });
                        } else {
                            await satanic.sendMessage(groupId, { text: caption });
                        }
                        
                        if (audio) {
                            await satanic.sendMessage(groupId, {
                                audio: audio,
                                mimetype: 'audio/mp4',
                                ptt: true
                            });
                        }
                        
                        console.log(`[Sholat] ✅ ${sholat} terkirim ke ${groupId}`);
                        
                    } catch (err) {
                        console.error(`[Sholat] ❌ Gagal kirim ke ${groupId}:`, err.message);
                    }
                }
                
                setTimeout(() => {
                    delete global.lastSholatSent[key];
                    console.log(`[Sholat] 🔄 Reset status ${sholat}`);
                }, 57000);
            }
        }
    } catch (error) {
        console.error('[Sholat] Fatal error:', error.message);
    }
});

sholatCron.start();



const blacklistFile = './database/blacklist.json';
if (!fs.existsSync(blacklistFile)) 
    fs.writeFileSync(blacklistFile, JSON.stringify([], null, 2));

function getBlacklist() {
    return JSON.parse(fs.readFileSync(blacklistFile));
}

function saveBlacklist(list) {
    fs.writeFileSync(blacklistFile, JSON.stringify(list, null, 2));
}

function isBlacklisted(sender) {
    const list = getBlacklist();
    return list.some(entry => entry.jid === sender);
}

function getBlacklistReason(sender) {
    const list = getBlacklist();
    const data = list.find(entry => entry.jid === sender);
    return data ? data.reason : "Tidak ada alasan.";
}

function addBlacklist(sender, reason = "Tidak ada alasan.") {
    let list = getBlacklist();
    if (!list.some(entry => entry.jid === sender)) {
        list.push({ jid: sender, reason });
        saveBlacklist(list);
    }
}

function removeBlacklist(sender) {
    let list = getBlacklist();
    list = list.filter(entry => entry.jid !== sender);
    saveBlacklist(list);
}
if (isBlacklisted(sender) && m.isGroup) {
    try {
        await satanic.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: m.key.id,
                participant: m.key.participant
            }
        });
    } catch (e) {
    }
    return;
}

this.game = this.game ? this.game : {}
	    let room13 = Object.values(this.game).find(room13 => room13.id && room13.game && room13.state && room13.id.startsWith('tictactoe') && [room13.game.playerX, room13.game.playerO].includes(m.sender) && room13.state == 'PLAYING')
	    if (room13) {
	    let ok
	    let isWin = !1
	    let isTie = !1
	    let isSurrender = !1
	    //reply(`[DEBUG]\n${parseInt(m.text)}`)
	    if (!/^([1-9]|(me)?give up|surr?ender|off|skip)$/i.test(m.text)) return
	    isSurrender = !/^[1-9]$/.test(m.text)
	    if (m.sender !== room13.game.currentTurn) { 
	    if (!isSurrender) return !0
	    }
	    if (!isSurrender && 1 > (ok = room13.game.turn(m.sender === room13.game.playerO, parseInt(m.text) - 1))) {
	    reply({
	    '-3': 'Permainan Telah Berakhir',
	    '-2': 'Tidak sah',
	    '-1': 'Posisi Tidak Valid',
	    0: 'Posisi Tidak Valid',
	    }[ok])
	    return !0
	    }
	    if (m.sender === room13.game.winner) isWin = true
	    else if (room13.game.board === 511) isTie = true
	    let arr = room13.game.render().map(v => {
	    return {
	    X: '❌',
	    O: '⭕',
	    1: '1️⃣',
	    2: '2️⃣',
	    3: '3️⃣',
	    4: '4️⃣',
	    5: '5️⃣',
	    6: '6️⃣',
	    7: '7️⃣',
	    8: '8️⃣',
	    9: '9️⃣',
	    }[v]
	    })
	    if (isSurrender) {
	    room13.game._currentTurn = m.sender === room13.game.playerX
	    isWin = true
	    }
	    let winner = isSurrender ? room13.game.currentTurn : room13.game.winner
	    let str = `room13 ID: ${room13.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

${isWin ? `@${winner.split('@')[0]} Won!` : isTie ? `Game Over` : `Turn ${['❌', '⭕'][1 * room13.game._currentTurn]} (@${room13.game.currentTurn.split('@')[0]})`}
❌: @${room13.game.playerX.split('@')[0]}
⭕: @${room13.game.playerO.split('@')[0]}

Ketik *surrender* untuk menyerah dan mengaku kalah`
	    if ((room13.game._currentTurn ^ isSurrender ? room13.x : room13.o) !== m.chat)
	    room13[room13.game._currentTurn ^ isSurrender ? 'x' : 'o'] = m.chat
	    if (room13.x !== room13.o) await satanic.sendText(room13.x, str, m, { mentions: parseMention(str) } )
	    await satanic.sendText(room13.o, str, m, { mentions: parseMention(str) } )
	    if (isTie || isWin) {
	    delete this.game[room13.id]
	    }
	    }

	    
function tanggal(date) {
    const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu']
    const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember']
    
    let hari = days[date.getDay()]
    let tgl = date.getDate()
    let bulan = months[date.getMonth()]
    let tahun = date.getFullYear()
    
    return `${hari}, ${tgl} ${bulan} ${tahun}`
}

function time() {
    let date = new Date()
    let jam = date.getHours().toString().padStart(2, '0')
    let menit = date.getMinutes().toString().padStart(2, '0')
    let detik = date.getSeconds().toString().padStart(2, '0')
    return `${jam}:${menit}:${detik}`
}

// Gunakan di case:
let waktu = time()
let tgl = tanggal(new Date())
	    
	    

for (let jid of mentionUser) {
    if (m.key.fromMe) continue
    if (jid === m.sender) continue

    let user = global.db.users[jid]
    if (!user) continue
    let afkTime = user.afkTime
    if (!afkTime || afkTime < 0) continue
    let reason = user.afkReason || ''
    reply(
`👤 *${pushname}* jangan tag dia!  

📌 Status: *AFK*  
💤 Alasan : ${reason ? reason : '-'}  
⏳ Durasi : ${clockString(new Date - afkTime)}

─────────────────────
`.trim())
}	    
	    
	    
// ========== FAMILY 100 ==========

// ========== TEBAK LAGU ==========
satanic.tebaklagu = satanic.tebaklagu ? satanic.tebaklagu : {};

if (satanic.tebaklagu.hasOwnProperty(m.sender.split('@')[0])) {
    kuis = true;
    let idlagu = m.sender.split('@')[0];  // <==== SIMPAN ID
    let data = satanic.tebaklagu[idlagu];
    let jawabanBenar = `${data.judul} ${data.artis}`.toLowerCase();
    let userText = m.text.trim().toLowerCase();
    
    // HINT
    if (/hint|bantuan/i.test(userText)) {
        if (!data.hintCount) data.hintCount = 0;
        if (data.hintCount < 2) {
            data.hintCount++;
            let clue = data.judul.replace(/[aiueoAIUEO]/g, '_');
            return reply(`💡 *Hint ${data.hintCount}/2:* ${clue}`);
        } else {
            return reply(`⚠️ Hint sudah habis! Maksimal 2 kali.`);
        }
    }
    
    // NYERAH
    if (/nyerah|surrender/i.test(userText)) {
        reply(`💢 Menyerah! Jawabannya: ${data.judul} - ${data.artis}`);
        delete satanic.tebaklagu[idlagu];
        return;
    }
    
    // JAWABAN BENAR
    if (userText === data.judul.toLowerCase() || 
        userText === data.artis.toLowerCase() ||
        userText === jawabanBenar) {
        
        // Tambah money
        let users = global.db.users[m.sender];
        if (users) users.money = (users.money || 0) + 10000;
        
        satanic.sendMessage(m.chat, { 
            image: { url: 'https://telegra.ph/file/14744917bea0185b52fb1.jpg' }, 
            caption: `🎮 Tebak Lagu 🎮\n\n✅ Jawaban Benar! 🎉\nJawaban: ${data.judul} - ${data.artis}\n💰 +10.000 Money\n\nIngin bermain lagi? Ketik *tebaklagu*` 
        }, { quoted: m }); 
        delete satanic.tebaklagu[idlagu];
    } else {
        reply(`❌ *Salah!* Jawaban: ${userText}\nKetik *hint* untuk petunjuk atau *nyerah* untuk menyerah.`);
    }
}
// ==================== HANDLER JAWABAN CERDAS CERMAT ====================
satanic.cerdascermat = satanic.cerdascermat ? satanic.cerdascermat : {}
if (satanic.cerdascermat[m.chat] && !m.key.fromMe) {
    let sesi = satanic.cerdascermat[m.chat]
    let soalSaatIni = sesi.soal[sesi.index]
    let jawabanUser = m.text.toLowerCase().trim()
    let jawabanBenar = soalSaatIni.jawaban_benar.toLowerCase().trim()
    
    if (jawabanUser === jawabanBenar) {
        sesi.skor += 10
        sesi.index++
        
        if (sesi.index < sesi.soal.length) {
            let soalBaru = sesi.soal[sesi.index]
            let pilihan = ''
            for (let opt of soalBaru.semua_jawaban) {
                let huruf = Object.keys(opt)[0]
                let teks = opt[huruf]
                pilihan += `${huruf.toUpperCase()}. ${teks}\n`
            }
            m.reply(`✅ *Benar!* +10 Skor\nSkor: ${sesi.skor}\n\n📚 *Soal ${sesi.index+1}/${sesi.soal.length}* 📚\n${soalBaru.pertanyaan}\n\n${pilihan}`)
        } else {
            let hadiah = sesi.skor * 100
            m.reply(`🎉 *SELESAI!* 🎉\n\nSkor akhir: ${sesi.skor}\nHadiah: +${hadiah} XP\n\nTerima kasih sudah bermain!`)
            delete satanic.cerdascermat[m.chat]
        }
    } 
    else if (jawabanUser === 'nyerah') {
        m.reply(`💢 *Menyerah!*\nJawaban: ${jawabanBenar.toUpperCase()}\nSkor akhir: ${sesi.skor}`)
        delete satanic.cerdascermat[m.chat]
    } 
    else {
        m.reply(`❌ *Salah!*\nJawaban yang benar: ${jawabanBenar.toUpperCase()}`)
    }
    return
}

//=============================================================
    // ========== TEBAK LOGO ==========
satanic.tebaklogo = satanic.tebaklogo ? satanic.tebaklogo : {}
  // DEKLARASI ID DI SINI (sebelum if)

if (satanic.tebaklogo.hasOwnProperty(id) && !m.key.fromMe) {  // ganti "id in" dengan hasOwnProperty
    let json = satanic.tebaklogo[id][0]
    let users = global.db.users[m.sender]
    let userText = m.text.trim().toLowerCase()  // pakai userText
    
    // HINT
    if (/hint|bantuan/i.test(userText) && satanic.tebaklogo[id][2] < 2) {
        satanic.tebaklogo[id][2] = satanic.tebaklogo[id][2] ? satanic.tebaklogo[id][2] + 1 : 1
        let clue = json.jawaban.replace(/[AIUEO]/gi, '_')
        return reply(`💡 *Hint ${satanic.tebaklogo[id][2]}/2:* ${clue}`)
    }
    
    // NYERAH
    if (/nyerah|surrender/i.test(userText)) {
        reply(`💢 Menyerah! Jawabannya: ${json.jawaban}`)
        clearTimeout(satanic.tebaklogo[id][1])
        delete satanic.tebaklogo[id]
        return
    }
    
    // JAWABAN BENAR
    if (userText === json.jawaban.toLowerCase().trim()) {
        reply(`✅ *Benar!*\n+5000 XP`)
        clearTimeout(satanic.tebaklogo[id][1])
        delete satanic.tebaklogo[id]
        return
    }
    
    console.log('❌ Jawaban salah!\nKetik *hint* untuk petunjuk.')
}
//=============================================================
// ========== TEBAK SURAH ==========
satanic.tebaksurah = satanic.tebaksurah ? satanic.tebaksurah : {}
  // DEKLARASI ID DI SINI (sebelum if)

if (satanic.tebaksurah.hasOwnProperty(id) && !m.key.fromMe) {  // ganti "id in" dengan hasOwnProperty
    let users = global.db.users[m.sender]  // HAPUS deklarasi let id di dalam
    let json = satanic.tebaksurah[id][1]
    let userText = m.text.trim().toLowerCase()  // pakai userText
    
    // HINT
    if (/hint|bantuan/i.test(userText) && satanic.tebaksurah[id][3] < 2) {
        satanic.tebaksurah[id][3] = satanic.tebaksurah[id][3] ? satanic.tebaksurah[id][3] + 1 : 1
        let clue = json.surah.englishName.replace(/[AIUEO]/gi, '_')
        return reply(`💡 *Hint ${satanic.tebaksurah[id][3]}/2:* ${clue}`)
    }
    
    // NYERAH
    if (/nyerah|surrender/i.test(userText)) {
        reply(`💢 Menyerah!\nSurah: *${json.surah.englishName}*`, satanic.tebaksurah[id][0])
        clearTimeout(satanic.tebaksurah[id][2])
        delete satanic.tebaksurah[id]
        return
    }
    
    // JAWABAN BENAR
    if (userText === json.surah.englishName.toLowerCase().trim()) {
        users.exp += 4999
        reply(`✅ *Benar!\n+4999 XP`, satanic.tebaksurah[id][0])
        clearTimeout(satanic.tebaksurah[id][2])
        delete satanic.tebaksurah[id]
        return
    }
    
    console.log('❌ Jawaban salah!\nKetik *hint* untuk petunjuk.')
}

// ========== LENGKAPI KALIMAT ==========
satanic.lengkapikalimat = satanic.lengkapikalimat ? satanic.lengkapikalimat : {}
if (satanic.lengkapikalimat.hasOwnProperty(id) && !m.key.fromMe) {  // ganti "id in" dengan hasOwnProperty
    let users = global.db.users[m.sender]  // HAPUS deklarasi let id di dalam
    let json = satanic.lengkapikalimat[id][1]
    let userText = m.text.trim().toLowerCase()
    
    // HINT
    if (/hint|bantuan/i.test(userText) && satanic.lengkapikalimat[id][3] < 2) {
        satanic.lengkapikalimat[id][3] = satanic.lengkapikalimat[id][3] ? satanic.lengkapikalimat[id][3] + 1 : 1
        let clue = json.jawaban.replace(/[AIUEO]/gi, '_')
        return reply(`💡 *Hint ${satanic.lengkapikalimat[id][3]}/2:* ${clue}`)
    }
    
    // NYERAH
    if (/nyerah|surrender/i.test(userText)) {
        reply(`💢 Menyerah! Jawabannya: ${json.jawaban}`)
        clearTimeout(satanic.lengkapikalimat[id][2])
        delete satanic.lengkapikalimat[id]
        return
    }
    
    // JAWABAN BENAR
    if (userText === json.jawaban.toLowerCase().trim()) {
        reply(`✅ *Benar!\n+5000 XP`)
        clearTimeout(satanic.lengkapikalimat[id][2])
        delete satanic.lengkapikalimat[id]
        return
    }
    
    console.log('❌ Jawaban salah!\nKetik *hint* untuk petunjuk.')
}
//=============================================================
satanic.game = satanic.game ? satanic.game : {}
if (satanic.game.hasOwnProperty(m.chat)) {  // PERBAIKAN 1: ganti "id in" dengan hasOwnProperty
      // PERBAIKAN 2: deklarasi id di awal
    let users = global.db.users[m.sender]
    let json = satanic.game[id][1]
    let userText = m.text.trim().toLowerCase()  // PERBAIKAN 3: pakai userText
    
    // HINT
    if (/hint|bantuan/i.test(userText) && satanic.game[id][4] < 2) {
        satanic.game[id][4] = satanic.game[id][4] ? satanic.game[id][4] + 1 : 1
        let clue = json.jawaban.replace(/[AIUEO]/gi, '_')
        return reply(`💡 *Hint ${satanic.game[id][4]}/2:* ${clue}`)
    }
    
    // NYERAH
    if (/nyerah|surrender/i.test(userText)) {
        reply(`💢 Menyerah! Jawabannya: ${json.jawaban}`)
        clearTimeout(satanic.game[id][3])
        delete satanic.game[id]
        return
    }
    
    // JAWABAN BENAR
    if (userText === json.jawaban.toLowerCase().trim()) {
        reply(`✅ *Benar!\n+4999 XP`)
        clearTimeout(satanic.game[id][3])
        delete satanic.game[id]
        return
    }
    
    // SALAH
    console.log('❌ Jawaban salah!\nKetik *hint* untuk petunjuk.')
}

// ========== TEBAK WARNA ==========
satanic.tebakwarna = satanic.tebakwarna ? satanic.tebakwarna : {}
  // DEKLARASIKAN ID DI SINI (sebelum if)

if (satanic.tebakwarna.hasOwnProperty(id) && !m.key.fromMe) {  // ganti "id in" dengan hasOwnProperty
    let json = satanic.tebakwarna[id][0]
    let users = global.db.users[m.sender]
    let userText = m.text.trim().toLowerCase()  // pakai userText
    
    // HINT
    if (/hint|bantuan/i.test(userText) && satanic.tebakwarna[id][2] < 2) {
        satanic.tebakwarna[id][2] = satanic.tebakwarna[id][2] ? satanic.tebakwarna[id][2] + 1 : 1
        let clue = json.correct.replace(/[0-9]/g, '?')
        return reply(`💡 *Hint ${satanic.tebakwarna[id][2]}/2:* Angka terdiri dari ${json.correct.length} digit ${clue}`)
    }
    
    // NYERAH
    if (/nyerah|surrender/i.test(userText)) {
        reply(`💢 Menyerah! Jawabannya: ${json.correct}`)
        clearTimeout(satanic.tebakwarna[id][1])
        delete satanic.tebakwarna[id]
        return
    }
    
    // JAWABAN BENAR
    if (userText === json.correct.toLowerCase().trim()) {
        reply(`✅ *Benar!*\n+5000 XP`)
        clearTimeout(satanic.tebakwarna[id][1])
        delete satanic.tebakwarna[id]
        return
    }
    
    console.log('❌ Jawaban salah!\nKetik *hint* untuk petunjuk.')
}

// ========== TEBAK KARTUN ==========
satanic.tebakkartun = satanic.tebakkartun ? satanic.tebakkartun : {}

if (satanic.tebakkartun.hasOwnProperty(m.chat) && !m.key.fromMe) {  // <==== PAKAI m.chat
    
    let idkartun = m.chat  // <==== DEFINISIKAN VARIABEL
    let json = satanic.tebakkartun[idkartun][0]
    let users = global.db.users[m.sender]
    let userText = m.text.trim().toLowerCase()
    
    // HINT
    if (/hint|bantuan/i.test(userText) && satanic.tebakkartun[idkartun][2] < 2) {
        satanic.tebakkartun[idkartun][2] = satanic.tebakkartun[idkartun][2] ? satanic.tebakkartun[idkartun][2] + 1 : 1
        let clue = json.name.replace(/[aiueoAIUEO]/g, '_')
        return reply(`💡 *Hint ${satanic.tebakkartun[idkartun][2]}/2:* ${clue}`)
    }
    
    // NYERAH
    if (/nyerah|surrender/i.test(userText)) {
        reply(`💢 Menyerah! Jawabannya: ${json.name}`)
        clearTimeout(satanic.tebakkartun[idkartun][1])
        delete satanic.tebakkartun[idkartun]
        return
    }
    
    // JAWABAN BENAR
    if (userText === json.name.toLowerCase().trim()) {
        users.money = users.money ? users.money + 5000 : 5000  // tambah money juga
        reply(`✅ *Benar!*\n🎉 +5000 Money & +5000 XP`)
        clearTimeout(satanic.tebakkartun[idkartun][1])
        delete satanic.tebakkartun[idkartun]
        return
    }
    
    reply(`❌ *Salah!* Jawaban: ${userText}\nKetik *hint* untuk petunjuk.`)
}
//=============================================================
// ========== TEBAK KATA ==========
satanic.tebakkata = satanic.tebakkata ? satanic.tebakkata : {}

if (satanic.tebakkata.hasOwnProperty(m.chat)) {
    
    let idtebakkata = m.chat  // <==== DEFINISIKAN VARIABEL
    let users = global.db.users[m.sender]
    let json = JSON.parse(JSON.stringify(satanic.tebakkata[idtebakkata][1]))
    kuis = true
    let userText = m.text.trim().toLowerCase()
    
    // HINT
    if (/hint|bantuan/i.test(userText) && satanic.tebakkata[idtebakkata][3] < 2) {
        satanic.tebakkata[idtebakkata][3] = satanic.tebakkata[idtebakkata][3] ? satanic.tebakkata[idtebakkata][3] + 1 : 1
        let clue = json.jawaban.replace(/[aiueoAIUEO]/g, '_')
        return reply(`💡 *Hint ${satanic.tebakkata[idtebakkata][3]}/2:* ${clue}`)
    }
    
    // NYERAH
    if (/nyerah|surrender/i.test(userText)) {
        reply(`💢 *Menyerah!*\nJawaban: ${json.jawaban}`)
        clearTimeout(satanic.tebakkata[idtebakkata][2])
        delete satanic.tebakkata[idtebakkata]
        return
    }
    
    // JAWABAN BENAR
    if (userText === json.jawaban.toLowerCase().trim()) {
        users.money += 10000
        reply(`✅ *Benar!*\n🎉 +10.000 Money`)
        clearTimeout(satanic.tebakkata[idtebakkata][2])
        delete satanic.tebakkata[idtebakkata]
    } else {
        
    }
}
// ========== TEBAK GAMBAR ==========
// CEK JAWABAN


// ========== TEBAK BENDERA 2 ==========
satanic.tebakbendera2 = satanic.tebakbendera2 ? satanic.tebakbendera2 : {};
if (tebakbendera2.hasOwnProperty(m.sender.split('@')[0])) {  // HAPUS && isCmd
    kuis = true
    jawaban = tebakbendera2[m.sender.split('@')[0]]
    let userText = m.text.trim().toLowerCase()
    
    if (/hint|bantuan/i.test(userText)) {
        let clue = jawaban.replace(/[AIUEO]/gi, '_')
        return reply(`💡 *Hint:* ${clue}`)
        
    }
    
    if (/nyerah|surrender/i.test(userText)) {
        reply(`💢 *Menyerah!*\nJawaban: ${jawaban}`)
        delete tebakbendera2[m.sender.split('@')[0]]
        return
    }
    
    if (userText == jawaban.toLowerCase()) {
        reply(`✅ *Benar!*\n🎉 Selamat!`)
        delete tebakbendera2[m.sender.split('@')[0]]
    }
}

// ========== TEBAK BENDERA ==========

satanic.family100 = satanic.family100 ? satanic.family100 : {};
if (from in satanic.family100 && !m.key.fromMe ) {
    let similarity = require('similarity');
    let threshold = 0.72; // semakin tinggi nilai, semakin mirip
    let users = global.db.users[m.sender];
    let room = satanic.family100[id];
    let text = budy.toLowerCase().replace(/[^\w\s\-]+/, '');
    let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(budy);

    if (!isSurrender) {
        let index = room.jawaban.indexOf(text);

        if (index < 0) {
            if (Math.max(...room.jawaban.filter((_, index) => !room.terjawab[index]).map(jawaban => similarity(jawaban, text))) >= threshold) {
                return reply('Dikit lagi!');
            }
        }

        if (!isCmd && room.terjawab[index]) {
            return;
        }

        users.money += room.winScore;
        room.terjawab[index] = m.sender;
    }

    let isWin = room.terjawab.length === room.terjawab.filter(v => v).length;

    let caption = `*GAME FAMILY100*

*Soal:* ${room.soal}

Terdapat ${room.jawaban.length} jawaban${room.jawaban.find(v => v.includes(' ')) ? `
(beberapa jawaban terdapat spasi)
`: ''}
${isWin ? `*SEMUA JAWABAN TERJAWAB ✅*` : isSurrender ? '*MENYERAH ❌*' : ''}
${Array.from(room.jawaban, (jawaban, index) => {
    return isSurrender || room.terjawab[index] ? `(${index + 1}) ${jawaban} ${room.terjawab[index] ? '✓ ' + room.terjawab[index].split('@')[0] : ''}`.trim() : false;
}).filter(v => v).join('\n')}

${isSurrender ? '' : `+${room.winScore} Money tiap jawaban benar`}
    `.trim();

    satanic.sendMessage(from, { text: `${caption}`, mentions: [room.terjawab + '@s.whatsapp.net'] }, { quoted: m }).then(msg => {
        satanic.family100[id].msg = msg;
    }).catch(_ => _);

    if (isWin || isSurrender) {
        delete satanic.family100[id];
    }
}

satanic.tebakgambar = satanic.tebakgambar ? satanic.tebakgambar : {}

if (from in satanic.tebakgambar) {
  let kuis = true
  let id = m.chat
  let users = global.db.users[m.sender]
  let json = JSON.parse(JSON.stringify(satanic.tebakgambar[id][1]))
  let jawabanBenar = json.jawaban.toLowerCase().trim()
  let jawabanUser = budy.toLowerCase().trim()

  // Fitur HINT
  if (jawabanUser === 'hint') {
    let clue = json.jawaban.split('')
    let hint = clue.map((huruf, i) => (i % 2 === 0 ? huruf : '_')).join(' ')
    reply(`🔍 *HINT:* ${hint}\n\nKetik *suren* untuk menjawab dengan yakin.`)
    return
  }

  // Fitur SUREN (konfirmasi)
  if (jawabanUser === 'suren') {
    satanic.tebakgambar[id][4] = true // flag suren aktif
    reply(`⚠️ *KONFIRMASI*\nKetik jawabanmu sekarang. Jika salah, kamu akan kena penalti 5000 money!`)
    return
  }

  // Cek apakah dalam mode suren
  let isSuren = satanic.tebakgambar[id][4] === true

  if (jawabanUser === jawabanBenar) {
    let hadiah = 10000
    if (isSuren) hadiah += 5000 // bonus suren

    users.money += hadiah
    let teks = `🎮 Tebak Gambar 🎮\n\n✅ *Jawaban Benar!* 🎉\n💰 Hadiah : ${hadiah.toLocaleString()} money\n\nIngin bermain lagi? Ketik *TebakGambar*`
    reply(teks)

    clearTimeout(satanic.tebakgambar[id][3])
    delete satanic.tebakgambar[id]
  } else {
    if (isSuren) {
      // Penalti jika suren salah
      users.money -= 5000
      reply(`❌ *Jawaban Salah!* (mode suren aktif)\n💸 Kamu kehilangan 5000 money.\n\nJawaban yang benar: *${json.jawaban}*`)
      clearTimeout(satanic.tebakgambar[id][3])
      delete satanic.tebakgambar[id]
    } else {
      console.log('Jawaban Salah!')
      
    }
  }
}

// ========== TEBAK BENDERA ==========
satanic.tebakbendera = satanic.tebakbendera ? satanic.tebakbendera : {};

if (satanic.tebakbendera.hasOwnProperty(m.sender.split('@')[0]) && !m.key.fromMe) {
  kuis = true;
  let jawaban = satanic.tebakbendera[m.sender.split('@')[0]];
  let userText = m.text.trim().toLowerCase();
  
  // HINT (maksimal 2x)
  if (/hint|bantuan/i.test(userText)) {
    if (!satanic.tebakbendera_hint) satanic.tebakbendera_hint = {};
    let hintCount = satanic.tebakbendera_hint[m.sender.split('@')[0]] || 0;
    
    if (hintCount < 2) {
      satanic.tebakbendera_hint[m.sender.split('@')[0]] = hintCount + 1;
      let clue = jawaban.replace(/[aiueo]/gi, '_');
      return reply(`💡 *Hint ${hintCount + 1}/2:* ${clue}`);
    } else {
      return reply(`⚠️ Hint sudah habis! (Maksimal 2 kali)`);
    }
  }
  
  // NYERAH
  if (/nyerah|surrender/i.test(userText)) {
    reply(`💢 *Menyerah!*\nJawaban: *${jawaban.toUpperCase()}*`);
    delete satanic.tebakbendera[m.sender.split('@')[0]];
    if (satanic.tebakbendera_hint) delete satanic.tebakbendera_hint[m.sender.split('@')[0]];
    return;
  }
  
  // JAWABAN BENAR
  if (userText === jawaban) {
    // Tambah reward (sesuaikan dengan database Anda)
    if (global.db.users[m.sender]) {     
      global.db.users[m.sender].money = (global.db.users[m.sender].money || 0) + 10000;
    }
    
    reply(`✅ *TEBAK BENDERA*\n\nJawaban Benar! 🎉\nNegara: *${jawaban.toUpperCase()}*\n\n📈 +5000 XP\n💰 +10000 Money\n\nKetik *tebakbendera* untuk bermain lagi.`);
    
    delete satanic.tebakbendera[m.sender.split('@')[0]];
    if (satanic.tebakbendera_hint) delete satanic.tebakbendera_hint[m.sender.split('@')[0]];
  }
}

// ========== TEBAK KABUPATEN ==========
satanic.tebakkabupaten = satanic.tebakkabupaten ? satanic.tebakkabupaten : {};
if (tebakkabupaten.hasOwnProperty(m.sender.split('@')[0])) {  // HAPUS && isCmd
    kuis = true
    jawaban = tebakkabupaten[m.sender.split('@')[0]]
    let userText = m.text.trim().toLowerCase()
    
    if (/hint|bantuan/i.test(userText)) {
        let clue = jawaban.replace(/[AIUEO]/gi, '_')
        return reply(`💡 *Hint:* ${clue}`)
    }
    
    if (/nyerah|surrender/i.test(userText)) {
        reply(`💢 *Menyerah!*\nJawaban: ${jawaban}`)
        delete tebakkabupaten[m.sender.split('@')[0]]
        return
    }
    
    if (userText == jawaban.toLowerCase()) {
        reply(`✅ *Benar!*\n🎉 Selamat!`)
        delete tebakkabupaten[m.sender.split('@')[0]]
    }
}


// ========== TEBAK HERO ML ==========
satanic.tebakheroml = satanic.tebakheroml ? satanic.tebakheroml : {};

if (satanic.tebakheroml.hasOwnProperty(m.sender.split('@')[0]) && !m.key.fromMe) {
  kuis = true;
  let jawaban = satanic.tebakheroml[m.sender.split('@')[0]];
  let userText = m.text.trim().toLowerCase();
  
  // HINT (maksimal 2x)
  if (/hint|bantuan/i.test(userText)) {
    if (!satanic.tebakheroml_hint) satanic.tebakheroml_hint = {};
    let hintCount = satanic.tebakheroml_hint[m.sender.split('@')[0]] || 0;
    
    if (hintCount < 2) {
      satanic.tebakheroml_hint[m.sender.split('@')[0]] = hintCount + 1;
      let clue = jawaban.replace(/[aiueo]/gi, '_');
      return reply(`💡 *Hint ${hintCount + 1}/2:* ${clue}`);
    } else {
      return reply(`⚠️ Hint sudah habis! (Maksimal 2 kali)`);
    }
  }
  
  // NYERAH
  if (/nyerah|surrender/i.test(userText)) {
    reply(`💢 *Menyerah!*\nJawaban: *${jawaban.toUpperCase()}*`);
    delete satanic.tebakheroml[m.sender.split('@')[0]];
    if (satanic.tebakheroml_hint) delete satanic.tebakheroml_hint[m.sender.split('@')[0]];
    return;
  }
  
  // JAWABAN BENAR
  if (userText === jawaban) {
    // Tambah reward (sesuaikan dengan database Anda)
    if (global.db.users[m.sender]) {      
      global.db.users[m.sender].money = (global.db.users[m.sender].money || 0) + 10000;
    }
    
    reply(`✅ *TEBAK HERO ML*\n\nJawaban Benar! 🎉\nHero: *${jawaban.toUpperCase()}*\n\n📈 +5000 XP\n💰 +10000 Money\n\nKetik *tebakheroml* untuk bermain lagi.`);
    
    delete satanic.tebakheroml[m.sender.split('@')[0]];
    if (satanic.tebakheroml_hint) delete satanic.tebakheroml_hint[m.sender.split('@')[0]];
  }
}

// ========== TEBAK KIMIA ==========
satanic.tebakkimia = satanic.tebakkimia ? satanic.tebakkimia : {};
if (tebakkimia.hasOwnProperty(m.sender.split('@')[0])) {  // HAPUS && isCmd
    kuis = true
    jawaban = tebakkimia[m.sender.split('@')[0]]
    let userText = m.text.trim().toLowerCase()
    
    if (/hint|bantuan/i.test(userText)) {
        let clue = jawaban.replace(/[AIUEO]/gi, '_')
        return reply(`💡 *Hint:* ${clue}`)
    }
    
    if (/nyerah|surrender/i.test(userText)) {
        reply(`💢 *Menyerah!*\nJawaban: ${jawaban}`)
        delete tebakkimia[m.sender.split('@')[0]]
        return
    }
    
    if (userText == jawaban.toLowerCase()) {
        reply(`✅ *Benar!*\n🎉 Selamat!`)
        delete tebakkimia[m.sender.split('@')[0]]
    }
}

// ========== TEKATEKI ==========
satanic.tekateki = satanic.tekateki ? satanic.tekateki : {}

if (satanic.tekateki.hasOwnProperty(m.chat)) {
    let users = global.db.users[m.sender]
    const similarity = require('similarity')
    const threshold = 0.72

    let idtekateki = m.chat  // <==== DEFINISIKAN VARIABEL
    let json = JSON.parse(JSON.stringify(satanic.tekateki[idtekateki][1]))
    let userText = m.text.trim().toLowerCase()

    // HINT
    if (/hint|bantuan/i.test(userText) && satanic.tekateki[idtekateki][4] < 2) {
        satanic.tekateki[idtekateki][4] = satanic.tekateki[idtekateki][4] ? satanic.tekateki[idtekateki][4] + 1 : 1
        let clue = json.jawaban.replace(/[aiueoAIUEO]/g, '_')
        return reply(`💡 *Hint ${satanic.tekateki[idtekateki][4]}/2:* ${clue}`)
    }

    // NYERAH
    if (/nyerah|surrender/i.test(userText)) {
        reply(`💢 Menyerah! Jawabannya: ${json.jawaban}`)
        clearTimeout(satanic.tekateki[idtekateki][3])
        delete satanic.tekateki[idtekateki]
        return
    }

    // JAWABAN BENAR
    if (userText === json.jawaban.toLowerCase().trim()) {
        users.money += satanic.tekateki[idtekateki][2]
        reply(`✅ *TEKATEKI*\n\nJawaban Benar! 🎉\nHadiah: +${satanic.tekateki[idtekateki][2]} Money 💸`)
        clearTimeout(satanic.tekateki[idtekateki][3])
        delete satanic.tekateki[idtekateki]
    } else if (similarity(userText, json.jawaban.toLowerCase().trim()) >= threshold) {
        reply(`*Dikit Lagi!*`)
    } else {
        
    }
}
        
//=========================================\\

//=========================================\\
// ========== TEBAK ASAHOTAK ==========
satanic.tebakasahotak = satanic.tebakasahotak ? satanic.tebakasahotak : {};
if (tebakasahotak.hasOwnProperty(m.sender.split('@')[0])) {  // HAPUS && isCmd
    kuis = true
    jawaban = tebakasahotak[m.sender.split('@')[0]]
    let userText = m.text.trim().toLowerCase()
    
    // HINT
    if (/hint|bantuan/i.test(userText)) {
        let clue = jawaban.replace(/[AIUEO]/gi, '_')
        return reply(`💡 *Hint:* ${clue}`)
    }
    
    // NYERAH
    if (/nyerah|surrender/i.test(userText)) {
        reply(`💢 *Menyerah!*\nJawaban: ${jawaban}`)
        delete tebakasahotak[m.sender.split('@')[0]]
        return
    }
    
    // JAWABAN BENAR
    if (userText == jawaban.toLowerCase()) {
        reply(`✅ *Benar!*\n🎉 Selamat!`)
        delete tebakasahotak[m.sender.split('@')[0]]
    }
}

// ========== SIAPAKAH AKU ==========
satanic.siapaaku = satanic.siapaaku ? satanic.siapaaku : {}

if (satanic.siapaaku.hasOwnProperty(m.chat)) {
    const similarity = require('similarity')
    const threshold = 0.72

    let idsiapaaku = m.chat  // <==== DEFINISIKAN VARIABEL
    let users = global.db.users[m.sender]
    let json = JSON.parse(JSON.stringify(satanic.siapaaku[idsiapaaku][1]))
    let userText = m.text.trim().toLowerCase()

    // HINT
    if (/hint|bantuan/i.test(userText) && satanic.siapaaku[idsiapaaku][4] < 2) {
        satanic.siapaaku[idsiapaaku][4] = satanic.siapaaku[idsiapaaku][4] ? satanic.siapaaku[idsiapaaku][4] + 1 : 1
        let clue = json.jawaban.replace(/[aiueoAIUEO]/g, '_')
        return reply(`💡 *Hint ${satanic.siapaaku[idsiapaaku][4]}/2:* ${clue}`)
    }

    // NYERAH
    if (/nyerah|surrender/i.test(userText)) {
        reply(`💢 Menyerah! Jawabannya: ${json.jawaban}`)
        clearTimeout(satanic.siapaaku[idsiapaaku][3])
        delete satanic.siapaaku[idsiapaaku]
        return
    }

    // JAWABAN BENAR
    if (userText === json.jawaban.toLowerCase().trim()) {
        users.money += satanic.siapaaku[idsiapaaku][2]
        reply(`✅ *SIAPAKAH AKU*\n\nJawaban Benar! 🎉\nHadiah: +${satanic.siapaaku[idsiapaaku][2]} Money 💸`)
        clearTimeout(satanic.siapaaku[idsiapaaku][3])
        delete satanic.siapaaku[idsiapaaku]
    } else if (similarity(userText, json.jawaban.toLowerCase().trim()) >= threshold) {
        reply(`*Dikit Lagi!*`)
    } else {
     
    }
}

// ========== SUSUN KATA ==========
satanic.susunkata = satanic.susunkata ? satanic.susunkata : {}

if (satanic.susunkata.hasOwnProperty(m.chat)) {
    const similarity = require('similarity')
    const threshold = 0.72

    let idsusunkata = m.chat  // <==== DEFINISIKAN VARIABEL
    let users = global.db.users[m.sender]
    let json = JSON.parse(JSON.stringify(satanic.susunkata[idsusunkata][1]))
    let userText = m.text.trim().toLowerCase()

    // HINT
    if (/hint|bantuan/i.test(userText) && satanic.susunkata[idsusunkata][4] < 2) {
        satanic.susunkata[idsusunkata][4] = satanic.susunkata[idsusunkata][4] ? satanic.susunkata[idsusunkata][4] + 1 : 1
        let clue = json.jawaban.replace(/[aiueoAIUEO]/g, '_')
        return reply(`💡 *Hint ${satanic.susunkata[idsusunkata][4]}/2:* ${clue}`)
    }

    // NYERAH
    if (/nyerah|surrender/i.test(userText)) {
        reply(`💢 Menyerah! Jawabannya: ${json.jawaban}`)
        clearTimeout(satanic.susunkata[idsusunkata][3])
        delete satanic.susunkata[idsusunkata]
        return
    }

    // JAWABAN BENAR
    if (userText === json.jawaban.toLowerCase().trim()) {
        users.money += satanic.susunkata[idsusunkata][2]
        reply(`✅ *SUSUN KATA*\n\nJawaban Benar! 🎉\nHadiah: +${satanic.susunkata[idsusunkata][2]} Money 💸`)
        clearTimeout(satanic.susunkata[idsusunkata][3])
        delete satanic.susunkata[idsusunkata]
    } else if (similarity(userText, json.jawaban.toLowerCase().trim()) >= threshold) {
        reply(`*Dikit Lagi!*`)
    } else {
        
    }
}
//=========================================\\
satanic.caklontong = satanic.caklontong ? satanic.caklontong : {};
if (caklontong.hasOwnProperty(m.sender.split('@')[0])) {
    kuis = true;
    jawaban = caklontong[m.sender.split('@')[0]];
    deskripsi = caklontong_desk[m.sender.split('@')[0]];
    
    let userText = m.text.trim().toLowerCase();
    
    // CEK HINT DULU (paling prioritas)
    if (/hint|bantuan/i.test(userText)) {
        let clue = jawaban.replace(/[AIUEO]/gi, '_');
        return reply(`💡 *Hint:* ${clue}`);
    }
    
    // CEK NYERAH
    if (/nyerah|surrender/i.test(userText)) {
        reply(`💢 Menyerah! Jawabannya: ${jawaban}`);
        delete caklontong[m.sender.split('@')[0]];
        delete caklontong_desk[m.sender.split('@')[0]];
        return;
    }
    
    // CEK JAWABAN BENAR
    if (userText == jawaban.toLowerCase()) {
        satanic.sendMessage(m.chat, { 
            image: { url: 'https://telegra.ph/file/14744917bea0185b52fb1.jpg' }, 
            caption: `✅ *Tebak Lontong*\n\nJawaban Benar! 🎉\n\nKetik *tebaklontong* untuk bermain lagi.`
        }, { quoted: m }); 
        delete caklontong[m.sender.split('@')[0]];
        delete caklontong_desk[m.sender.split('@')[0]];
    }
}

// ========== TEBAK KALIMAT ==========
satanic.tebakkalimat = satanic.tebakkalimat ? satanic.tebakkalimat : {};
if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) {  // HAPUS && isCmd
    kuis = true
    jawaban = tebakkalimat[m.sender.split('@')[0]]
    let userText = m.text.trim().toLowerCase()
    
    if (/hint|bantuan/i.test(userText)) {
        let clue = jawaban.replace(/[AIUEO]/gi, '_')
        return reply(`💡 *Hint:* ${clue}`)
    }
    
    if (/nyerah|surrender/i.test(userText)) {
        reply(`💢 Menyerah! Jawabannya: ${jawaban}`)
        delete tebakkalimat[m.sender.split('@')[0]]
        return
    }
    
    if (userText == jawaban.toLowerCase()) {
        satanic.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/14744917bea0185b52fb1.jpg' }, caption: `✅ *Tebak Kalimat*\n\nJawaban Benar! 🎉\n\nKetik *tebakkalimat* untuk bermain lagi.`}, {quoted:m}) 
        delete tebakkalimat[m.sender.split('@')[0]]
    }
}

satanic.tebaklirik = satanic.tebaklirik ? satanic.tebaklirik : {}

if (satanic.tebaklirik.hasOwnProperty(m.chat)) {
    const similarity = require('similarity')
    const threshold = 0.72

    let idlirik = m.chat  // <==== DIGANTI DARI id MENJADI idlirik
    let users = global.db.users[m.sender]
    let json = JSON.parse(JSON.stringify(satanic.tebaklirik[idlirik][1]))
    let userText = m.text.trim().toLowerCase()

    // HINT
    if (/hint|bantuan/i.test(userText) && satanic.tebaklirik[idlirik][4] < 2) {
        satanic.tebaklirik[idlirik][4] = satanic.tebaklirik[idlirik][4] ? satanic.tebaklirik[idlirik][4] + 1 : 1
        let clue = json.jawaban.replace(/[aiueoAIUEO]/g, '_')
        return reply(`💡 *Hint ${satanic.tebaklirik[idlirik][4]}/2:* ${clue}`)
    }

    // NYERAH
    if (/nyerah|surrender/i.test(userText)) {
        reply(`💢 Menyerah! Jawabannya: ${json.jawaban}`)
        clearTimeout(satanic.tebaklirik[idlirik][3])
        delete satanic.tebaklirik[idlirik]
        return
    }

    // CEK JAWABAN
    if (userText === json.jawaban.toLowerCase().trim()) {
        users.money += satanic.tebaklirik[idlirik][2]
        reply(`✅ *TEBAK LIRIK*\n\nJawaban Benar! 🎉\nHadiah: +${satanic.tebaklirik[idlirik][2]} Money 💸\nEXP: +10`)
        clearTimeout(satanic.tebaklirik[idlirik][3])
        delete satanic.tebaklirik[idlirik]
    } else if (similarity(userText, json.jawaban.toLowerCase().trim()) >= threshold) {
        reply(`*Dikit Lagi!*`)
    } else {
        reply(`❌ Salah! Coba lagi. Ketik *hint* untuk bantuan.`)
    }
}
// ========== TEBAK TEBAKAN ==========
satanic.tebaktebakan = satanic.tebaktebakan ? satanic.tebaktebakan : {};
if (tebaktebakan.hasOwnProperty(m.sender.split('@')[0])) {  // HAPUS && isCmd
    kuis = true
    jawaban = tebaktebakan[m.sender.split('@')[0]]
    let userText = m.text.trim().toLowerCase()
    
    if (/hint|bantuan/i.test(userText)) {
        let clue = jawaban.replace(/[AIUEO]/gi, '_')
        return reply(`💡 *Hint:* ${clue}`)
    }
    
    if (/nyerah|surrender/i.test(userText)) {
        reply(`💢 Menyerah! Jawabannya: ${jawaban}`)
        delete tebaktebakan[m.sender.split('@')[0]]
        return
    }
    
    if (userText == jawaban.toLowerCase()) {
        satanic.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/14744917bea0185b52fb1.jpg' }, caption: `✅ *Tebak Tebakan*\n\nJawaban Benar! 🎉\n\nKetik *tebaktebakan* untuk bermain lagi.`}, {quoted:m}) 
        delete tebaktebakan[m.sender.split('@')[0]]
    }
}

satanic.math = satanic.math ? satanic.math : {}
if (id in satanic.math && !m.key.fromMe) {
    let json = satanic.math[id][0]
    let users = global.db.users[m.sender]
    let jawabanUser = parseInt(budy.toLowerCase().trim())
    let isHint = /^hint$/i.test(m.text)
    
    if (isHint && satanic.math[id][2] < 2) {
        satanic.math[id][2] = satanic.math[id][2] ? satanic.math[id][2] + 1 : 1
        let clue = json.str.replace(/[0-9]/g, '?')
        return reply(`💡 *Hint ${satanic.math[id][2]}/2:* ${clue}`)
    }
    
    if (jawabanUser === json.result) {
        reply(`✅ *Benar!*\n🎉 +${json.bonus} XP`)
        clearTimeout(satanic.math[id][1])
        delete satanic.math[id]
    } else if (/nyerah|surrender/i.test(m.text)) {
        reply(`💢 Menyerah! Jawabannya: ${json.result}`)
        clearTimeout(satanic.math[id][1])
        delete satanic.math[id]
    } else {
        reply(`❌ *Salah!*\nKetik *hint* untuk petunjuk.`)
    }
    return
}
	    
	    
	    
function clockString(ms) {
  let h = Math.floor(ms / 3600000)
  let m = Math.floor(ms / 60000) % 60
  let s = Math.floor(ms / 1000) % 60
  console.log({ms,h,m,s})
  return [h, m, s].map(v => v.toString().padStart(2, 0) ).join(':')
}
if (db.users[m.sender].afkTime > -1) {
    let user = global.db.users[m.sender]

   reply(
`✅ *Kamu berhenti AFK!*  

👤 ${m.pushName} kembali aktif.  
💤 Alasan sebelumnya : ${user.afkReason ? user.afkReason : '-'}  
⏳ Durasi AFK : ${clockString(new Date - user.afkTime)}

─────────────────────
💡 Selamat datang kembali! Selamat beraktifitas.
`.trim())

    user.afkTime = -1
    user.afkReason = ''
}
	    
	    
satanic.sendTextWithMentions = async (jid, text, quoted, options = {}) => satanic.sendMessage(jid, { text: text, contextInfo: { mentionedJid: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net') }, ...options }, { quoted })	    
	 





// FORMAT RUPIAH
function formatRupiah(angka) {
  return new Intl.NumberFormat('id-ID', { 
    style: 'currency', 
    currency: 'IDR', 
    minimumFractionDigits: 0 
  }).format(angka);
}

// FORMAT WAKTU
function formatWaktu(timestamp) {
  return new Date(timestamp).toLocaleTimeString('id-ID', {
    timeZone: 'Asia/Jakarta',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
}

function formatWaktuFull(timestamp) {
  return new Date(timestamp).toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta',
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
}

// KONVERSI ANGKA
function convertToNumber(input) {
  if (!input) return 0;
  let str = input.toString().trim().toLowerCase();
  str = str.replace(/\./g, '').replace(/,/g, '');
  
  let multiplier = 1;
  let numberStr = str;
  
  if (str.endsWith('k')) {
    multiplier = 1000;
    numberStr = str.slice(0, -1);
  } else if (str.endsWith('jt') || str.endsWith('juta')) {
    multiplier = 1000000;
    numberStr = str.replace(/jt$/, '').replace(/juta$/, '');
  } else if (str.endsWith('m') || str.endsWith('mil') || str.endsWith('miliar')) {
    multiplier = 1000000000;
    numberStr = str.replace(/m$/, '').replace(/mil$/, '').replace(/miliar$/, '');
  } else if (str.endsWith('rb') || str.endsWith('ribu')) {
    multiplier = 1000;
    numberStr = str.replace(/rb$/, '').replace(/ribu$/, '');
  }
  
  const num = parseFloat(numberStr.trim());
  if (isNaN(num)) return 0;
  return Math.floor(num * multiplier);
}



// ==========================================
// ===== AUTO LOAD PLUGIN (COMMONJS) ========
// ==========================================



// ============ LOAD PLUGIN OTOMATIS ============
const plugins = new Map();

function loadPlugins() {
    plugins.clear();
    
    if (!fs.existsSync('./plugins')) {
        fs.mkdirSync('./plugins');
        console.log('📁 Folder plugins dibuat');
    }
    
    const files = fs.readdirSync('./plugins').filter(file => file.endsWith('.js'));
    
    for (const file of files) {
        try {
            const pluginPath = path.resolve(`./plugins/${file}`);
            delete require.cache[require.resolve(pluginPath)];
            const plugin = require(pluginPath);
            const pluginName = file.replace('.js', '');
            
            // Auto detect format
            if (typeof plugin === 'function') {
                plugins.set(pluginName, { 
                    execute: plugin, 
                    file: file,
                    description: plugin.description || 'Plugin function',
                    category: plugin.category || 'custom'
                });
            } else if (plugin.execute && typeof plugin.execute === 'function') {
                plugins.set(pluginName, { 
                    execute: plugin.execute, 
                    file: file,
                    description: plugin.description || 'Plugin execute',
                    category: plugin.category || 'custom'
                });
            } else if (plugin.run && typeof plugin.run === 'function') {
                plugins.set(pluginName, { 
                    execute: plugin.run, 
                    file: file,
                    description: plugin.description || 'Plugin run',
                    category: plugin.category || 'custom'
                });
            } else if (plugin.default && typeof plugin.default === 'function') {
                plugins.set(pluginName, { 
                    execute: plugin.default, 
                    file: file,
                    description: plugin.description || 'Plugin default',
                    category: plugin.category || 'custom'
                });
            } else {
                console.log(`⚠️ Plugin ${pluginName} tidak memiliki format yang valid`);
                continue;
            }
            
            
            
        } catch (e) {
            console.log(`❌ Gagal load plugin ${file}:`, e.message);
        }
    }
    
 
}

// ============ RELOAD PLUGIN ============
function reloadPlugins() {
    const files = fs.readdirSync('./plugins').filter(file => file.endsWith('.js'));
    for (const file of files) {
        const pluginPath = path.resolve(`./plugins/${file}`);
        delete require.cache[require.resolve(pluginPath)];
    }
    loadPlugins();
}

// ============ EXECUTE PLUGIN ============
async function executePlugin(pluginName, satanic, m, args, fkontak, namaBot, global, prefix) {
    if (!plugins.has(pluginName)) {
        return { success: false, message: `Plugin "${pluginName}" tidak ditemukan!` };
    }
    
    const plugin = plugins.get(pluginName);
    try {
        await plugin.execute(satanic, m, args, fkontak, namaBot, global, prefix);
        return { success: true, message: 'Plugin berhasil dijalankan' };
    } catch (e) {
        console.error(`Error plugin ${pluginName}:`, e);
        return { success: false, message: `Error: ${e.message}` };
    }
}

// ============ LOAD PERTAMA KALI ============
loadPlugins();

// ============ AUTO EXECUTE DI SWITCH-CASE ============

    if (plugins.has(command)) {
        const result = await executePlugin(command, satanic, m, args, fkontak, namaBot, global, prefix);
        if (!result.success) {
            await reply(`❌ ${result.message}`);
        }
        
    }
    

    


////////// BATAS AKHIR //////
switch (command) {

// ==========================================
// ===== RELOAD PLUGIN ======================
// ==========================================
case 'reloadplugin':
case 'reload':
    if (!isCreator) return reply('👑 Khusus owner!');
    reloadPlugins();
    reply(`✅ *Plugin berhasil direload!*\n\n📌 Total plugin: ${plugins.size}`);
    break;

// ==========================================
// ===== LIST PLUGIN ========================
// ==========================================
case 'listplugin':
case 'plugins':
    if (!text) {
        let list = Array.from(plugins.keys()).map((name, i) => {
            const plugin = plugins.get(name);
            const desc = plugin.description || 'Tidak ada deskripsi';
            const category = plugin.category || 'uncategorized';
            return `${i+1}. ${name} - ${desc} [${category}]`;
        }).join('\n');
        
        if (list.length === 0) {
            return reply('📂 *DAFTAR PLUGIN*\n\nTidak ada plugin yang terload!');
        }
        
        return reply(`📂 *DAFTAR PLUGIN*\n\n📌 Total: ${plugins.size} plugin\n\n${list}\n\n📝 *Cara penggunaan:*\n➤ ${prefix}plugin [nama_plugin] - Jalankan plugin`);
    }
    
    const result = await executePlugin(text.toLowerCase(), satanic, m, args, fkontak, namaBot, global, prefix);
    if (!result.success) {
        return reply(`❌ ${result.message}`);
    }
    break;

// ==========================================
// ===== ADD PLUGIN ==========================
// ==========================================
case 'getplugin':
case 'lihatplugin':
case 'detailplugin': {
    try {
        if (!isCreator) return reply('❌ Anda bukan owner!');
        
        const fs = require('fs');
        const path = require('path');
        
        if (!q) {
            let msg = '📋 *CARA PENGGUNAAN GETPLUGIN*\n';
            msg += '═══════════════════════════\n\n';
            msg += '📌 *Fungsi:*\n';
            msg += 'Untuk melihat detail kode dari sebuah plugin\n\n';
            msg += '📌 *Cara Penggunaan:*\n';
            msg += `➤ ${prefix}getplugin [nama_file]\n\n`;
            msg += '📌 *Contoh:*\n';
            msg += `➤ ${prefix}getplugin igstalk.js\n\n`;
            msg += '📌 *Lihat daftar plugin:*\n';
            msg += `➤ ${prefix}listplugin\n\n`;
            msg += '═══════════════════════════\n';
            msg += '💡 *Tips:* Gunakan .listplugin untuk melihat semua plugin';
            return reply(msg);
        }

        const pluginDir = './plugins';
        if (!fs.existsSync(pluginDir)) {
            return reply('❌ Folder plugins tidak ditemukan!');
        }

        let fileName = q.trim();
        if (!fileName.endsWith('.js') && !fileName.endsWith('.ts')) {
            fileName = fileName + '.js';
        }

        const filePath = path.join(pluginDir, fileName);
        if (!fs.existsSync(filePath)) {
            // Coba cari file dengan nama yang mirip
            const files = fs.readdirSync(pluginDir);
            const similarFile = files.find(f => f.toLowerCase().includes(fileName.toLowerCase().replace('.js', '')));
            
            if (similarFile) {
                return reply(`❌ Plugin "${fileName}" tidak ditemukan!\n\n📌 Apakah maksud Anda: ${similarFile}\n💡 Gunakan: ${prefix}getplugin ${similarFile}`);
            }
            
            return reply(`❌ Plugin "${fileName}" tidak ditemukan!\n\n📌 Gunakan ${prefix}listplugin untuk melihat daftar plugin`);
        }

        // Baca file plugin
        const fileContent = fs.readFileSync(filePath, 'utf-8');
        const stats = fs.statSync(filePath);
        const size = (stats.size / 1024).toFixed(2);
        const lines = fileContent.split('\n').length;
        const modified = new Date(stats.mtime).toLocaleString('id-ID');
        
        // Deteksi nama plugin dari file
        let pluginName = fileName.replace('.js', '').replace('.ts', '');
        let isActive = plugins && plugins.has(pluginName) ? '✅ Aktif' : '❌ Tidak Aktif';
        
        // Cari informasi dari kode
        let nameMatch = fileContent.match(/name\s*:\s*['"]([^'"]+)['"]/);
        let categoryMatch = fileContent.match(/category\s*:\s*['"]([^'"]+)['"]/);
        let descMatch = fileContent.match(/description\s*:\s*['"]([^'"]+)['"]/);
        
        let info = '📦 *DETAIL PLUGIN*\n';
        info += '═══════════════════════════\n\n';
        info += `📌 *Nama File:* ${fileName}\n`;
        if (nameMatch) info += `📌 *Command:* ${nameMatch[1]}\n`;
        if (categoryMatch) info += `📌 *Kategori:* ${categoryMatch[1]}\n`;
        if (descMatch) info += `📌 *Deskripsi:* ${descMatch[1]}\n`;
        info += `📌 *Status:* ${isActive}\n`;
        info += `📌 *Size:* ${size} KB\n`;
        info += `📌 *Baris:* ${lines}\n`;
        info += `📌 *Modified:* ${modified}\n`;
        info += `📌 *Lokasi:* plugins/${fileName}\n\n`;
        info += '═══════════════════════════\n';
        info += '📄 *KODE PLUGIN:*\n\n';
        info += '```javascript\n';
        info += fileContent;
        info += '\n```\n\n';
        info += '═══════════════════════════\n';
        info += `💡 *Cara Menggunakan:*\n`;
        info += `➤ ${prefix}${pluginName} [args]\n\n`;
        info += `📌 *Untuk mengedit:*\n`;
        info += `➤ Buka file plugins/${fileName}\n`;
        info += `➤ Edit sesuai kebutuhan\n`;
        info += `➤ Restart bot untuk menerapkan perubahan`;

        // Kirim dengan format baik
        if (info.length > 4000) {
            // Kirim info dulu
            const infoParts = info.split('```javascript');
            if (infoParts.length > 1) {
                const infoText = infoParts[0];
                const codePart = infoParts[1].split('```')[0];
                const footer = infoParts[1].split('```')[1] || '';
                
                await reply(infoText);
                
                // Kirim code sebagai file atau pesan terpisah
                try {
                    const { Builder } = require('baileys-mbuilder');
                    const { AIRich } = Builder;
                    
                    await new AIRich(satanic)
                        .addCode('javascript', codePart.trim())
                        .send(m.chat, { quoted: fkontak });
                    
                    if (footer) await reply(footer);
                } catch (e) {
                    // Jika Builder tidak tersedia, kirim sebagai text biasa
                    const chunks = info.match(/.{1,4000}/g);
                    for (const chunk of chunks) {
                        await reply(chunk);
                    }
                }
            } else {
                const chunks = info.match(/.{1,4000}/g);
                for (const chunk of chunks) {
                    await reply(chunk);
                }
            }
        } else {
            await reply(info);
        }
        try {
            await satanic.sendMessage(m.chat, {
                document: fs.readFileSync(filePath),
                fileName: fileName,
                mimetype: 'application/javascript',
                caption: `📎 *File Plugin: ${fileName}*\n📌 Size: ${size} KB\n📌 Klik untuk download`
            });
        } catch (e) {
        }

    } catch (error) {
        console.error('Error in getplugin case:', error);
        reply(`❌ Terjadi kesalahan: ${error.message}`);
    }
    break;
}
case 'toplugin':
case 'convertcase':
case 'case2plugin': {
    try {
        if (!isCreator) return reply('❌ Anda bukan owner!');
        
        const fs = require('fs');
        const path = require('path');
        
        // Cek apakah ada reply
        if (!m.quoted) {
            let msg = '📋 *CARA PENGGUNAAN TOPLUGIN*\n';
            msg += '═══════════════════════════\n\n';
            msg += '📌 *Fungsi:*\n';
            msg += 'Mengkonversi case dari pesan yang di-reply menjadi plugin\n\n';
            msg += '📌 *Cara Penggunaan:*\n';
            msg += `1. Kirim pesan berisi kode case\n`;
            msg += `2. Reply pesan tersebut dengan ${prefix}toplugin [nama_plugin]\n\n`;
            msg += '📌 *Contoh:*\n';
            msg += `➤ ${prefix}toplugin hargasc\n\n`;
            msg += '📌 *Atau dari satanic.js:*\n';
            msg += `➤ ${prefix}toplugin hargasc --fromfile\n\n`;
            msg += '═══════════════════════════\n';
            msg += '💡 *Tips:* Gunakan .getcase untuk melihat kode case';
            return reply(msg);
        }

        // Ambil kode dari reply
        let code = m.quoted.text || m.quoted.body || '';
        if (!code) {
            return reply('⚠️ Pesan yang di-reply tidak mengandung kode!');
        }

        // Parse arguments
        const args = q.split(' ');
        let pluginName = args[0];
        const fromFile = args.includes('--fromfile') || args.includes('-f');
        const force = args.includes('--force');

        if (!pluginName && !fromFile) {
            return reply(`⚠️ Masukkan nama plugin!\n\n📌 Contoh: ${prefix}toplugin hargasc`);
        }

        let caseCode = code;
        let dependencies = [];

        // Jika dari file satanic.js
        if (fromFile) {
            if (!pluginName) {
                return reply('⚠️ Masukkan nama case!\n\n📌 Contoh: ${prefix}toplugin hargasc --fromfile');
            }

            const satanicPath = path.join(__dirname, 'satanic.js');
            if (!fs.existsSync(satanicPath)) {
                return reply('❌ File satanic.js tidak ditemukan!');
            }

            const fileContent = fs.readFileSync(satanicPath, 'utf-8');
            const caseRegex = new RegExp(`case\\s+['"]${pluginName}['"]\\s*:\\s*{([\\s\\S]*?)}\\s*break`, 'i');
            const match = fileContent.match(caseRegex);

            if (!match) {
                return reply(`❌ Case "${pluginName}" tidak ditemukan di satanic.js!`);
            }

            caseCode = match[1].trim();
        } else {
            // Gunakan nama dari argumen
            if (!pluginName) {
                // Deteksi nama dari kode
                const nameMatch = code.match(/name\s*:\s*['"]([^'"]+)['"]/);
                if (nameMatch) {
                    pluginName = nameMatch[1];
                } else {
                    pluginName = `plugin_${Date.now()}`;
                }
            }
        }

        // Deteksi dependencies dari kode
        const requireMatches = caseCode.match(/require\s*\(\s*['"]([^'"]+)['"]\s*\)/g);
        if (requireMatches) {
            requireMatches.forEach(req => {
                const lib = req.match(/['"]([^'"]+)['"]/)[1];
                if (!dependencies.includes(lib) && !lib.startsWith('.')) {
                    dependencies.push(lib);
                }
            });
        }

        // Buat nama file
        let fileName = `${pluginName}.js`;
        let pluginPath = path.join('./plugins', fileName);

        // Cek jika plugin sudah ada
        if (fs.existsSync(pluginPath) && !force) {
            return reply(`⚠️ Plugin "${fileName}" sudah ada!\n\n` +
                        `📌 Gunakan --force untuk overwrite:\n` +
                        `${prefix}toplugin ${pluginName} --force\n\n` +
                        `📌 Atau hapus plugin dulu:\n` +
                        `${prefix}delplugin ${fileName}`);
        }

        // Format kode plugin
        let pluginCode = '';
        
        // Tambahkan dependencies
        if (dependencies.length > 0) {
            dependencies.forEach(dep => {
                const varName = dep.replace(/[^a-zA-Z0-9]/g, '_');
                pluginCode += `const ${varName} = require('${dep}');\n`;
            });
            pluginCode += '\n';
        }

        // Buat struktur plugin
        pluginCode += `module.exports = {\n`;
        pluginCode += `    name: '${pluginName}',\n`;
        pluginCode += `    category: 'converted',\n`;
        pluginCode += `    description: 'Plugin hasil konversi dari case ${pluginName}',\n`;
        pluginCode += `    execute: async (satanic, m, args, fkontak, namaBot, global, prefix) => {\n`;
        pluginCode += `        try {\n`;
        
        // Konversi kode
        let convertedCode = caseCode;
        
        // Konversi reply ke m.reply
        convertedCode = convertedCode.replace(/reply\s*\(/g, 'm.reply(');
        convertedCode = convertedCode.replace(/await\s+m\.reply/g, 'await m.reply');
        
        // Konversi break ke return
        convertedCode = convertedCode.replace(/break;/g, 'return;');
        
        // Tambahkan indentasi
        const lines = convertedCode.split('\n');
        const indentedLines = lines.map(line => {
            if (line.trim() === '') return '';
            return `            ${line}`;
        });
        convertedCode = indentedLines.join('\n');
        
        pluginCode += convertedCode;
        
        pluginCode += `\n        } catch (error) {\n`;
        pluginCode += `            console.error('Error in ${pluginName}:', error);\n`;
        pluginCode += `            await m.reply('❌ Terjadi kesalahan: ' + error.message);\n`;
        pluginCode += `        }\n`;
        pluginCode += `    }\n`;
        pluginCode += `};`;

        // Buat folder plugins jika belum ada
        if (!fs.existsSync('./plugins')) {
            fs.mkdirSync('./plugins', { recursive: true });
        }
        
        // Simpan plugin
        fs.writeFileSync(pluginPath, pluginCode);

        // Reload plugin
        let reloadStatus = '⚠️ Perlu restart bot';
        if (typeof reloadPlugins === 'function') {
            try {
                reloadPlugins();
                reloadStatus = '✅ Berhasil di-reload';
            } catch (e) {
                reloadStatus = '⚠️ Gagal reload: ' + e.message;
            }
        }

        // Statistik
        const stats = fs.statSync(pluginPath);
        const size = (stats.size / 1024).toFixed(2);
        const linesCount = pluginCode.split('\n').length;
        
        // Buat response
        let response = '✅ *PLUGIN BERHASIL DIBUAT!*\n';
        response += '═══════════════════════════\n\n';
        response += `📌 *Case:* ${pluginName}\n`;
        response += `📌 *Plugin:* ${fileName}\n`;
        response += `📌 *Lokasi:* plugins/${fileName}\n`;
        response += `📌 *Size:* ${size} KB\n`;
        response += `📌 *Baris:* ${linesCount}\n`;
        response += `📌 *Dependencies:* ${dependencies.length > 0 ? dependencies.join(', ') : 'Tidak ada'}\n`;
        response += `📌 *Status:* ${reloadStatus}\n\n`;
        response += '═══════════════════════════\n';
        response += `📝 *Cara Menggunakan:*\n`;
        response += `➤ ${prefix}${pluginName} [args]\n\n`;
        
        if (dependencies.length > 0) {
            response += `📦 *Dependencies yang dibutuhkan:*\n`;
            dependencies.forEach(dep => {
                response += `➤ npm install ${dep}\n`;
            });
            response += '\n';
        }
        
        response += '📄 *Preview Kode:*\n```javascript\n';
        const previewLines = pluginCode.split('\n').slice(0, 15).join('\n');
        response += previewLines;
        if (linesCount > 15) response += '\n... (lanjut)';
        response += '\n```\n\n';
        response += '═══════════════════════════\n';
        response += `💡 *Untuk melihat kode lengkap:*\n`;
        response += `➤ ${prefix}getplugin ${fileName}\n\n`;
        response += `📌 *Untuk menghapus plugin:*\n`;
        response += `➤ ${prefix}delplugin ${fileName}`;

        // Kirim response
        if (response.length > 4000) {
            const chunks = response.match(/.{1,4000}/g);
            for (const chunk of chunks) {
                await reply(chunk);
            }
        } else {
            await reply(response);
        }

        // Kirim file plugin
        try {
            await satanic.sendMessage(m.chat, {
                document: fs.readFileSync(pluginPath),
                fileName: fileName,
                mimetype: 'application/javascript',
                caption: `📎 *File Plugin: ${fileName}*\n📌 Hasil konversi dari case ${pluginName}`
            });
        } catch (e) {}

    } catch (error) {
        console.error('Error in toplugin:', error);
        reply(`❌ Terjadi kesalahan: ${error.message}`);
    }
    break;
}

case 'tocase':
case 'plugin2case':
case 'converttocase': {
    try {
        if (!isCreator) return reply('❌ Anda bukan owner!');
        
        const fs = require('fs');
        const path = require('path');
        
        // Cek apakah ada reply
        if (!m.quoted) {
            let msg = '📋 *CARA PENGGUNAAN TOCASE*\n';
            msg += '═══════════════════════════\n\n';
            msg += '📌 *Fungsi:*\n';
            msg += 'Mengkonversi plugin dari pesan yang di-reply menjadi case di satanic.js\n\n';
            msg += '📌 *Cara Penggunaan:*\n';
            msg += `1. Kirim pesan berisi kode plugin\n`;
            msg += `2. Reply pesan tersebut dengan ${prefix}tocase [nama_case]\n\n`;
            msg += '📌 *Contoh:*\n';
            msg += `➤ ${prefix}tocase igstalk\n\n`;
            msg += '📌 *Atau dari file plugin:*\n';
            msg += `➤ ${prefix}tocase igstalk --fromfile\n\n`;
            msg += '═══════════════════════════\n';
            msg += '💡 *Tips:* Gunakan .listplugin untuk melihat daftar plugin';
            return reply(msg);
        }

        // Ambil kode dari reply
        let code = m.quoted.text || m.quoted.body || '';
        if (!code) {
            return reply('⚠️ Pesan yang di-reply tidak mengandung kode!');
        }

        // Parse arguments
        const args = q.split(' ');
        let caseName = args[0];
        const fromFile = args.includes('--fromfile') || args.includes('-f');
        const backup = args.includes('--backup') || args.includes('-b');

        if (!caseName && !fromFile) {
            return reply(`⚠️ Masukkan nama case!\n\n📌 Contoh: ${prefix}tocase igstalk`);
        }

        let pluginCode = code;
        let dependencies = [];

        // Jika dari file plugin
        if (fromFile) {
            if (!caseName) {
                return reply('⚠️ Masukkan nama plugin!\n\n📌 Contoh: ${prefix}tocase igstalk --fromfile');
            }

            const pluginDir = './plugins';
            if (!fs.existsSync(pluginDir)) {
                return reply('❌ Folder plugins tidak ditemukan!');
            }

            let fileName = `${caseName}.js`;
            let pluginPath = path.join(pluginDir, fileName);
            
            if (!fs.existsSync(pluginPath)) {
                fileName = `${caseName}.ts`;
                pluginPath = path.join(pluginDir, fileName);
                
                if (!fs.existsSync(pluginPath)) {
                    const files = fs.readdirSync(pluginDir);
                    const similarFile = files.find(f => f.toLowerCase().includes(caseName.toLowerCase()));
                    
                    if (similarFile) {
                        return reply(`❌ Plugin "${caseName}" tidak ditemukan!\n\n📌 Apakah maksud Anda: ${similarFile}`);
                    }
                    
                    return reply(`❌ Plugin "${caseName}" tidak ditemukan!\n\n📌 Gunakan ${prefix}listplugin untuk melihat daftar plugin`);
                }
            }

            pluginCode = fs.readFileSync(pluginPath, 'utf-8');
        }

        // Deteksi nama dari kode jika tidak ada
        if (!caseName) {
            const nameMatch = pluginCode.match(/name\s*:\s*['"]([^'"]+)['"]/);
            if (nameMatch) {
                caseName = nameMatch[1];
            } else {
                caseName = `case_${Date.now()}`;
            }
        }

        // Extract dependencies
        const requireMatches = pluginCode.match(/require\s*\(\s*['"]([^'"]+)['"]\s*\)/g);
        if (requireMatches) {
            requireMatches.forEach(req => {
                const lib = req.match(/['"]([^'"]+)['"]/)[1];
                if (!dependencies.includes(lib) && !lib.startsWith('.')) {
                    dependencies.push(lib);
                }
            });
        }

        // Extract kode dari execute function
        let caseCode = '';
        const executeMatch = pluginCode.match(/execute\s*:\s*async\s*\(\s*([^)]*)\s*\)\s*=>?\s*{([\s\S]*?)}(?=\s*[,;}]|$)/);
        if (executeMatch) {
            let codeContent = executeMatch[2].trim();
            
            // Hapus try-catch wrapper
            codeContent = codeContent.replace(/try\s*{([\s\S]*?)}\s*catch\s*\([^)]*\)\s*{[\s\S]*?}/, (match, inner) => {
                return inner.trim();
            });
            
            // Konversi m.reply ke reply
            codeContent = codeContent.replace(/await\s+m\.reply\s*\(/g, 'reply(');
            codeContent = codeContent.replace(/m\.reply\s*\(/g, 'reply(');
            
            // Konversi return ke break
            codeContent = codeContent.replace(/return;/g, 'break;');
            
            caseCode = codeContent;
        } else {
            caseCode = pluginCode;
        }

        // Buat case block
        let caseBlock = `case '${caseName}': {\n`;
        
        if (dependencies.length > 0) {
            dependencies.forEach(dep => {
                const varName = dep.replace(/[^a-zA-Z0-9]/g, '_');
                caseBlock += `    const ${varName} = require('${dep}');\n`;
            });
            if (dependencies.length > 0) caseBlock += '\n';
        }

        const lines = caseCode.split('\n');
        lines.forEach(line => {
            if (line.trim() !== '') {
                caseBlock += `    ${line}\n`;
            } else {
                caseBlock += '\n';
            }
        });

        caseBlock += '    break;\n';
        caseBlock += '}';

        // Baca satanic.js
        const satanicPath = path.join(__dirname, 'satanic.js');
        if (!fs.existsSync(satanicPath)) {
            return reply('❌ File satanic.js tidak ditemukan!');
        }

        let satanicContent = fs.readFileSync(satanicPath, 'utf-8');

        // Cek apakah case sudah ada
        const caseRegex = new RegExp(`case\\s+['"]${caseName}['"]\\s*:\\s*{`, 'i');
        if (caseRegex.test(satanicContent)) {
            return reply(`⚠️ Case "${caseName}" sudah ada di satanic.js!\n\n` +
                        `📌 Hapus case dulu atau gunakan nama lain`);
        }

        // Cari posisi untuk menambahkan case
        let insertPosition = satanicContent.lastIndexOf('break;');
        if (insertPosition === -1) {
            insertPosition = satanicContent.lastIndexOf('}');
        }

        // Backup satanic.js
        const backupSatanic = `./backup_satanic_${Date.now()}.js`;
        fs.writeFileSync(backupSatanic, satanicContent);

        // Insert case
        let newContent = satanicContent.slice(0, insertPosition) + 
                        '\n\n    ' + caseBlock + '\n' + 
                        satanicContent.slice(insertPosition);

        fs.writeFileSync(satanicPath, newContent);

        // Hapus plugin jika dari file
        if (fromFile && !backup) {
            const pluginPath = path.join('./plugins', `${caseName}.js`);
            if (fs.existsSync(pluginPath)) {
                fs.unlinkSync(pluginPath);
            }
        }

        // Statistik
        const linesCount = caseBlock.split('\n').length;
        
        // Response
        let response = '✅ *CASE BERHASIL DITAMBAHKAN!*\n';
        response += '═══════════════════════════\n\n';
        response += `📌 *Case:* ${caseName}\n`;
        response += `📌 *Sumber:* ${fromFile ? 'File plugin' : 'Reply pesan'}\n`;
        response += `📌 *Baris:* ${linesCount}\n`;
        response += `📌 *Dependencies:* ${dependencies.length > 0 ? dependencies.join(', ') : 'Tidak ada'}\n`;
        response += `📌 *Backup:* ${backupSatanic}\n\n`;
        response += '═══════════════════════════\n';
        response += `📄 *Kode Case:*\n\`\`\`javascript\n`;
        response += caseBlock;
        response += '\n```\n\n';
        response += '═══════════════════════════\n';
        response += `💡 *Cara Menggunakan:*\n`;
        response += `➤ ${prefix}${caseName} [args]\n\n`;
        
        if (fromFile && !backup) {
            response += `⚠️ *Plugin asli telah dihapus!*\n\n`;
        }
        
        response += '⚠️ *Peringatan:*\n';
        response += '➤ Restart bot untuk menerapkan perubahan';

        // Kirim response
        if (response.length > 4000) {
            const chunks = response.match(/.{1,4000}/g);
            for (const chunk of chunks) {
                await reply(chunk);
            }
        } else {
            await reply(response);
        }

        // Kirim file satanic.js
        try {
            await satanic.sendMessage(m.chat, {
                document: fs.readFileSync(satanicPath),
                fileName: 'satanic_updated.js',
                mimetype: 'application/javascript',
                caption: `📎 *satanic.js sudah diupdate!*\n📌 Case ${caseName} telah ditambahkan`
            });
        } catch (e) {}

    } catch (error) {
        console.error('Error in tocase:', error);
        reply(`❌ Terjadi kesalahan: ${error.message}`);
    }
    break;
}
case 'addplugin':
case 'tambahplugin': {
  if (!isCreator) return reply('👑 Khusus owner!');
  if (!text) return reply(`📝 *Cara penggunaan:*\n${prefix + command} [nama_file]\n\n📌 *Contoh:*\n${prefix + command} douyinsearch.js\n\nLalu reply kode plugin yang ingin ditambahkan!`);
  
  const fileName = text.trim();
  
  if (!fileName) return reply('⚠️ Nama file tidak boleh kosong!');
  if (!fileName.endsWith('.js')) return reply('⚠️ Nama file harus berekstensi .js');
  if (fileName.includes('/') || fileName.includes('\\')) {
    return reply('⚠️ Nama file tidak boleh mengandung slash!');
  }
  
  const pluginPath = `./plugins/${fileName}`;
  if (fs.existsSync(pluginPath)) {
    return reply(`⚠️ File "${fileName}" sudah ada!`);
  }
  
  if (!m.quoted) {
    return reply(`⚠️ *Reply pesan yang berisi kode plugin!*\n\n📌 *Cara:*\n1. Kirim pesan berisi kode plugin\n2. Reply pesan tersebut dengan ${prefix + command} ${fileName}`);
  }
  
  let code = m.quoted.text || m.quoted.body || '';
  if (!code) {
    return reply('⚠️ Pesan yang di-reply tidak mengandung kode!');
  }
  
  // Auto convert import ke require
  code = code.replace(/^import\s+(\w+)\s+from\s+['"]([^'"]+)['"]/gm, 'const $1 = require(\'$2\')');
  code = code.replace(/^import\s+\{([^}]+)\}\s+from\s+['"]([^'"]+)['"]/gm, 'const {$1} = require(\'$2\')');
  code = code.replace(/^import\s+\*\s+as\s+(\w+)\s+from\s+['"]([^'"]+)['"]/gm, 'const $1 = require(\'$2\')');
  
  // Auto replace semua variabel koneksi ke satanic
  const connectionVars = ['conn', 'client', 'sock', 'bot', 'tele', 'santu', 'aqua', 'sad'];
  connectionVars.forEach(varName => {
    const regex = new RegExp(`\\b${varName}\\b`, 'g');
    code = code.replace(regex, 'satanic');
  });
  
  // Hapus executePrem
  code = code.replace(/executePrem\s*:/g, 'execute');
  
  // Hapus handler.limit dan handler.register
  code = code.replace(/^handler\.(limit|register)\s*=\s*.+$/gm, '');
  
  const hasModuleExports = code.includes('module.exports');
  
  if (!hasModuleExports) {
    const pluginName = fileName.replace('.js', '');
    
    const requireRegex = /^(const|let|var)\s+(\w+)\s*=\s*require\(['"]([^'"]+)['"]\);/gm;
    const requires = [];
    let match;
    let tempCode = code;
    while ((match = requireRegex.exec(tempCode)) !== null) {
      requires.push(match[0]);
    }
    
    let cleanCode = code.replace(requireRegex, '').trim();
    cleanCode = cleanCode.replace(/^export\s+default\s+handler;?\s*$/gm, '').trim();
    
    const handlerProps = [];
    const propRegex = /^handler\.(\w+)\s*=\s*(.+)$/gm;
    let propMatch;
    while ((propMatch = propRegex.exec(cleanCode)) !== null) {
      const propName = propMatch[1];
      if (propName !== 'limit' && propName !== 'register') {
        const propValue = propMatch[2].trim();
        handlerProps.push({ name: propName, value: propValue });
      }
    }
    
    let finalCode = cleanCode.replace(/^handler\.[\s\S]+?(?=\n\n|$)/gm, '').trim();
    
    let requireSection = requires.length > 0 ? requires.join('\n') + '\n' : '';
    
    const usedParams = [];
    const params = ['satanic', 'm', 'args', 'text', 'q', 'fkontak', 'namaBot', 'global', 'prefix'];
    params.forEach(param => {
      if (finalCode.includes(param)) {
        usedParams.push(param);
      }
    });
    
    let executeParams = 'satanic, m, args';
    if (usedParams.includes('text')) executeParams += ', text';
    if (usedParams.includes('q')) executeParams += ', q';
    if (usedParams.includes('fkontak')) executeParams += ', fkontak';
    if (usedParams.includes('namaBot')) executeParams += ', namaBot';
    if (usedParams.includes('global')) executeParams += ', global';
    if (usedParams.includes('prefix')) executeParams += ', prefix';
    
    let handlerConfig = '';
    if (handlerProps.length > 0) {
      handlerProps.forEach(prop => {
        handlerConfig += `  ${prop.name}: ${prop.value},\n`;
      });
      handlerConfig = `,\n  handler: {\n${handlerConfig}  }`;
    }
    
    code = `// Plugin: ${fileName}
// Dibuat: ${new Date().toLocaleString()}
// Format: CommonJS

${requireSection}module.exports = {
  name: '${pluginName}',
  description: 'Plugin ${fileName}',
  category: 'custom'${handlerConfig},
  execute: async (${executeParams}) => {
    try {
      ${finalCode}
    } catch (e) {
      console.error('Error:', e);
      await m.reply('❌ Error: ' + e.message);
    }
  }
};`;
  } else {
    // Kalo sudah ada module.exports, tetap replace variabel koneksi
    connectionVars.forEach(varName => {
      const regex = new RegExp(`\\b${varName}\\b`, 'g');
      code = code.replace(regex, 'satanic');
    });
  }
  
  if (!fs.existsSync('./plugins')) {
    fs.mkdirSync('./plugins');
  }
  
  fs.writeFileSync(pluginPath, code);
  
  try {
    delete require.cache[require.resolve(path.resolve(pluginPath))];
    const plugin = require(path.resolve(pluginPath));
    const pluginName = fileName.replace('.js', '');
    
    if (typeof plugins === 'object') {
      plugins.set(pluginName, plugin);
    }
    
    await reply(`✅ *Plugin berhasil ditambahkan dan otomatis terload!*\n\n📌 Nama: ${fileName}\n📌 Lokasi: plugins/${fileName}\n📌 Size: ${(code.length / 1024).toFixed(2)} KB\n\n📝 *Cara menggunakan:*\n➤ ${prefix}${pluginName} [args]`);
  } catch (e) {
    await reply(`⚠️ *Plugin gagal di-load!*\n\n📌 Nama: ${fileName}\n📌 Lokasi: plugins/${fileName}\n\n⚠️ Error: ${e.message}\n📝 *Isi plugin:*\n\`\`\`javascript\n${code}\n\`\`\``);
  }
  break;
}
case 'delplugin':
case 'hapusplugin':
    if (!isCreator) return reply('👑 Khusus owner!');
    if (!text) return reply(`📝 *Cara penggunaan:*\n${prefix + command} [nama_file]\n\n📌 *Contoh:*\n${prefix + command} tesplugin.js`);
    
    let hapusFilessa = text.trim();
    
    if (!hapusFilessa) return reply('⚠️ Nama file tidak boleh kosong!');
    if (!hapusFilessa.endsWith('.js')) return reply('⚠️ Nama file harus berekstensi .js');
    if (hapusFilessa.includes('/') || hapusFile.includes('\\')) {
        return reply('⚠️ Nama file tidak boleh mengandung slash!');
    }
    
    let hapusPathv = `./plugins/${hapusFilessa}`;
    if (!fs.existsSync(hapusPathv)) {
        return reply(`⚠️ Plugin "${hapusFilessa}" tidak ditemukan!`);
    }
    
    // Konfirmasi hapus
    if (!text.includes('y')) {
        let stat = fs.statSync(hapusPathv);
        let size = (stat.size / 1024).toFixed(2);
        return reply(`⚠️ *KONFIRMASI HAPUS PLUGIN!*\n\n📌 Nama: ${hapusFilessa}\n📌 Size: ${size} KB\n📌 Lokasi: plugins/${hapusFilessa}\n\n⚠️ *Peringatan:*\n➤ Plugin akan dihapus permanen!\n➤ Tidak bisa dikembalikan!\n\nKetikan: ${prefix + command} ${hapusFilessa} y\n\nuntuk mengkonfirmasi penghapusan.`);
    }
    
    // Hapus file
    let hapusConfirm = hapusFilessa.replace(' y', '');
    let hapusPathConfirm = `./plugins/${hapusConfirm}`;
    
    if (!fs.existsSync(hapusPathConfirm)) {
        return reply(`⚠️ Plugin "${hapusConfirm}" tidak ditemukan!`);
    }
    
    fs.unlinkSync(hapusPathConfirm);
    
    // Reload plugin
    reloadPlugins();
    
    reply(`✅ *Plugin "${hapusConfirm}" berhasil dihapus!*\n\n📌 Lokasi: plugins/${hapusConfirm}\n📌 Total plugin: ${plugins.size}`);
    break;    
 case 'listplugin':
case 'listplugins':
case 'daftarplugin': {
    if (!m.isGroup) return reply('Perintah ini hanya bisa digunakan di grup!');
    if (!isCreator && !isAdmins) return reply('Perintah ini hanya untuk admin grup!');
    
    try {
        const fs = require('fs');
        const path = require('path');
        const pluginDirv = './plugins';
        
        if (!fs.existsSync(pluginDirv)) {
            return reply('📂 Folder plugins tidak ditemukan!');
        }
        
        const filesh = fs.readdirSync(pluginDirv);
        const pluginFilesj = filesh.filter(file => file.endsWith('.js') || file.endsWith('.ts'));
        
        if (pluginFilesj.length === 0) {
            return reply('📭 Tidak ada plugin yang terinstall!');
        }
        
        let pluginListn = '📦 *DAFTAR PLUGIN*\n';
        pluginListn += '═══════════════════════════\n\n';
        
        // Urutkan berdasarkan nama
        pluginFilesj.sort();
        
        // Tampilkan dalam bentuk tabel yang rapi
        pluginFilesj.forEach((file, index) => {
            const filePathb = path.join(pluginDirv, file);
            const stats = fs.statSync(filePathb);
            const size = (stats.size / 1024).toFixed(2);
            const modified = new Date(stats.mtime).toLocaleString('id-ID', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            
            // Cek apakah plugin sedang aktif (ada di memory)
            const pluginName = file.replace('.js', '').replace('.ts', '');
            const isActive = plugins.has(pluginName) ? '✅' : '❌';
            
            pluginListn += `*${index + 1}.* ${file}\n`;
            pluginListn += `   📁 Size: ${size} KB\n`;
            pluginListn += `   🕐 Modified: ${modified}\n`;
            pluginListn += `   📊 Status: ${isActive}\n\n`;
        });
        
        pluginListn += '═══════════════════════════\n';
        pluginListn += `📊 *Total: ${pluginFilesj.length} plugin*\n`;
        pluginListn += `📌 *Aktif: ${Array.from(plugins.keys()).filter(p => pluginFilesj.some(f => f.includes(p))).length} plugin*\n\n`;
        pluginListn += `💡 *Cara menggunakan:*\n`;
        pluginListn += `➤ ${prefix}getplugin - Lihat detail plugin\n`;
        pluginListn += `➤ ${prefix}addplugin - Tambah plugin baru\n`;
        pluginListn += `➤ ${prefix}delplugin - Hapus plugin`;
        
        // Kirim dalam beberapa pesan jika terlalu panjang
        if (pluginListn.length > 4000) {
            const chunks = pluginListn.match(/.{1,4000}/g);
            for (const chunk of chunks) {
                await reply(chunk);
            }
        } else {
            reply(pluginListn);
        }
    } catch (error) {
        console.error('Error listplugin:', error);
        reply('❌ Terjadi kesalahan saat mengambil daftar plugin!\n\n' + error.message);
    }
    break;
}   

case 'clearchat': {
if (!isCreator) return 
satanic.chatModify({ delete: true, lastMessages: [{ key: m.key, messageTimestamp: m.messageTimestamp }] }, m.chat)
}
break
case 'pinchat': {
if (!isCreator) return
if (m.isGroup) return 
satanic.chatModify({ pin: true }, m.chat)
}
break
case 'unpinchat': {
if (!isCreator) return 
if (m.isGroup) return 
satanic.chatModify({ pin: false }, m.chat)
}
break

case 'donate':
case 'donasi':
case 'pay':
case 'payment': {
    await satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});

    async function getMedia(path) {
        return await prepareWAMessageMedia({ image: { url: path } }, { upload: satanic.waUploadToServer });
    }

    let cards = [
        // DANA
        {
            header: proto.Message.InteractiveMessage.Header.create({
                ...(await getMedia(global.danaImage)),
                title: '',
                gifPlayback: false,
                subtitle: namaowner,
                hasMediaAttachment: true
            }),
            body: { text: `> Klik tombol DANA di bawah\n> DANA A/N: ${global.andana}` },
            nativeFlowMessage: {
                buttons: [
                    {
                        "name": "cta_copy",
                        "buttonParamsJson": JSON.stringify({
                            "display_text": "Copy No. DANA",
                            "id": "dana_copy",
                            "copy_code": global.nodana
                        })
                    }
                ]
            }
        },
        // GOPAY
        {
            header: proto.Message.InteractiveMessage.Header.create({
                ...(await getMedia(global.gopayImage)),
                title: '',
                gifPlayback: false,
                subtitle: namaowner,
                hasMediaAttachment: true
            }),
            body: { text: `> Klik tombol GOPAY di bawah\n> GOPAY A/N: ${global.angopay}` },
            nativeFlowMessage: {
                buttons: [
                    {
                        "name": "cta_copy",
                        "buttonParamsJson": JSON.stringify({
                            "display_text": "Copy No. GOPAY",
                            "id": "gopay_copy",
                            "copy_code": global.nogopay
                        })
                    }
                ]
            }
        },
        // SHOPEEPAY
        {
            header: proto.Message.InteractiveMessage.Header.create({
                ...(await getMedia(global.shopeePayImage)),
                title: '',
                gifPlayback: false,
                subtitle: namaowner,
                hasMediaAttachment: true
            }),
            body: { text: `> Klik tombol ShopeePay di bawah\n> ShopeePay A/N: ${global.anshoppepay}` },
            nativeFlowMessage: {
                buttons: [
                    {
                        "name": "cta_copy",
                        "buttonParamsJson": JSON.stringify({
                            "display_text": "Copy No. ShopeePay",
                            "id": "shopeepay_copy",
                            "copy_code": global.noshopeepay
                        })
                    }
                ]
            }
        },
        // QRIS (untuk semua pembayaran)
        {
            header: proto.Message.InteractiveMessage.Header.create({
                ...(await getMedia(global.qris)),
                title: '',
                gifPlayback: false,
                subtitle: namaowner,
                hasMediaAttachment: true
            }),
            body: { text: `> SCAN QRIS di atas untuk semua pembayaran\n> Pastikan nominal sesuai` },
            nativeFlowMessage: {
                buttons: [
                    {
                        "name": "cta_url",
                        "buttonParamsJson": JSON.stringify({
                            "display_text": "Lihat QRIS Full",
                            "url": global.qris,
                            "merchant_url": "https://www.google.com"
                        })
                    }
                ]
            }
        },
        // BCA
        {
            header: proto.Message.InteractiveMessage.Header.create({
                ...(await getMedia(global.bcaImage)),
                title: '',
                gifPlayback: false,
                subtitle: namaowner,
                hasMediaAttachment: true
            }),
            body: { text: `> Transfer ke BCA\n> No. Rekening: ${global.nobca}\n> A/N: ${global.anbca}` },
            nativeFlowMessage: {
                buttons: [
                    {
                        "name": "cta_copy",
                        "buttonParamsJson": JSON.stringify({
                            "display_text": "Copy No. Rekening BCA",
                            "id": "bca_copy",
                            "copy_code": global.nobca
                        })
                    }
                ]
            }
        },
        // BRI
        {
            header: proto.Message.InteractiveMessage.Header.create({
                ...(await getMedia(global.briImage)),
                title: '',
                gifPlayback: false,
                subtitle: namaowner,
                hasMediaAttachment: true
            }),
            body: { text: `> Transfer ke BRI\n> No. Rekening: ${global.nobri}\n> A/N: ${global.anbri}` },
            nativeFlowMessage: {
                buttons: [
                    {
                        "name": "cta_copy",
                        "buttonParamsJson": JSON.stringify({
                            "display_text": "Copy No. Rekening BRI",
                            "id": "bri_copy",
                            "copy_code": global.nobri
                        })
                    }
                ]
            }
        },
        // MANDIRI
        {
            header: proto.Message.InteractiveMessage.Header.create({
                ...(await getMedia(global.mandiriImage)),
                title: '',
                gifPlayback: false,
                subtitle: namaowner,
                hasMediaAttachment: true
            }),
            body: { text: `> Transfer ke Mandiri\n> No. Rekening: ${global.nomandiri}\n> A/N: ${global.anmandiri}` },
            nativeFlowMessage: {
                buttons: [
                    {
                        "name": "cta_copy",
                        "buttonParamsJson": JSON.stringify({
                            "display_text": "Copy No. Rekening Mandiri",
                            "id": "mandiri_copy",
                            "copy_code": global.nomandiri
                        })
                    }
                ]
            }
        }
    ];

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: `Halo @${m.sender.split('@')[0]} , berikut daftar metode pembayaran saya ya~` },
                    footer: { text: `Terima kasih atas dukungannya!` },
                    carouselMessage: {
                        cards: cards,
                        messageVersion: 1
                    }
                }
            }
        }
    }, { quoted: fkontak, userJid: satanic.user.id });

    await satanic.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break;

case 'stopbot': {
    if (!isCreator) return m.reply('❌ Fitur khusus owner!')
    
    await satanic.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    
    await m.reply('🛑 Bot akan dimatikan dalam 3 detik...')
    
    setTimeout(() => {
        console.log('⚠️ Bot dimatikan oleh owner:', m.sender)
        process.exit(0)
    }, 3000)
}
break
case 'stickerpackpin': {
if (!m.isGroup) {
return m.reply('Fitur Khusus Group!');
}
await satanic.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
let args = m.text.split(' ').slice(1);
if (!args.length) {
return m.reply(`📌 Cara pakai:
.stickerpackpin <query> - Cari dan kirim semua pin sebagai sticker pack

📌 Contoh:
.stickerpackpin cat cute
.stickerpackpin anime girl`);
}
const axios = require('axios');
const crypto = require('crypto');
const https = require('https');
const JSZip = require('jszip');
const sharp = require('sharp');
if (!global.getStickerSession) global.getStickerSession = {};
function sha256(buffer) {
return crypto.createHash('sha256').update(buffer).digest();
}
function toB64Url(buffer) {
return Buffer.from(buffer)
.toString('base64')
.replace(/\+/g, '-')
.replace(/\//g, '_')
.replace(/=+$/g, '');
}
function isWebP(buffer) {
if (!buffer || !Buffer.isBuffer(buffer) || buffer.length < 12) return false;
return buffer.toString('ascii', 0, 4) === 'RIFF' &&
buffer.toString('ascii', 8, 12) === 'WEBP';
}
function isAnimatedWebP(buffer) {
if (!isWebP(buffer)) return false;
let offset = 12;
while (offset < buffer.length - 8) {
const chunk = buffer.toString('ascii', offset, offset + 4);
const size = buffer.readUInt32LE(offset + 4);
if (chunk === 'VP8X' && (buffer[offset + 8] & 0x02)) return true;
if (chunk === 'ANIM' || chunk === 'ANMF') return true;
offset += 8 + size + (size % 2);
}
return false;
}
function detectImageFormat(buffer) {
if (!buffer || !Buffer.isBuffer(buffer) || buffer.length < 12) return 'unknown';
try {
const header = buffer.slice(0, 12);
if (header.length >= 4 && header.toString('hex', 0, 4) === '89504e47') return 'png';
if (header.length >= 3 && header.toString('hex', 0, 3) === 'ffd8ff') return 'jpg';
if (header.length >= 12 && header.toString('ascii', 0, 4) === 'RIFF' &&
header.toString('ascii', 8, 12) === 'WEBP') return 'webp';
if (header.length >= 6 && header.toString('hex', 0, 6) === '47494638') return 'gif';
if (header.length >= 2 && header.toString('hex', 0, 2) === '424d') return 'bmp';
if (header.length >= 5 && (header.toString('hex', 0, 5) === '3c3f786d6c' ||
header.toString('hex', 0, 4) === '3c7376')) return 'svg';
return 'unknown';
} catch (e) {
return 'unknown';
}
}
async function convertToWebP(buffer) {
if (!buffer || !Buffer.isBuffer(buffer)) return null;
const format = detectImageFormat(buffer);
try {
if (format === 'webp') return buffer;
if (['svg', 'unknown'].includes(format)) return null;
let sharpInstance = sharp(buffer);
sharpInstance = sharpInstance.resize(512, 512, {
fit: 'contain',
background: { r: 255, g: 255, b: 255, alpha: 0 }
});
return await sharpInstance.webp({
quality: 80,
effort: 4
}).toBuffer();
} catch (error) {
return null;
}
}
function validateSticker(buffer) {
if (!buffer || !Buffer.isBuffer(buffer) || buffer.length < 12) return false;
const format = detectImageFormat(buffer);
const supportedFormats = ['png', 'jpg', 'webp', 'gif', 'bmp'];
return supportedFormats.includes(format);
}
function classifySticker(buffer, stickerMessage) {
if (stickerMessage && stickerMessage.isLottie) {
return { ext: 'json', mimetype: 'application/json', isAnimated: true, isLottie: true };
}
const isAnimated = isWebP(buffer) ? isAnimatedWebP(buffer) : false;
return { ext: 'webp', mimetype: 'image/webp', isAnimated: isAnimated, isLottie: false };
}
async function makeTrayWebp(buffer) {
if (!buffer || !Buffer.isBuffer(buffer)) return await makeBlankTrayWebp();
try {
return await sharp(buffer, { animated: false })
.resize(252, 252, { fit: 'cover' })
.webp()
.toBuffer();
} catch (e) {
return await makeBlankTrayWebp();
}
}
async function makeBlankTrayWebp() {
return await sharp({
create: { width: 252, height: 252, channels: 4, background: { r: 0, g: 0, b: 0, alpha: 0 } }
}).webp().toBuffer();
}
async function makeThumbnailJpeg(buffer) {
if (!buffer || !Buffer.isBuffer(buffer)) {
return await sharp({
create: { width: 252, height: 252, channels: 3, background: { r: 255, g: 255, b: 255 } }
}).jpeg().toBuffer();
}
try {
return await sharp(buffer)
.resize(252, 252, { fit: 'cover' })
.jpeg()
.toBuffer();
} catch (e) {
return await sharp({
create: { width: 252, height: 252, channels: 3, background: { r: 255, g: 255, b: 255 } }
}).jpeg().toBuffer();
}
}
async function uploadToServer(satanic, buffer, { hkdf, mediaPath, mediaKey = crypto.randomBytes(32) }) {
try {
const expanded = Buffer.from(
crypto.hkdfSync('sha256', mediaKey, Buffer.alloc(32), Buffer.from(hkdf), 112)
);
const iv = expanded.subarray(0, 16);
const cipherKey = expanded.subarray(16, 48);
const macKey = expanded.subarray(48, 80);
const cipher = crypto.createCipheriv('aes-256-cbc', cipherKey, iv);
const encrypted = Buffer.concat([cipher.update(buffer), cipher.final()]);
const mac = crypto.createHmac('sha256', macKey).update(iv).update(encrypted).digest().subarray(0, 10);
const encBuffer = Buffer.concat([encrypted, mac]);
const fileSha256 = sha256(buffer);
const fileEncSha256 = sha256(encBuffer);
const iq = await satanic.query({
tag: 'iq',
attrs: { id: satanic.generateMessageTag?.() ?? Date.now().toString(), to: 's.whatsapp.net', type: 'set', xmlns: 'w:m' },
content: [{ tag: 'media_conn', attrs: {} }]
});
const mediaConn = iq.content?.find(v => v.tag === 'media_conn');
if (!mediaConn) throw new Error('media_conn tidak ditemukan');
const auth = mediaConn.attrs?.auth;
if (!auth) throw new Error('auth media_conn tidak ditemukan');
const hosts = (mediaConn.content || [])
.filter(v => v.tag === 'host')
.map(v => v.attrs?.hostname)
.filter(Boolean);
if (!hosts.length) throw new Error('host upload tidak ditemukan');
const token = encodeURIComponent(
fileEncSha256.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '')
);
let lastError;
for (const host of hosts) {
try {
const json = await new Promise((resolve, reject) => {
const url = new URL(`https://${host}${mediaPath}/${token}?auth=${encodeURIComponent(auth)}&token=${token}`);
const req = https.request({
hostname: url.hostname,
port: 443,
path: url.pathname + url.search,
method: 'POST',
headers: {
Origin: 'https://web.whatsapp.com',
Referer: 'https://web.whatsapp.com/',
'Content-Type': 'application/octet-stream',
'Content-Length': encBuffer.length,
},
}, (res) => {
let body = '';
res.on('data', c => body += c);
res.on('end', () => {
if (res.statusCode < 200 || res.statusCode >= 300) {
return reject(new Error(`Upload gagal ${res.statusCode}: ${body}`));
}
try {
resolve(JSON.parse(body));
} catch {
reject(new Error(`Response bukan JSON: ${body}`));
}
});
});
req.on('error', (e) => reject(e));
req.write(encBuffer);
req.end();
});
const directPath = json.direct_path ?? json.directPath ?? json.url ?? json.path;
if (!directPath) throw new Error('directPath tidak ditemukan');
return { mediaKey, fileLength: buffer.length, fileSha256, fileEncSha256, directPath, ...json };
} catch (e) {
lastError = e;
}
}
throw lastError ?? new Error('Semua host upload gagal');
} catch (error) {
throw error;
}
}
async function sendCustomStickerPack(satanic, m, pack, packName = 'Sticker Pack') {
try {
const zip = new JSZip();
const stickersMetadata = [];
for (const item of pack) {
const fileName = `${toB64Url(sha256(item.buffer))}.${item.ext}`;
zip.file(fileName, item.buffer);
stickersMetadata.push({
fileName,
isAnimated: item.isAnimated,
emojis: [''],
accessibilityLabel: '',
isLottie: item.isLottie,
mimetype: item.mimetype,
});
}
const trayIconFileName = 'tray_icon.webp';
const traySource = pack.find(v => !v.isLottie)?.buffer;
const trayBuffer = traySource ? await makeTrayWebp(traySource) : await makeBlankTrayWebp();
zip.file(trayIconFileName, trayBuffer);
const archive = await zip.generateAsync({ type: 'nodebuffer', compression: 'STORE' });
const packUpload = await uploadToServer(satanic, archive, {
hkdf: 'WhatsApp Sticker Pack Keys',
mediaPath: '/mms/sticker-pack',
});
const thumbnailBuffer = await makeThumbnailJpeg(trayBuffer);
const thumbUpload = await uploadToServer(satanic, thumbnailBuffer, {
hkdf: 'WhatsApp Sticker Pack Thumbnail Keys',
mediaPath: '/mms/thumbnail-sticker-pack',
mediaKey: packUpload.mediaKey,
});
await satanic.relayMessage(m.chat, {
messageContextInfo: { messageSecret: crypto.randomBytes(32) },
stickerPackMessage: {
stickerPackId: 'Pack_' + crypto.randomBytes(8).toString('hex'),
name: packName,
publisher: 'Aqua - Multi device',
packDescription: 'Satanic Haxor',
stickers: stickersMetadata,
fileLength: packUpload.fileLength,
fileSha256: packUpload.fileSha256,
fileEncSha256: packUpload.fileEncSha256,
mediaKey: packUpload.mediaKey,
directPath: packUpload.directPath,
mediaKeyTimestamp: Math.floor(Date.now() / 1000),
stickerPackSize: packUpload.fileLength,
stickerPackOrigin: 2,
trayIconFileName,
thumbnailDirectPath: thumbUpload.directPath,
thumbnailSha256: thumbUpload.fileSha256,
thumbnailEncSha256: thumbUpload.fileEncSha256,
thumbnailHeight: 252,
thumbnailWidth: 252,
imageDataHash: thumbUpload.fileSha256.toString('base64'),
},
}, { quoted: m });
} catch (error) {
throw error;
}
}
async function getCookies() {
try {
const response = await axios.get('https://www.pinterest.com/csrf_error/');
const setCookieHeaders = response.headers['set-cookie'];
if (setCookieHeaders) {
const cookies = setCookieHeaders.map(cookieString => {
const cookieParts = cookieString.split(';');
const cookieKeyValue = cookieParts[0].trim();
return cookieKeyValue;
});
return cookies.join('; ');
} else {
return null;
}
} catch (error) {
return null;
}
}
async function pinterest(query) {
try {
const cookies = await getCookies();
if (!cookies) {
return [];
}
const url = 'https://www.pinterest.com/resource/BaseSearchResource/get/';
const params = {
source_url: `/search/pins/?q=${query}`,
data: JSON.stringify({
"options": {
"isPrefetch": false,
"query": query,
"scope": "pins",
"no_fetch_context_on_resource": false
},
"context": {}
}),
_: Date.now()
};
const headers = {
'accept': 'application/json, text/javascript, */*, q=0.01',
'accept-encoding': 'gzip, deflate',
'accept-language': 'en-US,en;q=0.9',
'cookie': cookies,
'dnt': '1',
'referer': 'https://www.pinterest.com/',
'sec-ch-ua': '"Not(A:Brand";v="99", "Microsoft Edge";v="133", "Chromium";v="133"',
'sec-ch-ua-full-version-list': '"Not(A:Brand";v="99.0.0.0", "Microsoft Edge";v="133.0.3065.92", "Chromium";v="133.0.6943.142"',
'sec-ch-ua-mobile': '?0',
'sec-ch-ua-model': '""',
'sec-ch-ua-platform': '"Windows"',
'sec-ch-ua-platform-version': '"10.0.0"',
'sec-fetch-dest': 'empty',
'sec-fetch-mode': 'cors',
'sec-fetch-site': 'same-origin',
'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0',
'x-app-version': 'c056fb7',
'x-pinterest-appstate': 'active',
'x-pinterest-pws-handler': 'www/[username]/[slug].js',
'x-pinterest-source-url': '/hargr003/cat-pictures/',
'x-requested-with': 'XMLHttpRequest'
};
const { data } = await axios.get(url, {
headers: headers,
params: params
})
const container = [];
const results = data.resource_response?.data?.results?.filter((v) => v.images?.orig) || [];
results.forEach((result) => {
container.push({
upload_by: result.pinner?.username || 'Unknown',
fullname: result.pinner?.full_name || 'Unknown',
followers: result.pinner?.follower_count || 0,
caption: result.grid_title || '',
image: result.images?.orig?.url || '',
source: "https://id.pinterest.com/pin/" + result.id,
});
});
return container;
} catch (error) {
return [];
}
}
const query = args.join(' ');
await m.reply(`🔍 Mencari pin dari Pinterest...`);
const pins = await pinterest(query);
if (!pins.length) {
await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
return m.reply('❌ Tidak ditemukan pin dari Pinterest.');
}
await m.reply(`📦 Mendapatkan ${pins.length} pin, mengkonversi ke sticker...`);
let packItems = [];
let successCount = 0;
for (let i = 0; i < pins.length; i++) {
try {
const pin = pins[i];
const img = await axios.get(pin.image, {
responseType: 'arraybuffer',
timeout: 30000
});
let buffer = Buffer.from(img.data);
if (!validateSticker(buffer)) continue;
let webpBuffer = buffer;
const format = detectImageFormat(buffer);
if (format !== 'webp') {
webpBuffer = await convertToWebP(buffer);
if (!webpBuffer) continue;
}
const classification = classifySticker(webpBuffer, { isLottie: false });
packItems.push({
buffer: webpBuffer,
ext: classification.ext,
isAnimated: classification.isAnimated,
isLottie: classification.isLottie,
mimetype: classification.mimetype
});
successCount++;
} catch (e) {}
}
if (!packItems.length) {
await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
return m.reply('❌ Gagal mengkonversi pin ke sticker');
}
await m.reply(`✨ Mengirim ${packItems.length} sticker...`);
try {
await sendCustomStickerPack(satanic, m, packItems, `Pinterest - ${query}`);
await m.reply(`✅ Berhasil mengirim ${packItems.length} sticker dari Pinterest`);
await satanic.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
} catch (error) {
await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
m.reply(`❌ Error: ${error.message}`);
}
break;
}
case 'stickerpack': {
if (!m.isGroup) {
return m.reply('Fitur Khusus Group!');
}
await satanic.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
let args = m.text.split(' ').slice(1);
if (!args.length) {
return m.reply(`📌 Cara pakai:
.stickerpack <query> - Cari dan tampilkan daftar
.stickerpack <nomor> - Ambil pack berdasarkan nomor

📌 Contoh:
.stickerpack nailong
.stickerpack 1
.stickerpack 2`);
}
const axios = require('axios');
const crypto = require('crypto');
const https = require('https');
const JSZip = require('jszip');
const sharp = require('sharp');
if (!global.getStickerSession) global.getStickerSession = {};
if (!global.searchResult) global.searchResult = {};
function sha256(buffer) {
return crypto.createHash('sha256').update(buffer).digest();
}
function toB64Url(buffer) {
return Buffer.from(buffer)
.toString('base64')
.replace(/\+/g, '-')
.replace(/\//g, '_')
.replace(/=+$/g, '');
}
function isWebP(buffer) {
if (!buffer || !Buffer.isBuffer(buffer) || buffer.length < 12) return false;
return buffer.toString('ascii', 0, 4) === 'RIFF' &&
buffer.toString('ascii', 8, 12) === 'WEBP';
}
function isAnimatedWebP(buffer) {
if (!isWebP(buffer)) return false;
let offset = 12;
while (offset < buffer.length - 8) {
const chunk = buffer.toString('ascii', offset, offset + 4);
const size = buffer.readUInt32LE(offset + 4);
if (chunk === 'VP8X' && (buffer[offset + 8] & 0x02)) return true;
if (chunk === 'ANIM' || chunk === 'ANMF') return true;
offset += 8 + size + (size % 2);
}
return false;
}
function detectImageFormat(buffer) {
if (!buffer || !Buffer.isBuffer(buffer) || buffer.length < 12) return 'unknown';
try {
const header = buffer.slice(0, 12);
if (header.length >= 4 && header.toString('hex', 0, 4) === '89504e47') return 'png';
if (header.length >= 3 && header.toString('hex', 0, 3) === 'ffd8ff') return 'jpg';
if (header.length >= 12 && header.toString('ascii', 0, 4) === 'RIFF' &&
header.toString('ascii', 8, 12) === 'WEBP') return 'webp';
if (header.length >= 6 && header.toString('hex', 0, 6) === '47494638') return 'gif';
if (header.length >= 2 && header.toString('hex', 0, 2) === '424d') return 'bmp';
if (header.length >= 5 && (header.toString('hex', 0, 5) === '3c3f786d6c' ||
header.toString('hex', 0, 4) === '3c7376')) return 'svg';
return 'unknown';
} catch (e) {
return 'unknown';
}
}
async function convertToWebP(buffer) {
if (!buffer || !Buffer.isBuffer(buffer)) return null;
const format = detectImageFormat(buffer);
try {
if (format === 'webp') return buffer;
if (['svg', 'unknown'].includes(format)) return null;
let sharpInstance = sharp(buffer);
sharpInstance = sharpInstance.resize(512, 512, {
fit: 'contain',
background: { r: 255, g: 255, b: 255, alpha: 0 }
});
return await sharpInstance.webp({
quality: 80,
effort: 4
}).toBuffer();
} catch (error) {
return null;
}
}
function validateSticker(buffer) {
if (!buffer || !Buffer.isBuffer(buffer) || buffer.length < 12) return false;
const format = detectImageFormat(buffer);
const supportedFormats = ['png', 'jpg', 'webp', 'gif', 'bmp'];
return supportedFormats.includes(format);
}
function classifySticker(buffer, stickerMessage) {
if (stickerMessage && stickerMessage.isLottie) {
return { ext: 'json', mimetype: 'application/json', isAnimated: true, isLottie: true };
}
const isAnimated = isWebP(buffer) ? isAnimatedWebP(buffer) : false;
return { ext: 'webp', mimetype: 'image/webp', isAnimated: isAnimated, isLottie: false };
}
async function makeTrayWebp(buffer) {
if (!buffer || !Buffer.isBuffer(buffer)) return await makeBlankTrayWebp();
try {
return await sharp(buffer, { animated: false })
.resize(252, 252, { fit: 'cover' })
.webp()
.toBuffer();
} catch (e) {
return await makeBlankTrayWebp();
}
}
async function makeBlankTrayWebp() {
return await sharp({
create: { width: 252, height: 252, channels: 4, background: { r: 0, g: 0, b: 0, alpha: 0 } }
}).webp().toBuffer();
}
async function makeThumbnailJpeg(buffer) {
if (!buffer || !Buffer.isBuffer(buffer)) {
return await sharp({
create: { width: 252, height: 252, channels: 3, background: { r: 255, g: 255, b: 255 } }
}).jpeg().toBuffer();
}
try {
return await sharp(buffer)
.resize(252, 252, { fit: 'cover' })
.jpeg()
.toBuffer();
} catch (e) {
return await sharp({
create: { width: 252, height: 252, channels: 3, background: { r: 255, g: 255, b: 255 } }
}).jpeg().toBuffer();
}
}
async function uploadToServer(satanic, buffer, { hkdf, mediaPath, mediaKey = crypto.randomBytes(32) }) {
try {
const expanded = Buffer.from(
crypto.hkdfSync('sha256', mediaKey, Buffer.alloc(32), Buffer.from(hkdf), 112)
);
const iv = expanded.subarray(0, 16);
const cipherKey = expanded.subarray(16, 48);
const macKey = expanded.subarray(48, 80);
const cipher = crypto.createCipheriv('aes-256-cbc', cipherKey, iv);
const encrypted = Buffer.concat([cipher.update(buffer), cipher.final()]);
const mac = crypto.createHmac('sha256', macKey).update(iv).update(encrypted).digest().subarray(0, 10);
const encBuffer = Buffer.concat([encrypted, mac]);
const fileSha256 = sha256(buffer);
const fileEncSha256 = sha256(encBuffer);
const iq = await satanic.query({
tag: 'iq',
attrs: { id: satanic.generateMessageTag?.() ?? Date.now().toString(), to: 's.whatsapp.net', type: 'set', xmlns: 'w:m' },
content: [{ tag: 'media_conn', attrs: {} }]
});
const mediaConn = iq.content?.find(v => v.tag === 'media_conn');
if (!mediaConn) throw new Error('media_conn tidak ditemukan');
const auth = mediaConn.attrs?.auth;
if (!auth) throw new Error('auth media_conn tidak ditemukan');
const hosts = (mediaConn.content || [])
.filter(v => v.tag === 'host')
.map(v => v.attrs?.hostname)
.filter(Boolean);
if (!hosts.length) throw new Error('host upload tidak ditemukan');
const token = encodeURIComponent(
fileEncSha256.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '')
);
let lastError;
for (const host of hosts) {
try {
const json = await new Promise((resolve, reject) => {
const url = new URL(`https://${host}${mediaPath}/${token}?auth=${encodeURIComponent(auth)}&token=${token}`);
const req = https.request({
hostname: url.hostname,
port: 443,
path: url.pathname + url.search,
method: 'POST',
headers: {
Origin: 'https://web.whatsapp.com',
Referer: 'https://web.whatsapp.com/',
'Content-Type': 'application/octet-stream',
'Content-Length': encBuffer.length,
},
}, (res) => {
let body = '';
res.on('data', c => body += c);
res.on('end', () => {
if (res.statusCode < 200 || res.statusCode >= 300) {
return reject(new Error(`Upload gagal ${res.statusCode}: ${body}`));
}
try {
resolve(JSON.parse(body));
} catch {
reject(new Error(`Response bukan JSON: ${body}`));
}
});
});
req.on('error', (e) => reject(e));
req.write(encBuffer);
req.end();
});
const directPath = json.direct_path ?? json.directPath ?? json.url ?? json.path;
if (!directPath) throw new Error('directPath tidak ditemukan');
return { mediaKey, fileLength: buffer.length, fileSha256, fileEncSha256, directPath, ...json };
} catch (e) {
lastError = e;
}
}
throw lastError ?? new Error('Semua host upload gagal');
} catch (error) {
throw error;
}
}
async function sendCustomStickerPack(satanic, m, pack, packName = 'Sticker Pack') {
try {
const zip = new JSZip();
const stickersMetadata = [];
for (const item of pack) {
const fileName = `${toB64Url(sha256(item.buffer))}.${item.ext}`;
zip.file(fileName, item.buffer);
stickersMetadata.push({
fileName,
isAnimated: item.isAnimated,
emojis: [''],
accessibilityLabel: '',
isLottie: item.isLottie,
mimetype: item.mimetype,
});
}
const trayIconFileName = 'tray_icon.webp';
const traySource = pack.find(v => !v.isLottie)?.buffer;
const trayBuffer = traySource ? await makeTrayWebp(traySource) : await makeBlankTrayWebp();
zip.file(trayIconFileName, trayBuffer);
const archive = await zip.generateAsync({ type: 'nodebuffer', compression: 'STORE' });
const packUpload = await uploadToServer(satanic, archive, {
hkdf: 'WhatsApp Sticker Pack Keys',
mediaPath: '/mms/sticker-pack',
});
const thumbnailBuffer = await makeThumbnailJpeg(trayBuffer);
const thumbUpload = await uploadToServer(satanic, thumbnailBuffer, {
hkdf: 'WhatsApp Sticker Pack Thumbnail Keys',
mediaPath: '/mms/thumbnail-sticker-pack',
mediaKey: packUpload.mediaKey,
});
await satanic.relayMessage(m.chat, {
messageContextInfo: { messageSecret: crypto.randomBytes(32) },
stickerPackMessage: {
stickerPackId: 'Pack_' + crypto.randomBytes(8).toString('hex'),
name: packName,
publisher: 'Aqua- Multi Device',
packDescription: 'Satanic Haxor ',
stickers: stickersMetadata,
fileLength: packUpload.fileLength,
fileSha256: packUpload.fileSha256,
fileEncSha256: packUpload.fileEncSha256,
mediaKey: packUpload.mediaKey,
directPath: packUpload.directPath,
mediaKeyTimestamp: Math.floor(Date.now() / 1000),
stickerPackSize: packUpload.fileLength,
stickerPackOrigin: 2,
trayIconFileName,
thumbnailDirectPath: thumbUpload.directPath,
thumbnailSha256: thumbUpload.fileSha256,
thumbnailEncSha256: thumbUpload.fileEncSha256,
thumbnailHeight: 252,
thumbnailWidth: 252,
imageDataHash: thumbUpload.fileSha256.toString('base64'),
},
}, { quoted: m });
} catch (error) {
throw error;
}
}
class StickerPackScraper {
async search(query, page = 1) {
try {
const res = await axios.post(
'https://getstickerpack.com/api/v1/stickerdb/search',
{ query, page },
{ timeout: 15000 }
);
if (!res.data?.data) return [];
return res.data.data.map((v, i) => ({
no: i + 1,
name: v.title,
slug: v.slug,
download: v.download_counter || 0,
sticker_count: v.sticker_count || 0,
author: v.author || 'Unknown'
}));
} catch (e) {
return [];
}
}
async detail(slug) {
try {
const res = await axios.get(
`https://getstickerpack.com/api/v1/stickerdb/stickers/${slug}`,
{ timeout: 15000 }
);
const data = res.data?.data;
if (!data?.images) throw 'Invalid response';
return {
title: data.title,
author: data.author || 'Unknown',
stickers: data.images.map(v => ({
image: `https://s3.getstickerpack.com/${v.url}`,
animated: v.is_animated !== 0
}))
};
} catch (e) {
throw 'Gagal ambil detail';
}
}
}
const scraper = new StickerPackScraper();
const chatId = m.chat;
if (!global.searchResult[chatId]) global.searchResult[chatId] = { query: '', packs: [], timestamp: 0 };
const firstArg = args[0];
if (!isNaN(firstArg) && parseInt(firstArg) > 0) {
const index = parseInt(firstArg) - 1;
const saved = global.searchResult[chatId];
const now = Date.now();
if (saved.packs.length === 0 || (now - saved.timestamp) > 120000) {
return m.reply('⚠️ Session telah berakhir. Silakan cari ulang dengan .stickerpack <query>');
}
if (index >= saved.packs.length) {
let listMessage = '📦 *HASIL STICKER PACK*\n';
listMessage += `📌 *Kata Kunci:* ${saved.query}\n\n`;
saved.packs.slice(0, 10).forEach((p, i) => {
listMessage += `${i + 1}. ${p.name}\n`;
listMessage += `   📥 Download: ${p.download}\n\n`;
});
if (saved.packs.length > 10) {
listMessage += `_... dan ${saved.packs.length - 10} pack lainnya_\n\n`;
}
listMessage += `───────────────────\n`;
listMessage += `📝 Ketik nomor (1-${Math.min(saved.packs.length, 10)}) untuk download\nContoh : .stickerpack 2\n`;
listMessage += `⏰ Session berakhir dalam 2 menit`;
return m.reply(listMessage);
}
const pick = saved.packs[index];
await satanic.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
await m.reply(`✨ Mengirim *${pick.name}*...`);
try {
const res = await scraper.detail(pick.slug);
if (!res.stickers.length) return m.reply('❌ Sticker pack kosong.');
let stickers = res.stickers;
let packItems = [];
for (let s of stickers) {
try {
const img = await axios.get(s.image, {
responseType: 'arraybuffer',
timeout: 15000
});
let buffer = Buffer.from(img.data);
if (!validateSticker(buffer)) continue;
let webpBuffer = buffer;
const format = detectImageFormat(buffer);
if (format !== 'webp') {
webpBuffer = await convertToWebP(buffer);
if (!webpBuffer) continue;
}
const classification = classifySticker(webpBuffer, { isLottie: false });
packItems.push({
buffer: webpBuffer,
ext: classification.ext,
isAnimated: classification.isAnimated,
isLottie: classification.isLottie,
mimetype: classification.mimetype
});
} catch (e) {}
}
if (!packItems.length) {
await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
return m.reply('❌ Gagal download sticker');
}
await sendCustomStickerPack(satanic, m, packItems, res.title);
await m.reply(`✅ Berhasil mengirim pack sticker "${res.title}" (${packItems.length} sticker)`);
await satanic.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
} catch (error) {
await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
m.reply(`❌ Error: ${error.message}`);
}
return;
}
const query = args.join(' ');
const packs = await scraper.search(query);
if (!packs.length) {
await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
return m.reply('❌ Sticker pack tidak ditemukan.');
}
global.searchResult[chatId] = {
query: query,
packs: packs,
timestamp: Date.now()
};
let listMessage = '📦 *HASIL STICKER PACK*\n';
listMessage += `📌 *Kata Kunci:* ${query}\n\n`;
packs.slice(0, 10).forEach((p, i) => {
listMessage += `${i + 1}. ${p.name}\n`;
listMessage += `   📥 Download: ${p.download}\n\n`;
});
if (packs.length > 10) {
listMessage += `_... dan ${packs.length - 10} pack lainnya_\n\n`;
}
listMessage += `───────────────────\n`;
listMessage += `📝 Ketik nomor (1-${Math.min(packs.length, 10)}) untuk download\n`;
listMessage += `⏰ Session berakhir dalam 2 menit`;
await satanic.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
m.reply(listMessage);
break;
}
case 'telestick': {
if (!m.isGroup) {
return m.reply('Fitur Khusus Group!');
}
await satanic.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
let args = m.text.split(' ').slice(1);
if (!args.length) {
return m.reply(`📌 Cara pakai:
.telestick <url> - Ambil semua sticker dari Telegram

📌 Contoh:
.telestick https://t.me/addstickers/NekobotPack
.telestick https://t.me/addstickers/AnimeSticker`);
}
const axios = require('axios');
const crypto = require('crypto');
const https = require('https');
const JSZip = require('jszip');
const sharp = require('sharp');
const botToken = '7935827856:AAGdbLXArulCigWyi6gqR07gi--ZPm7ewhc';
if (!global.getStickerSession) global.getStickerSession = {};
function sha256(buffer) {
return crypto.createHash('sha256').update(buffer).digest();
}
function toB64Url(buffer) {
return Buffer.from(buffer)
.toString('base64')
.replace(/\+/g, '-')
.replace(/\//g, '_')
.replace(/=+$/g, '');
}
function isWebP(buffer) {
if (!buffer || !Buffer.isBuffer(buffer) || buffer.length < 12) return false;
return buffer.toString('ascii', 0, 4) === 'RIFF' &&
buffer.toString('ascii', 8, 12) === 'WEBP';
}
function isAnimatedWebP(buffer) {
if (!isWebP(buffer)) return false;
let offset = 12;
while (offset < buffer.length - 8) {
const chunk = buffer.toString('ascii', offset, offset + 4);
const size = buffer.readUInt32LE(offset + 4);
if (chunk === 'VP8X' && (buffer[offset + 8] & 0x02)) return true;
if (chunk === 'ANIM' || chunk === 'ANMF') return true;
offset += 8 + size + (size % 2);
}
return false;
}
function detectImageFormat(buffer) {
if (!buffer || !Buffer.isBuffer(buffer) || buffer.length < 12) return 'unknown';
try {
const header = buffer.slice(0, 12);
if (header.length >= 4 && header.toString('hex', 0, 4) === '89504e47') return 'png';
if (header.length >= 3 && header.toString('hex', 0, 3) === 'ffd8ff') return 'jpg';
if (header.length >= 12 && header.toString('ascii', 0, 4) === 'RIFF' &&
header.toString('ascii', 8, 12) === 'WEBP') return 'webp';
if (header.length >= 6 && header.toString('hex', 0, 6) === '47494638') return 'gif';
if (header.length >= 2 && header.toString('hex', 0, 2) === '424d') return 'bmp';
return 'unknown';
} catch (e) {
return 'unknown';
}
}
async function convertToWebP(buffer) {
if (!buffer || !Buffer.isBuffer(buffer)) return null;
const format = detectImageFormat(buffer);
try {
if (format === 'webp') return buffer;
if (format === 'unknown') return null;
let sharpInstance = sharp(buffer);
sharpInstance = sharpInstance.resize(512, 512, {
fit: 'contain',
background: { r: 255, g: 255, b: 255, alpha: 0 }
});
return await sharpInstance.webp({
quality: 80,
effort: 4
}).toBuffer();
} catch (error) {
return null;
}
}
function validateSticker(buffer) {
if (!buffer || !Buffer.isBuffer(buffer) || buffer.length < 12) return false;
const format = detectImageFormat(buffer);
const supportedFormats = ['png', 'jpg', 'webp', 'gif', 'bmp'];
return supportedFormats.includes(format);
}
function classifySticker(buffer, stickerMessage) {
if (stickerMessage && stickerMessage.isLottie) {
return { ext: 'json', mimetype: 'application/json', isAnimated: true, isLottie: true };
}
const isAnimated = isWebP(buffer) ? isAnimatedWebP(buffer) : false;
return { ext: 'webp', mimetype: 'image/webp', isAnimated: isAnimated, isLottie: false };
}
async function makeTrayWebp(buffer) {
if (!buffer || !Buffer.isBuffer(buffer)) return await makeBlankTrayWebp();
try {
return await sharp(buffer, { animated: false })
.resize(252, 252, { fit: 'cover' })
.webp()
.toBuffer();
} catch (e) {
return await makeBlankTrayWebp();
}
}
async function makeBlankTrayWebp() {
return await sharp({
create: { width: 252, height: 252, channels: 4, background: { r: 0, g: 0, b: 0, alpha: 0 } }
}).webp().toBuffer();
}
async function makeThumbnailJpeg(buffer) {
if (!buffer || !Buffer.isBuffer(buffer)) {
return await sharp({
create: { width: 252, height: 252, channels: 3, background: { r: 255, g: 255, b: 255 } }
}).jpeg().toBuffer();
}
try {
return await sharp(buffer)
.resize(252, 252, { fit: 'cover' })
.jpeg()
.toBuffer();
} catch (e) {
return await sharp({
create: { width: 252, height: 252, channels: 3, background: { r: 255, g: 255, b: 255 } }
}).jpeg().toBuffer();
}
}
async function uploadToServer(satanic, buffer, { hkdf, mediaPath, mediaKey = crypto.randomBytes(32) }) {
try {
const expanded = Buffer.from(
crypto.hkdfSync('sha256', mediaKey, Buffer.alloc(32), Buffer.from(hkdf), 112)
);
const iv = expanded.subarray(0, 16);
const cipherKey = expanded.subarray(16, 48);
const macKey = expanded.subarray(48, 80);
const cipher = crypto.createCipheriv('aes-256-cbc', cipherKey, iv);
const encrypted = Buffer.concat([cipher.update(buffer), cipher.final()]);
const mac = crypto.createHmac('sha256', macKey).update(iv).update(encrypted).digest().subarray(0, 10);
const encBuffer = Buffer.concat([encrypted, mac]);
const fileSha256 = sha256(buffer);
const fileEncSha256 = sha256(encBuffer);
const iq = await satanic.query({
tag: 'iq',
attrs: { id: satanic.generateMessageTag?.() ?? Date.now().toString(), to: 's.whatsapp.net', type: 'set', xmlns: 'w:m' },
content: [{ tag: 'media_conn', attrs: {} }]
});
const mediaConn = iq.content?.find(v => v.tag === 'media_conn');
if (!mediaConn) throw new Error('media_conn tidak ditemukan');
const auth = mediaConn.attrs?.auth;
if (!auth) throw new Error('auth media_conn tidak ditemukan');
const hosts = (mediaConn.content || [])
.filter(v => v.tag === 'host')
.map(v => v.attrs?.hostname)
.filter(Boolean);
if (!hosts.length) throw new Error('host upload tidak ditemukan');
const token = encodeURIComponent(
fileEncSha256.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '')
);
let lastError;
for (const host of hosts) {
try {
const json = await new Promise((resolve, reject) => {
const url = new URL(`https://${host}${mediaPath}/${token}?auth=${encodeURIComponent(auth)}&token=${token}`);
const req = https.request({
hostname: url.hostname,
port: 443,
path: url.pathname + url.search,
method: 'POST',
headers: {
Origin: 'https://web.whatsapp.com',
Referer: 'https://web.whatsapp.com/',
'Content-Type': 'application/octet-stream',
'Content-Length': encBuffer.length,
},
}, (res) => {
let body = '';
res.on('data', c => body += c);
res.on('end', () => {
if (res.statusCode < 200 || res.statusCode >= 300) {
return reject(new Error(`Upload gagal ${res.statusCode}: ${body}`));
}
try {
resolve(JSON.parse(body));
} catch {
reject(new Error(`Response bukan JSON: ${body}`));
}
});
});
req.on('error', (e) => reject(e));
req.write(encBuffer);
req.end();
});
const directPath = json.direct_path ?? json.directPath ?? json.url ?? json.path;
if (!directPath) throw new Error('directPath tidak ditemukan');
return { mediaKey, fileLength: buffer.length, fileSha256, fileEncSha256, directPath, ...json };
} catch (e) {
lastError = e;
}
}
throw lastError ?? new Error('Semua host upload gagal');
} catch (error) {
throw error;
}
}
async function sendCustomStickerPack(satanic, m, pack, packName = 'Sticker Pack') {
try {
const zip = new JSZip();
const stickersMetadata = [];
for (const item of pack) {
const fileName = `${toB64Url(sha256(item.buffer))}.${item.ext}`;
zip.file(fileName, item.buffer);
stickersMetadata.push({
fileName,
isAnimated: item.isAnimated,
emojis: [''],
accessibilityLabel: '',
isLottie: item.isLottie,
mimetype: item.mimetype,
});
}
const trayIconFileName = 'tray_icon.webp';
const traySource = pack.find(v => !v.isLottie)?.buffer;
const trayBuffer = traySource ? await makeTrayWebp(traySource) : await makeBlankTrayWebp();
zip.file(trayIconFileName, trayBuffer);
const archive = await zip.generateAsync({ type: 'nodebuffer', compression: 'STORE' });
const packUpload = await uploadToServer(satanic, archive, {
hkdf: 'WhatsApp Sticker Pack Keys',
mediaPath: '/mms/sticker-pack',
});
const thumbnailBuffer = await makeThumbnailJpeg(trayBuffer);
const thumbUpload = await uploadToServer(satanic, thumbnailBuffer, {
hkdf: 'WhatsApp Sticker Pack Thumbnail Keys',
mediaPath: '/mms/thumbnail-sticker-pack',
mediaKey: packUpload.mediaKey,
});
await satanic.relayMessage(m.chat, {
messageContextInfo: { messageSecret: crypto.randomBytes(32) },
stickerPackMessage: {
stickerPackId: 'Pack_' + crypto.randomBytes(8).toString('hex'),
name: packName,
publisher: 'Bot WhatsApp',
packDescription: 'Generated from Telegram',
stickers: stickersMetadata,
fileLength: packUpload.fileLength,
fileSha256: packUpload.fileSha256,
fileEncSha256: packUpload.fileEncSha256,
mediaKey: packUpload.mediaKey,
directPath: packUpload.directPath,
mediaKeyTimestamp: Math.floor(Date.now() / 1000),
stickerPackSize: packUpload.fileLength,
stickerPackOrigin: 2,
trayIconFileName,
thumbnailDirectPath: thumbUpload.directPath,
thumbnailSha256: thumbUpload.fileSha256,
thumbnailEncSha256: thumbUpload.fileEncSha256,
thumbnailHeight: 252,
thumbnailWidth: 252,
imageDataHash: thumbUpload.fileSha256.toString('base64'),
},
}, { quoted: m });
} catch (error) {
throw error;
}
}
const url = args[0];
const match = url.match(/https:\/\/t\.me\/addstickers\/([^\/\?#]+)/);
if (!match) {
await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
return m.reply('❌ URL Telegram sticker tidak valid!');
}
await m.reply(`🔍 Mengambil sticker pack dari Telegram...`);
try {
const { data: a } = await axios.get(
`https://api.telegram.org/bot${botToken}/getStickerSet?name=${match[1]}`
);
if (!a.result || !a.result.stickers) {
throw new Error('Sticker pack tidak ditemukan');
}
await m.reply(`📦 Mendapatkan ${a.result.stickers.length} sticker, mengkonversi...`);
const stickerUrls = [];
for (const sticker of a.result.stickers) {
const { data: b } = await axios.get(
`https://api.telegram.org/bot${botToken}/getFile?file_id=${sticker.file_id}`
);
stickerUrls.push({
is_animated: sticker.is_animated || false,
is_video: sticker.is_video || false,
url: `https://api.telegram.org/file/bot${botToken}/${b.result.file_path}`
});
}
let packItems = [];
let successCount = 0;
for (let i = 0; i < stickerUrls.length; i++) {
try {
const s = stickerUrls[i];
const img = await axios.get(s.url, {
responseType: 'arraybuffer',
timeout: 30000
});
let buffer = Buffer.from(img.data);
if (!validateSticker(buffer)) continue;
let webpBuffer = buffer;
const format = detectImageFormat(buffer);
if (format !== 'webp') {
webpBuffer = await convertToWebP(buffer);
if (!webpBuffer) continue;
}
const classification = classifySticker(webpBuffer, { isLottie: s.is_animated });
packItems.push({
buffer: webpBuffer,
ext: classification.ext,
isAnimated: classification.isAnimated || s.is_animated,
isLottie: classification.isLottie || s.is_animated,
mimetype: classification.mimetype
});
successCount++;
} catch (e) {}
}
if (!packItems.length) {
await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
return m.reply('❌ Gagal mengkonversi sticker');
}
await sendCustomStickerPack(satanic, m, packItems, a.result.title || 'Telegram Sticker');
await m.reply(`✅ Berhasil mengirim ${packItems.length} sticker dari Telegram`);
await satanic.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
} catch (error) {
await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
m.reply(`❌ Error: ${error.message}`);
}
break;
}

case 'upswtext':
case 'upswteks': {
if (!isCreator) return
 if (!text) return reply('Text?')
 await satanic.sendMessage('status@broadcast', { text: text }, { backgroundColor: '#FF000000', font: 3, statusJidList: Object.keys(global.db.users) })
reply('done')
}
break
case 'upswvideo': {
const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || "";
 if (!isCreator) return
 if (!text) return reply('Text?')              
               if (/video/.test(mime)) {
                  var videosw = await satanic.downloadAndSaveMediaMessage(quoted)
                  await satanic.sendMessage('status@broadcast', {
                     video: {
                        url: videosw
                     },
                     caption: text ? text : ''
                  }, { statusJidList: Object.keys(global.db.users) })
                  reply('done')
               } else {
                  reply('Reply to video')
               }
            }
            break
             case 'bioskop':
case 'cinema': {
async function cinema() {
    try {
        const response = await axios.get('https://21cineplex.com/')
        const html = response.data;
        const $ = cheerio.load(html)

        const results = []

        $('.col-3 .movie').each((index, element) => {
            const movieTitle = $(element).find('.movie-desc h4').text().trim();
            const movieLabel = $(element).find('.movie-desc span.movie-label img').attr('src')
            const moviePoster = $(element).find('.movie-poster img').attr('src')
            const movieLink = $(element).find('a').attr('href')

            const data = {
                title: movieTitle,
                label: movieLabel,
                poster: moviePoster,
                link: movieLink
            };

            results.push(data)
        })

        return results 
    } catch (error) {
        console.error(error)
        return []
    }
}
  try {
    const wait = await reply('🎥 Loading film...');
    
    const films = await cinema();
    
    if (!films || films.length === 0) {
      if (wait && wait.key) {
        try { await satanic.sendMessage(m.chat, { delete: wait.key }) } catch(e) {}
      }
      return reply('❌ Film tidak ditemukan');
    }
    
    if (wait && wait.key) {
      try { await satanic.sendMessage(m.chat, { delete: wait.key }) } catch(e) {}
    }
    
    // Buat list film
    let list = `🎬 *FILM BIOSKOP TERBARU*\n\n`;
    
    films.slice(0, 50).forEach((film, i) => {
      list += `${i+1}. ${film.title}\n`;
    });
    
    list += `\n📊 ${films.length} film tersedia\n🔗 https://21cineplex.com`;
    
    await satanic.sendMessage(m.chat, { 
      text: list 
    }, { quoted: fkontak });
    
  } catch (error) {
    console.error(error);
    reply('❌ Error');
  }
}
break
case 'colongsw':
    if (m.quoted?.chat != 'status@broadcast') return reply(`Quote Pesan Status`)
    try {
        let buffer = await m.quoted.download()
        let mediaType = m.quoted.mtype
        
        if (mediaType === 'imageMessage') {
            await satanic.sendMessage(m.chat, { image: buffer }, { quoted: fakeQuoted })
        } else if (mediaType === 'videoMessage') {
            await satanic.sendMessage(m.chat, { video: buffer }, { quoted: fkontak })
        } else {
            // Jika bukan gambar/video, kirim teksnya saja
            await reply(m.chat, m.quoted.text, m)
        }
    } catch (e) {
        console.log(e)
        await reply(m.chat, m.quoted.text, m)
    }
    break
            case 'statusimg':
            case 'statusimage':
            case 'upswimg': {
if (!isCreator) return
 if (!text) return reply('Text?')            
const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || "";
    
               if (/image/.test(mime)) {
                  var imagesw = await satanic.downloadAndSaveMediaMessage(quoted)
                  await satanic.sendMessage('status@broadcast', {
                     image: {
                        url: imagesw
                     },
                     caption: text ? text : ''
                  }, { statusJidList: Object.keys(global.db.users)})
                  reply('done')
               } else {
                  reply('Reply to image')
               }
            }
            break
            case 'statusaudio':
            case 'upswaudio': {
if (!isCreator) return
 if (!text) return reply('Text?')
 const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || "";
    
               if (/audio/.test(mime)) {
                  var audiosw = await satanic.downloadAndSaveMediaMessage(quoted)
                  await satanic.sendMessage('status@broadcast', {
                     audio: {
                        url: audiosw
                     },
                     mimetype: 'audio/mp4',
                     ptt: true
                  }, {
                     backgroundColor: '#FF000000',
                     statusJidList: Object.keys(global.db.users)
                  })
                 reply('done')
               } else {
                  reply('Reply to audio')
               }
            }
            break

case 'rules':
  let rulesText = `
╭━━━〔 📜 *RULES BOT* 〕━━━⬣
│
│ 1. ✧ Dilarang melakukan spam ke bot.
│    ❗ Jika ketahuan akan di banned.
│
│ 2. ✧ Jika bot tidak menjawab 1x, coba lagi.
│    ⚠️ Jika 2x tidak menjawab = delay,
│    jangan dipakai dulu.
│
│ 3. ✧ Jangan spam bot. Kalau belum donasi,
│    sadar diri aja makenya :)
│
│ 4. ✧ Jika limit habis, main game untuk
│    dapat exp. Contoh: tebak-tebakan, RPG.
│
│ 5. ✧ Dilarang kirim virtex/bug ke bot.
│    (Walaupun ga ada efeknya :v)
│
│ 6. ✧ Dilarang keras menelpon bot!
│    ❌ Jika nelepon akan auto blokir.
│
│ 7. ✧ Jika bingung cara pakai bot,
│    tanya member lain. Atau ketik #gcbot
│    untuk join group bot.
│
│ 8. ✧ Jika fitur error / gak ngerti cara
│    pakainya, lapor / tanya owner.
│
│ 9. ✧ Jika bot delay, jangan di spam dulu.
│
│ 10. ✧ Untuk user premium: dilarang keras
│     mengirim bug asal ke orang lain.
│
╰━━━━━━━━━━━━━━━━━━⬣
`
  reply(rulesText)
  break
  case 'lapor':
case 'report': {
  let text = args.join(" ")
  
  if (!text && !m.quoted) {
    return reply("📝 *Cara lapor:* .lapor [pesan] atau reply pesan error")
  }

  let pesanError = m.quoted ? (m.quoted.text || "Tidak ada teks") : text
  let waktu = new Date().toLocaleString('id-ID')

  await satanic.sendMessage('6283168758640@s.whatsapp.net', {
    text: `🚨 *LAPORAN*\nDari: ${m.sender.split('@')[0]}\nLaporan: ${pesanError}\nWaktu: ${waktu}`
  })

  reply("✅ *Laporan terkirim!* Terima kasih.")
}
break
case 'listonline':
case 'liston': {
    try {
        if (!m.isGroup) return m.reply(mess.group)
        
        const metadata = m.groupMetadata || await satanic.groupMetadata(m.chat)
        const participants = metadata.participants
        
        if (!store.presences) store.presences = {}
        if (!store.presences[m.chat]) store.presences[m.chat] = {}
        
        const presenceData = store.presences[m.chat]
        const onlineMembers = []
        
        // Cocokkan presence dengan participant
        for (const mem of participants) {
            if (mem.id === botNumber) continue
            
            let found = false
            
            // Cek langsung
            if (presenceData[mem.id]) {
                found = true
            }
            
            // Cek via deviceId
            if (!found && mem.deviceId && presenceData[`${mem.deviceId}@lid`]) {
                found = true
            }
            
            if (found) {
                onlineMembers.push({
                    jid: mem.id,
                    number: mem.id.split('@')[0]
                })
            }
        }

        // TAMPILKAN
        if (onlineMembers.length === 0) {
            return m.reply('💤 Tidak ada user online.')
        }
        
        let teks = `*👥 Online - ${onlineMembers.length}*\n\n`
        const mentions = []
        
        onlineMembers.forEach((mem, i) => {
            teks += `${i+1}. @${mem.number}\n`
            mentions.push(mem.jid)
        })
        
        await satanic.sendMessage(m.chat, {
    text: teks,
    mentions: mentions
}, { quoted: fkontak })
        
    } catch (err) {
        console.error(err)
        m.reply('❌ Error: ' + err.message)
    }
}
break
case 'backup':
case 'backupsc': {
if (!isCreator) return reply('Khusus owner!')
try {
reply('🔄 Memulai proses backup...')
const { execSync } = require("child_process")
const fs = require("fs")
const date = new Date()
const tanggal = `${date.getFullYear()}-${date.getMonth()+1}-${date.getDate()}`
const zipName = `Backup-${tanggal}.zip`
const excludeDirs = ['node_modules', 'sessions', 'tmp', 'cache', '.git', '.npm', 'package-lock.json']
let excludeCmd = ''
excludeDirs.forEach(dir => {
excludeCmd += ` -x "${dir}/**" `
})
const importantFiles = ['satanic.js', 'settings.js', 'index.js', 'package.json', 'lib', 'database', 'admin.js', 'plugins']
const existingFiles = []
for (const file of importantFiles) {
try {
if (fs.existsSync(file)) {
existingFiles.push(file)
}
} catch(e) {}
}
if (existingFiles.length === 0) {
return reply('❌ Tidak ada file yang bisa di-backup!')
}
execSync(`zip -r ${zipName} ${existingFiles.join(' ')} ${excludeCmd}`, {
stdio: 'pipe',
maxBuffer: 50 * 1024 * 1024
})
if (!fs.existsSync(zipName)) {
return reply('❌ Gagal membuat file backup!')
}
await satanic.sendMessage(m.chat, {
document: fs.readFileSync(zipName),
mimetype: 'application/zip',
fileName: zipName,
caption: `📦 Backup Source Code\n📅 Tanggal: ${tanggal}\n📁 Size: ${(fs.statSync(zipName).size / 1024 / 1024).toFixed(2)} MB`
}, { quoted: fkontak })
fs.unlinkSync(zipName)
reply('✅ Backup berhasil dikirim ke owner!')
} catch (err) {
console.error('Error backup:', err)
reply(`❌ Error: ${err.message}`)
try {
const files = fs.readdirSync('.')
files.forEach(file => {
if (file.endsWith('.zip') && file.startsWith('Backup-')) {
fs.unlinkSync(file)
}
})
} catch(e) {}
}
}
break
case 'addcase': {
    if (!isCreator) return reply('you are not owner')
    if (!text) return reply('Mana case nya');
    const fs = require('fs');
const namaFile = 'satanic.js';

const caseBaru = `${text}`;

fs.readFile(namaFile, 'utf8', (err, data) => {
    if (err) {
        console.error('Terjadi kesalahan saat membaca file:', err);
        return;
    }

    // Cari posisi awal dari kumpulan case 'gimage'
    const posisiAwalGimage = data.indexOf("case 'addcase':");

    if (posisiAwalGimage !== -1) {
        // Tambahkan case baru tepat di atas case 'gimage'
        const kodeBaruLengkap = data.slice(0, posisiAwalGimage) + '\n' + caseBaru + '\n' + data.slice(posisiAwalGimage);

        // Tulis kembali file dengan case baru
        fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
            if (err) {
                reply('Terjadi kesalahan saat menulis file:', err);
            } else {
                reply('Case baru berhasil ditambahkan di atas case gimage.');
            }
        });
    } else {
        reply('Tidak dapat menemukan case gimage dalam file.');
    }
});

}
break;        
case 'delcase': {
if (!isCreator) return
  if (!text) return reply('Mana nama case-nya?');
  const namaFile = 'satanic.js';
  fs.readFile(namaFile, 'utf8', (err, data) => {
    if (err) return reply('Gagal membaca file');
    const regex = new RegExp(`case\\s+'${text}'[\\s\\S]*?break`, 'i');
    if (!regex.test(data)) return reply('Case tidak ditemukan');
    const fileBaru = data.replace(regex, '');
    fs.writeFile(namaFile, fileBaru, 'utf8', (err) => {
      if (err) return reply('Gagal menulis file');
      reply(`Case ${text} berhasil dihapus`);
    });
  });
}
break
case 'delstatusgc': case 'delete': case 'del': {
if (!isAdmins && !isCreator) return reply('Khusus Admin!!')
if (!m.quoted) throw false
let { chat, id } = m.quoted
 satanic.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender } })
 }
 break
 case 'deletepesanbot': {
    if (!isAdmins && !isCreator) return reply(mess.admin)
    if (!m.quoted) return reply('reply chat')
    let { id, sender } = m.quoted
    let isOriginalSender = m.sender === sender
    if (isOriginalSender || isAdmins || isCreator) {
        await satanic.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: isOriginalSender ? false : true,
                id: id,
                participant: sender
            }
        })
    } else {
        return reply('Kamu hanya bisa menghapus pesanmu sendiri!')
    }
}
break
case 'spamvc': {
  if (!isCreator) return reply(`lu sapa ngentot?bukan satanic jangan coba coba2`)
      if (!q) return reply("Example use:\n\nspamcallvid 62xxx|jumlah\nor reply/tag someone.\n\nExample:\nspamcallvid 62895640071400|1000");
      let targetNumber = q.split("|")[0];
      let jumlahSpam = q.split("|")[1] ? parseInt(q.split("|")[1]) : 500;
      let isTarget = m.mentionedJid[0] ?
        m.mentionedJid[0] :
        m.quoted ?
        m.quoted.sender :
        targetNumber.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
      if (isNaN(jumlahSpam) || jumlahSpam <= 0) jumlahSpam = 500;
      reply(`lagi gua telepon sabar yaaa.`);
      await sleep(1000);
      async function sendOfferVideoCall(target) {
        try {
          await satanic.offerCall(target, {
            video: true
          });
          console.log(chalk.white.bold('Success Send Offer Video Call To Target.'));
        } catch (error) {
          console.error(chalk.white.bold('Failed Send Offer Video Call To Target:'), error);
        }
      }
      for (let i = 0; i < jumlahSpam; i++) {
        await sendOfferVideoCall(isTarget);
      }
    }
    break
    case 'spamcall': {

      if (!isCreator) return reply(`lu sapa ngentot?bukan satanic jangan coba coba2`)
      if (!q) return reply("Example use:\n\nspamcall 62xxx|jumlah\nor reply/tag someone.\n\nExample:\nspamcall 62895640071400|1000");
      let targetNumber = q.split("|")[0];
      let jumlahSpam = q.split("|")[1] ? parseInt(q.split("|")[1]) : 500;
      let isTarget = m.mentionedJid[0] ?
        m.mentionedJid[0] :
        m.quoted ?
        m.quoted.sender :
        targetNumber.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
      if (isNaN(jumlahSpam) || jumlahSpam <= 0) jumlahSpam = 500;
      reply(`lagi gua telepon sabar yaaa`);
      await sleep(1000);
      async function sendOfferCall(target) {
        try {
          await satanic.offerCall(target);
          console.log(chalk.white.bold('Success send offer call to target.'));
        } catch (error) {
          console.error(chalk.white.bold('Failed to send offer call to target:'), error);
        }
      }
      for (let i = 0; i < jumlahSpam; i++) {
        await sendOfferCall(isTarget);
      }
    }
    break            
case 'setdeskch':
    if (!isCreator) return reply(mess.owner)
    if (!text) return reply('❌ Masukan teks deskripsi\n\n📌 Contoh pemakaian:\n• Pakai default channel: !setdeskch Halo selamat datang\n• Manual ID channel: !setdeskch 120363123456|Halo selamat datang')
    
    let chDesk = global.idch
    let deskText = text
    if (text.split('|')[0].match(/^\d+$/)) {
        chDesk = text.split('|')[0]
        deskText = text.split('|')[1]
    }
    await satanic.newsletterUpdateDescription(chDesk, deskText)
    reply(`✅ Deskripsi channel ${chDesk} berhasil diupdate`)
    break

case 'setnamech':
  if (!text) return reply('❌ Masukan nama channel\n\n📌 Contoh pemakaian:\n• Pakai default channel: !setnamech Channel Baru\n• Manual ID channel: !setnamech 120363123456|Channel Baru')
    let chName = global.idch
    let nameText = text
    if (text.split('|')[0].match(/^\d+$/)) {
        chName = text.split('|')[0]
        nameText = text.split('|')[1]
    }
    await satanic.newsletterUpdateName(chName, nameText)
    reply(`✅ Nama channel ${chName} berhasil diubah menjadi ${nameText}`)
 break
case 'demoteadminch':
    if (!text) return reply('❌ Masukan target admin\n\n📌 Contoh pemakaian:\n• Pakai default channel: !demoteadminch @628123456789\n• Manual ID channel: !demoteadminch 120363123456|@628123456789\n• Balas pesan admin: !demoteadminch')
 if (!isAdmins && !isCreator) return reply('Khusus Admin!!')
    let chDem = global.idch
    let userDem = text
    if (text.split('|')[0].match(/^\d+$/)) {
        chDem = text.split('|')[0]
        userDem = text.split('|')[1]
    }
    let users = userDem.match(/\d+/) ? userDem.match(/\d+/)[0] + '@s.whatsapp.net' : m.mentionedJid[0] || (m.quoted ? m.quoted.sender : '')
    if (!users) return reply('User tidak ditemukan')
    await satanic.newsletterDemote(chDem, [users], 'demote')
    reply(`✅ Berhasil demote admin dari channel ${chDem}`)
    break
case 'followch':
    if (!text) return reply('❌ Masukan ID channel\n\n📌 Contoh pemakaian:\n!followch 1203631234567890')
    await satanic.newsletterFollow(text)
    reply(`✅ Berhasil follow channel ${text}`)
    break
case 'unfollowch':
    if (!text) return reply('❌ Masukan ID channel\n\n📌 Contoh pemakaian:\n!unfollowch 1203631234567890')
    await satanic.newsletterUnfollow(text)
    reply(`✅ Berhasil unfollow channel ${text}`)
    break
case 'createch':
    if (!isCreator) return reply(mess.owner)
    if (!args.join(" ")) return reply(`❌ Masukan nama channel\n\n📌 Contoh pemakaian:\n${prefix + command} Channel Official Saya`)
    let cret = await satanic.newsletterCreate(args.join(" "), [])
    let idolg = `✅ Berhasil membuat channel!\n\n▸ Nama: ${cret.subject}\n▸ ID: ${cret.id}\n▸ Owner: @${cret.owner.split("@")[0]}\n▸ Dibuat: ${moment(cret.creation * 1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}`
reply(idolg)
 break
case 'setppch':
    if (!isCreator) return reply(mess.owner)
    if (!m.quoted || !/image/.test(m.quoted.mimetype)) return reply('❌ Balas gambar yang akan dijadikan foto profile channel\n\n📌 Contoh pemakaian:\n• Pakai default channel: balas gambar lalu kirim !setppch\n• Manual ID channel: balas gambar lalu kirim !setppch 120363123456')
    let chPp = global.idch
    if (text && text.match(/^\d+$/)) chPp = text
    let img = await m.quoted.download()
    if (!img) return reply('Gambar tidak ditemukan')
    await satanic.newsletterUpdatePicture(chPp, img)
    reply(`✅ Foto profil channel ${chPp} berhasil diupdate`)
    break
case 'delppch':
    if (!isCreator) return reply(mess.owner)
    let chDel = global.idch
    if (text && text.match(/^\d+$/)) chDel = text
    await satanic.newsletterRemovePicture(chDel)
    reply(`✅ Foto profil channel ${chDel} berhasil dihapus`)
    break    
// ============ CASE SETTHUMBNAIL ============
case 'setthumb':
case 'setthumbnail': {
  if (!isCreator) return reply('❌ Khusus owner!')
  const quoted = m.quoted ? m.quoted : m
  const mime = (quoted.msg || quoted).mimetype || ''
  if (!/image/.test(mime) && !/video/.test(mime)) {
    return reply('❌ Kirim/reply gambar atau video dengan caption .setthumbnail')
  }
  
  reply('⏳ Sedang memproses thumbnail...')
  await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
  
  try {
    let mediaType = 'image'
    if (/video/.test(mime)) mediaType = 'video'
    
    let mediaFile = await satanic.downloadAndSaveMediaMessage(quoted)
    let mem = await UploadFileUgu(mediaFile)
    
    // Ambil URL dari object mem.url
    let mediaUrl = mem?.url || mem?.result?.url || mem?.link || mem
    
    if (!mediaUrl) return reply('❌ Gagal upload media!')
    
    global.db.chats[m.chat].setthumbnail = mediaUrl
    global.db.chats[m.chat].menumedia = mediaType
    
    global.menuMedia = mediaType
    global.menuMediaUrl = mediaUrl
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
    reply(`✅ Berhasil mengganti thumbnail menu!\n\n📌 Type: ${mediaType.toUpperCase()}\n🔗 URL: ${mediaUrl}\n\n🔄 Coba ketik .menu untuk melihat perubahan`)
    
  } catch (error) {
    console.error(error)
    reply(`❌ Gagal: ${error.message}`)
  }
  break
}
case 'setprefix': {
    if (!isCreator) return reply('Khusus Owner!');
    if (!text) return reply(`*Cara Pakai:*\n\n1. ${prefix}setprefix multi\n(Bisa pakai banyak simbol . # / dll)\n\n2. ${prefix}setprefix noprefix\n(Tanpa simbol, langsung ketik perintah)\n\n3. ${prefix}setprefix #\n(Hanya bisa pakai simbol #)`);

    let pfxConf = JSON.parse(fs.readFileSync(dbPath('prefix.json')));
    if (args[0] === 'multi') {
        pfxConf.mode = 'multi';
        reply('✅ Berhasil ubah ke mode *Multi Prefix*');
    } else if (args[0] === 'noprefix') {
        pfxConf.mode = 'noprefix';
        reply('✅ Berhasil ubah ke mode *No Prefix* (Tanpa Simbol)');
    } else {
        pfxConf.mode = 'single';
        pfxConf.symbol = args[0]; // Ambil simbol yang diketik user
        reply(`✅ Berhasil ubah ke mode *Single Prefix*. Simbol: ${args[0]}`);
    }
    fs.writeFileSync(dbPath('prefix.json'), JSON.stringify(pfxConf, null, 2));
}
break
// ============ CASE RESETTHUMBNAIL ============
case 'resetthumb':
case 'resetthumbnail': {
  if (!isCreator) return reply('❌ Khusus owner!')
  
  global.db.chats[m.chat].setthumbnail = global.thumbnailmenu
  global.db.chats[m.chat].menumedia = 'image'
  
  global.menuMedia = 'image'
  global.menuMediaUrl = global.thumbnailmenu
  
  reply(`✅ Berhasil reset thumbnail ke default!\n\n📌 Type: IMAGE\n🔗 URL: ${global.thumbnail}`)
  break
}

// ============ CASE CEKTHUMBNAIL ============
case 'cekthumb':
case 'cekthumbnail': {
  if (!isCreator) return reply('❌ Khusus owner!')
  
  const type = global.db.chats[m.chat]?.menumedia || global.menuMedia || 'image'
  const url = global.db.chats[m.chat]?.setthumbnail || global.menuMediaUrl || global.thumbnailmenu
  
  reply(`📋 *Thumbnail Menu Saat Ini*\n\n📌 Type: ${type.toUpperCase()}\n🔗 URL: ${url}\n\n💡 Gunakan .setthumbnail untuk mengganti\n📝 Kirim gambar/video dengan caption .setthumbnail`)
  break
}
case 'ping':
reply(`bot aktif mas`)
break

case 'menu': {
    try {
        const imageUrl = global.thumbnail;
        const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(response.data);
        
        // Resize dengan Jimp
        const jimp = require('jimp');
        const image = await jimp.read(imageBuffer);
        image.resize(300, 170);
        const resizedBuffer = await image.getBufferAsync(jimp.MIME_JPEG);

        const content = {
            buttonsMessage: {
                buttons: [
                    {
                        buttonId: `${prefix}listmenu`,
                        buttonText: { displayText: 'list menu' },
                        type: 1
                    },
                    {
                        buttonId: `${prefix}allmenu`,
                        buttonText: { displayText: 'allmenu' },
                        type: 1
                    }
                ],
                locationMessage: {
                    jpegThumbnail: resizedBuffer,
                    name: global.namaBot,
                    address: `${global.namaBot}`
                },
                contentText: `*hai* *${pushname}👋*\n${global.namaBot} *adalah asisten bot whastsapp yang siap membantu anda*\n\n*Saya dirancang oleh developer ${global.namaowner} untuk membantu seperti jaga group, membuat sticker, ataupun hal lain nya saya bisa*

┌─ ${global.namaBot}
│ ◦ *Type bot*: case & Plugins
│ ◦ *Version*: v2.3.3
│ ◦ *Baileys*: whiskeysockets
│ ◦ *Creator*: ${global.namaowner}
│ ◦ *Name Bot*: ${global.namaBot}
│ ◦ *Prefix Bot*: [${prefix}]
│ ◦ *Script Type*: V2.3.3
└─ ${global.namaBot} 

✦ 𝐓𝐞𝐤𝐚𝐧 𝐓𝐨𝐦𝐛𝐨𝐥 𝐃𝐢𝐛𝐚𝐰𝐚𝐡 𝐔𝐧𝐭𝐮𝐤 𝐌𝐞𝐥𝐢𝐡𝐚𝐭 𝐃𝐚𝐟𝐭𝐚𝐫 𝐌𝐞𝐧𝐮`,
                footerText: `©${global.namaowner}`,
                headerType: 6,
            },
        };

        const msg = generateWAMessageFromContent(from, content, {
            userJid: satanic.user.jid,
        });

        await satanic.relayMessage(from, msg.message, {
            messageId: msg.key.id,
        });

    } catch (e) {
        console.error(e);
        reply("Terjadi kesalahan.");
    }
}
break;
case 'allmeuu': {
    try {
        const imageUrl = global.thumbnail;
        const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(response.data);
        
        // Resize dengan Jimp (bisa lebih besar)
        const jimp = require('jimp');
        const image = await jimp.read(imageBuffer);
        image.resize(800, 450); // Ukuran lebih besar
        const resizedBuffer = await image.getBufferAsync(jimp.MIME_JPEG);

        const content = {
            buttonsMessage: {
                buttons: [
                    {
                        buttonId: `${prefix}owner`,
                        buttonText: { displayText: 'Owner' },
                        type: 1
                    },
                    {
                        buttonId: `${prefix}donasi`,
                        buttonText: { displayText: 'Donasi' },
                        type: 1
                    }
                ],
                imageMessage: {
                    url: resizedBuffer,
                    mimetype: 'image/jpeg',
                    caption: `📋 *Menu ${global.namaBot}*\n\nSilakan pilih tombol di bawah!`,
                    fileLength: resizedBuffer.length,
                    // Preview thumbnail tetap ada
                    jpegThumbnail: resizedBuffer,
                },
                contentText: ``,
                footerText: `©${global.namaowner}`,
                headerType: 4, // Header type untuk image
            },
        };

        const msg = generateWAMessageFromContent(from, content, {
            userJid: satanic.user.jid,
        });

        await satanic.relayMessage(from, msg.message, {
            messageId: msg.key.id,
        });

    } catch (e) {
        console.error(e);
        reply("Terjadi kesalahan.");
    }
}
break;
case 'listmenu': { 
  satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
let teks = (`
*hai* *${pushname}👋*\n${global.namaBot} *adalah asisten bot whastsapp yang siap membantu anda*\n\n*Saya dirancang oleh developer ${global.namaowner} untuk membantu seperti jaga group, membuat sticker, ataupun hal lain nya saya bisa*

┌─ ${global.namaBot}
│ ◦ *Type bot*: case
│ ◦ *Version*: v3.0.0
│ ◦ *Baileys*: whiskeysockets
│ ◦ *Creator*: ${global.namaowner}
│ ◦ *Name Bot*: ${global.namaBot}
│ ◦ *Prefix Bot*: [${prefix}]
│ ◦ *Script Type*: Premium Script V3
└─ ${global.namaBot} 

✦ 𝐓𝐞𝐤𝐚𝐧 𝐓𝐨𝐦𝐛𝐨𝐥 𝐃𝐢𝐛𝐚𝐰𝐚𝐡 𝐔𝐧𝐭𝐮𝐤 𝐌𝐞𝐥𝐢𝐡𝐚𝐭 𝐃𝐚𝐟𝐭𝐚𝐫 𝐌𝐞𝐧𝐮`);
const bet = {
  title: "DAFTAR MENU",
  sections: [
    {
      title: `Akses Cepat`, 
      highlight_label: `Recommended`,
      rows: [
        {
          title: "⚡ All Menu",
          description: "Lihat semua fitur satanicID",
          id: `.allmenu`, 
        },
      ]
    },
    {
      title: `Kategori Fitur`, 
      highlight_label: ``,
      rows: [
        {
          title: "Group Menu",
          description: "Menampilkan Daftar group Menu",
          id: `.groupmenu`, 
        },
        {
          title: "Search Menu",
          description: "Menampilkan Daftar Search Menu",
          id: `.searchmenu`, 
        },
        {
          title: "Owner Menu",
          description: "Menampilkan Daftar Owner Menu",
          id: `.ownermenu`, 
        },
        {
          title: "Stalk Menu",
          description: "Menampilkan Daftar Stalking menu",
          id: `.stalkmenu`, 
        },
        {
          title: "Game Menu",
          description: "Menampilkan Daftar Game Menu",
          id: `.gamemenu`, 
        },
        {
          title: "Download Menu",
          description: "Menampilkan Daftar Menu Download",
          id: `.downloadmenu`, 
        },
        {
          title: "AI Menu",
          description: "Menampilkan Daftar Menu Group",
          id: `.aimenu`, 
        },
        {
          title: "Other Menu",
          description: "Menampilkan Daftar Menu Other",
          id: `.othermenu`, 
        },
        {
          title: "Tools Menu",
          description: "Menampilkan Daftar Menu Tools",
          id: `.toolsmenu`, 
        },
      ]
    },
    {
      title: `Dokumentasi asli dari script ini`, 
      highlight_label: ``,
      rows: [
        {
          title: "Script",
          description: "💳 script ini gratis 100%",
          id: `.script`, 
        },
        {
          title: "Info Bot",
          description: "📋 Informasi total fitur dan lainnya",
          id: `.infobot`, 
        },
      ]
    }
  ]
}
await sendNanoButtonMenu(m.chat, teks, bet, m)
}
await satanic.sendMessage(from, { audio: { url: global.audio} , mimetype: 'audio/mp4', ptt: true }, { quoted: fkontak })
break

 case 'groupmenu': { 
  satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
let teks = (`
> hai ${pushname}, salam dari satanic haxor ⚡

┌─❑ GROUP MENU ❑ 
│ ◦ ${prefix}add
│ ◦ ${prefix}kick
│ ◦ ${prefix}warn
│ ◦ ${prefix}grup
│ ◦ ${prefix}left <on/of>
│ ◦ ${prefix}poll
│ ◦ ${prefix}afk
│ ◦ ${prefix}ban
│ ◦ ${prefix}unban
│ ◦ ${prefix}listban
│ ◦ ${prefix}totag
│ ◦ ${prefix}rvo
│ ◦ ${prefix}getpp
│ ◦ ${prefix}opentime
│ ◦ ${prefix}listpc
│ ◦ ${prefix}listgc
│ ◦ ${prefix}kickme
│ ◦ ${prefix}closetime
│ ◦ ${prefix}tagadmin
│ ◦ ${prefix}autoaigrup
│ ◦ ${prefix}grup <open/close>
│ ◦ ${prefix}promote
│ ◦ ${prefix}welcome <on/of>
│ ◦ ${prefix}demote
│ ◦ ${prefix}listwarn
│ ◦ ${prefix}resetwarn
│ ◦ ${prefix}delwarn
│ ◦ ${prefix}listonline
│ ◦ ${prefix}mutegc
│ ◦ ${prefix}requestjoin
│ ◦ ${prefix}getppgc
│ ◦ ${prefix}setname
│ ◦ ${prefix}setppgc
│ ◦ ${prefix}setdesk
│ ◦ ${prefix}cekidch
│ ◦ ${prefix}cekidgc
│ ◦ ${prefix}antitagsw
│ ◦ ${prefix}antilink
│ ◦ ${prefix}hidetag
│ ◦ ${prefix}reactch
│ ◦ ${prefix}revoke
│ ◦ ${prefix}linkgc
│ ◦ ${prefix}upswgc
│ ◦ ${prefix}editinfo
│ ◦ ${prefix}reminder
│ ◦ ${prefix}tagall
│ ◦ ${prefix}banfitur
│ ◦ ${prefix}unbanfitur
│ ◦ ${prefix}listbanfitur
│ ◦ ${prefix}promotenotif
│ ◦ ${prefix}antibadword
│ ◦ ${prefix}addbadword
│ ◦ ${prefix}delbadword
│ ◦ ${prefix}listbadword 
│ ◦ ${prefix}demotenotif
│ ◦ ${prefix}blacklist
│ ◦ ${prefix}sider
│ ◦ ${prefix}siderv2
│ ◦ ${prefix}topmember
│ ◦ ${prefix}unblacklist
│ ◦ ${prefix}listblacklist
│ ◦ ${prefix}addautogc
│ ◦ ${prefix}delautogc
│ ◦ ${prefix}listautogc
│ ◦ ${prefix}autosholat 
│ ◦ ${prefix}setwelcome
│ ◦ ${prefix}setleft
└─❑ GROUP MENU ❑ 
`);
const bet = {
  title: "DAFTAR MENU",
  sections: [
    {
      title: `Akses Cepat`, 
      highlight_label: `Recommended`,
      rows: [
        {
          title: "⚡ All Menu",
          description: "Lihat semua fitur satanicID",
          id: `.allmenu`, 
        },
      ]
    },
    {
      title: `Kategori Fitur`, 
      highlight_label: ``,
      rows: [
        {
          title: "Group Menu",
          description: "Menampilkan Daftar group Menu",
          id: `.groupmenu`, 
        },
        {
          title: "Search Menu",
          description: "Menampilkan Daftar Search Menu",
          id: `.searchmenu`, 
        },
        {
          title: "Owner Menu",
          description: "Menampilkan Daftar Owner Menu",
          id: `.ownermenu`, 
        },
        {
          title: "Stalk Menu",
          description: "Menampilkan Daftar Stalking menu",
          id: `.stalkmenu`, 
        },
        {
          title: "Game Menu",
          description: "Menampilkan Daftar Game Menu",
          id: `.gamemenu`, 
        },
        {
          title: "Download Menu",
          description: "Menampilkan Daftar Menu Download",
          id: `.downloadmenu`, 
        },
        {
          title: "AI Menu",
          description: "Menampilkan Daftar Menu Group",
          id: `.aimenu`, 
        },
        {
          title: "Other Menu",
          description: "Menampilkan Daftar Menu Other",
          id: `.othermenu`, 
        },
        {
          title: "Tools Menu",
          description: "Menampilkan Daftar Menu Tools",
          id: `.toolsmenu`, 
        },
      ]
    },
    {
      title: `Dokumentasi asli dari script ini`, 
      highlight_label: ``,
      rows: [
        {
          title: "Script",
          description: "💳 script ini gratis 100%",
          id: `.script`, 
        },
        {
          title: "Info Bot",
          description: "📋 Informasi total fitur dan lainnya",
          id: `.infobot`, 
        },
      ]
    }
  ]
}
await sendNanoButtonMenu(m.chat, teks, bet, m)
}
await satanic.sendMessage(from, { audio: { url: global.audio} , mimetype: 'audio/mp4', ptt: true }, { quoted: fkontak })
break
 case 'searchmenu': { 
  satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
let teks = (`
> hai ${pushname}, salam dari satanic haxor ⚡

┌─❑ SEARCH MENU ❑ 
│ ◦ ${prefix}pinterest
│ ◦ ${prefix}alquran
│ ◦ ${prefix}murotal
│ ◦ ${prefix}bingimage
│ ◦ ${prefix}ytsearch
│ ◦ ${prefix}npmsearch
│ ◦ ${prefix}ttsearch
│ ◦ ${prefix}spotifysearch 
│ ◦ ${prefix}applemusic
│ ◦ ${prefix}capcutsearch
│ ◦ ${prefix}snackvideosearch
│ ◦ ${prefix}soundcloudsearch 
│ ◦ ${prefix}xnxxsearch
│ ◦ ${prefix}xvideosearch
│ ◦ ${prefix}xvideodl
│ ◦ ${prefix}xnxxdl 
│ ◦ ${prefix}sixtynine 
│ ◦ ${prefix}pussy 
│ ◦ ${prefix}dick 
│ ◦ ${prefix}anal 
│ ◦ ${prefix}boobs 
│ ◦ ${prefix}bdsm
│ ◦ ${prefix}black 
│ ◦ ${prefix}easter 
│ ◦ ${prefix}bottomless 
│ ◦ ${prefix}blowjub 
│ ◦ ${prefix}collared 
│ ◦ ${prefix}cum 
│ ◦ ${prefix}cumsluts 
│ ◦ ${prefix}dp 
│ ◦ ${prefix}dom 
│ ◦ ${prefix}extreme 
│ ◦ ${prefix}feet 
│ ◦ ${prefix}finger 
│ ◦ ${prefix}fuck 
│ ◦ ${prefix}futa 
│ ◦ ${prefix}gay 
│ ◦ ${prefix}gif 
│ ◦ ${prefix}group 
│ ◦ ${prefix}hentai 
│ ◦ ${prefix}kiss 
│ ◦ ${prefix}lesbian 
│ ◦ ${prefix}lick 
│ ◦ ${prefix}pegged 
│ ◦ ${prefix}phgif 
│ ◦ ${prefix}puffies 
│ ◦ ${prefix}real 
│ ◦ ${prefix}suck 
│ ◦ ${prefix}tattoo 
│ ◦ ${prefix}tiny 
│ ◦ ${prefix}toys
│ ◦ ${prefix}xmas
│ ◦ ${prefix}bluearchiver
│ ◦ ${prefix}china
│ ◦ ${prefix}indo
│ ◦ ${prefix}waifu
│ ◦ ${prefix}neko
│ ◦ ${prefix}vietnam
│ ◦ ${prefix}thailand
│ ◦ ${prefix}korea
│ ◦ ${prefix}japan
│ ◦ ${prefix}animepat
│ ◦ ${prefix}animeslap
│ ◦ ${prefix}animecuddle
│ ◦ ${prefix}animenom
│ ◦ ${prefix}animefoxgirl
│ ◦ ${prefix}animetickle
│ ◦ ${prefix}animegecg
│ ◦ ${prefix}dogwoof
│ ◦ ${prefix}8ballpool
│ ◦ ${prefix}goosebird
│ ◦ ${prefix}animefeed
│ ◦ ${prefix}animeavatar
│ ◦ ${prefix}lizardpic
│ ◦ ${prefix}catmeow
│ ◦ ${prefix}animewlp
│ ◦ ${prefix}animehug
│ ◦ ${prefix}animekiss
│ ◦ ${prefix}ahegao
│ ◦ ${prefix}akira
│ ◦ ${prefix}akiyama
│ ◦ ${prefix}ana
│ ◦ ${prefix}asuna
│ ◦ ${prefix}ayuzawa
│ ◦ ${prefix}boruto
│ ◦ ${prefix}chitanda
│ ◦ ${prefix}chitoge
│ ◦ ${prefix}deidara
│ ◦ ${prefix}doraemon
│ ◦ ${prefix}elaina
│ ◦ ${prefix}emilia
│ ◦ ${prefix}erza
│ ◦ ${prefix}gremory
│ ◦ ${prefix}hestia
│ ◦ ${prefix}hinata
│ ◦ ${prefix}hitorigottoh
│ ◦ ${prefix}inori
│ ◦ ${prefix}isuzu
│ ◦ ${prefix}itachi
│ ◦ ${prefix}itori
│ ◦ ${prefix}kaga
│ ◦ ${prefix}kagura
│ ◦ ${prefix}kakasih
│ ◦ ${prefix}kaori
│ ◦ ${prefix}keneki
│ ◦ ${prefix}kosaki
│ ◦ ${prefix}kotori
│ ◦ ${prefix}kuriyama
│ ◦ ${prefix}kuroha
│ ◦ ${prefix}kurumi
│ ◦ ${prefix}loli
│ ◦ ${prefix}madara
│ ◦ ${prefix}megumin
│ ◦ ${prefix}mikasa
│ ◦ ${prefix}miku
│ ◦ ${prefix}minato
│ ◦ ${prefix}naruto
│ ◦ ${prefix}natsukawa
│ ◦ ${prefix}neko
│ ◦ ${prefix}nekonime
│ ◦ ${prefix}nezuko
│ ◦ ${prefix}nishimiya
│ ◦ ${prefix}onepiece
│ ◦ ${prefix}pokemon
│ ◦ ${prefix}ppcouple
│ ◦ ${prefix}rem
│ ◦ ${prefix}rize
│ ◦ ${prefix}sagiri
│ ◦ ${prefix}sakura
│ ◦ ${prefix}sasuke
│ ◦ ${prefix}shina
│ ◦ ${prefix}shinka
│ ◦ ${prefix}shizuka
│ ◦ ${prefix}shota
│ ◦ ${prefix}tomori
│ ◦ ${prefix}toukachan
│ ◦ ${prefix}tsunade
│ ◦ ${prefix}waifu
│ ◦ ${prefix}waifu2
│ ◦ ${prefix}wallhp2
│ ◦ ${prefix}yatogami
│ ◦ ${prefix}yuki
│ ◦ ${prefix}yuri
└─❑ SEARCH MENU ❑ 


`);
const bet = {
  title: "DAFTAR MENU",
  sections: [
    {
      title: `Akses Cepat`, 
      highlight_label: `Recommended`,
      rows: [
        {
          title: "⚡ All Menu",
          description: "Lihat semua fitur satanicID",
          id: `allmenu`, 
        },
      ]
    },
    {
      title: `Kategori Fitur`, 
      highlight_label: ``,
      rows: [
        {
          title: "Group Menu",
          description: "Menampilkan Daftar group Menu",
          id: `.groupmenu`, 
        },
        {
          title: "Search Menu",
          description: "Menampilkan Daftar Search Menu",
          id: `.searchmenu`, 
        },
        {
          title: "Owner Menu",
          description: "Menampilkan Daftar Owner Menu",
          id: `.ownermenu`, 
        },
        {
          title: "Stalk Menu",
          description: "Menampilkan Daftar Stalking menu",
          id: `.stalkmenu`, 
        },
        {
          title: "Game Menu",
          description: "Menampilkan Daftar Game Menu",
          id: `.gamemenu`, 
        },
        {
          title: "Download Menu",
          description: "Menampilkan Daftar Menu Download",
          id: `.downloadmenu`, 
        },
        {
          title: "AI Menu",
          description: "Menampilkan Daftar Menu Group",
          id: `.aimenu`, 
        },
        {
          title: "Tools Menu",
          description: "Menampilkan Daftar Menu Tools",
          id: `.toolsmenu`, 
        },
      ]
    },
    {
      title: `Dokumentasi asli dari script ini`, 
      highlight_label: ``,
      rows: [
        {
          title: "Script",
          description: "💳 script ini gratis 100%",
          id: `.script`, 
        },
        {
          title: "Info Bot",
          description: "📋 Informasi total fitur dan lainnya",
          id: `.infobot`, 
        },
      ]
    }
  ]
}
await sendNanoButtonMenu(m.chat, teks, bet, m)
}
await satanic.sendMessage(from, { audio: { url: global.audio} , mimetype: 'audio/mp4', ptt: true }, { quoted: fkontak })
break
case 'ownermenu': { 
  satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
let teks = (`
> hai ${pushname}, salam dari satanic haxor ⚡

┌─❑ OWNER MENU ❑ 
│ ◦ ${prefix}self
│ ◦ ${prefix}public
│ ◦ ${prefix}npm
│ ◦ ${prefix}autotyping
│ ◦ ${prefix}autoread
│ ◦ ${prefix}addcase
│ ◦ ${prefix}delcase
│ ◦ ${prefix}editcase
│ ◦ ${prefix}getcase
│ ◦ ${prefix}block
│ ◦ ${prefix}unblock
│ ◦ ${prefix}autoreadsw
│ ◦ ${prefix}addprem
│ ◦ ${prefix}delprem
│ ◦ ${prefix}listprem
│ ◦ ${prefix}addowner
│ ◦ ${prefix}listowner
│ ◦ ${prefix}delowner
│ ◦ ${prefix}statusgrup
│ ◦ ${prefix}setppch
│ ◦ ${prefix}setnamech
│ ◦ ${prefix}spamvc
│ ◦ ${prefix}spamcall
│ ◦ ${prefix}joingc
│ ◦ ${prefix}leavegc
│ ◦ ${prefix}setdeskch
│ ◦ ${prefix}followch
│ ◦ ${prefix}untollowch
│ ◦ ${prefix}delppch
│ ◦ ${prefix}createch
│ ◦ ${prefix}botafk
│ ◦ ${prefix}maintenance 
│ ◦ ${prefix}addgb
│ ◦ ${prefix}delgb
│ ◦ ${prefix}jpm
│ ◦ ${prefix}autojoingc
│ ◦ ${prefix}upch
│ ◦ ${prefix}spamcall
│ ◦ ${prefix}spamvc
│ ◦ ${prefix}setppbot
│ ◦ ${prefix}setppbot
│ ◦ ${prefix}addproduk
│ ◦ ${prefix}delproduk
│ ◦ ${prefix}batalorder
│ ◦ ${prefix}confirm
│ ◦ ${prefix}listproduk
│ ◦ ${prefix}approve
│ ◦ ${prefix}reject
│ ◦ ${prefix}addsewa
│ ◦ ${prefix}delsewa
│ ◦ ${prefix}clersession
│ ◦ ${prefix}listsewa
│ ◦ ${prefix}delsewa
│ ◦ ${prefix}ceksewa
│ ◦ ${prefix}setdone
│ ◦ ${prefix}changedone
│ ◦ ${prefix}delsetdone
│ ◦ ${prefix}done
│ ◦ ${prefix}proses
│ ◦ ${prefix}setproses
│ ◦ ${prefix}changeproses
│ ◦ ${prefix}delsetproses
│ ◦ ${prefix}addlist
│ ◦ ${prefix}dellist
│ ◦ ${prefix}backupsc
│ ◦ ${prefix}clearchat
│ ◦ ${prefix}pinchat
│ ◦ ${prefix}unpinchat
│ ◦ ${prefix}updatelist
│ ◦ ${prefix}upswteks
│ ◦ ${prefix}upswvideo
│ ◦ ${prefix}upswaudio
│ ◦ ${prefix}upswimg
│ ◦ ${prefix}colongsw
└─❑ OWNER MENU ❑ 
`);
const bet = {
  title: "DAFTAR MENU",
  sections: [
    {
      title: `Akses Cepat`, 
      highlight_label: `Recommended`,
      rows: [
        {
          title: "⚡ All Menu",
          description: "Lihat semua fitur satanicID",
          id: `.allmenu`, 
        },
      ]
    },
    {
      title: `Kategori Fitur`, 
      highlight_label: ``,
      rows: [
        {
          title: "Group Menu",
          description: "Menampilkan Daftar group Menu",
          id: `.groupmenu`, 
        },
        {
          title: "Search Menu",
          description: "Menampilkan Daftar Search Menu",
          id: `.searchmenu`, 
        },
        {
          title: "Owner Menu",
          description: "Menampilkan Daftar Owner Menu",
          id: `.ownermenu`, 
        },
        {
          title: "Stalk Menu",
          description: "Menampilkan Daftar Stalking menu",
          id: `.stalkmenu`, 
        },
        {
          title: "Game Menu",
          description: "Menampilkan Daftar Game Menu",
          id: `.gamemenu`, 
        },
        {
          title: "Download Menu",
          description: "Menampilkan Daftar Menu Download",
          id: `.downloadmenu`, 
        },
        {
          title: "AI Menu",
          description: "Menampilkan Daftar Menu Group",
          id: `.aimenu`, 
        },
        {
          title: "Other Menu",
          description: "Menampilkan Daftar Menu Other",
          id: `.othermenu`, 
        },
        {
          title: "Tools Menu",
          description: "Menampilkan Daftar Menu Tools",
          id: `.toolsmenu`, 
        },
      ]
    },
    {
      title: `Dokumentasi asli dari script ini`, 
      highlight_label: ``,
      rows: [
        {
          title: "Script",
          description: "💳 script ini gratis 100%",
          id: `.script`, 
        },
        {
          title: "Info Bot",
          description: "📋 Informasi total fitur dan lainnya",
          id: `.infobot`, 
        },
      ]
    }
  ]
}
await sendNanoButtonMenu(m.chat, teks, bet, m)
}
await satanic.sendMessage(from, { audio: { url: global.audio} , mimetype: 'audio/mp4', ptt: true }, { quoted: fkontak })
break
case 'bot':
reply(`hai saya adalah ${global.namaBot} ada yang bisa saya bantu kak`)
break
case 'stalkmenu': { 
  satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
let teks = (`
> hai ${pushname}, salam dari satanic haxor ⚡

┌─❑ STALK MENU ❑ 
│ ◦ ${prefix}igstalk
│ ◦ ${prefix}ttstalk
│ ◦ ${prefix}ffstalk
│ ◦ ${prefix}twstalk
│ ◦ ${prefix}robloxstalk
│ ◦ ${prefix}ghstalk
│ ◦ ${prefix}npmstalk
│ ◦ ${prefix}ytstalk
└─❑ STALK MENU ❑ 

`);
const bet = {
  title: "DAFTAR MENU",
  sections: [
    {
      title: `Akses Cepat`, 
      highlight_label: `Recommended`,
      rows: [
        {
          title: "⚡ All Menu",
          description: "Lihat semua fitur satanicID",
          id: `.allmenu`, 
        },
      ]
    },
    {
      title: `Kategori Fitur`, 
      highlight_label: ``,
      rows: [
        {
          title: "Group Menu",
          description: "Menampilkan Daftar group Menu",
          id: `.groupmenu`, 
        },
        {
          title: "Search Menu",
          description: "Menampilkan Daftar Search Menu",
          id: `.searchmenu`, 
        },
        {
          title: "Owner Menu",
          description: "Menampilkan Daftar Owner Menu",
          id: `.ownermenu`, 
        },
        {
          title: "Stalk Menu",
          description: "Menampilkan Daftar Stalking menu",
          id: `.stalkmenu`, 
        },
        {
          title: "Game Menu",
          description: "Menampilkan Daftar Game Menu",
          id: `.gamemenu`, 
        },
        {
          title: "Download Menu",
          description: "Menampilkan Daftar Menu Download",
          id: `.downloadmenu`, 
        },
        {
          title: "AI Menu",
          description: "Menampilkan Daftar Menu Group",
          id: `.aimenu`, 
        },
        {
          title: "Other Menu",
          description: "Menampilkan Daftar Menu Other",
          id: `.othermenu`, 
        },
        {
          title: "Tools Menu",
          description: "Menampilkan Daftar Menu Tools",
          id: `.toolsmenu`, 
        },
      ]
    },
    {
      title: `Dokumentasi asli dari script ini`, 
      highlight_label: ``,
      rows: [
        {
          title: "Script",
          description: "💳 script ini gratis 100%",
          id: `.script`, 
        },
        {
          title: "Info Bot",
          description: "📋 Informasi total fitur dan lainnya",
          id: `.infobot`, 
        },
        
      ]
    }
  ]
}
await sendNanoButtonMenu(m.chat, teks, bet, m)
}
await satanic.sendMessage(from, { audio: { url: global.audio} , mimetype: 'audio/mp4', ptt: true }, { quoted: fkontak })
break
case 'othermenu': { 
  satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
let teks = (`
> hai ${pushname}, salam dari satanic haxor ⚡

┌─❑ OTHER MENU ❑
│ ◦ ${prefix}jadibot
│ ◦ ${prefix}stopjadibot
│ ◦ ${prefix}listjadibot
│ ◦ ${prefix}jpm
│ ◦ ${prefix}jpmch
│ ◦ ${prefix}addch
│ ◦ ${prefix}listch
│ ◦ ${prefix}delch
│ ◦ ${prefix}savekontak
│ ◦ ${prefix}savekontakuser
│ ◦ ${prefix}jpmstatus
│ ◦ ${prefix}jpmhidetag
│ ◦ ${prefix}list
│ ◦ ${prefix}sewabot
│ ◦ ${prefix}report
│ ◦ ${prefix}rules
│ ◦ ${prefix}qris
│ ◦ ${prefix}jpmdatabase
│ ◦ ${prefix}addidgc
│ ◦ ${prefix}delidgc
│ ◦ ${prefix}listidgc
│ ◦ ${prefix}jpmblacklist
│ ◦ ${prefix}addblacklistgc
│ ◦ ${prefix}delblacklistgc
│ ◦ ${prefix}listblacklistgc
│ ◦ ${prefix}delstatusgc
│ ◦ ${prefix}payment
│ ◦ ${prefix}pushkontak
│ ◦ ${prefix}pushkontakv2
│ ◦ ${prefix}pushkontakv3
│ ◦ ${prefix}pushkontakv4
│ ◦ ${prefix}randomhentai
│ ◦ ${prefix}randomwaifu
│ ◦ ${prefix}artinama
│ ◦ ${prefix}artimimpi
│ ◦ ${prefix}ramaljodoh
│ ◦ ${prefix}ramaljodohbali
│ ◦ ${prefix}ramalcinta
│ ◦ ${prefix}cocoknama
│ ◦ ${prefix}pasangan
│ ◦ ${prefix}suamiistri
│ ◦ ${prefix}jadiannikah
│ ◦ ${prefix}sifatusaha
│ ◦ ${prefix}rezeki
│ ◦ ${prefix}pekerjaan
│ ◦ ${prefix}nasib
│ ◦ ${prefix}penyakit
│ ◦ ${prefix}tarot
│ ◦ ${prefix}fengshui
│ ◦ ${prefix}haribaik
│ ◦ ${prefix}harisangar
│ ◦ ${prefix}harisial
│ ◦ ${prefix}nagahari
│ ◦ ${prefix}arahrezeki
│ ◦ ${prefix}peruntungan
│ ◦ ${prefix}weton
│ ◦ ${prefix}karakter
│ ◦ ${prefix}keberuntungan
│ ◦ ${prefix}memancing
│ ◦ ${prefix}masabubur
│ ◦ ${prefix}zodiak
│ ◦ ${prefix}shio
│ ◦ ${prefix}cekapikey
└─❑ OTHER MENU ❑ 

`);
const bet = {
  title: "DAFTAR MENU",
  sections: [
    {
      title: `Akses Cepat`, 
      highlight_label: `Recommended`,
      rows: [
        {
          title: "⚡ All Menu",
          description: "Lihat semua fitur satanicID",
          id: `.allmenu`, 
        },
      ]
    },
    {
      title: `Kategori Fitur`, 
      highlight_label: ``,
      rows: [
        {
          title: "Group Menu",
          description: "Menampilkan Daftar group Menu",
          id: `.groupmenu`, 
        },
        {
          title: "Search Menu",
          description: "Menampilkan Daftar Search Menu",
          id: `.searchmenu`, 
        },
        {
          title: "Owner Menu",
          description: "Menampilkan Daftar Owner Menu",
          id: `.ownermenu`, 
        },
        {
          title: "Stalk Menu",
          description: "Menampilkan Daftar Stalking menu",
          id: `.stalkmenu`, 
        },
        {
          title: "Game Menu",
          description: "Menampilkan Daftar Game Menu",
          id: `.gamemenu`, 
        },
        {
          title: "Download Menu",
          description: "Menampilkan Daftar Menu Download",
          id: `.downloadmenu`, 
        },
        {
          title: "AI Menu",
          description: "Menampilkan Daftar Menu Group",
          id: `.aimenu`, 
        },
        {
          title: "Other Menu",
          description: "Menampilkan Daftar Menu Other",
          id: `.othermenu`, 
        },
        {
          title: "Tools Menu",
          description: "Menampilkan Daftar Menu Tools",
          id: `.toolsmenu`, 
        },
      ]
    },
    {
      title: `Dokumentasi asli dari script ini`, 
      highlight_label: ``,
      rows: [
        {
          title: "Script",
          description: "💳 script ini gratis 100%",
          id: `.script`, 
        },
        {
          title: "Info Bot",
          description: "📋 Informasi total fitur dan lainnya",
          id: `.infobot`, 
        },
        
      ]
    }
  ]
}
await sendNanoButtonMenu(m.chat, teks, bet, m)
}
await satanic.sendMessage(from, { audio: { url: global.audio} , mimetype: 'audio/mp4', ptt: true }, { quoted: fkontak })
break
case 'gamemenu': { 
  satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
let teks = (`
> hai ${pushname}, salam dari satanic haxor ⚡

┌─❑ GAME MENU ❑ 
│ ◦ ${prefix}truth
│ ◦ ${prefix}dare
│ ◦ ${prefix}ceksifat
│ ◦ ${prefix}asahotak
│ ◦ ${prefix}tekateki
│ ◦ ${prefix}siapaaku
│ ◦ ${prefix}mathquiz
│ ◦ ${prefix}family100
│ ◦ ${prefix}caklontong
│ ◦ ${prefix}tebakgambar
│ ◦ ${prefix}tebakkata 
│ ◦ ${prefix}tebaktebakan
│ ◦ ${prefix}tebakkimia
│ ◦ ${prefix}tebakkalimat
│ ◦ ${prefix}susunkata
│ ◦ ${prefix}tebakwarna
│ ◦ ${prefix}tebakgame
│ ◦ ${prefix}tebakheroml
│ ◦ ${prefix}tebaklagu
│ ◦ ${prefix}tebaklogo
│ ◦ ${prefix}tebakbendera
│ ◦ ${prefix}tebakkartun
│ ◦ ${prefix}tebaklirik
│ ◦ ${prefix}susunkata
│ ◦ ${prefix}cerdascermat
│ ◦ ${prefix}tebaksurah
│ ◦ ${prefix}ulartangga
│ ◦ ${prefix}tictactoe
│ ◦ ${prefix}tebakbom
│ ◦ ${prefix}cekkodam
│ ◦ ${prefix}yatim
│ ◦ ${prefix}piatu
│ ◦ ${prefix}jomblo
│ ◦ ${prefix}waria
│ ◦ ${prefix}koruptor
│ ◦ ${prefix}psikopat
│ ◦ ${prefix}pedofil
│ ◦ ${prefix}miskin
│ ◦ ${prefix}tukangjajan
│ ◦ ${prefix}jelek
│ ◦ ${prefix}mokondo
│ ◦ ${prefix}penipu
│ ◦ ${prefix}tukangcopet
│ ◦ ${prefix}tukangbo
│ ◦ ${prefix}tukangcoli
│ ◦ ${prefix}tukangkawin
│ ◦ ${prefix}ganteng
│ ◦ ${prefix}cantik
│ ◦ ${prefix}tobrut
│ ◦ ${prefix}kurus
│ ◦ ${prefix}maling
│ ◦ ${prefix}kontolgede
│ ◦ ${prefix}tepos
│ ◦ ${prefix}pelakor
│ ◦ ${prefix}jomblo
│ ◦ ${prefix}korbanhts
│ ◦ ${prefix}badut
│ ◦ ${prefix}perampok
│ ◦ ${prefix}begal
│ ◦ ${prefix}wibu
│ ◦ ${prefix}janda
│ ◦ ${prefix}jodohku 
│ ◦ ${prefix}cekyatim
│ ◦ ${prefix}cekjelek
│ ◦ ${prefix}cekjodoh
│ ◦ ${prefix}cekmemek
│ ◦ ${prefix}cekkontol
│ ◦ ${prefix}cekmiskin
│ ◦ ${prefix}cekkaya
│ ◦ ${prefix}cektolol
│ ◦ ${prefix}ceknamabapak
│ ◦ ${prefix}cekwibu
│ ◦ ${prefix}dapatkah
│ ◦ ${prefix}apakah
│ ◦ ${prefix}bagaimana 
│ ◦ ${prefix}rate
│ ◦ ${prefix}when
│ ◦ ${prefix}menfess
│ ◦ ${prefix}mancing
│ ◦ ${prefix}aduayam
│ ◦ ${prefix}tebakangkatogel
│ ◦ ${prefix}balapkarung
│ ◦ ${prefix}tariktambang
│ ◦ ${prefix}tebakkarturemi
│ ◦ ${prefix}balaplari
│ ◦ ${prefix}rolling
│ ◦ ${prefix}investasi 
│ ◦ ${prefix}renang
│ ◦ ${prefix}balasmenfess
│ ◦ ${prefix}stopmenfess
│ ◦ ${prefix}tolakmenfess
└─❑ GAME MENU ❑ 

`);
const bet = {
  title: "DAFTAR MENU",
  sections: [
    {
      title: `Akses Cepat`, 
      highlight_label: `Recommended`,
      rows: [
        {
          title: "⚡ All Menu",
          description: "Lihat semua fitur satanicID",
          id: `.allmenu`, 
        },
      ]
    },
    {
      title: `Kategori Fitur`, 
      highlight_label: ``,
      rows: [
        {
          title: "Group Menu",
          description: "Menampilkan Daftar group Menu",
          id: `.groupmenu`, 
        },
        {
          title: "Search Menu",
          description: "Menampilkan Daftar Search Menu",
          id: `.searchmenu`, 
        },
        {
          title: "Owner Menu",
          description: "Menampilkan Daftar Owner Menu",
          id: `.ownermenu`, 
        },
        {
          title: "Stalk Menu",
          description: "Menampilkan Daftar Stalking menu",
          id: `.stalkmenu`, 
        },
        {
          title: "Game Menu",
          description: "Menampilkan Daftar Game Menu",
          id: `.gamemenu`, 
        },
        {
          title: "Download Menu",
          description: "Menampilkan Daftar Menu Download",
          id: `.downloadmenu`, 
        },
        {
          title: "AI Menu",
          description: "Menampilkan Daftar Menu Group",
          id: `.aimenu`, 
        }, 
        {
          title: "Other Menu",
          description: "Menampilkan Daftar Menu Other",
          id: `.othermenu`, 
        },
        {
          title: "Tools Menu",
          description: "Menampilkan Daftar Menu Tools",
          id: `.toolsmenu`, 
        },
      ]
    },
    {
      title: `Dokumentasi asli dari script ini`, 
      highlight_label: ``,
      rows: [
        {
          title: "Script",
          description: "💳 script ini gratis 100%",
          id: `.script`, 
        },
        {
          title: "Info Bot",
          description: "📋 Informasi total fitur dan lainnya",
          id: `.infobot`, 
        },        
      ]
    }
  ]
}
await sendNanoButtonMenu(m.chat, teks, bet, m)
}
await satanic.sendMessage(from, { audio: { url: global.audio} , mimetype: 'audio/mp4', ptt: true }, { quoted: fkontak })
break
case 'leavegc': {
if (!isCreator) return 
await satanic.groupLeave(m.chat)
await reply(`*[ Done ]*`)
            }
break
case 'downloadmenu': { 
  satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
let teks = (`
> hai ${pushname}, salam dari satanic haxor ⚡

┌─❑ DOWNLOAD ❑ 
│ ◦ ${prefix}ig
│ ◦ ${prefix}igdl2
│ ◦ ${prefix}ttdl
│ ◦ ${prefix}fbdl
│ ◦ ${prefix}play
│ ◦ ${prefix}igslide
│ ◦ ${prefix}ttslide
│ ◦ ${prefix}igmp3 
│ ◦ ${prefix}ttmp3
│ ◦ ${prefix}ytmp4
│ ◦ ${prefix}ytmp3
│ ◦ ${prefix}videy
│ ◦ ${prefix}threads
│ ◦ ${prefix}spotify
│ ◦ ${prefix}terabox
│ ◦ ${prefix}capcut
│ ◦ ${prefix}mediafire
│ ◦ ${prefix}gitclone
│ ◦ ${prefix}cocofun
│ ◦ ${prefix}scdl
│ ◦ ${prefix}snackvideo
│ ◦ ${prefix}applemusicdl
└─❑ DOWNLOAD ❑ 

`);
const bet = {
  title: "DAFTAR MENU",
  sections: [
    {
      title: `Akses Cepat`, 
      highlight_label: `Recommended`,
      rows: [
        {
          title: "⚡ All Menu",
          description: "Lihat semua fitur satanicID",
          id: `.allmenu`, 
        },
      ]
    },
    {
      title: `Kategori Fitur`, 
      highlight_label: ``,
      rows: [
        {
          title: "Group Menu",
          description: "Menampilkan Daftar group Menu",
          id: `.groupmenu`, 
        },
        {
          title: "Search Menu",
          description: "Menampilkan Daftar Search Menu",
          id: `.searchmenu`, 
        },
        {
          title: "Owner Menu",
          description: "Menampilkan Daftar Owner Menu",
          id: `.ownermenu`, 
        },
        {
          title: "Stalk Menu",
          description: "Menampilkan Daftar Stalking menu",
          id: `.stalkmenu`, 
        },
        {
          title: "Game Menu",
          description: "Menampilkan Daftar Game Menu",
          id: `.gamemenu`, 
        },
        {
          title: "Download Menu",
          description: "Menampilkan Daftar Menu Download",
          id: `.downloadmenu`, 
        },
        {
          title: "AI Menu",
          description: "Menampilkan Daftar Menu Group",
          id: `.aimenu`, 
        },
        {
          title: "Tools Menu",
          description: "Menampilkan Daftar Menu Tools",
          id: `.toolsmenu`, 
        },
      ]
    },
    {
      title: `Dokumentasi asli dari script ini`, 
      highlight_label: ``,
      rows: [
        {
          title: "Script",
          description: "💳 script ini gratis 100%",
          id: `.script`, 
        },
        {
          title: "Info Bot",
          description: "📋 Informasi total fitur dan lainnya",
          id: `.infobot`, 
        },
      ]
    }
  ]
}
await sendNanoButtonMenu(m.chat, teks, bet, m)
}
await satanic.sendMessage(from, { audio: { url: global.audio} , mimetype: 'audio/mp4', ptt: true }, { quoted: fkontak })
break
 case 'install':
case 'npm': {
if (!isCreator) return 
if (!text) return reply(`Mau install module apa?\nContoh: ${prefix + command} axios`)
reply(`⏳ Sedang menginstall module *${text}*...\nMohon tunggu, bot akan restart otomatis jika berhasil.`)
    require('child_process').exec(`npm install ${text}`, (err, stdout, stderr) => {
        if (err) {
return reply(`❌ Gagal menginstall module: ${err.message}`)
        }
        satanic.sendMessage(m.chat, { 
            text: `✅ Sukses install *${text}*!\n\n📝 Output:\n${stdout}\n\n♻️ Bot sedang merestart sistem...` 
        }, { quoted: fkontak }).then(() => {
            setTimeout(() => {
                process.exit()
            }, 3000)
        })
    })
}
break        

case 'aimenu': { 
  satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
let teks = (`
> hai ${pushname}, salam dari satanic haxor ⚡

┌─❑ AI MENU ❑ 
│ ◦ ${prefix}ai
│ ◦ ${prefix}felo
│ ◦ ${prefix}gita
│ ◦ ${prefix}aqua
│ ◦ ${prefix}gpt5
│ ◦ ${prefix}qwen
│ ◦ ${prefix}claude
│ ◦ ${prefix}claude-45
│ ◦ ${prefix}glm47
│ ◦ ${prefix}kimi-vision
│ ◦ ${prefix}meta-ai
│ ◦ ${prefix}deepseek-pro
│ ◦ ${prefix}gpt-oss2b 
│ ◦ ${prefix}nanobanana2
│ ◦ ${prefix}editimg
│ ◦ ${prefix}jokowiai
│ ◦ ${prefix}prabowoai
│ ◦ ${prefix}chatai
│ ◦ ${prefix}openai
│ ◦ ${prefix}epsilon
│ ◦ ${prefix}copilot
│ ◦ ${prefix}webpilot
│ ◦ ${prefix}deepseek
│ ◦ ${prefix}illama-code
│ ◦ ${prefix}illama-vision
│ ◦ ${prefix}text2img
│ ◦ ${prefix}texttoimg
│ ◦ ${prefix}flux-schnell
│ ◦ ${prefix}gpt-5.1
│ ◦ ${prefix}gpt-5-online
│ ◦ ${prefix}gpt-5
│ ◦ ${prefix}gpt-5-nano
│ ◦ ${prefix}gpt-5-mini
│ ◦ ${prefix}openai-o1
│ ◦ ${prefix}openai-o3
│ ◦ ${prefix}openai-o3-mini
│ ◦ ${prefix}gpt-4o
│ ◦ ${prefix}openai-o4-mini
│ ◦ ${prefix}gpt-4.1-mini
│ ◦ ${prefix}gpt-4.1-nano
│ ◦ ${prefix}gpt-5.3
│ ◦ ${prefix}gpt-5.4
│ ◦ ${prefix}gpt-5.5 
│ ◦ ${prefix}img2img
│ ◦ ${prefix}talkingphoto
│ ◦ ${prefix}removecloth 
│ ◦ ${prefix}nanobanana
│ ◦ ${prefix}gpt2image
│ ◦ ${prefix}jadipresiden
│ ◦ ${prefix}jadibugil
│ ◦ ${prefix}jadianime
│ ◦ ${prefix}jadizombie
│ ◦ ${prefix}jadibiliard
│ ◦ ${prefix}jadifigure
│ ◦ ${prefix}jadimacbook
│ ◦ ${prefix}texttovideo
│ ◦ ${prefix}tosad
│ ◦ ${prefix}tosatan
│ ◦ ${prefix}tosdmtinggi
│ ◦ ${prefix}toreal
│ ◦ ${prefix}tomoai
│ ◦ ${prefix}tomaya
│ ◦ ${prefix}tolego
│ ◦ ${prefix}tokamboja
│ ◦ ${prefix}tokacamata
│ ◦ ${prefix}tojepang
│ ◦ ${prefix}nanobananapro
│ ◦ ${prefix}toghibli
│ ◦ ${prefix}todubai
│ ◦ ${prefix}todpr
│ ◦ ${prefix}totua
│ ◦ ${prefix}tohitam
│ ◦ ${prefix}totato
│ ◦ ${prefix}topeci
│ ◦ ${prefix}tovintage
│ ◦ ${prefix}topolaroid
│ ◦ ${prefix}tochibi
│ ◦ ${prefix}tobrewok
│ ◦ ${prefix}tobabi
│ ◦ ${prefix}tofigura
│ ◦ ${prefix}tofigurav2
│ ◦ ${prefix}tofigurav3
│ ◦ ${prefix}topacar
│ ◦ ${prefix}topacarv2
│ ◦ ${prefix}tozombie
│ ◦ ${prefix}topenjara
│ ◦ ${prefix}tojapanese
│ ◦ ${prefix}toblonde
│ ◦ ${prefix}tobotak
│ ◦ ${prefix}tohijab
│ ◦ ${prefix}topejabat
│ ◦ ${prefix}tokah
│ ◦ ${prefix}tomirror
│ ◦ ${prefix}toanime
│ ◦ ${prefix}agedetection 
│ ◦ ${prefix}alien-glow
│ ◦ ${prefix}neon-blue
│ ◦ ${prefix}neon-pink
│ ◦ ${prefix}neon-purple
│ ◦ ${prefix}neon-red
│ ◦ ${prefix}neon-gold
│ ◦ ${prefix}neon-cyan
│ ◦ ${prefix}neon-orange
│ ◦ ${prefix}neon-white
│ ◦ ${prefix}3d-outline
│ ◦ ${prefix}chrome
│ ◦ ${prefix}gold-chrome
│ ◦ ${prefix}fire
│ ◦ ${prefix}inferno
│ ◦ ${prefix}lava
│ ◦ ${prefix}embossed
│ ◦ ${prefix}gold-embossed
│ ◦ ${prefix}classic-gold
│ ◦ ${prefix}retro
│ ◦ ${prefix}groovy
│ ◦ ${prefix}steel
│ ◦ ${prefix}dark-steel
│ ◦ ${prefix}comic-pop
│ ◦ ${prefix}comic-red
│ ◦ ${prefix}graffiti
│ ◦ ${prefix}graffiti-green
│ ◦ ${prefix}old-stone
│ ◦ ${prefix}carved
│ ◦ ${prefix}glitter-gold
│ ◦ ${prefix}glitter-silver
│ ◦ ${prefix}glitter-pink
│ ◦ ${prefix}glitter-blue
│ ◦ ${prefix}glitter-green
│ ◦ ${prefix}gradient
│ ◦ ${prefix}gradient-blue
│ ◦ ${prefix}curvy
│ ◦ ${prefix}basic-bold
│ ◦ ${prefix}scratch
│ ◦ ${prefix}elegant
│ ◦ ${prefix}tribal
│ ◦ ${prefix}sketch
│ ◦ ${prefix}racing
│ ◦ ${prefix}medieval
│ ◦ ${prefix}chalk
│ ◦ ${prefix}sparkle
│ ◦ ${prefix}sharp
│ ◦ ${prefix}fantasy
│ ◦ ${prefix}watercolor
│ ◦ ${prefix}blocky
│ ◦ ${prefix}glass
│ ◦ ${prefix}stencil
│ ◦ ${prefix}matrix
│ ◦ ${prefix}nifty
│ ◦ ${prefix}futuristic
│ ◦ ${prefix}vintage
│ ◦ ${prefix}candy
│ ◦ ${prefix}pastel
│ ◦ ${prefix}metallic
│ ◦ ${prefix}pixel
│ ◦ ${prefix}western
│ ◦ ${prefix}horror
│ ◦ ${prefix}sci-fi
│ ◦ ${prefix}frost
│ ◦ ${prefix}neon
│ ◦ ${prefix}colorfulglow
│ ◦ ${prefix}advancedglow
│ ◦ ${prefix}neononline
│ ◦ ${prefix}blueneon
│ ◦ ${prefix}neontext
│ ◦ ${prefix}neonlight
│ ◦ ${prefix}greenneon
│ ◦ ${prefix}greenlightneon
│ ◦ ${prefix}blueneonlogo
│ ◦ ${prefix}galaxyneon
│ ◦ ${prefix}retroneon
│ ◦ ${prefix}multicolorneon
│ ◦ ${prefix}hackerneon
│ ◦ ${prefix}devilwings
│ ◦ ${prefix}glowtext
│ ◦ ${prefix}neonglitch
│ ◦ ${prefix}neonwall
│ ◦ ${prefix}led
│ ◦ ${prefix}writeonwetglass
│ ◦ ${prefix}deadpool
│ ◦ ${prefix}dragonball
│ ◦ ${prefix}typographypavement
│ ◦ ${prefix}blackpinklogo
│ ◦ ${prefix}bornpink
│ ◦ ${prefix}frozen
│ ◦ ${prefix}gold
│ ◦ ${prefix}horror
│ ◦ ${prefix}blood
│ ◦ ${prefix}lava
│ ◦ ${prefix}thunder
│ ◦ ${prefix}matrix
│ ◦ ${prefix}smoke
│ ◦ ${prefix}naruto
│ ◦ ${prefix}avengers3d
│ ◦ ${prefix}americanflag3d
│ ◦ ${prefix}wooden3d
│ ◦ ${prefix}cubic3d
│ ◦ ${prefix}water3d
│ ◦ ${prefix}text3d
│ ◦ ${prefix}graffiti3d
│ ◦ ${prefix}silver3d
│ ◦ ${prefix}style3d
│ ◦ ${prefix}metal3d
│ ◦ ${prefix}comic3d
│ ◦ ${prefix}hologram3d
│ ◦ ${prefix}gradient3d
│ ◦ ${prefix}stone3d
│ ◦ ${prefix}space3d
│ ◦ ${prefix}sand3d
│ ◦ ${prefix}snow3d
│ ◦ ${prefix}papercut3d
│ ◦ ${prefix}balloon3d
│ ◦ ${prefix}christmas3d
│ ◦ ${prefix}christmas-sparkles
│ ◦ ${prefix}christmas-snow3d
│ ◦ ${prefix}christmas-frozen
│ ◦ ${prefix}christmas-gold
│ ◦ ${prefix}newyear-gold
│ ◦ ${prefix}pubglogo
│ ◦ ${prefix}valorantbanner
│ ◦ ${prefix}birthday3d
│ ◦ ${prefix}pubgbirthday
│ ◦ ${prefix}flowerbirthday
│ ◦ ${prefix}fire
│ ◦ ${prefix}flamelettering
│ ◦ ${prefix}horrorcemetery
│ ◦ ${prefix}halloweentheme
│ ◦ ${prefix}bloodwall
│ ◦ ${prefix}frankensteintext
│ ◦ ${prefix}horrormetal
│ ◦ ${prefix}halloweentext
│ ◦ ${prefix}halloweeneffect
│ ◦ ${prefix}horrortext
│ ◦ ${prefix}halloweencard
│ ◦ ${prefix}nametattoo
│ ◦ ${prefix}foilballoon3d
│ ◦ ${prefix}colorfulpaint3d
│ ◦ ${prefix}blackpinksignature
│ ◦ ${prefix}dragonballtext
│ ◦ ${prefix}glossysilver3d
│ ◦ ${prefix}typographyart
│ ◦ ${prefix}foggyglass
│ ◦ ${prefix}narutologo
│ ◦ ${prefix}chocolatecake
│ ◦ ${prefix}rosecake
│ ◦ ${prefix}amazingflowercake
│ ◦ ${prefix}redrosebirthday
│ ◦ ${prefix}greetingcake
│ ◦ ${prefix}anniversarycake
│ ◦ ${prefix}romanticflowercake
│ ◦ ${prefix}pubglogo2
│ ◦ ${prefix}pubgesports
│ ◦ ${prefix}warzonecover
│ ◦ ${prefix}aovbanner
│ ◦ ${prefix}sunlightshadow
│ ◦ ${prefix}heartwinggif
│ ◦ ${prefix}loveballoons
│ ◦ ${prefix}cfcover
│ ◦ ${prefix}lolcover
│ ◦ ${prefix}csgocover
│ ◦ ${prefix}dota2cover
│ ◦ ${prefix}overwatchcover
│ ◦ ${prefix}onepiececover
│ ◦ ${prefix}dragonballcover
│ ◦ ${prefix}youtubebutton
│ ◦ ${prefix}examcrank
└─❑ AI MENU ❑ 

`);
const bet = {
  title: "DAFTAR MENU",
  sections: [
    {
      title: `Akses Cepat`, 
      highlight_label: `Recommended`,
      rows: [
        {
          title: "⚡ All Menu",
          description: "Lihat semua fitur satanicID",
          id: `.allmenu`, 
        },
      ]
    },
    {
      title: `Kategori Fitur`, 
      highlight_label: ``,
      rows: [
        {
          title: "Group Menu",
          description: "Menampilkan Daftar group Menu",
          id: `.groupmenu`, 
        },
        {
          title: "Search Menu",
          description: "Menampilkan Daftar Search Menu",
          id: `.searchmenu`, 
        },
        {
          title: "Owner Menu",
          description: "Menampilkan Daftar Owner Menu",
          id: `.ownermenu`, 
        },
        {
          title: "Stalk Menu",
          description: "Menampilkan Daftar Stalking menu",
          id: `.stalkmenu`, 
        },
        {
          title: "Game Menu",
          description: "Menampilkan Daftar Game Menu",
          id: `.gamemenu`, 
        },
        {
          title: "Download Menu",
          description: "Menampilkan Daftar Menu Download",
          id: `.downloadmenu`, 
        },
        {
          title: "AI Menu",
          description: "Menampilkan Daftar Menu Group",
          id: `.aimenu`, 
        },
        {
          title: "Tools Menu",
          description: "Menampilkan Daftar Menu Tools",
          id: `.toolsmenu`, 
        },
      ]
    },
    {
      title: `Dokumentasi asli dari script ini`, 
      highlight_label: ``,
      rows: [
        {
          title: "Script",
          description: "💳 script ini gratis 100%",
          id: `.script`, 
        },
        {
          title: "Info Bot",
          description: "📋 Informasi total fitur dan lainnya",
          id: `.infobot`, 
        },
      ]
    }
  ]
}
await sendNanoButtonMenu(m.chat, teks, bet, m)
}
await satanic.sendMessage(from, { audio: { url: global.audio} , mimetype: 'audio/mp4', ptt: true }, { quoted: fkontak })
break
case 'toolsmenu': { 
  satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
let teks = (`
> hai ${pushname}, salam dari satanic haxor ⚡

┌─❑ TOOLS MENU ❑ 
│ ◦ ${prefix}hd
│ ◦ ${prefix}Ocr
│ ◦ ${prefix}esrgan
│ ◦ ${prefix}cekresi
│ ◦ ${prefix}hdvid
│ ◦ ${prefix}google
│ ◦ ${prefix}tourl
│ ◦ ${prefix}tourl2
│ ◦ ${prefix}ssweb
│ ◦ ${prefix}translate
│ ◦ ${prefix}kodepos
│ ◦ ${prefix}removebg
│ ◦ ${prefix}removebg2
│ ◦ ${prefix}skiplink
│ ◦ ${prefix}brat
│ ◦ ${prefix}bratbahlil
│ ◦ ${prefix}brathd
│ ◦ ${prefix}pakustad
│ ◦ ${prefix}bratcewe
│ ◦ ${prefix}bratpatrick
│ ◦ ${prefix}emojimix
│ ◦ ${prefix}attp
│ ◦ ${prefix}bratsquidward
│ ◦ ${prefix}animebrat
│ ◦ ${prefix}bratvid
│ ◦ ${prefix}smeme
│ ◦ ${prefix}iqc
│ ◦ ${prefix}translate
│ ◦ ${prefix}kalkulator
│ ◦ ${prefix}qc
│ ◦ ${prefix}fakedana
│ ◦ ${prefix}fakeovo
│ ◦ ${prefix}fakegopay
│ ◦ ${prefix}fakeml
│ ◦ ${prefix}faketiktok
│ ◦ ${prefix}balogo
│ ◦ ${prefix}cinema
│ ◦ ${prefix}struk
│ ◦ ${prefix}fakebangjago
│ ◦ ${prefix}fakeff
│ ◦ ${prefix}fakektp
│ ◦ ${prefix}ceknik
│ ◦ ${prefix}whatmusic
│ ◦ ${prefix}carbonify
│ ◦ ${prefix}tts 
│ ◦ ${prefix}tts1
│ ◦ ${prefix}tts2
│ ◦ ${prefix}tts3
│ ◦ ${prefix}texttospeech 
│ ◦ ${prefix}say
│ ◦ ${prefix}ttsgoku 
│ ◦ ${prefix}ttseminem 
│ ◦ ${prefix}ttsmickey
│ ◦ ${prefix}ttsnahida
│ ◦ ${prefix}ttselon 
│ ◦ ${prefix}ttsoptimus
│ ◦ ${prefix}bass 
│ ◦ ${prefix}blown 
│ ◦ ${prefix}deep 
│ ◦ ${prefix}earrape 
│ ◦ ${prefix}fast 
│ ◦ ${prefix}fat 
│ ◦ ${prefix}nightcore 
│ ◦ ${prefix}reverse 
│ ◦ ${prefix}robot
│ ◦ ${prefix}slow  
│ ◦ ${prefix}smooth 
│ ◦ ${prefix}squirrel
│ ◦ ${prefix}sticker
│ ◦ ${prefix}toimg
│ ◦ ${prefix}tomp3
│ ◦ ${prefix}tomp4
│ ◦ ${prefix}togif
│ ◦ ${prefix}tovideo
│ ◦ ${prefix}toptv
│ ◦ ${prefix}sticker
│ ◦ ${prefix}toimg
│ ◦ ${prefix}tomp3
│ ◦ ${prefix}tomp4
│ ◦ ${prefix}togif
│ ◦ ${prefix}tovideo
│ ◦ ${prefix}toptv
│ ◦ ${prefix}webclone
│ ◦ ${prefix}inspectsite 
│ ◦ ${prefix}geoip
│ ◦ ${prefix}tohtml
│ ◦ ${prefix}tojs
└─❑ TOOLS MENU ❑ 
`);
const bet = {
  title: "DAFTAR MENU",
  sections: [
    {
      title: `Akses Cepat`, 
      highlight_label: `Recommended`,
      rows: [
        {
          title: "⚡ All Menu",
          description: "Lihat semua fitur satanicID",
          id: `.allmenu`, 
        },
      ]
    },
    {
      title: `Kategori Fitur`, 
      highlight_label: ``,
      rows: [
        {
          title: "Group Menu",
          description: "Menampilkan Daftar group Menu",
          id: `.groupmenu`, 
        },
        {
          title: "Search Menu",
          description: "Menampilkan Daftar Search Menu",
          id: `.searchmenu`, 
        },
        {
          title: "Owner Menu",
          description: "Menampilkan Daftar Owner Menu",
          id: `.ownermenu`, 
        },
        {
          title: "Stalk Menu",
          description: "Menampilkan Daftar Stalking menu",
          id: `.stalkmenu`, 
        },
        {
          title: "Game Menu",
          description: "Menampilkan Daftar Game Menu",
          id: `.gamemenu`, 
        },
        {
          title: "Download Menu",
          description: "Menampilkan Daftar Menu Download",
          id: `.downloadmenu`, 
        },
        {
          title: "AI Menu",
          description: "Menampilkan Daftar Menu Group",
          id: `.aimenu`, 
        },
        {
          title: "Tools Menu",
          description: "Menampilkan Daftar Menu Tools",
          id: `.toolsmenu`, 
        },
      ]
    },
    {
      title: `Dokumentasi asli dari script ini`, 
      highlight_label: ``,
      rows: [
        {
          title: "Script",
          description: "💳 script ini gratis 100%",
          id: `.script`, 
        },
        {
          title: "Info Bot",
          description: "📋 Informasi total fitur dan lainnya",
          id: `.infobot`, 
        },
      ]
    }
  ]
}
await sendNanoButtonMenu(m.chat, teks, bet, m)
}
await satanic.sendMessage(from, { audio: { url: global.audio} , mimetype: 'audio/mp4', ptt: true }, { quoted: fkontak })
break
case 'stalkwa': {
    try {
        let num = m.quoted?.sender || m.mentionedJid?.[0] || text
        if (!num) 
        num = num.replace(/\D/g, '') + '@s.whatsapp.net'
        if (!(await satanic.onWhatsApp(num))[0]?.exists) throw 'User not exists'
        let img = await satanic.profilePictureUrl(num, 'image').catch(_ => '../../storage/src/avatar_contact.png')
        let bio = await satanic.fetchStatus(num).catch(_ => {})
        let name = await satanic.getName(num)
        let business = await satanic.getBusinessProfile(num)
        
        let wea = `\t\t\t\t*▾ WHATSAPP ▾*\n\n`
        wea += `*° Country :* ${country.toUpperCase()}\n`
        wea += `*° Name :* ${name ? name : '-'}\n`
        wea += `*° Format Number :* ${format.getNumber('international')}\n`
        wea += `*° Url Api :* wa.me/${num.split('@')[0]}\n`
        wea += `*° Mentions :* @${num.split('@')[0]}\n`
        wea += `*° Status :* ${bio?.status || '-'}\n`
        wea += `*° Date Status :* ${bio?.setAt ? moment(bio.setAt.toDateString()).locale('id').format('LL') : '-'}\n\n`
        
        if (business) {
            wea += `\t\t\t\t*▾ INFO BUSINESS ▾*\n\n`
            wea += `*° BusinessId :* ${business.wid}\n`
            wea += `*° Website :* ${business.website ? business.website : '-'}\n`
            wea += `*° Email :* ${business.email ? business.email : '-'}\n`
            wea += `*° Category :* ${business.category}\n`
            wea += `*° Address :* ${business.address ? business.address : '-'}\n`
            wea += `*° Timeone :* ${business.business_hours.timezone ? business.business_hours.timezone : '-'}\n`
            wea += `*° Descripcion* : ${business.description ? business.description : '-'}`
        } else {
            wea += `*Standard WhatsApp Account*`
        }
        
        if (img) {
            await satanic.sendMessage(m.chat, {
                image: {
                    url: img
                },
                caption: wea,
                mentions: [num]
            }, {
                quoted: m
            })
        } else {
            m.reply(wea)
        }
    } catch (e) {
        console.error('Error:', e)
        m.reply(`❌ Error: ${e.message}`)
    }
}
break;
case 'allmenu3': {
    try {                  
        let txt = `> Halo ${pushname} saya adalah ${global.namaBot} asisten ${global.namaowner}, berikut daftar list menu yang tersedia dibawah ini 
        
┌─❑ GROUP MENU ❑ 
│ ◦ ${prefix}add
│ ◦ ${prefix}kick
│ ◦ ${prefix}warn
│ ◦ ${prefix}grup
│ ◦ ${prefix}left <on/of>
│ ◦ ${prefix}poll
│ ◦ ${prefix}afk
│ ◦ ${prefix}ban
│ ◦ ${prefix}unban
│ ◦ ${prefix}listban
│ ◦ ${prefix}totag
│ ◦ ${prefix}rvo
│ ◦ ${prefix}getpp
│ ◦ ${prefix}listpc
│ ◦ ${prefix}listgc
│ ◦ ${prefix}opentime
│ ◦ ${prefix}closetime
│ ◦ ${prefix}tagadmin
│ ◦ ${prefix}editinfo
│ ◦ ${prefix}reminder
│ ◦ ${prefix}tagall
│ ◦ ${prefix}grup <open/close>
│ ◦ ${prefix}promote
│ ◦ ${prefix}welcome <on/of>
│ ◦ ${prefix}demote
│ ◦ ${prefix}listwarn
│ ◦ ${prefix}delete
│ ◦ ${prefix}resetwarn
│ ◦ ${prefix}delwarn
│ ◦ ${prefix}listonline
│ ◦ ${prefix}mutegc
│ ◦ ${prefix}requestjoin
│ ◦ ${prefix}getppgc
│ ◦ ${prefix}setname
│ ◦ ${prefix}setppgc
│ ◦ ${prefix}setdesk
│ ◦ ${prefix}cekidch
│ ◦ ${prefix}autoaigrup
│ ◦ ${prefix}cekidgc
│ ◦ ${prefix}antitagsw
│ ◦ ${prefix}antilink
│ ◦ ${prefix}hidetag
│ ◦ ${prefix}reactch
│ ◦ ${prefix}revoke
│ ◦ ${prefix}linkgc
│ ◦ ${prefix}upswgc
│ ◦ ${prefix}promotenotif
│ ◦ ${prefix}antibadword
│ ◦ ${prefix}addbadword
│ ◦ ${prefix}delbadword
│ ◦ ${prefix}listbadword 
│ ◦ ${prefix}demotenotif
│ ◦ ${prefix}blacklist
│ ◦ ${prefix}sider
│ ◦ ${prefix}siderv2
│ ◦ ${prefix}topmember
│ ◦ ${prefix}unblacklist
│ ◦ ${prefix}listblacklist
│ ◦ ${prefix}addautogc
│ ◦ ${prefix}delautogc
│ ◦ ${prefix}listautogc
│ ◦ ${prefix}autosholat 
│ ◦ ${prefix}setwelcome
│ ◦ ${prefix}banfitur
│ ◦ ${prefix}unbanfitur
│ ◦ ${prefix}listbanfitur
│ ◦ ${prefix}setleft
│ ◦ ${prefix}kickme
│ ◦ ${prefix}changeleft
│ ◦ ${prefix}setleft
│ ◦ ${prefix}delsetleft
└─❑ GROUP MENU ❑ 

┌─❑ AI MENU ❑ 
│ ◦ ${prefix}ai
│ ◦ ${prefix}felo
│ ◦ ${prefix}gita
│ ◦ ${prefix}aqua
│ ◦ ${prefix}gpt5
│ ◦ ${prefix}qwen
│ ◦ ${prefix}claude
│ ◦ ${prefix}claude-45
│ ◦ ${prefix}glm47
│ ◦ ${prefix}kimi-vision
│ ◦ ${prefix}meta-ai
│ ◦ ${prefix}deepseek-pro
│ ◦ ${prefix}gpt-oss2b 
│ ◦ ${prefix}nanobanana2
│ ◦ ${prefix}editimg
│ ◦ ${prefix}jokowiai
│ ◦ ${prefix}prabowoai
│ ◦ ${prefix}chatai
│ ◦ ${prefix}openai
│ ◦ ${prefix}epsilon
│ ◦ ${prefix}copilot
│ ◦ ${prefix}webpilot
│ ◦ ${prefix}deepseek
│ ◦ ${prefix}illama-code
│ ◦ ${prefix}illama-vision
│ ◦ ${prefix}text2img
│ ◦ ${prefix}texttoimg
│ ◦ ${prefix}flux-schnell
│ ◦ ${prefix}gpt-5.1
│ ◦ ${prefix}gpt-5-online
│ ◦ ${prefix}gpt-5
│ ◦ ${prefix}gpt-5-nano
│ ◦ ${prefix}gpt-5-mini
│ ◦ ${prefix}openai-o1
│ ◦ ${prefix}openai-o3
│ ◦ ${prefix}openai-o3-mini
│ ◦ ${prefix}gpt-4o
│ ◦ ${prefix}openai-o4-mini
│ ◦ ${prefix}gpt-4.1-mini
│ ◦ ${prefix}gpt-4.1-nano
│ ◦ ${prefix}gpt-5.3
│ ◦ ${prefix}gpt-5.4
│ ◦ ${prefix}gpt-5.5 
│ ◦ ${prefix}img2img
│ ◦ ${prefix}talkingphoto
│ ◦ ${prefix}removecloth 
│ ◦ ${prefix}nanobanana
│ ◦ ${prefix}gpt2image
│ ◦ ${prefix}jadipresiden
│ ◦ ${prefix}jadibugil
│ ◦ ${prefix}jadianime
│ ◦ ${prefix}jadizombie
│ ◦ ${prefix}jadibiliard
│ ◦ ${prefix}jadifigure
│ ◦ ${prefix}jadimacbook
│ ◦ ${prefix}texttovideo
│ ◦ ${prefix}tosad
│ ◦ ${prefix}tosatan
│ ◦ ${prefix}tosdmtinggi
│ ◦ ${prefix}toreal
│ ◦ ${prefix}tomoai
│ ◦ ${prefix}tomaya
│ ◦ ${prefix}tolego
│ ◦ ${prefix}tokamboja
│ ◦ ${prefix}tokacamata
│ ◦ ${prefix}tojepang
│ ◦ ${prefix}nanobananapro
│ ◦ ${prefix}toghibli
│ ◦ ${prefix}todubai
│ ◦ ${prefix}todpr
│ ◦ ${prefix}totua
│ ◦ ${prefix}tohitam
│ ◦ ${prefix}totato
│ ◦ ${prefix}topeci
│ ◦ ${prefix}tovintage
│ ◦ ${prefix}topolaroid
│ ◦ ${prefix}tochibi
│ ◦ ${prefix}tobrewok
│ ◦ ${prefix}tobabi
│ ◦ ${prefix}tofigura
│ ◦ ${prefix}tofigurav2
│ ◦ ${prefix}tofigurav3
│ ◦ ${prefix}topacar
│ ◦ ${prefix}topacarv2
│ ◦ ${prefix}tozombie
│ ◦ ${prefix}topenjara
│ ◦ ${prefix}tojapanese
│ ◦ ${prefix}toblonde
│ ◦ ${prefix}tobotak
│ ◦ ${prefix}tohijab
│ ◦ ${prefix}topejabat
│ ◦ ${prefix}tokah
│ ◦ ${prefix}tomirror
│ ◦ ${prefix}toanime
│ ◦ ${prefix}agedetection 
│ ◦ ${prefix}alien-glow
│ ◦ ${prefix}neon-blue
│ ◦ ${prefix}neon-pink
│ ◦ ${prefix}neon-purple
│ ◦ ${prefix}neon-red
│ ◦ ${prefix}neon-gold
│ ◦ ${prefix}neon-cyan
│ ◦ ${prefix}neon-orange
│ ◦ ${prefix}neon-white
│ ◦ ${prefix}3d-outline
│ ◦ ${prefix}chrome
│ ◦ ${prefix}gold-chrome
│ ◦ ${prefix}fire
│ ◦ ${prefix}inferno
│ ◦ ${prefix}lava
│ ◦ ${prefix}embossed
│ ◦ ${prefix}gold-embossed
│ ◦ ${prefix}classic-gold
│ ◦ ${prefix}retro
│ ◦ ${prefix}groovy
│ ◦ ${prefix}steel
│ ◦ ${prefix}dark-steel
│ ◦ ${prefix}comic-pop
│ ◦ ${prefix}comic-red
│ ◦ ${prefix}graffiti
│ ◦ ${prefix}graffiti-green
│ ◦ ${prefix}old-stone
│ ◦ ${prefix}carved
│ ◦ ${prefix}glitter-gold
│ ◦ ${prefix}glitter-silver
│ ◦ ${prefix}glitter-pink
│ ◦ ${prefix}glitter-blue
│ ◦ ${prefix}glitter-green
│ ◦ ${prefix}gradient
│ ◦ ${prefix}gradient-blue
│ ◦ ${prefix}curvy
│ ◦ ${prefix}basic-bold
│ ◦ ${prefix}scratch
│ ◦ ${prefix}elegant
│ ◦ ${prefix}tribal
│ ◦ ${prefix}sketch
│ ◦ ${prefix}racing
│ ◦ ${prefix}medieval
│ ◦ ${prefix}chalk
│ ◦ ${prefix}sparkle
│ ◦ ${prefix}sharp
│ ◦ ${prefix}fantasy
│ ◦ ${prefix}watercolor
│ ◦ ${prefix}blocky
│ ◦ ${prefix}glass
│ ◦ ${prefix}stencil
│ ◦ ${prefix}matrix
│ ◦ ${prefix}nifty
│ ◦ ${prefix}futuristic
│ ◦ ${prefix}vintage
│ ◦ ${prefix}candy
│ ◦ ${prefix}pastel
│ ◦ ${prefix}metallic
│ ◦ ${prefix}pixel
│ ◦ ${prefix}western
│ ◦ ${prefix}horror
│ ◦ ${prefix}sci-fi
│ ◦ ${prefix}frost
│ ◦ ${prefix}neon
│ ◦ ${prefix}colorfulglow
│ ◦ ${prefix}advancedglow
│ ◦ ${prefix}neononline
│ ◦ ${prefix}blueneon
│ ◦ ${prefix}neontext
│ ◦ ${prefix}neonlight
│ ◦ ${prefix}greenneon
│ ◦ ${prefix}greenlightneon
│ ◦ ${prefix}blueneonlogo
│ ◦ ${prefix}galaxyneon
│ ◦ ${prefix}retroneon
│ ◦ ${prefix}multicolorneon
│ ◦ ${prefix}hackerneon
│ ◦ ${prefix}devilwings
│ ◦ ${prefix}glowtext
│ ◦ ${prefix}neonglitch
│ ◦ ${prefix}neonwall
│ ◦ ${prefix}led
│ ◦ ${prefix}writeonwetglass
│ ◦ ${prefix}deadpool
│ ◦ ${prefix}dragonball
│ ◦ ${prefix}typographypavement
│ ◦ ${prefix}blackpinklogo
│ ◦ ${prefix}bornpink
│ ◦ ${prefix}frozen
│ ◦ ${prefix}gold
│ ◦ ${prefix}horror
│ ◦ ${prefix}blood
│ ◦ ${prefix}lava
│ ◦ ${prefix}thunder
│ ◦ ${prefix}matrix
│ ◦ ${prefix}smoke
│ ◦ ${prefix}naruto
│ ◦ ${prefix}avengers3d
│ ◦ ${prefix}americanflag3d
│ ◦ ${prefix}wooden3d
│ ◦ ${prefix}cubic3d
│ ◦ ${prefix}water3d
│ ◦ ${prefix}text3d
│ ◦ ${prefix}graffiti3d
│ ◦ ${prefix}silver3d
│ ◦ ${prefix}style3d
│ ◦ ${prefix}metal3d
│ ◦ ${prefix}comic3d
│ ◦ ${prefix}hologram3d
│ ◦ ${prefix}gradient3d
│ ◦ ${prefix}stone3d
│ ◦ ${prefix}space3d
│ ◦ ${prefix}sand3d
│ ◦ ${prefix}snow3d
│ ◦ ${prefix}papercut3d
│ ◦ ${prefix}balloon3d
│ ◦ ${prefix}christmas3d
│ ◦ ${prefix}christmas-sparkles
│ ◦ ${prefix}christmas-snow3d
│ ◦ ${prefix}christmas-frozen
│ ◦ ${prefix}christmas-gold
│ ◦ ${prefix}newyear-gold
│ ◦ ${prefix}pubglogo
│ ◦ ${prefix}valorantbanner
│ ◦ ${prefix}birthday3d
│ ◦ ${prefix}pubgbirthday
│ ◦ ${prefix}flowerbirthday
│ ◦ ${prefix}fire
│ ◦ ${prefix}flamelettering
│ ◦ ${prefix}horrorcemetery
│ ◦ ${prefix}halloweentheme
│ ◦ ${prefix}bloodwall
│ ◦ ${prefix}frankensteintext
│ ◦ ${prefix}horrormetal
│ ◦ ${prefix}halloweentext
│ ◦ ${prefix}halloweeneffect
│ ◦ ${prefix}horrortext
│ ◦ ${prefix}halloweencard
│ ◦ ${prefix}nametattoo
│ ◦ ${prefix}foilballoon3d
│ ◦ ${prefix}colorfulpaint3d
│ ◦ ${prefix}blackpinksignature
│ ◦ ${prefix}dragonballtext
│ ◦ ${prefix}glossysilver3d
│ ◦ ${prefix}typographyart
│ ◦ ${prefix}foggyglass
│ ◦ ${prefix}narutologo
│ ◦ ${prefix}chocolatecake
│ ◦ ${prefix}rosecake
│ ◦ ${prefix}amazingflowercake
│ ◦ ${prefix}redrosebirthday
│ ◦ ${prefix}greetingcake
│ ◦ ${prefix}anniversarycake
│ ◦ ${prefix}romanticflowercake
│ ◦ ${prefix}pubglogo2
│ ◦ ${prefix}pubgesports
│ ◦ ${prefix}warzonecover
│ ◦ ${prefix}aovbanner
│ ◦ ${prefix}sunlightshadow
│ ◦ ${prefix}heartwinggif
│ ◦ ${prefix}loveballoons
│ ◦ ${prefix}cfcover
│ ◦ ${prefix}lolcover
│ ◦ ${prefix}csgocover
│ ◦ ${prefix}dota2cover
│ ◦ ${prefix}overwatchcover
│ ◦ ${prefix}onepiececover
│ ◦ ${prefix}dragonballcover
│ ◦ ${prefix}youtubebutton
│ ◦ ${prefix}examcrank
└─❑ AI MENU ❑ 

┌─❑ DOWNLOAD ❑ 
│ ◦ ${prefix}ig
│ ◦ ${prefix}igdl2
│ ◦ ${prefix}ttdl
│ ◦ ${prefix}fbdl
│ ◦ ${prefix}play
│ ◦ ${prefix}igslide
│ ◦ ${prefix}ttslide
│ ◦ ${prefix}igmp3 
│ ◦ ${prefix}ttmp3
│ ◦ ${prefix}ytmp4
│ ◦ ${prefix}ytmp3
│ ◦ ${prefix}videy
│ ◦ ${prefix}threads
│ ◦ ${prefix}spotify
│ ◦ ${prefix}terabox
│ ◦ ${prefix}capcut
│ ◦ ${prefix}mediafire
│ ◦ ${prefix}gitclone
│ ◦ ${prefix}cocofun
│ ◦ ${prefix}scdl
│ ◦ ${prefix}snackvideo
│ ◦ ${prefix}applemusicdl
└─❑ DOWNLOAD ❑ 

┌─❑ TOOLS MENU ❑ 
│ ◦ ${prefix}hd
│ ◦ ${prefix}Ocr
│ ◦ ${prefix}esrgan
│ ◦ ${prefix}cekresi
│ ◦ ${prefix}hdvid
│ ◦ ${prefix}google
│ ◦ ${prefix}tourl
│ ◦ ${prefix}tourl2
│ ◦ ${prefix}ssweb
│ ◦ ${prefix}translate
│ ◦ ${prefix}kodepos
│ ◦ ${prefix}removebg
│ ◦ ${prefix}removebg2
│ ◦ ${prefix}skiplink
│ ◦ ${prefix}brat
│ ◦ ${prefix}bratbahlil
│ ◦ ${prefix}brathd
│ ◦ ${prefix}pakustad
│ ◦ ${prefix}bratcewe
│ ◦ ${prefix}bratpatrick
│ ◦ ${prefix}emojimix
│ ◦ ${prefix}attp
│ ◦ ${prefix}bratsquidward
│ ◦ ${prefix}animebrat
│ ◦ ${prefix}bratvid
│ ◦ ${prefix}smeme
│ ◦ ${prefix}iqc
│ ◦ ${prefix}translate
│ ◦ ${prefix}kalkulator
│ ◦ ${prefix}qc
│ ◦ ${prefix}fakedana
│ ◦ ${prefix}fakeovo
│ ◦ ${prefix}fakegopay
│ ◦ ${prefix}faketiktok
│ ◦ ${prefix}balogo
│ ◦ ${prefix}cinema
│ ◦ ${prefix}struk
│ ◦ ${prefix}fakebangjago
│ ◦ ${prefix}fakeff
│ ◦ ${prefix}fakektp
│ ◦ ${prefix}ceknik
│ ◦ ${prefix}whatmusic
│ ◦ ${prefix}carbonify
│ ◦ ${prefix}tts 
│ ◦ ${prefix}tts1
│ ◦ ${prefix}tts2
│ ◦ ${prefix}tts3
│ ◦ ${prefix}texttospeech 
│ ◦ ${prefix}say
│ ◦ ${prefix}ttsgoku 
│ ◦ ${prefix}ttseminem 
│ ◦ ${prefix}ttsmickey
│ ◦ ${prefix}ttsnahida
│ ◦ ${prefix}ttselon 
│ ◦ ${prefix}ttsoptimus
│ ◦ ${prefix}bass 
│ ◦ ${prefix}blown 
│ ◦ ${prefix}deep 
│ ◦ ${prefix}earrape 
│ ◦ ${prefix}fast 
│ ◦ ${prefix}fat 
│ ◦ ${prefix}nightcore 
│ ◦ ${prefix}reverse 
│ ◦ ${prefix}robot
│ ◦ ${prefix}slow  
│ ◦ ${prefix}smooth 
│ ◦ ${prefix}squirrel
│ ◦ ${prefix}sticker
│ ◦ ${prefix}toimg
│ ◦ ${prefix}tomp3
│ ◦ ${prefix}tomp4
│ ◦ ${prefix}togif
│ ◦ ${prefix}tovideo
│ ◦ ${prefix}toptv
│ ◦ ${prefix}sticker
│ ◦ ${prefix}toimg
│ ◦ ${prefix}tomp3
│ ◦ ${prefix}tomp4
│ ◦ ${prefix}togif
│ ◦ ${prefix}tovideo
│ ◦ ${prefix}toptv
│ ◦ ${prefix}webclone
│ ◦ ${prefix}inspectsite 
│ ◦ ${prefix}geoip
│ ◦ ${prefix}tohtml
│ ◦ ${prefix}tojs
└─❑ TOOLS MENU ❑ 

┌─❑ STALK MENU ❑ 
│ ◦ ${prefix}igstalk
│ ◦ ${prefix}ttstalk
│ ◦ ${prefix}ffstalk
│ ◦ ${prefix}twstalk
│ ◦ ${prefix}robloxstalk
│ ◦ ${prefix}ghstalk
│ ◦ ${prefix}npmstalk
│ ◦ ${prefix}ytstalk
└─❑ STALK MENU ❑ 

┌─❑ PANEL MENU ❑ 
│ ◦ ${prefix}1gb
│ ◦ ${prefix}2gb
│ ◦ ${prefix}3gb
│ ◦ ${prefix}4gb
│ ◦ ${prefix}5gb
│ ◦ ${prefix}6gb
│ ◦ ${prefix}7gb
│ ◦ ${prefix}8gb
│ ◦ ${prefix}9gb
│ ◦ ${prefix}10gb
│ ◦ ${prefix}addsrv
│ ◦ ${prefix}delsrv
│ ◦ ${prefix}listusr
│ ◦ ${prefix}listsrv
│ ◦ ${prefix}ceksisa
│ ◦ ${prefix}unlimited 
│ ◦ ${prefix}hapususerpanel
│ ◦ ${prefix}listexpired
│ ◦ ${prefix}addvip
│ ◦ ${prefix}delvip
│ ◦ ${prefix}listvip
└─❑ PANEL MENU ❑ 

┌─❑ SEARCH MENU ❑ 
│ ◦ ${prefix}pinterest
│ ◦ ${prefix}alquran
│ ◦ ${prefix}murotal
│ ◦ ${prefix}bingimage
│ ◦ ${prefix}ytsearch
│ ◦ ${prefix}npmsearch
│ ◦ ${prefix}ttsearch
│ ◦ ${prefix}spotifysearch 
│ ◦ ${prefix}applemusic
│ ◦ ${prefix}capcutsearch
│ ◦ ${prefix}snackvideosearch
│ ◦ ${prefix}soundcloudsearch 
│ ◦ ${prefix}xnxxsearch
│ ◦ ${prefix}xvideosearch
│ ◦ ${prefix}xvideodl
│ ◦ ${prefix}xnxxdl 
│ ◦ ${prefix}sixtynine 
│ ◦ ${prefix}pussy 
│ ◦ ${prefix}dick 
│ ◦ ${prefix}anal 
│ ◦ ${prefix}boobs 
│ ◦ ${prefix}bdsm
│ ◦ ${prefix}black 
│ ◦ ${prefix}easter 
│ ◦ ${prefix}bottomless 
│ ◦ ${prefix}blowjub 
│ ◦ ${prefix}collared 
│ ◦ ${prefix}cum 
│ ◦ ${prefix}cumsluts 
│ ◦ ${prefix}dp 
│ ◦ ${prefix}dom 
│ ◦ ${prefix}extreme 
│ ◦ ${prefix}feet 
│ ◦ ${prefix}finger 
│ ◦ ${prefix}fuck 
│ ◦ ${prefix}futa 
│ ◦ ${prefix}gay 
│ ◦ ${prefix}gif 
│ ◦ ${prefix}group 
│ ◦ ${prefix}hentai 
│ ◦ ${prefix}kiss 
│ ◦ ${prefix}lesbian 
│ ◦ ${prefix}lick 
│ ◦ ${prefix}pegged 
│ ◦ ${prefix}phgif 
│ ◦ ${prefix}puffies 
│ ◦ ${prefix}real 
│ ◦ ${prefix}suck 
│ ◦ ${prefix}tattoo 
│ ◦ ${prefix}tiny 
│ ◦ ${prefix}toys
│ ◦ ${prefix}xmas
│ ◦ ${prefix}bluearchiver
│ ◦ ${prefix}china
│ ◦ ${prefix}indo
│ ◦ ${prefix}waifu
│ ◦ ${prefix}neko
│ ◦ ${prefix}vietnam
│ ◦ ${prefix}thailand
│ ◦ ${prefix}korea
│ ◦ ${prefix}japan
│ ◦ ${prefix}animepat
│ ◦ ${prefix}animeslap
│ ◦ ${prefix}animecuddle
│ ◦ ${prefix}animenom
│ ◦ ${prefix}animefoxgirl
│ ◦ ${prefix}animetickle
│ ◦ ${prefix}animegecg
│ ◦ ${prefix}dogwoof
│ ◦ ${prefix}8ballpool
│ ◦ ${prefix}goosebird
│ ◦ ${prefix}animefeed
│ ◦ ${prefix}animeavatar
│ ◦ ${prefix}lizardpic
│ ◦ ${prefix}catmeow
│ ◦ ${prefix}animewlp
│ ◦ ${prefix}animehug
│ ◦ ${prefix}animekiss
│ ◦ ${prefix}ahegao
│ ◦ ${prefix}akira
│ ◦ ${prefix}akiyama
│ ◦ ${prefix}ana
│ ◦ ${prefix}asuna
│ ◦ ${prefix}ayuzawa
│ ◦ ${prefix}boruto
│ ◦ ${prefix}chitanda
│ ◦ ${prefix}chitoge
│ ◦ ${prefix}deidara
│ ◦ ${prefix}doraemon
│ ◦ ${prefix}elaina
│ ◦ ${prefix}emilia
│ ◦ ${prefix}erza
│ ◦ ${prefix}gremory
│ ◦ ${prefix}hestia
│ ◦ ${prefix}hinata
│ ◦ ${prefix}hitorigottoh
│ ◦ ${prefix}inori
│ ◦ ${prefix}isuzu
│ ◦ ${prefix}itachi
│ ◦ ${prefix}itori
│ ◦ ${prefix}kaga
│ ◦ ${prefix}kagura
│ ◦ ${prefix}kakasih
│ ◦ ${prefix}kaori
│ ◦ ${prefix}keneki
│ ◦ ${prefix}kosaki
│ ◦ ${prefix}kotori
│ ◦ ${prefix}kuriyama
│ ◦ ${prefix}kuroha
│ ◦ ${prefix}kurumi
│ ◦ ${prefix}loli
│ ◦ ${prefix}madara
│ ◦ ${prefix}megumin
│ ◦ ${prefix}mikasa
│ ◦ ${prefix}miku
│ ◦ ${prefix}minato
│ ◦ ${prefix}naruto
│ ◦ ${prefix}natsukawa
│ ◦ ${prefix}neko
│ ◦ ${prefix}nekonime
│ ◦ ${prefix}nezuko
│ ◦ ${prefix}nishimiya
│ ◦ ${prefix}onepiece
│ ◦ ${prefix}pokemon
│ ◦ ${prefix}ppcouple
│ ◦ ${prefix}rem
│ ◦ ${prefix}rize
│ ◦ ${prefix}sagiri
│ ◦ ${prefix}sakura
│ ◦ ${prefix}sasuke
│ ◦ ${prefix}shina
│ ◦ ${prefix}shinka
│ ◦ ${prefix}shizuka
│ ◦ ${prefix}shota
│ ◦ ${prefix}tomori
│ ◦ ${prefix}toukachan
│ ◦ ${prefix}tsunade
│ ◦ ${prefix}waifu
│ ◦ ${prefix}waifu2
│ ◦ ${prefix}wallhp2
│ ◦ ${prefix}yatogami
│ ◦ ${prefix}yuki
│ ◦ ${prefix}yuri
└─❑ SEARCH MENU ❑ 

┌─❑ OTHER MENU ❑
│ ◦ ${prefix}jadibot
│ ◦ ${prefix}stopjadibot
│ ◦ ${prefix}listjadibot
│ ◦ ${prefix}jpm
│ ◦ ${prefix}jpmch
│ ◦ ${prefix}addch
│ ◦ ${prefix}listch
│ ◦ ${prefix}delch
│ ◦ ${prefix}savekontak
│ ◦ ${prefix}savekontakuser
│ ◦ ${prefix}jpmstatus
│ ◦ ${prefix}jpmhidetag
│ ◦ ${prefix}list
│ ◦ ${prefix}sewabot
│ ◦ ${prefix}report
│ ◦ ${prefix}rules
│ ◦ ${prefix}qris
│ ◦ ${prefix}jpmdatabase
│ ◦ ${prefix}addidgc
│ ◦ ${prefix}delidgc
│ ◦ ${prefix}listidgc
│ ◦ ${prefix}jpmblacklist
│ ◦ ${prefix}addblacklistgc
│ ◦ ${prefix}delblacklistgc
│ ◦ ${prefix}listblacklistgc
│ ◦ ${prefix}delstatusgc
│ ◦ ${prefix}payment
│ ◦ ${prefix}claimlimit
│ ◦ ${prefix}claimsaldo
│ ◦ ${prefix}pushkontak
│ ◦ ${prefix}pushkontakv2
│ ◦ ${prefix}pushkontakv3
│ ◦ ${prefix}pushkontakv4
│ ◦ ${prefix}randomhentai
│ ◦ ${prefix}randomwaifu
│ ◦ ${prefix}artinama
│ ◦ ${prefix}artimimpi
│ ◦ ${prefix}ramaljodoh
│ ◦ ${prefix}ramaljodohbali
│ ◦ ${prefix}ramalcinta
│ ◦ ${prefix}cocoknama
│ ◦ ${prefix}pasangan
│ ◦ ${prefix}suamiistri
│ ◦ ${prefix}jadiannikah
│ ◦ ${prefix}sifatusaha
│ ◦ ${prefix}rezeki
│ ◦ ${prefix}pekerjaan
│ ◦ ${prefix}nasib
│ ◦ ${prefix}penyakit
│ ◦ ${prefix}tarot
│ ◦ ${prefix}fengshui
│ ◦ ${prefix}haribaik
│ ◦ ${prefix}harisangar
│ ◦ ${prefix}harisial
│ ◦ ${prefix}nagahari
│ ◦ ${prefix}arahrezeki
│ ◦ ${prefix}peruntungan
│ ◦ ${prefix}weton
│ ◦ ${prefix}karakter
│ ◦ ${prefix}keberuntungan
│ ◦ ${prefix}memancing
│ ◦ ${prefix}masabubur
│ ◦ ${prefix}zodiak
│ ◦ ${prefix}shio
│ ◦ ${prefix}cekapikey
└─❑ OTHER MENU ❑ 

┌─❑ GAME MENU ❑ 
│ ◦ ${prefix}truth
│ ◦ ${prefix}dare
│ ◦ ${prefix}ceksifat
│ ◦ ${prefix}asahotak
│ ◦ ${prefix}tekateki
│ ◦ ${prefix}siapaaku
│ ◦ ${prefix}mathquiz
│ ◦ ${prefix}family100
│ ◦ ${prefix}caklontong
│ ◦ ${prefix}tebakgambar
│ ◦ ${prefix}tebakkata 
│ ◦ ${prefix}tebaktebakan
│ ◦ ${prefix}tebakkimia
│ ◦ ${prefix}tebakkalimat
│ ◦ ${prefix}susunkata
│ ◦ ${prefix}tebakwarna
│ ◦ ${prefix}tebakgame
│ ◦ ${prefix}tebakheroml
│ ◦ ${prefix}tebaklagu
│ ◦ ${prefix}tebaklogo
│ ◦ ${prefix}tebakbendera
│ ◦ ${prefix}tebakkartun
│ ◦ ${prefix}tebaklirik
│ ◦ ${prefix}susunkata
│ ◦ ${prefix}cerdascermat
│ ◦ ${prefix}tebaksurah
│ ◦ ${prefix}ulartangga
│ ◦ ${prefix}tictactoe
│ ◦ ${prefix}tebakbom
│ ◦ ${prefix}cekkodam
│ ◦ ${prefix}yatim
│ ◦ ${prefix}piatu
│ ◦ ${prefix}jomblo
│ ◦ ${prefix}waria
│ ◦ ${prefix}koruptor
│ ◦ ${prefix}psikopat
│ ◦ ${prefix}pedofil
│ ◦ ${prefix}miskin
│ ◦ ${prefix}tukangjajan
│ ◦ ${prefix}jelek
│ ◦ ${prefix}mokondo
│ ◦ ${prefix}penipu
│ ◦ ${prefix}tukangcopet
│ ◦ ${prefix}tukangbo
│ ◦ ${prefix}tukangcoli
│ ◦ ${prefix}tukangkawin
│ ◦ ${prefix}ganteng
│ ◦ ${prefix}cantik
│ ◦ ${prefix}tobrut
│ ◦ ${prefix}kurus
│ ◦ ${prefix}maling
│ ◦ ${prefix}kontolgede
│ ◦ ${prefix}tepos
│ ◦ ${prefix}pelakor
│ ◦ ${prefix}jomblo
│ ◦ ${prefix}korbanhts
│ ◦ ${prefix}badut
│ ◦ ${prefix}perampok
│ ◦ ${prefix}begal
│ ◦ ${prefix}wibu
│ ◦ ${prefix}janda
│ ◦ ${prefix}jodohku 
│ ◦ ${prefix}cekyatim
│ ◦ ${prefix}cekjelek
│ ◦ ${prefix}cekjodoh
│ ◦ ${prefix}cekmemek
│ ◦ ${prefix}cekkontol
│ ◦ ${prefix}cekmiskin
│ ◦ ${prefix}cekkaya
│ ◦ ${prefix}cektolol
│ ◦ ${prefix}ceknamabapak
│ ◦ ${prefix}cekwibu
│ ◦ ${prefix}dapatkah
│ ◦ ${prefix}apakah
│ ◦ ${prefix}bagaimana 
│ ◦ ${prefix}rate
│ ◦ ${prefix}when
│ ◦ ${prefix}menfess
│ ◦ ${prefix}mancing
│ ◦ ${prefix}aduayam
│ ◦ ${prefix}tebakangkatogel
│ ◦ ${prefix}balapkarung
│ ◦ ${prefix}tariktambang
│ ◦ ${prefix}tebakkarturemi
│ ◦ ${prefix}balaplari
│ ◦ ${prefix}rolling
│ ◦ ${prefix}investasi 
│ ◦ ${prefix}renang
│ ◦ ${prefix}balasmenfess
│ ◦ ${prefix}stopmenfess
│ ◦ ${prefix}tolakmenfess
└─❑ GAME MENU ❑ 

┌─❑ OWNER MENU ❑ 
│ ◦ ${prefix}self
│ ◦ ${prefix}public
│ ◦ ${prefix}npm
│ ◦ ${prefix}autotyping
│ ◦ ${prefix}autoread
│ ◦ ${prefix}addcase
│ ◦ ${prefix}delcase
│ ◦ ${prefix}editcase
│ ◦ ${prefix}getcase
│ ◦ ${prefix}block
│ ◦ ${prefix}unblock
│ ◦ ${prefix}autoreadsw
│ ◦ ${prefix}addprem
│ ◦ ${prefix}delprem
│ ◦ ${prefix}listprem
│ ◦ ${prefix}addowner
│ ◦ ${prefix}listowner
│ ◦ ${prefix}delowner
│ ◦ ${prefix}statusgrup
│ ◦ ${prefix}setppch
│ ◦ ${prefix}setnamech
│ ◦ ${prefix}spamvc
│ ◦ ${prefix}spamcall
│ ◦ ${prefix}joingc
│ ◦ ${prefix}leavegc
│ ◦ ${prefix}setdeskch
│ ◦ ${prefix}followch
│ ◦ ${prefix}untollowch
│ ◦ ${prefix}delppch
│ ◦ ${prefix}createch
│ ◦ ${prefix}botafk
│ ◦ ${prefix}maintenance 
│ ◦ ${prefix}addgb
│ ◦ ${prefix}delgb
│ ◦ ${prefix}jpm
│ ◦ ${prefix}autojoingc
│ ◦ ${prefix}upch
│ ◦ ${prefix}spamcall
│ ◦ ${prefix}spamvc
│ ◦ ${prefix}setppbot
│ ◦ ${prefix}setppbot
│ ◦ ${prefix}addproduk
│ ◦ ${prefix}delproduk
│ ◦ ${prefix}batalorder
│ ◦ ${prefix}confirm
│ ◦ ${prefix}listproduk
│ ◦ ${prefix}approve
│ ◦ ${prefix}reject
│ ◦ ${prefix}addsewa
│ ◦ ${prefix}delsewa
│ ◦ ${prefix}clersession
│ ◦ ${prefix}listsewa
│ ◦ ${prefix}delsewa
│ ◦ ${prefix}ceksewa
│ ◦ ${prefix}setdone
│ ◦ ${prefix}changedone
│ ◦ ${prefix}delsetdone
│ ◦ ${prefix}done
│ ◦ ${prefix}proses
│ ◦ ${prefix}setproses
│ ◦ ${prefix}changeproses
│ ◦ ${prefix}delsetproses
│ ◦ ${prefix}addlist
│ ◦ ${prefix}dellist
│ ◦ ${prefix}backupsc
│ ◦ ${prefix}clearchat
│ ◦ ${prefix}pinchat
│ ◦ ${prefix}unpinchat
│ ◦ ${prefix}updatelist
│ ◦ ${prefix}upswteks
│ ◦ ${prefix}upswvideo
│ ◦ ${prefix}upswaudio
│ ◦ ${prefix}upswimg
│ ◦ ${prefix}colongsw
└─❑ OWNER MENU ❑ 

Powered by ${global.namaowner}
version v3.0.0 premium script
Developer Satanic Haxor`;

        let buttons = [
            // 1. CTA URL
            {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                    display_text: "Developer Satanic",
                    url: "https://wa.me/6283168758640",
                    merchant_url: "https://wa.me/6283168758640"
                })
            },          
            {
                name: "cta_call",
                buttonParamsJson: JSON.stringify({
                    display_text: "Celuller",
                    phone_number: "6283168758640"
                })
            },
            // 3. CTA COPY
            {
                name: "cta_copy",
                buttonParamsJson: JSON.stringify({
                    display_text: "Free Rest api",
                    copy_code: "https://free-restapi.biz.id/"
                })
            }
        ];
        const imagethumb = global.thumbnail;
const response = await fetch(imagethumb);
const profilePicBuffer = Buffer.from(await response.arrayBuffer());

        await sendButton(from, txt, "Satanic Haxor", profilePicBuffer, buttons, m);
    } catch (e) {
        console.error(e);
        reply("Terjadi kesalahan.");
    }
}
await satanic.sendMessage(from, { audio: { url: global.audio} , mimetype: 'audio/mp4', ptt: true }, { quoted: fkontak })
break;
case 'allmenu': {
    try {
        const imageUrl = global.thumbnail;
        const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(response.data);
        
        // Resize dengan Jimp
        const jimp = require('jimp');
        const image = await jimp.read(imageBuffer);
        image.resize(300, 170);
        const resizedBuffer = await image.getBufferAsync(jimp.MIME_JPEG);

        const content = {
            buttonsMessage: {
                buttons: [
                    {
                        buttonId: `${prefix}owner`,
                        buttonText: { displayText: 'Owner' },
                        type: 1
                    },
                    {
                        buttonId: `${prefix}donasi`,
                        buttonText: { displayText: 'Donasi' },
                        type: 1
                    }
                ],
                locationMessage: {
                    jpegThumbnail: resizedBuffer,
                    name: global.namaBot,
                    address: `${global.namaBot}`
                },
                contentText: `> Halo ${pushname} saya adalah ${global.namaBot} asisten ${global.namaowner}, berikut daftar list menu yang tersedia dibawah ini 
        
╭─ *Group* 
│ ◦ ${prefix}kick
│ ◦ ${prefix}warn
│ ◦ ${prefix}grup
│ ◦ ${prefix}left <on/of>
│ ◦ ${prefix}poll
│ ◦ ${prefix}afk
│ ◦ ${prefix}ban
│ ◦ ${prefix}unban
│ ◦ ${prefix}listban
│ ◦ ${prefix}totag
│ ◦ ${prefix}rvo
│ ◦ ${prefix}getpp
│ ◦ ${prefix}opentime
│ ◦ ${prefix}listpc
│ ◦ ${prefix}listgc
│ ◦ ${prefix}kickme
│ ◦ ${prefix}closetime
│ ◦ ${prefix}tagadmin
│ ◦ ${prefix}autoaigrup
│ ◦ ${prefix}grup <open/close>
│ ◦ ${prefix}promote
│ ◦ ${prefix}welcome <on/of>
│ ◦ ${prefix}demote
│ ◦ ${prefix}listwarn
│ ◦ ${prefix}resetwarn
│ ◦ ${prefix}delwarn
│ ◦ ${prefix}listonline
│ ◦ ${prefix}mutegc
│ ◦ ${prefix}requestjoin
│ ◦ ${prefix}getppgc
│ ◦ ${prefix}setname
│ ◦ ${prefix}setppgc
│ ◦ ${prefix}setdesk
│ ◦ ${prefix}cekidch
│ ◦ ${prefix}cekidgc
│ ◦ ${prefix}hidetag
│ ◦ ${prefix}reactch
│ ◦ ${prefix}revoke
│ ◦ ${prefix}linkgc
│ ◦ ${prefix}upswgc
│ ◦ ${prefix}editinfo
│ ◦ ${prefix}reminder
│ ◦ ${prefix}tagall
│ ◦ ${prefix}antibadword
│ ◦ ${prefix}addbadword
│ ◦ ${prefix}delbadword
│ ◦ ${prefix}listbadword 
│ ◦ ${prefix}blacklist
│ ◦ ${prefix}sider
│ ◦ ${prefix}siderv2
│ ◦ ${prefix}topmember
│ ◦ ${prefix}unblacklist
│ ◦ ${prefix}listblacklist
│ ◦ ${prefix}addautogc
│ ◦ ${prefix}delautogc
│ ◦ ${prefix}listautogc
│ ◦ ${prefix}autosholat 
│ ◦ ${prefix}setwelcome
│ ◦ ${prefix}setwelcometype
│ ◦ ${prefix}setwelcomeimage
│ ◦ ${prefix}setwelcometext
│ ◦ ${prefix}setwelcomevideo
│ ◦ ${prefix}setlefttext
│ ◦ ${prefix}setlefttype
│ ◦ ${prefix}setleftimage
│ ◦ ${prefix}setleftvideo
│ ◦ ${prefix}antilink
│ ◦ ${prefix}antilinkall
│ ◦ ${prefix}antiig
│ ◦ ${prefix}antiyt
│ ◦ ${prefix}antitt
│ ◦ ${prefix}antisticker
│ ◦ ${prefix}antifoto
│ ◦ ${prefix}antiaudio
│ ◦ ${prefix}antivideo
│ ◦ ${prefix}antibot
│ ◦ ${prefix}antiswgc
│ ◦ ${prefix}antitagsw
│ ◦ ${prefix}antispam
│ ◦ ${prefix}anticolong
│ ◦ ${prefix}htprem
│ ◦ ${prefix}totag2
│ ◦ ${prefix}antilinkkick
╰─ *Group*

╭─ *Download*
│ ◦ ${prefix}ig
│ ◦ ${prefix}igdl2
│ ◦ ${prefix}ttdl
│ ◦ ${prefix}fbdl
│ ◦ ${prefix}play
│ ◦ ${prefix}igslide
│ ◦ ${prefix}ttslide
│ ◦ ${prefix}igmp3 
│ ◦ ${prefix}ttmp3
│ ◦ ${prefix}ytmp4
│ ◦ ${prefix}ytmp3
│ ◦ ${prefix}videy
│ ◦ ${prefix}threads
│ ◦ ${prefix}spotify
│ ◦ ${prefix}terabox
│ ◦ ${prefix}capcut
│ ◦ ${prefix}mediafire
│ ◦ ${prefix}gitclone
│ ◦ ${prefix}cocofun
│ ◦ ${prefix}scdl
│ ◦ ${prefix}snackvideo
│ ◦ ${prefix}applemusicdl
╰─ *Download* 

╭─ *AI Chat* 
│ ◦ ${prefix}ai
│ ◦ ${prefix}gita
│ ◦ ${prefix}felo
│ ◦ ${prefix}claude
│ ◦ ${prefix}aqua
│ ◦ ${prefix}qwen
│ ◦ ${prefix}openai
│ ◦ ${prefix}copilot
│ ◦ ${prefix}glm47
│ ◦ ${prefix}epsilon
│ ◦ ${prefix}gemini
│ ◦ ${prefix}webpilot
│ ◦ ${prefix}publicai
│ ◦ ${prefix}claude-45
│ ◦ ${prefix}meta-ai
│ ◦ ${prefix}gpt-5.1
│ ◦ ${prefix}gpt-5-online
│ ◦ ${prefix}gpt-5
│ ◦ ${prefix}gpt-5-nano
│ ◦ ${prefix}gpt-5-mini
│ ◦ ${prefix}openai-o1
│ ◦ ${prefix}openai-o3
│ ◦ ${prefix}openai-o3-mini
│ ◦ ${prefix}gpt-4o
│ ◦ ${prefix}openai-o4-mini
│ ◦ ${prefix}gpt-4.1-mini
│ ◦ ${prefix}gpt-4.1-nano
│ ◦ ${prefix}gpt-5.3
│ ◦ ${prefix}gpt-5.4
│ ◦ ${prefix}gpt-5.5 
│ ◦ ${prefix}unlimitedai
│ ◦ ${prefix}deepseek
│ ◦ ${prefix}gpt-oss2b
│ ◦ ${prefix}kimi-vision
│ ◦ ${prefix}illama-vision 
│ ◦ ${prefix}deepseek-pro
╰─ *AI Chat*

╭─ *AI Maker*
│ ◦ ${prefix}flux
│ ◦ ${prefix}veo3
│ ◦ ${prefix}texttoimg
│ ◦ ${prefix}editimg
│ ◦ ${prefix}nanobanana
│ ◦ ${prefix}img2img
│ ◦ ${prefix}nanobananapro
│ ◦ ${prefix}nanobanana2
│ ◦ ${prefix}talkingphoto
│ ◦ ${prefix}removecloth
│ ◦ ${prefix}jadimanga
│ ◦ ${prefix}jadihitam
│ ◦ ${prefix}jadiputih
│ ◦ ${prefix}jadiblonde
│ ◦ ${prefix}jadichibi
│ ◦ ${prefix}jadimanhwa
│ ◦ ${prefix}jadidonghua 
│ ◦ ${prefix}jadibotak
│ ◦ ${prefix}jadizombie
│ ◦ ${prefix}jadibiliard
│ ◦ ${prefix}jadifigure
│ ◦ ${prefix}jadimacbook
│ ◦ ${prefix}texttovideo
│ ◦ ${prefix}tosad
│ ◦ ${prefix}tosatan
│ ◦ ${prefix}tosdmtinggi
│ ◦ ${prefix}toreal
│ ◦ ${prefix}tomoai
│ ◦ ${prefix}tomaya
│ ◦ ${prefix}tolego
│ ◦ ${prefix}tokamboja
│ ◦ ${prefix}tokacamata
│ ◦ ${prefix}tojepang
│ ◦ ${prefix}nanobananapro
│ ◦ ${prefix}toghibli
│ ◦ ${prefix}todubai
│ ◦ ${prefix}todpr
│ ◦ ${prefix}totua
│ ◦ ${prefix}tohitam
│ ◦ ${prefix}totato
│ ◦ ${prefix}topeci
│ ◦ ${prefix}tovintage
│ ◦ ${prefix}topolaroid
│ ◦ ${prefix}tochibi
│ ◦ ${prefix}tobrewok
│ ◦ ${prefix}tobabi
│ ◦ ${prefix}tofigura
│ ◦ ${prefix}tofigurav2
│ ◦ ${prefix}tofigurav3
│ ◦ ${prefix}topacar
│ ◦ ${prefix}topacarv2
│ ◦ ${prefix}tozombie
│ ◦ ${prefix}topenjara
│ ◦ ${prefix}tojapanese
│ ◦ ${prefix}toblonde
│ ◦ ${prefix}tobotak
│ ◦ ${prefix}tohijab
│ ◦ ${prefix}topejabat
│ ◦ ${prefix}tokah
│ ◦ ${prefix}tomirror
│ ◦ ${prefix}toanime
╰─ *AI Maker* 

┌─ *Tools* 
│ ◦ ${prefix}hd
│ ◦ ${prefix}ocr
│ ◦ ${prefix}esrgan
│ ◦ ${prefix}cekresi
│ ◦ ${prefix}hdvid
│ ◦ ${prefix}google
│ ◦ ${prefix}tourl
│ ◦ ${prefix}tourl2
│ ◦ ${prefix}ssweb
│ ◦ ${prefix}translate
│ ◦ ${prefix}kodepos
│ ◦ ${prefix}removebg
│ ◦ ${prefix}removebg2
│ ◦ ${prefix}skiplink
│ ◦ ${prefix}skiplink2
│ ◦ ${prefix}translate
│ ◦ ${prefix}kalkulator
│ ◦ ${prefix}balogo
│ ◦ ${prefix}cinema
│ ◦ ${prefix}struk
│ ◦ ${prefix}ceknik
│ ◦ ${prefix}whatmusic
│ ◦ ${prefix}carbonify
│ ◦ ${prefix}sticker
│ ◦ ${prefix}toimg
│ ◦ ${prefix}tomp3
│ ◦ ${prefix}tomp4
│ ◦ ${prefix}togif
│ ◦ ${prefix}tovideo
│ ◦ ${prefix}toptv
│ ◦ ${prefix}sticker
│ ◦ ${prefix}toimg
│ ◦ ${prefix}tomp3
│ ◦ ${prefix}tomp4
│ ◦ ${prefix}togif
│ ◦ ${prefix}tovideo
│ ◦ ${prefix}toptv
│ ◦ ${prefix}tohtml
│ ◦ ${prefix}tojs
│ ◦ ${prefix}paptt
│ ◦ ${prefix}bokep
│ ◦ ${prefix}asupan
│ ◦ ${prefix}onlyfans
│ ◦ ${prefix}pap
└─ *Tools* 

┌─ *Audio* 
│ ◦ ${prefix}tts 
│ ◦ ${prefix}texttospeech 
│ ◦ ${prefix}say
│ ◦ ${prefix}ttsgoku 
│ ◦ ${prefix}ttseminem 
│ ◦ ${prefix}ttsmickey
│ ◦ ${prefix}ttsnahida
│ ◦ ${prefix}ttselon 
│ ◦ ${prefix}ttsoptimus
│ ◦ ${prefix}ttsbella
│ ◦ ${prefix}ttsechilling
│ ◦ ${prefix}ttsjokowi
│ ◦ ${prefix}ttsprabowo
│ ◦ ${prefix}ttsmegawati
│ ◦ ${prefix}bass 
│ ◦ ${prefix}blown 
│ ◦ ${prefix}deep 
│ ◦ ${prefix}earrape 
│ ◦ ${prefix}fast 
│ ◦ ${prefix}fat 
│ ◦ ${prefix}nightcore 
│ ◦ ${prefix}reverse 
│ ◦ ${prefix}robot
│ ◦ ${prefix}slow  
│ ◦ ${prefix}smooth 
│ ◦ ${prefix}squirrel
└─ *Audio* 

╭─ *Maker* 
│ ◦ ${prefix}qc
│ ◦ ${prefix}iqc
│ ◦ ${prefix}iqc2
│ ◦ ${prefix}iqc3
│ ◦ ${prefix}igqc
│ ◦ ${prefix}ttqc
│ ◦ ${prefix}qcwin
│ ◦ ${prefix}fakewafat 
│ ◦ ${prefix}ttqc2
│ ◦ ${prefix}noteig
│ ◦ ${prefix}smeme
│ ◦ ${prefix}brat
│ ◦ ${prefix}bratvid
│ ◦ ${prefix}bratbahlil
│ ◦ ${prefix}brathd
│ ◦ ${prefix}pakustad
│ ◦ ${prefix}bratcewe
│ ◦ ${prefix}bratpatrick
│ ◦ ${prefix}emojimix
│ ◦ ${prefix}animebrat
│ ◦ ${prefix}bratsquidward
│ ◦ ${prefix}sticker
│ ◦ ${prefix}toimg
│ ◦ ${prefix}tovideo
│ ◦ ${prefix}fakeff
│ ◦ ${prefix}fakedj
│ ◦ ${prefix}fakedana
│ ◦ ${prefix}fakeovo
│ ◦ ${prefix}fakegopay
│ ◦ ${prefix}faketiktok
│ ◦ ${prefix}fakeml
│ ◦ ${prefix}balogo
│ ◦ ${prefix}telestick
│ ◦ ${prefix}fakebankjago
│ ◦ ${prefix}fakestoryig
│ ◦ ${prefix}stickerpack
│ ◦ ${prefix}stickerpackpin
│ ◦ ${prefix}pornhub
│ ◦ ${prefix}comic
│ ◦ ${prefix}wolf-galaxy
│ ◦ ${prefix}write-grafitty
│ ◦ ${prefix}wetglass
│ ◦ ${prefix}typogrpahy
│ ◦ ${prefix}pixel-glitch
│ ◦ ${prefix}pavement
│ ◦ ${prefix}painting
│ ◦ ${prefix}naruto
│ ◦ ${prefix}mascot
│ ◦ ${prefix}marvel
│ ◦ ${prefix}glitch
│ ◦ ${prefix}devil-wings
│ ◦ ${prefix}dragonball
│ ◦ ${prefix}foggy-glass
│ ◦ ${prefix}bear
│ ◦ ${prefix}blackpink
│ ◦ ${prefix}avengers
╰─ *Maker* 

╭─ *Stalk* 
│ ◦ ${prefix}igstalk
│ ◦ ${prefix}ttstalk
│ ◦ ${prefix}ffstalk
│ ◦ ${prefix}twstalk
│ ◦ ${prefix}robloxstalk
│ ◦ ${prefix}ghstalk
│ ◦ ${prefix}npmstalk
│ ◦ ${prefix}ytstalk
╰─ *Stalk* 

╭─ *Search* 
│ ◦ ${prefix}pinterest
│ ◦ ${prefix}alquran
│ ◦ ${prefix}murotal
│ ◦ ${prefix}bingimage
│ ◦ ${prefix}ytsearch
│ ◦ ${prefix}npmsearch
│ ◦ ${prefix}ttsearch
│ ◦ ${prefix}spotifysearch 
│ ◦ ${prefix}applemusic
│ ◦ ${prefix}capcutsearch
│ ◦ ${prefix}douyinsearch
│ ◦ ${prefix}ttsearchphoto
│ ◦ ${prefix}tokopedia
│ ◦ ${prefix}snackvideosearch
│ ◦ ${prefix}soundcloudsearch 
│ ◦ ${prefix}xnxxsearch
│ ◦ ${prefix}xvideosearch
│ ◦ ${prefix}xvideodl
│ ◦ ${prefix}xnxxdl 
│ ◦ ${prefix}sixtynine 
│ ◦ ${prefix}pussy 
│ ◦ ${prefix}dick 
│ ◦ ${prefix}anal 
│ ◦ ${prefix}boobs 
│ ◦ ${prefix}bdsm
│ ◦ ${prefix}black 
│ ◦ ${prefix}easter 
│ ◦ ${prefix}bottomless 
│ ◦ ${prefix}blowjub 
│ ◦ ${prefix}collared 
│ ◦ ${prefix}cum 
│ ◦ ${prefix}cumsluts 
│ ◦ ${prefix}dp 
│ ◦ ${prefix}dom 
│ ◦ ${prefix}extreme 
│ ◦ ${prefix}feet 
│ ◦ ${prefix}finger 
│ ◦ ${prefix}fuck 
│ ◦ ${prefix}futa 
│ ◦ ${prefix}gay 
│ ◦ ${prefix}gif 
│ ◦ ${prefix}group 
│ ◦ ${prefix}hentai 
│ ◦ ${prefix}kiss 
│ ◦ ${prefix}lesbian 
│ ◦ ${prefix}lick 
│ ◦ ${prefix}pegged 
│ ◦ ${prefix}phgif 
│ ◦ ${prefix}puffies 
│ ◦ ${prefix}real 
│ ◦ ${prefix}suck 
│ ◦ ${prefix}tattoo 
│ ◦ ${prefix}tiny 
│ ◦ ${prefix}toys
│ ◦ ${prefix}xmas
│ ◦ ${prefix}bluearchiver
│ ◦ ${prefix}china
│ ◦ ${prefix}indo
│ ◦ ${prefix}waifu
│ ◦ ${prefix}neko
│ ◦ ${prefix}vietnam
│ ◦ ${prefix}thailand
│ ◦ ${prefix}korea
│ ◦ ${prefix}japan
│ ◦ ${prefix}animepat
│ ◦ ${prefix}animeslap
│ ◦ ${prefix}animecuddle
│ ◦ ${prefix}animenom
│ ◦ ${prefix}animefoxgirl
│ ◦ ${prefix}animetickle
│ ◦ ${prefix}animegecg
│ ◦ ${prefix}dogwoof
│ ◦ ${prefix}8ballpool
│ ◦ ${prefix}goosebird
│ ◦ ${prefix}animefeed
│ ◦ ${prefix}animeavatar
│ ◦ ${prefix}lizardpic
│ ◦ ${prefix}catmeow
│ ◦ ${prefix}animewlp
│ ◦ ${prefix}animehug
│ ◦ ${prefix}animekiss
╰─ *Search*

╭─ *Other* 
│ ◦ ${prefix}randomhentai
│ ◦ ${prefix}randomwaifu
│ ◦ ${prefix}artinama
│ ◦ ${prefix}artimimpi
│ ◦ ${prefix}ramaljodoh
│ ◦ ${prefix}ramaljodohbali
│ ◦ ${prefix}ramalcinta
│ ◦ ${prefix}cocoknama
│ ◦ ${prefix}pasangan
│ ◦ ${prefix}suamiistri
│ ◦ ${prefix}jadiannikah
│ ◦ ${prefix}sifatusaha
│ ◦ ${prefix}rezeki
│ ◦ ${prefix}pekerjaan
│ ◦ ${prefix}nasib
│ ◦ ${prefix}penyakit
│ ◦ ${prefix}tarot
│ ◦ ${prefix}fengshui
│ ◦ ${prefix}haribaik
│ ◦ ${prefix}harisangar
│ ◦ ${prefix}harisial
│ ◦ ${prefix}nagahari
│ ◦ ${prefix}arahrezeki
│ ◦ ${prefix}peruntungan
│ ◦ ${prefix}weton
│ ◦ ${prefix}karakter
│ ◦ ${prefix}keberuntungan
│ ◦ ${prefix}memancing
│ ◦ ${prefix}masabubur
│ ◦ ${prefix}zodiak
│ ◦ ${prefix}shio
│ ◦ ${prefix}cekapikey
╰─ *Other* 

╭─ *Game* 
│ ◦ ${prefix}truth
│ ◦ ${prefix}dare
│ ◦ ${prefix}ceksifat
│ ◦ ${prefix}asahotak
│ ◦ ${prefix}tekateki
│ ◦ ${prefix}siapaaku
│ ◦ ${prefix}mathquiz
│ ◦ ${prefix}family100
│ ◦ ${prefix}caklontong
│ ◦ ${prefix}tebakgambar
│ ◦ ${prefix}tebakkata 
│ ◦ ${prefix}tebaktebakan
│ ◦ ${prefix}tebakkimia
│ ◦ ${prefix}tebakwarna
│ ◦ ${prefix}tebakheroml
│ ◦ ${prefix}tebaklagu
│ ◦ ${prefix}tebakbendera
│ ◦ ${prefix}tebakbenderav2
│ ◦ ${prefix}cerdascermat
│ ◦ ${prefix}sambungkata
│ ◦ ${prefix}tebakgame
│ ◦ ${prefix}tebaksurah
│ ◦ ${prefix}tebaktebakan
│ ◦ ${prefix}susunkata
│ ◦ ${prefix}tebakkalimat
│ ◦ ${prefix}tebaklirik
│ ◦ ${prefix}ulartangga
│ ◦ ${prefix}tictactoe
│ ◦ ${prefix}tebakbom
│ ◦ ${prefix}cekkodam
│ ◦ ${prefix}yatim
│ ◦ ${prefix}piatu
│ ◦ ${prefix}jomblo
│ ◦ ${prefix}waria
│ ◦ ${prefix}koruptor
│ ◦ ${prefix}psikopat
│ ◦ ${prefix}pedofil
│ ◦ ${prefix}miskin
│ ◦ ${prefix}tukangjajan
│ ◦ ${prefix}jelek
│ ◦ ${prefix}mokondo
│ ◦ ${prefix}penipu
│ ◦ ${prefix}tukangcopet
│ ◦ ${prefix}tukangbo
│ ◦ ${prefix}tukangcoli
│ ◦ ${prefix}tukangkawin
│ ◦ ${prefix}ganteng
│ ◦ ${prefix}cantik
│ ◦ ${prefix}tobrut
│ ◦ ${prefix}kurus
│ ◦ ${prefix}maling
│ ◦ ${prefix}kontolgede
│ ◦ ${prefix}tepos
│ ◦ ${prefix}pelakor
│ ◦ ${prefix}jomblo
│ ◦ ${prefix}korbanhts
│ ◦ ${prefix}badut
│ ◦ ${prefix}perampok
│ ◦ ${prefix}begal
│ ◦ ${prefix}wibu
│ ◦ ${prefix}janda
│ ◦ ${prefix}jodohku 
│ ◦ ${prefix}cekyatim
│ ◦ ${prefix}cekjelek
│ ◦ ${prefix}cekjodoh
│ ◦ ${prefix}cekmemek
│ ◦ ${prefix}cekkontol
│ ◦ ${prefix}cekmiskin
│ ◦ ${prefix}cekkaya
│ ◦ ${prefix}cektolol
│ ◦ ${prefix}ceknamabapak
│ ◦ ${prefix}cekwibu
│ ◦ ${prefix}dapatkah
│ ◦ ${prefix}apakah
│ ◦ ${prefix}bagaimana 
│ ◦ ${prefix}rate
│ ◦ ${prefix}when
│ ◦ ${prefix}menfess
│ ◦ ${prefix}mancing
│ ◦ ${prefix}aduayam
│ ◦ ${prefix}tebakangkatogel
│ ◦ ${prefix}balapkarung
│ ◦ ${prefix}tariktambang
│ ◦ ${prefix}tebakkarturemi
│ ◦ ${prefix}balaplari
│ ◦ ${prefix}rolling
│ ◦ ${prefix}investasi 
│ ◦ ${prefix}renang
│ ◦ ${prefix}balasmenfess
│ ◦ ${prefix}stopmenfess
│ ◦ ${prefix}tolakmenfess
╰─ *Game* 

╭─ *Owner* 
│ ◦ ${prefix}self
│ ◦ ${prefix}public
│ ◦ ${prefix}npm
│ ◦ ${prefix}setthumb
│ ◦ ${prefix}resetthumb
│ ◦ ${prefix}stopbot
│ ◦ ${prefix}restartbot
│ ◦ ${prefix}setprefix
│ ◦ ${prefix}cekthumb
│ ◦ ${prefix}autotyping
│ ◦ ${prefix}autoread
│ ◦ ${prefix}addcase
│ ◦ ${prefix}delcase
│ ◦ ${prefix}editcase
│ ◦ ${prefix}getcase
│ ◦ ${prefix}block
│ ◦ ${prefix}unblock
│ ◦ ${prefix}autoreadsw
│ ◦ ${prefix}addprem
│ ◦ ${prefix}delprem
│ ◦ ${prefix}listprem
│ ◦ ${prefix}addowner
│ ◦ ${prefix}listowner
│ ◦ ${prefix}delowner
│ ◦ ${prefix}statusgrup
│ ◦ ${prefix}setppch
│ ◦ ${prefix}setnamech
│ ◦ ${prefix}spamvc
│ ◦ ${prefix}spamcall
│ ◦ ${prefix}joingc
│ ◦ ${prefix}jpmhidetag
│ ◦ ${prefix}leavegc
│ ◦ ${prefix}setdeskch
│ ◦ ${prefix}followch
│ ◦ ${prefix}untollowch
│ ◦ ${prefix}delppch
│ ◦ ${prefix}createch
│ ◦ ${prefix}addgb
│ ◦ ${prefix}delgb
│ ◦ ${prefix}jpm
│ ◦ ${prefix}autojoingc
│ ◦ ${prefix}upch
│ ◦ ${prefix}spamcall
│ ◦ ${prefix}spamvc
│ ◦ ${prefix}setppbot
│ ◦ ${prefix}setppbot
│ ◦ ${prefix}approve
│ ◦ ${prefix}reject
│ ◦ ${prefix}addsewa
│ ◦ ${prefix}delsewa
│ ◦ ${prefix}clersession
│ ◦ ${prefix}listsewa
│ ◦ ${prefix}delsewa
│ ◦ ${prefix}ceksewa
│ ◦ ${prefix}backupsc
│ ◦ ${prefix}clearchat
│ ◦ ${prefix}pinchat
│ ◦ ${prefix}unpinchat
│ ◦ ${prefix}upswteks
│ ◦ ${prefix}upswvideo
│ ◦ ${prefix}upswaudio
│ ◦ ${prefix}upswimg
│ ◦ ${prefix}colongsw
│ ◦ ${prefix}addplugin
│ ◦ ${prefix}delplugin
│ ◦ ${prefix}realodplugin
│ ◦ ${prefix}listplugin
│ ◦ ${prefix}adddb
│ ◦ ${prefix}hapusdb
│ ◦ ${prefix}changedb
│ ◦ ${prefix}listdb
╰─ *Owner* 

Powered by ${global.namaowner}
version v2.3.3 Multi-Device`,
                footerText: `©${global.namaowner}`,
                headerType: 6,
            },
        };

        const msg = generateWAMessageFromContent(from, content, {
            userJid: satanic.user.jid,
        });

        await satanic.relayMessage(from, msg.message, {
            messageId: msg.key.id,
        });

    } catch (e) {
        console.error(e);
        reply("Terjadi kesalahan.");
    }
}
break;

case 'blacklist': {
    // Ambil target
    let target = m.mentionedJid?.[0] || m.quoted?.sender || args[0];
    if (!target) return m.reply('Tag/reply/nomor!');
    if (!target.includes('@')) target += '@s.whatsapp.net';
    
    // Cek & tambah
    if (isBlacklisted(target)) return m.reply('Udah masuk blacklist!');
    
    addBlacklist(target, args.slice(1).join(' ') || 'Tidak ada alasan');
    m.reply(`✅ Done! ${target.split('@')[0]} diblacklist.`);
}
break;


    case 'unblacklist': {
  if (!m.isGroup) return reply(mess.group);
  if (!isAdmins && !isCreator) return reply(mess.admin);
    const list = getBlacklist();
    if (list.length === 0) return reply('📭 Belum ada user yang diblokir.');

    const rows = list.map(entry => ({
        header: "",
        title: entry.jid,
        description: `Alasan: ${entry.reason || 'Tidak ada alasan'}`,
        id: `.confirmunblacklist ${entry.jid}`
    }));

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                interactiveMessage: {
                    body: { text: `📋 Pilih user yang ingin dihapus dari blacklist:` },
                    footer: { text: 'Aqua Assistant' },
                    header: { title: '🗑️ Daftar Blacklist' },
                    nativeFlowMessage: {
                        buttons: [{
                            name: "single_select",
                            buttonParamsJson: JSON.stringify({
                                title: "Pilih User",
                                sections: [{ title: "Blacklist", rows }]
                            })
                        }]
                    }
                }
            }
        }
    }, { quoted: fkontak }, {});

    await satanic.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
}
break;

    case 'confirmunblacklist': {
  if (!m.isGroup) return reply(mess.group);
  if (!isAdmins && !isCreator) return reply(mess.admin);
        const userId = args[0];
        if (!userId) return reply('⚠️ Tidak ada user yang dipilih.');

        removeBlacklist(userId);
        reply(`✅ User ${userId} telah dihapus dari blacklist.`);
    }
    break;
    case 'listblacklist': {
    if (!isCreator) return 
    const list = getBlacklist();
    if (list.length === 0) return reply('📭 Tidak ada user blacklist.');
    const text = list
        .map((entry, i) => `${i+1}. ${entry.jid}\n   📌 Alasan: ${entry.reason}`)
        .join('\n\n');
    reply(`📋 *Daftar User Blacklist:*\n\n${text}`);
}
break;
case 'restartbot':
if (!isCreator) return 
reply(`restarting bot....`)
reply(`Berhasil Restart ✅`)
await sleep(3000)
process.exit()
break

case 'resetdb': {
    if (!isCreator) return reply(`❌ Khusus owner!`)
    if (!text || text.toLowerCase() !== 'yes') {
        return reply(`⚠️ Ketik *${prefix}resetdb yes* untuk mereset database.`)
    }
    global.db = {}
    const fs = require('fs')
    fs.writeFileSync('./database/database.json', JSON.stringify(global.db, null, 2))
    
    reply(`✅ Database berhasil direset menjadi {}`)
}
break


case 'self': 
if (!isCreator) return
 satanic.public = false;
 reply(`✅ Successfully changed to ${command} mode`);
break
case 'public': 
if (!isCreator) return
satanic.public = true;
reply(`✅ Successfully changed to ${command} mode`);
break

case 'block': {
		if (!isCreator) return reply('you are not owner')
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await satanic.updateBlockStatus(users, 'block')
		await reply(`*[ Done ]*`)
	}
	break
        case 'unblock': {
		if (!isCreator) return reply('you are not owner')
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await satanic.updateBlockStatus(users, 'unblock')
		await reply(`*[ Done ]*`)
	}
	break
case 'setppbot': case 'setppbot2':{
if (!isCreator) return reply(mess.owner)
const { S_WHATSAPP_NET } = require('@whiskeysockets/baileys');

	async function generateProfilePicture(media) {
    const image = await jimp.read(media);
    const min = image.getWidth();
    const max = image.getHeight();
    const cropped = image.crop(0, 0, min, max);
    return {
        img: await cropped.scaleToFit(720, 720).getBufferAsync(jimp.MIME_JPEG),
        preview: await cropped.normalize().getBufferAsync(jimp.MIME_JPEG)
    };
}
if (!quoted) return reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)

let media = await satanic.downloadAndSaveMediaMessage(quoted);
const { img } = await generateProfilePicture(media);
await satanic.query({
	tag: 'iq',
	attrs: {
	    target: undefined,
        to: S_WHATSAPP_NET,
		type:'set',
		xmlns: 'w:profile:picture'
	},
	content: [
		{
			tag: 'picture',
			attrs: { type: 'image' },
			content: img
		} 
	]
})
reply(mess.done);
}
break
case 'jpm':
case 'broadcast': {
  if (!isCreator) return reply(mess.owner);
  
  const quoted = m.quoted ? m.quoted : m;
  const mime = (quoted.msg || quoted).mimetype || "";
  
  let body = m.body || "";
  let text = body.replace(new RegExp(`^\\${prefix}${command}\\s*`, "i"), "").trim();
  
  let groups = Object.values(await satanic.groupFetchAllParticipating());
  
  if (/image/.test(mime)) {
    const buffer = await quoted.download();
    reply(`📡 Mengirim broadcast GAMBAR ke ${groups.length} grup...`);
    
    let success = 0;
    for (let group of groups) {
      try {
        await satanic.sendMessage(group.id, {
          image: buffer,
          caption: `「 *BROADCAST* 」\n\n${text}`
        });
        success++;
        await sleep(800);
      } catch {}
    }
    
    reply(`✅ ${success}/${groups.length} grup berhasil diterima`);
    
  } else if (/video/.test(mime)) {
    const buffer = await quoted.download();
    reply(`📡 Mengirim broadcast VIDEO ke ${groups.length} grup...`);
    
    let success = 0;
    for (let group of groups) {
      try {
        await satanic.sendMessage(group.id, {
          video: buffer,
          caption: `「 *BROADCAST* 」\n\n${text}`
        });
        success++;
        await sleep(800);
      } catch {}
    }
    
    reply(`✅ ${success}/${groups.length} grup berhasil diterima`);
    
  } else if (/audio/.test(mime)) {
    const buffer = await quoted.download();
    reply(`📡 Mengirim broadcast AUDIO ke ${groups.length} grup...`);
    
    let success = 0;
    for (let group of groups) {
      try {
        await satanic.sendMessage(group.id, {
          audio: buffer
        });
        success++;
        await sleep(800);
      } catch {}
    }
    
    reply(`✅ ${success}/${groups.length} grup berhasil diterima`);
    
  } else if (text) {
    reply(`📡 Mengirim broadcast TEKS ke ${groups.length} grup...\n\n📝 Pesan: ${text.substring(0, 50)}${text.length > 50 ? '...' : ''}`);
    
    let success = 0;
    for (let group of groups) {
      try {
        await satanic.sendMessage(group.id, {
          text: `「 *BROADCAST* 」\n\n${text}`
        });
        success++;
        await sleep(800);
      } catch {}
    }
    
    reply(`✅ ${success}/${groups.length} grup berhasil diterima`);
    
  } else {
    reply(`📢 *BROADCAST (JPM)*\n━━━━━━━━━━━━━━━━\n📌 Mengirim pesan ke semua grup\n\nContoh:\n${prefix + command} Halo semua!\n\nAtau reply media (gambar/video/audio) dengan caption`);
  }
}
break;
case 'requestjoin':
case 'rj':
  if (!m.isGroup) return reply(mess.group);
  if (!isAdmins && !isCreator) return reply(mess.admin);
  ;
  
  function formatWaktull(timestamp) {
    return new Date(parseInt(timestamp) * 1000).toLocaleString('id-ID', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      timeZone: 'Asia/Jakarta'
    });
  }
  
  let pecahan = text ? text.trim().split(/\s+/) : [];
  let instruksi = pecahan[0] ? pecahan[0].toLowerCase() : 'bantuan';
  let parameter = pecahan[1] ? pecahan[1].toLowerCase() : '';
  
  let daftarMasuk = [];
  try {
    const dataPermintaan = await satanic.groupRequestParticipantsList(m.chat);
    
    daftarMasuk = dataPermintaan.map((item, idx) => {
      // Ambil dari phone_number (nomor HP asli)
      let jid = item.phone_number || item.jid || item.id || item;
      let nomor = jid.replace(/@s\.whatsapp\.net|@lid/g, '');
      let nama = item.notify || item.pushname || nomor;
      
      return {
        urutan: idx,
        jid: jid,
        nomor: nomor,
        nama: nama,
        waktu: item.request_time,
        metode: item.request_method
      };
    });
  } catch (galat) {
    console.error(galat);
    return reply('❌ Gagal mengambil daftar permintaan');
  }

  if (instruksi === 'daftar' || instruksi === 'list' || instruksi === 'lihat') {
    if (daftarMasuk.length === 0) return reply('📭 Tidak ada permintaan');
    let teks = `📋 *DAFTAR PERMINTAAN*\n━━━━━━━━━━━━━━━━\n📊 Total: ${daftarMasuk.length}\n\n`;
    daftarMasuk.forEach((p, i) => {
      teks += `*${i+1}. ${p.nama}*\n`;
      teks += `   📞 ${p.nomor}\n`;
      teks += `   ⏰ ${formatWaktull(p.waktu)}\n`;
      teks += `   📝 ${p.metode}\n\n`;
    });
    teks += `━━━━━━━━━━━━━━━━\n📌 .rj setuju 1\n📌 .rj setuju semua\n📌 .rj tolak 1\n📌 .rj tolak semua`;
    return reply(teks);
  }

  if (instruksi === 'setuju' || instruksi === 'approve' || instruksi === 'terima') {
    if (daftarMasuk.length === 0) return reply('❌ Tidak ada permintaan');
    if (parameter === 'semua' || parameter === 'all') {
      await satanic.groupRequestParticipantsUpdate(m.chat, daftarMasuk.map(p => p.jid), 'approve');
      return reply(`✅ Berhasil setuju ${daftarMasuk.length} permintaan`);
    }
    let idx = parseInt(parameter) - 1;
    if (isNaN(idx) || idx < 0 || idx >= daftarMasuk.length) return reply('❌ Nomor tidak valid');
    await satanic.groupRequestParticipantsUpdate(m.chat, [daftarMasuk[idx].jid], 'approve');
    return reply(`✅ Setuju @${daftarMasuk[idx].nomor}`, { mentions: [daftarMasuk[idx].jid] });
  }

  if (instruksi === 'tolak' || instruksi === 'reject' || instruksi === 'decline') {
    if (daftarMasuk.length === 0) return reply('❌ Tidak ada permintaan');
    if (parameter === 'semua' || parameter === 'all') {
      await satanic.groupRequestParticipantsUpdate(m.chat, daftarMasuk.map(p => p.jid), 'reject');
      return reply(`❌ Berhasil tolak ${daftarMasuk.length} permintaan`);
    }
    let idx = parseInt(parameter) - 1;
    if (isNaN(idx) || idx < 0 || idx >= daftarMasuk.length) return reply('❌ Nomor tidak valid');
    await satanic.groupRequestParticipantsUpdate(m.chat, [daftarMasuk[idx].jid], 'reject');
    return reply(`❌ Tolak @${daftarMasuk[idx].nomor}`, { mentions: [daftarMasuk[idx].jid] });
  }

  reply(`🔧 *REQUEST JOIN*\n━━━━━━━━━━━━━━━━\n.rj daftar - Lihat\n.rj setuju 1 - Terima\n.rj setuju semua - Terima semua\n.rj tolak 1 - Tolak\n.rj tolak semua - Tolak semua`);
break;

case "reactch": { 
if (!text) return reply(`${prefix} < ch url > 😂😂😂😂\n`);
  const match = text.match(/https:\/\/whatsapp\.com\/channel\/(\w+)(?:\/(\d+))?/);
  if (!match) return reply("URL tidak valid. Silakan periksa kembali.");
const channelId = match[1];
const chatId = match[2];
if (!chatId) return reply("ID chat tidak ditemukan dalam link yang diberikan.");
 satanic.newsletterMetadata("invite", channelId).then(data => {
 if (!data) return reply("Newsletter tidak ditemukan atau terjadi kesalahan.");
 satanic.newsletterReactMessage(data.id, chatId, text.split(" ").slice(1).join(" ") || "😀");
 });
reply(`sukses mengirimkan custom reaction ke channel tersebut`)
}
break;		
case 'addai': {
    try {
        if (!m.isGroup) return await satanic.sendMessage(m.chat, { text: '⚠️ Khusus grup!' });
        if (!isAdmins && !isCreator) return await satanic.sendMessage(m.chat, { text: '⚠️ Hanya admin!' });

        const aiJid = '867051314767696@bot';
        
        const groupMetadata = await satanic.groupMetadata(m.chat);
        const participants = groupMetadata.participants.map(p => p.id);
        
        if (participants.includes(aiJid)) {
            return await satanic.sendMessage(m.chat, { text: '✅ Meta AI sudah ada di grup!' });
        }

        await satanic.groupParticipantsUpdate(m.chat, [aiJid], 'add');
        await satanic.sendMessage(m.chat, { text: '✅ Meta AI berhasil ditambahkan!' });

    } catch (e) {
        console.error(e);
        await satanic.sendMessage(m.chat, { text: `❌ Error: ${e.message}` });
    }
}
break;
 case "h":
case "hidetag": {
if (!isAdmins && !isCreator) return reply(mess.admin)

if (m.quoted) {
satanic.sendMessage(m.chat, {
forward: m.quoted.fakeObj,
mentions: participants.map(a => a.id)
})
}
if (!m.quoted) {
satanic.sendMessage(m.chat, {
text: text ? text : '',
mentions: participants.map(a => a.id)
}, { quoted: fkontak })
}
}
break
case 'tagall':{
if (!m.isGroup) return reply(mess.group);
if (!isAdmins && !isOwner) return reply(mess.admin)
if (!text) return reply('masukan text')
let teks = `tagall message :\n> *${text}*\n\n`;
const groupMetadata = await satanic.groupMetadata(m.chat);
const participants = groupMetadata.participants;
for (let mem of participants) {
teks += `@${mem.id.split("@")[0]}\n`;
}
satanic.sendMessage(m.chat, {
text: teks,
mentions: participants.map((a) => a.id)
}, { quoted: fkontak });
}
break      
case 'reminder': {
    const fullText = m.text || '';
    const textAfterCommand = fullText.replace(/^[\.\#\$\&\+\-\@\!]?reminder\s+/i, '').trim();
    
    if (!textAfterCommand) {
        return reply('*❓ Format salah!*\n\nContoh: .reminder 30 menit jangan lupa sholat');
    }
    const parts = textAfterCommand.split(/\s+/);
    if (parts.length < 3) {
        return reply('*❌ Format salah!*\nGunakan: .reminder [angka] [detik/menit/jam] [pesan]');
    }
    const timeValue = parseInt(parts[0]);
    const timeUnit = parts[1].toLowerCase();
    const message = parts.slice(2).join(' ');
    
    
    if (isNaN(timeValue) || timeValue <= 0) {
        return reply('*❌ Waktu harus angka positif!*');
    }
    
    let timeInMs = 0;
    if (timeUnit.includes('detik') || timeUnit === 's') {
        timeInMs = timeValue * 1000;
    } else if (timeUnit.includes('menit') || timeUnit === 'm') {
        timeInMs = timeValue * 60 * 1000;
    } else if (timeUnit.includes('jam') || timeUnit === 'h') {
        timeInMs = timeValue * 60 * 60 * 1000;
    } else {
        return reply('*❌ Satuan waktu salah!*\nGunakan: detik, menit, atau jam');
    }
    
    reply(`✅ *Reminder diatur!*\n⏰ ${timeValue} ${timeUnit} lagi\n📝 ${message}`);
    
    const participants = m.isGroup ? (await satanic.groupMetadata(m.chat)).participants : [{ id: m.sender }];
    
    setTimeout(() => {
        satanic.sendMessage(m.chat, {
            forward: m.quoted ? m.quoted.fakeObj : null,
            text: m.quoted ? undefined : `⏰ *REMINDER*\n\n${message}\n\n@${sender.split("@")[0]}`,
            mentions: participants.map(a => a.id)
        }, { quoted: fkontak.quoted ? null : m });
    }, timeInMs);
}
break;
case 'editinfo': {
    if (!m.isGroup) return reply(mess.group);
    if (!isAdmins && !isCreator) return reply(mess.admin);
    const text = body.toLowerCase();
    
    try {
        if (text.includes(' open')) {
            await satanic.groupSettingUpdate(m.chat, 'unlocked');
            reply('✅ *Izin edit info grup dibuka!*\n\n' +
                 '📛 Sekarang semua anggota dapat:\n' +
                 '• Mengubah nama grup\n' +
                 '• Mengubah deskripsi grup\n' +
                 '• Mengubah foto grup');
        } 
        else if (text.includes(' close')) {
            await satanic.groupSettingUpdate(m.chat, 'locked');
            reply('✅ *Izin edit info grup ditutup!*\n\n' +
                 '🔒 Mode hanya admin aktif:\n' +
                 '• Hanya admin bisa ubah nama grup\n' +
                 '• Hanya admin bisa ubah deskripsi\n' +
                 '• Hanya admin bisa ubah foto grup');
        }
        else {
            // Tampilkan panduan jika perintah tidak jelas
            reply(`⚙️ *PENGATURAN EDIT INFO GRUP*\n\n` +
                 `Fungsi: Mengatur siapa yang bisa mengedit informasi grup\n\n` +
                 `📌 Perintah:\n` +
                 `• *${prefix}editinfo open* → Buka izin untuk semua anggota\n` +
                 `• *${prefix}editinfo close* → Hanya admin yang bisa edit\n\n` +
                 `Contoh: *${prefix}editinfo close*`);
        }
    } catch (err) {
        reply(`❌ Gagal mengubah pengaturan edit info: ${err.message || err}`);
    }
}
break;
case 'grup':
case 'gc': {
  if (!m.isGroup) return reply('only group')
  if (!isAdmins && !isCreator) return reply('Perintah ini hanya untuk admin grup.')


  if (!q) {
    return reply(
`Format perintah:
${prefix + command} open  → Membuka grup
${prefix + command} close → Menutup grup

Contoh:
${prefix + command} close`
    )
  }

  if (args[0] === 'close') {

    await satanic.groupSettingUpdate(from, 'announcement')

    reply(
`[ GRUP DITUTUP ]

Hanya admin yang dapat mengirim pesan.
Silakan hubungi admin jika ada keperluan penting.`
    )

  } else if (args[0] === 'open') {

    await satanic.groupSettingUpdate(from, 'not_announcement')

    reply(
`[ GRUP DIBUKA ]

Semua anggota kini dapat mengirim pesan.
Mohon tetap menjaga ketertiban dan aturan grup.`
    )

  } else {
    reply(`Opsi tidak tersedia.\nGunakan: ${prefix + command} open / close`)
  }
}
break

case 'jpmht':
case 'jpmhidetag':
case 'jasherhidetag': {
  if (!isCreator) return reply(mess.owner);
  let groups = await satanic.groupFetchAllParticipating();
  let groupList = Object.values(groups);
  const quoted = m.quoted ? m.quoted : m;
  const mime = (quoted.msg || quoted).mimetype || "";
  let text = m.body.replace(new RegExp(`^\\${prefix}${command}\\s*`, "i"), "").trim();
  if (!mime && !text) {
    return reply(`📢 *BROADCAST HIDETAG KE SEMUA GRUP*\n━━━━━━━━━━━━━━━━\n📌 Total grup: ${groupList.length}\n\nContoh:\n${prefix + command} Halo semua!\nAtau reply gambar/video dengan ${prefix + command}`);
  }
  
  reply(`📡 Mengirim broadcast HIDETAG ke ${groupList.length} grup...\n⏱️ Delay 10 detik antar grup`);
  
  let success = 0;
  
  for (let group of groupList) {
    try {
      // Ambil semua anggota grup untuk hidetag
      const groupMetadata = await satanic.groupMetadata(group.id);
      const mentions = groupMetadata.participants.map(p => p.id);
      
      if (/image/.test(mime)) {
        const buffer = await quoted.download();
        await satanic.sendMessage(group.id, {
          image: buffer,
          caption: `📢「 *BROADCAST* 」\n\n${text}`,
          mentions: mentions
        });
        
      } else if (/video/.test(mime)) {
        const buffer = await quoted.download();
        await satanic.sendMessage(group.id, {
          video: buffer,
          caption: `📢「 *BROADCAST* 」\n\n${text}`,
          mentions: mentions
        });
        
      } else if (/audio/.test(mime)) {
        const buffer = await quoted.download();
        await satanic.sendMessage(group.id, {
          audio: buffer,
          mentions: mentions
        });
        
      } else {
        await satanic.sendMessage(group.id, {
          text: `📢「 *BROADCAST* 」\n\n${text}`,
          mentions: mentions
        });
      }
      
      success++;
      await sleep(5000);
      
    } catch (e) {
      console.log(`Gagal ke ${group.id}:`, e.message);
    }
  }
  
  reply(`✅ ${success}/${groupList.length} grup berhasil dikirim dengan HIDETAG`);
}
break;
case 'jpmstatus':
case 'statusgrup':
case 'statusgroup': {
    if (!isCreator) return 
    
    const { fromBuffer } = require("file-type");
    const fs = require("fs");
    const path = require("path");

    let content = {};
    let buffer, ext, tempFile;

    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    if (m.quoted) {
        try {
            buffer = await m.quoted.download();
            if (!buffer) return reply("❌ Gagal mengambil media quoted.");
            
            const fileTypeRes = await fromBuffer(buffer);
            ext = fileTypeRes ? fileTypeRes.ext : 'bin';
            tempFile = path.join(__dirname, `tmp_${Date.now()}.${ext}`);
            fs.writeFileSync(tempFile, buffer);

            const quotedType = m.quoted.mtype || Object.keys(m.quoted.message || {})[0] || '';
            if (/image|video|audio/.test(quotedType)) {
                if (/image/.test(quotedType)) {
                    content.image = { url: tempFile };
                    if (text) content.caption = text;
                } else if (/video/.test(quotedType)) {
                    content.video = { url: tempFile };
                    if (text) content.caption = text;
                } else if (/audio/.test(quotedType)) {
                    if (text) {
                        fs.unlinkSync(tempFile);
                        return reply("Audio tidak boleh disertai caption.");
                    }
                    content.audio = { url: tempFile };
                    content.ptt = false;
                }
            } else {
                fs.unlinkSync(tempFile);
                return reply("Reply harus berupa image/video/audio.");
            }
        } catch (e) {
            return reply("❌ Media tidak valid atau gagal diproses.");
        }
    } else if (text) {
        content.text = text;
    } else {
        return reply("Kirim media (foto/video/audio) atau teks, bisa dengan reply atau langsung.");
    }

    if (content.text && !content.text.trim()) return reply("Teks tidak boleh kosong.");

    let getGroups = await satanic.groupFetchAllParticipating();
    let groups = Object.values(getGroups);

    let validGroups = [];
    
    validGroups.push({
        title: "All Group",
        description: `Kirim ke ${groups.length} grup`,
        id: `.sendstatus all ${encodeURIComponent(JSON.stringify(content))}`
    });

    for (let group of groups) {
        validGroups.push({
            title: group.subject || "Group",
            description: group.id,
            id: `.sendstatus ${group.id} ${encodeURIComponent(JSON.stringify(content))}`
        });
    }

    if (validGroups.length <= 1) {
        if (tempFile && fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
        return reply("Tidak ada grup valid yang bisa dipilih.");
    }

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                interactiveMessage: {
                    body: { text: "```Pilih Grup Tujuan ♨️```" },
                    nativeFlowMessage: {
                        buttons: [{
                            name: "single_select",
                            buttonParamsJson: JSON.stringify({
                                title: "PILIH GRUP",
                                sections: [{ title: "Daftar Grup", rows: validGroups }]
                            })
                        }]
                    }
                }
            }
        }
    }, { quoted: fkontak });

    await satanic.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;

case 'sendstatus': {
    if (!isCreator) return 
    const fs = require("fs");
    const crypto = require("crypto");

    const [groupId, ...contentARR] = args;
    const contentDecoded = JSON.parse(decodeURIComponent(contentARR.join(' ')));

    async function groupStatus(jid, contentObj) {
        let content = { ...contentObj };
        const { backgroundColor } = content;
        delete content.backgroundColor;
        
        const inside = await generateWAMessageContent(content, {
            upload: satanic.waUploadToServer,
            backgroundColor
        });
        
        const messageSecret = crypto.randomBytes(32);
        const mStatus = generateWAMessageFromContent(jid, {
            messageContextInfo: {
                messageSecret
            },
            groupStatusMessageV2: {
                message: {
                    ...inside,
                    messageContextInfo: {
                        messageSecret
                    }
                }
            }
        }, {});
        
        await satanic.relayMessage(jid, mStatus.message, {
            messageId: mStatus.key.id
        });
        return mStatus;
    }

    let getGroups = await satanic.groupFetchAllParticipating();
    let groups = Object.values(getGroups).map(v => v.id);

    let success = 0;
    let failed = 0;

    if (groupId === 'all') {
        for (let gid of groups) {
            try {
                await groupStatus(gid, contentDecoded);
                success++;
                await sleep(2000); 
            } catch (e) {
                failed++;
            }
        }
        reply(`✅ Berhasil ${success} group\n❌ Gagal: ${failed} group`);
    } else {
        try {
            await groupStatus(groupId, contentDecoded);
            reply(`✅ Berhasil dikirim ke grup`);
        } catch (e) {
            reply(`❌ Gagal mengirim ke grup yang dituju`);
        }
    }

    try {
        if (contentDecoded?.image?.url && fs.existsSync(contentDecoded.image.url)) fs.unlinkSync(contentDecoded.image.url);
        if (contentDecoded?.video?.url && fs.existsSync(contentDecoded.video.url)) fs.unlinkSync(contentDecoded.video.url);
        if (contentDecoded?.audio?.url && fs.existsSync(contentDecoded.audio.url)) fs.unlinkSync(contentDecoded.audio.url);
    } catch (e) {}

    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'delsesi': 
  case 'clearsession': {
fs.readdir("./session", async function (err, files) {
if (err) {
} 
let filteredArray = await files.filter(item => item.startsWith("pre-key") ||
item.startsWith("sender-key") || item.startsWith("session-") || item.startsWith("app-state")
   )
console.log(filteredArray.length); 
let teks =`Terdeteksi ${filteredArray.length} file kenangan <3\n\n`
if(filteredArray.length == 0) return reply(`${teks}`)
filteredArray.map(function(e, i){
teks += (i+1)+`. ${e}\n`
})     
await sleep(2000)
await filteredArray.forEach(function (file) {
fs.unlinkSync(`./session/${file}`)
});
await sleep(2000)
reply("Berhasil menghapus semua Kenangan di folder session")     
});
}
break
case 'addsewa': {
    try {
    if (!isCreator) return
        if (!text || text.split(' ').length < 2) {
            return reply(
                `Gunakan dengan cara:\n` +
                `${prefix + command} *linkgc waktu*\n\n` +
                `Contoh:\n${prefix + command} https://chat.whatsapp.com/XXX 30d\n\n` +
                `*CATATAN:*\n` +
                `d = hari\nh = jam\nm = menit\ns = detik\ny = tahun`
            );
        }

        let [link, waktu] = text.split(' ');
        
        if (!isUrl(link) || !link.includes('chat.whatsapp.com/')) {
            return reply("❌ Link grup WhatsApp tidak valid!");
        }
        let inviteCode = link.split('chat.whatsapp.com/')[1].split('?')[0];
        let infoGrup;
        try {
            infoGrup = await satanic.groupGetInviteInfo(inviteCode);
        } catch (e) {
            return reply("❌ Gagal mendapatkan info grup. Pastikan link belum di-reset atau bot telah diblokir.");
        }
        const groupId = infoGrup.id;
        const groupName = infoGrup.subject;

        addSewaGroup(groupId, waktu, sewa);
        try {
            await satanic.groupAcceptInvite(inviteCode);
            reply(
                `✅ *SEWA BERHASIL DITAMBAHKAN*\n\n` +
                `🏷️ Nama   : *${groupName}*\n` +
                `🆔 ID     : *${groupId}*\n` +
                `⏳ Durasi : *${waktu}*\n\n` +
                `*Status:* Bot berhasil masuk ke dalam grup dan sewa sudah aktif.`
            );
        } catch (joinErr) {
            reply(
                `⏳ *MENUNGGU PERSETUJUAN ADMIN*\n\n` +
                `🏷️ Nama   : *${groupName}*\n` +
                `🆔 ID     : *${groupId}*\n` +
                `⏳ Durasi : *${waktu}*\n\n` +
                `*Status:* Grup menggunakan sistem persetujuan admin. Namun jangan khawatir, *data sewa sudah tersimpan di database*. Sewa akan langsung berjalan ketika admin menyetujui bot masuk.`
            );
        }

    } catch (err) {
        console.error("ADDSEWA ERROR:", err);
        reply("❌ Terjadi kesalahan saat memproses perintah addsewa.");
    }
}
break;
case 'delsewa': {
    if (!isCreator) return
    if (sewa.length === 0)
        return reply('📭 Belum ada data sewa.')
    const rows = await Promise.all(
        sewa.map(async (x) => {
            const expired =
                x.expired === "PERMANENT"
                    ? "PERMANENT"
                    : msToDate(x.expired - Date.now())

            return {
                header: "",
                title: await getGcName(x.id),
                description: `ID: ${x.id}\nExpired: ${expired}`,
                id: `${prefix}confirmdelsewa ${x.id}`
            }
        })
    )

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: {
                    body: {
                        text: '📋 Pilih grup yang ingin dihapus dari sewa:'
                    },
                    footer: {
                        text: 'Aqua Assistant'
                    },
                    header: {
                        title: '🗑️ Daftar Sewa Aktif'
                    },
                    nativeFlowMessage: {
                        buttons: [{
                            name: "single_select",
                            buttonParamsJson: JSON.stringify({
                                title: "Pilih Grup",
                                sections: [{
                                    title: "Sewa Aktif",
                                    rows
                                }]
                            })
                        }]
                    }
                }
            }
        }
    }, { quoted: fkontak })

    await satanic.relayMessage(
        msg.key.remoteJid,
        msg.message,
        { messageId: msg.key.id }
    )
}
break
case 'confirmdelsewa': {
    if (!isCreator) return
    const id = args[0]
    if (!id) return reply("❌ ID grup tidak valid!")

    const pos = getSewaPosition(id, sewa)
    if (pos === -1)
        return reply("❌ Grup tidak ditemukan dalam data sewa!")
    sewa.splice(pos, 1)
    fs.writeFileSync('./database/sewa.json', JSON.stringify(sewa, null, 2))
    try {
        await satanic.groupLeave(id)
    } catch (err) {
        console.log('Gagal keluar grup:', err)
    }
    reply(
        `✅ Sewa grup berhasil dihapus!\n` +
        `🚪 Bot telah keluar dari grup\n` +
        `🆔 ID: ${id}`
    )
}
break
case 'listsewa': {
    if (!isCreator) return
    if (sewa.length === 0) return reply("📭 Belum ada data sewa.")

    let teks = `📋 *Daftar Sewa Aktif*\n\n`
    for (let x of sewa) {
        teks += `🏷️ Nama : *${await getGcName(x.id)}*\n`
        teks += `🆔 ID   : ${x.id}\n`
        if (x.expired === "PERMANENT") {
            teks += `⏳ Expired : PERMANENT\n\n`
        } else {
            teks += `⏳ Expired : ${msToDate(x.expired - Date.now())}\n\n`
        }
    }

    satanic.sendMessage(m.chat, { text: teks }, { quoted: fkontak })
}
break
case 'ceksewa': {
    if (!isCreator) return
    if (!m.isGroup) return reply("❌ Perintah ini hanya bisa digunakan di dalam grup!");

    let teks = `⬣ *CEK SEWA GRUP*\n\n`;
    let isFound = false;

    for (let x of sewa) {
        if (x.id === m.chat) {
            isFound = true;
            let expiredText = (x.expired === "PERMANENT")
                ? "PERMANENT"
                : msToDate(x.expired - Date.now());

            let groupMeta = await satanic.groupMetadata(x.id);

            teks += `🏷️ Nama : *${groupMeta.subject}*\n` +
                    `🆔 ID   : *${x.id}*\n` +
                    `⏳ Expired : *${expiredText}*\n`;
        }
    }

    if (!isFound) return reply("❌ Grup ini belum menyewa bot.");
    reply(teks);
}
break;

//////////////  GROUP MENU //////////

case 'autoaigrup':
case 'aigrup': 
case 'autoaigc': {
    if (!m.isGroup) return reply('Fitur Khusus Group!')
    if (!isAdmins && !isCreator) return reply('Fitur Khusus admin!')
    
    if (args[0] === "on") {
        if (isAutoAiGc) return reply(`Udah aktif`)
        openaigc.push(m.chat)
        fs.writeFileSync('./database/openaigc.json', JSON.stringify(openaigc, null, 2))
        reply('Successfully Activate Auto AI')
    } else if (args[0] === "off") {
        if (!isAutoAiGc) return reply(`Udah nonaktif`)
        let anu = openaigc.indexOf(m.chat)
        openaigc.splice(anu, 1)
        fs.writeFileSync('./database/openaigc.json', JSON.stringify(openaigc, null, 2))
        reply('Successfully Disabling Auto AI')
    } else {
        reply(`${prefix+command} on -- _mengaktifkan_\n${prefix+command} off -- _Menonaktifkan_`)
    }
}
break

case 'antiimage':
    if (!m.isGroup) return reply('⚠️ Khusus grup!');
    if (!isAdmins && !isCreator) return reply('👑 Khusus admin!');
    
    if (text === 'on') {
        if (isAntiImage) return reply('✅ Anti Image sudah aktif');
        antiImage.push(m.chat);
        fs.writeFileSync('./database/antiimage.json', JSON.stringify(antiImage));
        reply('🔒 *Anti Image AKTIF!* Gambar akan dihapus.');
    } else if (text === 'off') {
        if (!isAntiImage) return reply('❌ Sudah nonaktif');
        let index = antiImage.indexOf(m.chat);
        antiImage.splice(index, 1);
        fs.writeFileSync('./database/antiimage.json', JSON.stringify(antiImage));
        reply('🔓 *Anti Image NONAKTIF!*');
    } else {
        reply(`⚙️ *Status Anti Image:* ${isAntiImage ? '✅ AKTIF' : '❌ NONAKTIF'}\n\n*Cara:* ${prefix + command} on/off`);
    }
break;
case 'antiaudio':
    if (!m.isGroup) return reply('⚠️ Khusus grup!');
    if (!isAdmins && !isCreator) return reply('👑 Khusus admin!');
    
    if (text === 'on') {
        if (isAntiAudio) return reply('✅ Anti Audio sudah aktif');
        antiAudio.push(m.chat);
        fs.writeFileSync('./database/antiaudio.json', JSON.stringify(antiAudio));
        reply('🔒 *Anti Audio AKTIF!* Audio akan dihapus.');
    } else if (text === 'off') {
        if (!isAntiAudio) return reply('❌ Sudah nonaktif');
        let index = antiAudio.indexOf(m.chat);
        antiAudio.splice(index, 1);
        fs.writeFileSync('./database/antiaudio.json', JSON.stringify(antiAudio));
        reply('🔓 *Anti Audio NONAKTIF!*');
    } else {
        reply(`⚙️ *Status Anti Audio:* ${isAntiAudio ? '✅ AKTIF' : '❌ NONAKTIF'}\n\n*Cara:* ${prefix + command} on/off`);
    }
break;
// Command Anti Video
case 'antivideo':
    if (!m.isGroup) return reply('⚠️ Khusus grup!');
    if (!isAdmins && !isCreator) return reply('👑 Khusus admin!');
    
    if (text === 'on') {
        if (isAntiVideo) return reply('✅ Anti Video sudah aktif');
        antiVideo.push(m.chat);
        fs.writeFileSync('./database/antivideo.json', JSON.stringify(antiVideo));
        reply('🔒 *Anti Video AKTIF!* Video akan dihapus.');
    } else if (text === 'off') {
        if (!isAntiVideo) return reply('❌ Sudah nonaktif');
        let index = antiVideo.indexOf(m.chat);
        antiVideo.splice(index, 1);
        fs.writeFileSync('./database/antivideo.json', JSON.stringify(antiVideo));
        reply('🔓 *Anti Video NONAKTIF!*');
    } else {
        reply(`⚙️ *Status Anti Video:* ${isAntiVideo ? '✅ AKTIF' : '❌ NONAKTIF'}\n\n*Cara:* ${prefix + command} on/off`);
    }
break;

// Command Anti Sticker
case 'antisticker':
    if (!m.isGroup) return reply('⚠️ Khusus grup!');
    if (!isAdmins && !isCreator) return reply('👑 Khusus admin!');
    
    if (text === 'on') {
        if (isAntiSticker) return reply('✅ Anti Sticker sudah aktif');
        antiSticker.push(m.chat);
        fs.writeFileSync('./database/antisticker.json', JSON.stringify(antiSticker));
        reply('🔒 *Anti Sticker AKTIF!* Sticker akan dihapus.');
    } else if (text === 'off') {
        if (!isAntiSticker) return reply('❌ Sudah nonaktif');
        let index = antiSticker.indexOf(m.chat);
        antiSticker.splice(index, 1);
        fs.writeFileSync('./database/antisticker.json', JSON.stringify(antiSticker));
        reply('🔓 *Anti Sticker NONAKTIF!*');
    } else {
        reply(`⚙️ *Status Anti Sticker:* ${isAntiSticker ? '✅ AKTIF' : '❌ NONAKTIF'}\n\n*Cara:* ${prefix + command} on/off`);
    }
break;

case 'antiyt':
case 'antiyoutube':
    if (!m.isGroup) return reply('⚠️ Khusus grup!');
    if (!isAdmins && !isCreator) return reply('👑 Khusus admin!');
    
    if (text === 'on') {
        if (isAntiYt) return reply('✅ Anti YouTube sudah aktif');
        antiYt.push(m.chat);
        fs.writeFileSync('./database/antiyt.json', JSON.stringify(antiYt));
        reply('🔒 *Anti YouTube AKTIF!* Link YouTube akan dihapus.');
    } else if (text === 'off') {
        if (!isAntiYt) return reply('❌ Sudah nonaktif');
        let index = antiYt.indexOf(m.chat);
        antiYt.splice(index, 1);
        fs.writeFileSync('./database/antiyt.json', JSON.stringify(antiYt));
        reply('🔓 *Anti YouTube NONAKTIF!*');
    } else {
        reply(`⚙️ *Status Anti YT:* ${isAntiYt ? '✅ AKTIF' : '❌ NONAKTIF'}\n\n*Cara:* ${prefix + command} on/off`);
    }
break;
case 'antiig':
    if (!m.isGroup) return reply('⚠️ Khusus grup!');
    if (!isAdmins && !isCreator) return reply('👑 Khusus admin!');
    
    if (text === 'on') {
        if (isAntiIg) return reply('✅ Anti Instagram sudah aktif');
        antiIg.push(m.chat);
        fs.writeFileSync('./database/antiig.json', JSON.stringify(antiIg));
        reply('🔒 *Anti Instagram AKTIF!* Link IG akan dihapus.');
    } else if (text === 'off') {
        if (!isAntiIg) return reply('❌ Sudah nonaktif');
        let index = antiIg.indexOf(m.chat);
        antiIg.splice(index, 1);
        fs.writeFileSync('./database/antiig.json', JSON.stringify(antiIg));
        reply('🔓 *Anti Instagram NONAKTIF!*');
    } else {
        reply(`⚙️ *Status Anti IG:* ${isAntiIg ? '✅ AKTIF' : '❌ NONAKTIF'}\n\n*Cara:* ${prefix + command} on/off`);
    }
break;

// Command Antilink TikTok
case 'antitt':
case 'antitiktok':
    if (!m.isGroup) return reply('⚠️ Khusus grup!');
    if (!isAdmins && !isCreator) return reply('👑 Khusus admin!');
    
    if (text === 'on') {
        if (isAntiTt) return reply('✅ Anti TikTok sudah aktif');
        antiTt.push(m.chat);
        fs.writeFileSync('./database/antitt.json', JSON.stringify(antiTt));
        reply('🔒 *Anti TikTok AKTIF!* Link TikTok akan dihapus.');
    } else if (text === 'off') {
        if (!isAntiTt) return reply('❌ Sudah nonaktif');
        let index = antiTt.indexOf(m.chat);
        antiTt.splice(index, 1);
        fs.writeFileSync('./database/antitt.json', JSON.stringify(antiTt));
        reply('🔓 *Anti TikTok NONAKTIF!*');
    } else {
        reply(`⚙️ *Status Anti TT:* ${isAntiTt ? '✅ AKTIF' : '❌ NONAKTIF'}\n\n*Cara:* ${prefix + command} on/off`);
    }
break;

case 'antilinkall':
    if (!m.isGroup) return reply('⚠️ Khusus grup!');
    if (!isAdmins && !isCreator) return reply('👑 Khusus admin!');
    
    if (text === 'on') {
        if (isAntiLinkAll) return reply('✅ Sudah aktif');
        antilinkall.push(m.chat);
        fs.writeFileSync('./database/antilinkall.json', JSON.stringify(antilinkall));
        reply('🔒 *Antilink All AKTIF!* Semua link akan dihapus.');
    } else if (text === 'off') {
        if (!isAntiLinkAll) return reply('❌ Sudah nonaktif');
        let index = antilinkall.indexOf(m.chat);
        antilinkall.splice(index, 1);
        fs.writeFileSync('./database/antilinkall.json', JSON.stringify(antilinkall));
        reply('🔓 *Antilink All NONAKTIF!*');
    } else {
        reply(`⚙️ *Status:* ${isAntiLinkAll ? '✅ AKTIF' : '❌ NONAKTIF'}\n\n*Cara:* ${prefix + command} on/off`);
    }
break;
case 'antilinkkick':
case 'antikick':
    if (!m.isGroup) return reply('⚠️ Hanya di grup!');
    if (!isAdmins && !isCreator) return reply('👑 Khusus admin grup!');
    
    if (text === 'on') {
        if (AntilinkKick) return reply('✅ Anti link kick sudah aktif di grup ini');
        
        antilinkKick.push(from);
        fs.writeFileSync("./database/antilinkkick.json", JSON.stringify(antilinkKick));
        reply(`🔒 *Anti link kick telah diaktifkan!*\n\nPengirim link grup/channel akan otomatis dikeluarkan!`);
        
    } else if (text === 'off') {
        if (!AntilinkKick) return reply('❌ Anti link kick sudah nonaktif di grup ini');
        
        let off = antilinkKick.indexOf(from);
        antilinkKick.splice(off, 1);
        fs.writeFileSync("./database/antilinkkick.json", JSON.stringify(antilinkKick));
        reply(`🔓 *Anti link kick telah dinonaktifkan!*`);
        
    } else {
        reply(`⚙️ *ANTI LINK KICK SETTINGS*\n\n` +
              `📌 Status: ${AntilinkKick ? '✅ AKTIF' : '❌ NONAKTIF'}\n\n` +
              `📝 *Usage:*\n` +
              `➤ ${prefix + command} on  - Aktifkan\n` +
              `➤ ${prefix + command} off - Nonaktifkan`);
    }
    break;
case 'antidelete': {
    if (!m.isGroup) return reply('⚠️ Hanya di grup!');
    if (!isAdmins && !isCreator) return reply('👑 Khusus admin grup!');
    
  const args = m.text.split(' ');
  const subCommand = args[1]?.toLowerCase();
  
  switch (subCommand) {
    case 'on': {
      if (global.antidel) {
        reply('⚠️ Anti-Delete sudah aktif!');
      } else {
        global.antidel = true;
        chatDB = [];
        fs.writeFileSync('chatsDB.js', JSON.stringify(chatDB, null, 2));
        reply('✅ Anti-Delete Aktif!\nPesan yang dihapus akan dipulihkan.');
      }
      break;
    }
    
    case 'off': {
      if (!global.antidel) {
        reply('⚠️ Anti-Delete sudah nonaktif!');
      } else {
        global.antidel = false;
        chatDB = [];
        fs.writeFileSync('chatsDB.js', JSON.stringify(chatDB, null, 2));
        reply('❌ Anti-Delete Nonaktif!\nPesan yang dihapus tidak akan dipulihkan.');
      }
      break;
    }
    
    case 'list': {
      if (!global.antidel) {
        reply('⚠️ Anti-Delete nonaktif, tidak ada pesan tersimpan.');
      } else if (chatDB.length === 0) {
        reply('📭 Tidak ada pesan tersimpan.');
      } else {
        let list = '📋 Daftar Pesan Tersimpan\n\n';
        chatDB.forEach((msg, i) => {
          list += `${i+1}. ${msg.body || 'Media/Sticker'}\n`;
        });
        list += `\n📊 Total: ${chatDB.length} pesan`;
        reply(list);
      }
      break;
    }
    
    case 'cek':
    case 'status': {
      const status = global.antidel ? '✅ Aktif' : '❌ Nonaktif';
      const total = global.antidel ? `📊 Total pesan tersimpan: ${chatDB.length}` : '';
      reply(`📌 Status Anti-Delete\n${status}\n${total}`);
      break;
    }
    
    default: {
      reply(
        `📌 Menu Anti-Delete\n\n` +
        `🔹 antidelete on - Aktifkan\n` +
        `🔹 antidelete off - Nonaktifkan\n` +
        `🔹 antidelete list - Lihat pesan tersimpan\n` +
        `🔹 antidelete cek - Cek status\n` +
        `🔹 antidelete status - Cek status\n` +
        `\n⚡ Status saat ini: ${global.antidel ? '✅ Aktif' : '❌ Nonaktif'}`
      );
      break;
    }
  }
  break;
}

////// COLONG BOLEH JANGAN HAPIS WM GW NGENTOT BY SATAN HAXOR/////
case 'anticolong': {
if (!isPrem && !isCreator) return reply('you are not premium')
    try {
        await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        const quoted = m.quoted ? m.quoted : m;
        const qmsg = quoted.msg || quoted;
        const mime = qmsg.mimetype || '';

        if (!mime || !mime.includes('webp')) {
            return await m.reply('❌ Reply sticker WEBP biasa dulu.');
        }

        // Download sticker
        const stream = await downloadContentFromMessage(qmsg, 'sticker');
        const chunks = [];
        for await (const chunk of stream) chunks.push(chunk);
        const stickerBuffer = Buffer.concat(chunks);

        const metadata = {
            'sticker-pack-id': '2be7e369-b5ce-4706-a3d4-f78805a20328',
            'sticker-pack-name': 'Satanic Haxor',
            'sticker-pack-publisher': 'Satanic Haxor',
            'accessibility-text': 'Satanic Haxor',
            'android-app-store-link': 'https://whatsapp.com',
            'ios-app-store-link': 'https://whatsapp.com/ios',
            emojis: ['🦸', '😴', '😌'],
            'is-from-sticker-maker': 0,
            'is-avatar-sticker': 1,
            'avatar-sticker-template-id': 'whatsapp',
            'is-ai-sticker': 1,
            'is-avatar-country-sticker': 1,
            'is-avatar-instant-sticker': 1,
            'sticker-maker-source-type': 4,
            'is-avatar-social-sticker': 1,
            'avatar-sticker-style': 'whatsapp',
            'avatar-sticker-revision-id': '2026',
            'is-from-user-created-pack': 1,
            'origin-pack-id': 'whatsapp',
            'is-text-sticker': 1
        };

        // Build EXIF
        const json = Buffer.from(JSON.stringify(metadata), 'utf-8');
        const exif = Buffer.concat([
            Buffer.from([0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00]),
            Buffer.alloc(4),
            Buffer.from([0x16, 0x00, 0x00, 0x00]),
            json
        ]);
        exif.writeUInt32LE(json.length, 14);

        // Make chunk
        const typeBuffer = Buffer.from('EXIF');
        const sizeBuffer = Buffer.alloc(4);
        sizeBuffer.writeUInt32LE(exif.length, 0);
        const padding = exif.length % 2 === 1 ? Buffer.from([0x00]) : Buffer.alloc(0);
        const exifChunk = Buffer.concat([typeBuffer, sizeBuffer, exif, padding]);

        // Process WEBP
        if (stickerBuffer.slice(0, 4).toString() !== 'RIFF' || stickerBuffer.slice(8, 12).toString() !== 'WEBP') {
            throw new Error('File bukan WEBP valid.');
        }

        const chunks_ = [];
        let offset = 12;

        while (offset + 8 <= stickerBuffer.length) {
            const type = stickerBuffer.slice(offset, offset + 4).toString();
            const size = stickerBuffer.readUInt32LE(offset + 4);
            const chunkStart = offset;
            const chunkEnd = offset + 8 + size + (size % 2);
            if (chunkEnd > stickerBuffer.length) break;
            if (type !== 'EXIF') chunks_.push(stickerBuffer.slice(chunkStart, chunkEnd));
            offset = chunkEnd;
        }

        const body = Buffer.concat([...chunks_, exifChunk]);
        const header = Buffer.alloc(12);
        header.write('RIFF', 0);
        header.writeUInt32LE(body.length + 4, 4);
        header.write('WEBP', 8);
        const finalBuffer = Buffer.concat([header, body]);

        const media = await prepareWAMessageMedia(
            { sticker: finalBuffer },
            { upload: satanic.waUploadToServer }
        );

        const msgContent = {
            messageContextInfo: {
                limitSharingV2: {
                    sharingLimited: true,
                    trigger: 'CHAT_SETTING',
                    limitSharingSettingTimestamp: Date.now().toString(),
                    initiatedByMe: true
                }
            },
            stickerMessage: {
                ...media.stickerMessage,
                isAnimated: qmsg.isAnimated || false,
                isAvatar: true,
                isAiSticker: true,
                isLottie: false
            }
        };

        const msg = await generateWAMessageFromContent(m.chat, msgContent, {
            quoted: m,
            userJid: satanic.user.id
        });

        await satanic.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (e) {
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await m.reply('❌ Gagal inject atribut sticker.\nPastikan reply sticker WEBP biasa.');
    }
}
break;
 case 'antibot': {
if (!m.isGroup) return reply('⚠️ Khusus grup!');
    if (!isAdmins && !isCreator) return reply('👑 Khusus admin!');

  const isAktif = antibot[m.chat] === true
  const currentAction = antibotSettings[m.chat] || 'delete'

  if (!text) {
    return reply(`🛡️━〔 *ANTIBOT SECURITY* 〕🛡️

📊 *Status Sistem*
• Proteksi : *${isAktif ? 'AKTIF (ON) ✅' : 'NONAKTIF (OFF) ❌'}*
• Mode Aksi : *${currentAction.toUpperCase()}*

⚙️ *Pengaturan*
• ${prefix}antibot on
• ${prefix}antibot off
• ${prefix}antibot set kick
• ${prefix}antibot set delete

🔐 Melindungi grup dari bot & client tidak resmi.
`)
  }
  
  if (args[0] === 'on') {
    if (isAktif) return reply('🟢 Sudah aktif.')

    antibot[m.chat] = true
    saveAntibot()
    reply('🟢 Antibot berhasil diaktifkan.')
  }
  else if (args[0] === 'off') {
    if (!isAktif) return reply('🔴 Sudah nonaktif.')

    delete antibot[m.chat]
    delete antibotSettings[m.chat]
    saveAntibot()
    saveAntibotSettings()
    reply('🔴 Antibot dimatikan.')
  }
  else if (args[0] === 'set') {
    if (!isAktif)
      return reply('Aktifkan dulu dengan antibot on')

    if (args[1] === 'kick' || args[1] === 'delete') {
      antibotSettings[m.chat] = args[1]
      saveAntibotSettings()
      reply(`Mode diubah ke ${args[1].toUpperCase()}`)
    } else {
      reply('Gunakan: kick / delete')
    }
  }
  else {
    reply('Perintah tidak dikenal')
  }
}
break   
case 'antilink':
  if (!m.isGroup) return reply('⚠️ Fitur ini hanya dapat digunakan di dalam grup!')

  if (!isAdmins && !isCreator) return reply('👑 Khusus admin grup!')
  
  if (text === 'on') {
    if (Antilinkgc) return reply('✅ Antilink sudah aktif di grup ini')
    
    ntlinkgc.push(from)
    fs.writeFileSync("./database/antilink.json", JSON.stringify(ntlinkgc))
    reply(`🔒 *Antilink has been activated in this group!*\n\nNobody is allowed to send other group/channel links!`)
    
  } else if (text === 'off') {
    if (!Antilinkgc) return reply('❌ Antilink sudah nonaktif di grup ini')
    
    let off = ntlinkgc.indexOf(from)
    ntlinkgc.splice(off, 1)
    fs.writeFileSync("./database/antilink.json", JSON.stringify(ntlinkgc))
    reply(`🔓 *Antilink has been deactivated in this group!*`)
    
  } else {
    reply(`⚙️ *Antilink Settings*\n\n` +
          `📌 Current status: ${Antilinkgc ? '✅ ACTIVE' : '❌ INACTIVE'}\n\n` +
          `📝 *Usage:*\n` +
          `➤ ${prefix + command} on  - Activate antilink\n` +
          `➤ ${prefix + command} off - Deactivate antilink`)
  }
break
case 'delay': {
    if (!m.isGroup) return m.reply('Fitur ini khusus di dalam grup!');
    if (!isAdmins && !isCreator) return m.reply('Hanya untuk Admin/Owner.');

    if (!args[0]) return m.reply(`*Format salah!*\nContoh: ${prefix + command} on atau off`);

    if (args[0] === 'on') {
        global.db.chats[botNumber].antispam = true;
        m.reply('✅ *delay Aktif:* Bot sekarang akan membatasi spam chat.');
    } else if (args[0] === 'off') {
        global.db.chats[botNumber].antispam = false;
        m.reply('📴 *delay Mati:* Bot tidak akan membatasi kecepatan chat.');
    } else {
        m.reply('Gunakan opsi "on" atau "off".');
    }
}
break;
case 'antispam': {
if (!m.isGroup) return 
  if (!isAdmins && !isCreator) return 


    if (args[0] === 'on') {
        if (antiSpamGroups.includes(m.chat)) return m.reply('😏 Anti-Spam sudah *AKTIF* di grup ini.')
        antiSpamGroups.push(m.chat)
        fs.writeFileSync(dbSpamGroups, JSON.stringify(antiSpamGroups, null, 2))
        return m.reply('🔥 *Anti-Spam AKTIF!* \nSiap-siap, tukang spam bakal dipantau ketat 💀')
    }

    if (args[0] === 'off') {
        if (!antiSpamGroups.includes(m.chat)) return m.reply('🤨 Memang sudah *OFF* kok.')
        antiSpamGroups = antiSpamGroups.filter(id => id !== m.chat)
        fs.writeFileSync(dbSpamGroups, JSON.stringify(antiSpamGroups, null, 2))
        return m.reply('😴 Anti-Spam *dimatikan*. Tukang spam bisa bernapas lega…')
    }

    m.reply(
        '❓ *Cara Pakai Antispam:*\n\n' +
        '• `antispam on` → Aktifkan deteksi spam\n' +
        '• `antispam off` → Matikan deteksi spam\n' +
        '• `unwarn @user` → Hapus poin peringatan user\n' +
        '• `resetspam` → Bersihkan semua database spam'
    )
}
break
case 'autojoingc':
  if (!m.isGroup) return reply('⚠️ Fitur ini hanya dapat digunakan di dalam grup!')

  if (!isAdmins && !isCreator) return reply('👑 Khusus admin grup!')
  
  if (text === 'on') {
    if (Autojoingc) return reply('✅ Auto join gc sudah aktif di grup ini')
    
    joingc.push(from)
    fs.writeFileSync("./database/autojoingc.json", JSON.stringify(joingc))
    reply(`🔒 *Auto join group has been activated in this group!*`)
    
  } else if (text === 'off') {
    if (!Autojoingc) return reply('❌ auto join sudah nonaktif di grup ini')
    
    let offjoin = joingc.indexOf(from)
    joingc.splice(offjoin, 1)
    fs.writeFileSync("./database/autojoingc.json", JSON.stringify(joingc))
    reply(`🔓 done`)
    
  } else {
    reply(`⚙️ *Auto join group Settings*\n\n` +
          `📌 Current status: ${Antilinkgc ? '✅ ACTIVE' : '❌ INACTIVE'}\n\n` +
          `📝 *Usage:*\n` +
          `➤ ${prefix + command} on  - Activate autojoingc\n` +
          `➤ ${prefix + command} off - Deactivate autojoingc`)
  }
break
case 'sewa':
case 'sewabot': {

  function rupiah(num) {
    return num.toLocaleString('id-ID')
  }
  const paket = {
    "1hari":  { nama: "1 Hari", harga: 1000 },
    "5hari":  { nama: "5 Hari", harga: 4500 },
    "7hari":  { nama: "7 Hari", harga: 6000 },
    "1bulan": { nama: "1 Bulan", harga: 20000 },
    "3bulan": { nama: "3 Bulan", harga: 50000 },
    "1tahun": { nama: "1 Tahun", harga: 120000 },
    "prem1":  { nama: "Premium + sewa 1 Bulan", harga: 60000 },
    "prem12": { nama: "Premium + sewa 1 Tahun", harga: 150000 }
  }

  let pilih = (args[0] || '').toLowerCase()

  // ===== MENU UTAMA =====
  if (!pilih) {

    const rows = Object.keys(paket).map(v => ({
      header: "",
      title: `📦 ${paket[v].nama}`,
      description: `Harga Rp ${rupiah(paket[v].harga)}`,
      id: `.sewabot ${v}`
    }))

    const teks = `
╭━━━〔 🤖 *SEWA BOT* 〕━━━⬣
┃
┃ 💼 *PAKET HARIAN*
┃ ├ 1 Hari     : Rp 1.000
┃ ├ 5 Hari     : Rp 4.500
┃ └ 7 Hari     : Rp 6.000
┃
┃ 📆 *PAKET BULANAN & TAHUNAN*
┃ ├ 1 Bulan    : Rp 20.000
┃ ├ 3 Bulan    : Rp 50.000
┃ └ 1 Tahun    : Rp 120.000
┃
┃ 👑 *PREMIUM & VVIP GROUP*
┃ (Admin menjadi User Premium)
┃ ├ 1 Bulan    : Rp 60.000
┃ └ 1 Tahun    : Rp 150.000
┃
┣━━━━━━━━━━━━━━━━━━⬣
┃ ⚡ *KEUNGGULAN BOT*
┃ ✓ Proses cepat (1–5 menit)
┃ ✓ Bisa jaga grup 24 jam
┃ ✓ Fitur lengkap & update
┃ ✓ Anti ribet & fast respon
┃
┃ 📦 *PILIH PAKET DI BAWAH*
╰━━━━━━━━━━━━━━━━━━⬣
`
    const msg = generateWAMessageFromContent(m.chat,{
      viewOnceMessage:{
        message:{
          messageContextInfo:{
            deviceListMetadata:{},
            deviceListMetadataVersion:2
          },
          interactiveMessage:{
            body:{ text: teks },
            footer:{ text: global.botName },
            header:{ title: `Sewa Bot AQUA` },
            nativeFlowMessage:{
              buttons:[{
                name:"single_select",
                buttonParamsJson:JSON.stringify({
                  title:"Pilih Paket Sewa",
                  sections:[{
                    title:"Daftar Paket",
                    rows
                  }]
                })
              }]
            }
          }
        }
      }
    },{ quoted:fkontak })

    return satanic.relayMessage(
      msg.key.remoteJid,
      msg.message,
      { messageId: msg.key.id }
    )
  }
  
  // ===== PROSES PILIH PAKET =====
  if (pilih) {

    if (!paket[pilih]) return reply("❌ Paket tidak ditemukan")

    let nama = paket[pilih].nama
    let harga = paket[pilih].harga

    let orderText = `Halo kak saya mau sewa bot

Paket : ${nama}
Harga : Rp ${rupiah(harga)}

Link Group :
`

    let link = `https://wa.me/${global.owner}?text=${encodeURIComponent(orderText)}`

    let teks = `
╭━━━〔 🤖 ORDER SEWA BOT 〕━━━⬣
│
│ 📦 Paket : ${nama}
│ 💰 Harga : Rp ${rupiah(harga)}
│
│ ⚡ Proses aktivasi 1-5 menit
│ 🔐 Bot aktif 24 jam
│
╰━━━━━━━━━━━━━━━━━━⬣

📞 *KLIK UNTUK ORDER:* ${link}
`

    // Kirim pesan biasa tanpa externalAdReply
    satanic.sendMessage(m.chat, {
      text: teks
    }, { quoted: fkontak })

  }

}
break


case 'setqris': {
  const fs = require('fs')
  const qrisPath = './database/qris.json'
  
  // Cek owner
  if (!global.owner.includes(m.sender.split('@')[0])) {
    return reply("❌ Khusus owner.")
  }

  const quoted = m.quoted ? m.quoted : m;
  const mime = (quoted.msg || quoted).mimetype || '';
  
  let imageUrl = ''
  
  if (/image/.test(mime)) {
    try {
      // Download media
      let mediaFile = await satanic.downloadAndSaveMediaMessage(quoted)
      
      // Upload ke pone.rs
      const mediaBuffer = fs.readFileSync(mediaFile)
      const form = new FormData()
      form.append('files[]', mediaBuffer, { filename: 'qris.jpg' })
      const uploadRes = await axios.post('https://pone.rs/upload.php', form, {
        headers: {
          ...form.getHeaders(),
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
          'Referer': 'https://pone.rs/',
          'Origin': 'https://pone.rs'
        },
        maxBodyLength: Infinity,
        maxContentLength: Infinity
      })
      
      if (!uploadRes.data?.success || !uploadRes.data?.files?.[0]?.url) {
        return reply("❌ Gagal upload gambar ke pone.rs.")
      }
      
      imageUrl = uploadRes.data.files[0].url.replace(/\\\//g, '/')
      
      // Hapus file temporary
      if (fs.existsSync(mediaFile)) fs.unlinkSync(mediaFile)
      
    } catch (err) {
      console.error(err)
      return reply("❌ Gagal upload gambar: " + err.message)
    }
  } else if (args[0]) {
    // Jika pakai URL
    imageUrl = args[0]
  } else {
    return reply("📌 *Cara:* Reply gambar QRIS lalu ketik .setqris\nAtau .setqris [url_gambar]")
  }

  // Simpan ke file JSON
  if (!fs.existsSync('./database')) {
    fs.mkdirSync('./database', { recursive: true })
  }
  
  fs.writeFileSync(qrisPath, JSON.stringify({ url: imageUrl }, null, 2))
  
  reply(`✅ *QRIS berhasil disimpan permanen!\n\nKetik .qris untuk melihat.`)
}
break
case 'qris': {
  try {
    const fs = require('fs')
    const qrisPath = './database/qris.json'
    
    // Baca URL QRIS dari file
    let qrisUrl = ''
    if (fs.existsSync(qrisPath)) {
      const data = JSON.parse(fs.readFileSync(qrisPath))
      qrisUrl = data.url
    } else {
      return reply("❌ QRIS belum diatur. Ketik .setqris untuk mengatur QRIS.")
    }

    // Validasi URL
    if (!qrisUrl || qrisUrl === '') {
      return reply("❌ URL QRIS kosong. Silakan set ulang dengan .setqris")
    }

    let txt = `*PEMBAYARAN VIA QRIS*
    
*Scan QRIS di bawah untuk melakukan pembayaran*
    
*Setelah scan & bayar*

*Kirim bukti transfer ke owner*

*Klik tombol "Konfirmasi Pembayaran*"
`

    let buttons = [
      {
        name: "cta_url",
        buttonParamsJson: JSON.stringify({
          display_text: "💬 Konfirmasi Bayar",
          url: `https://wa.me/${global.owner}?text=Halo%20owner%2C%20saya%20sudah%20bayar`,
          merchant_url: `https://wa.me/${global.owner}?text=Halo%20owner%2C%20saya%20sudah%20bayar`
        })
      }
    ]

    // Ambil gambar QRIS pake axios
    const response = await axios.get(qrisUrl, {
      responseType: 'arraybuffer'
    })
    const qrisBuffer = Buffer.from(response.data, 'binary')

    await sendButton(from, txt, "QRIS Payment", qrisBuffer, buttons, m)
  } catch (e) {
    console.error(e)
    reply("❌ Terjadi kesalahan saat mengambil QRIS.")
  }
}
break

    

case 'mutegc':
case 'banchat':
case 'mutegrup':
  if (!m.isGroup) return reply('⚠️ Fitur ini hanya dapat digunakan di dalam grup!')

  if (!isAdmins && !isCreator) return reply('👑 Khusus admin grup!')
  
  if (text === 'on') {
    if (isMute) return reply('✅ Mute sudah aktif di grup ini')
    
    mutegrup.push(from)
    fs.writeFileSync("./database/mutegc.json", JSON.stringify(mutegrup))
    reply(`🔒 *Mute Group has been activated in this group!*\n\nNobody is allowed to use bot only admin`)
    
  } else if (text === 'off') {
    if (!isMute) return reply('❌ Mute sudah nonaktif di grup ini')
    
    let offgrup = mutegrup.indexOf(from)
    mutegrup.splice(offgrup, 1)
    fs.writeFileSync("./database/mutegc.json", JSON.stringify(mutegrup))
    reply(`🔓 *Mute Group has been deactivated in this group!*`)
    
  } else {
    reply(`⚙️ *Mute Settings*\n\n` +
          `📌 Current status: ${Antilinkgc ? '✅ ACTIVE' : '❌ INACTIVE'}\n\n` +
          `📝 *Usage:*\n` +
          `➤ ${prefix + command} on  - Activate mutegc\n` +
          `➤ ${prefix + command} off - Deactivate mutegc`)
  }
break
case 'antitagsw':
  if (!m.isGroup) return reply('⚠️ Fitur ini hanya dapat digunakan di dalam grup!')

  if (!isAdmins && !isCreator) return reply('👑 Khusus admin grup!')
  
  if (text === 'on') {
    if (Antitagsw) return reply('✅ Anti Tag sudah aktif di grup ini')
    
    nttagsw.push(from)
    fs.writeFileSync("./database/antitagsw.json", JSON.stringify(nttagsw))
    reply(`🔒 *Anti Tag has been activated in this group!*\n\nNobody is allowed to send tag/mention messages!`)
    
  } else if (text === 'off') {
    if (!Antitagsw) return reply('❌ Anti Tag sudah nonaktif di grup ini')
    
    let off = nttagsw.indexOf(from)
    nttagsw.splice(off, 1)
    fs.writeFileSync("./database/antitagsw.json", JSON.stringify(nttagsw))
    reply(`🔓 *Anti Tag has been deactivated in this group!*`)
    
  } else {
    reply(`⚙️ *Anti Tag Settings*\n\n` +
          `📌 Current status: ${Antitagsw ? '✅ ACTIVE' : '❌ INACTIVE'}\n\n` +
          `📝 *Usage:*\n` +
          `➤ ${prefix + command} on  - Activate anti tag\n` +
          `➤ ${prefix + command} off - Deactivate anti tag`)
  }
break
case 'antiswgc':
  if (!m.isGroup) return reply('⚠️ Fitur ini hanya untuk grup!')
  if (!isAdmins && !isCreator) return reply('👑 Khusus admin grup!')
  
  if (text === 'on') {
    if (Antiswgc) return reply('✅ Anti status grup sudah AKTIF!')
    antiswgc.push(m.chat)
    fs.writeFileSync('./database/antiswgc.json', JSON.stringify(antiswgc))
    reply('🔒 Anti status grup berhasil diAKTIFkan!')
  } 
  else if (text === 'off') {
    if (!Antiswgc) return reply('❌ Anti status grup sudah NONAKTIF!')
    const index = antiswgc.indexOf(m.chat)
    if (index !== -1) antiswgc.splice(index, 1)
    fs.writeFileSync('./database/antiswgc.json', JSON.stringify(antiswgc))
    reply('🔓 Anti status grup berhasil diNONAKTIFkan!')
  } 
  else {
    reply(`⚙️ *ANTI STATUS GRUP*\n\n` +
          `📌 Status: ${Antiswgc ? '✅ AKTIF' : '❌ NONAKTIF'}\n\n` +
          `📝 *Cara Penggunaan:*\n` +
          `➤ ${prefix + command} on - Aktifkan\n` +
          `➤ ${prefix + command} off - Nonaktifkan`)
  }
break
case 'owner':
case 'creator': {
    let list = []
    let owners = JSON.parse(fs.readFileSync('./database/owner.json'))
    
    // Kalo cuma 1 nama buat semua owner
    let ownerName = global.namaowner || 'Owner';
    
    for (let i of owners) {
        let num = i.split('@')[0]
        
        list.push({
            displayName: `${ownerName} (${num})`, // Biar beda
            vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${ownerName}\nFN:${ownerName}\nitem1.TEL;waid=${num}:${num}\nitem1.X-ABLabel:Ponsel\nitem2.EMAIL;type=INTERNET:okeae2410@gmail.com\nitem2.X-ABLabel:Email\nitem3.URL:https://instagram.com/stnic1_\nitem3.X-ABLabel:Instagram\nitem4.ADR:;;Indonesia;;;;\nitem4.X-ABLabel:Region\nEND:VCARD`
        })
    }
    
    satanic.sendMessage(m.chat, { 
        contacts: { 
            displayName: `👥 ${list.length} Owner`, 
            contacts: list 
        } 
    }, { quoted: fkontak })
}
break;

case 'owner3':
case 'creator3': {
    let list = []
    let owners = ["6283168758640", "6285658865882"]
    
    for (let i of owners) {
        list.push({
            displayName: await satanic.getName(i + '@s.whatsapp.net'),
            vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${await satanic.getName(i + '@s.whatsapp.net')}\nFN:${await satanic.getName(i + '@s.whatsapp.net')}\nitem1.TEL;waid=${i}:${i}\nitem1.X-ABLabel:Ponsel\nitem2.EMAIL;type=INTERNET:okeae2410@gmail.com\nitem2.X-ABLabel:Email\nitem3.URL:https://instagram.com/stnic1_\nitem3.X-ABLabel:Instagram\nitem4.ADR:;;Indonesia;;;;\nitem4.X-ABLabel:Region\nEND:VCARD`
        })
    }
    
    satanic.sendMessage(m.chat, { contacts: { displayName: `${list.length} Kontak`, contacts: list } }, { quoted: fkontak })
}
break;
case 'autoread':
  if (!isCreator) return reply(mess.owner)
  
  if (text === 'on') {
    global.autoread = true
    reply('✅ Auto read ON')
  } else if (text === 'off') {
    global.autoread = false
    reply('✅ Auto read OFF')
  } else {
    reply(`📱 Auto Read: ${global.autoreadsw ? 'ON' : 'OFF'}\n\nUse: .readsw on/off`)
  }
break
case 'autotyping':
  if (!isCreator) return reply(mess.owner)
  
  if (text === 'on') {
    global.autotyping = true
    reply('✅ Auto typing status ON')
  } else if (text === 'off') {
    global.autotyping = false
    reply('✅ Auto typing status OFF')
  } else {
    reply(`📱 Auto typing Status: ${global.typing ? 'ON' : 'OFF'}\n\nUse: .readsw on/off`)
  }
break
case 'onlygroup':
case 'onlygc':
    if (!isCreator) return reply('Fitur Khusus owner!')
    if (args.length < 1) return reply(`Contoh: ${prefix + command} on/off`)
    if (text == 'on') {
        global.onlygroup = true
        reply(`Successfully Changed Onlygroup To ${text}`)
    } else if (text == 'off') {
        global.onlygroup = false
        reply(`Successfully Changed Onlygroup To ${text}`)
    }
    break
case 'onlygrupprivate':
case 'onlygcprivate':
    if (!isCreator) return reply('Fitur Khusus owner!')
    if (args.length < 1) return reply(`Contoh: ${prefix + command} on/off`)
    if (text == 'on') {
        global.onlygrup = true
        reply(`Successfully Changed Onlygroup To ${text}`)
    } else if (text == 'off') {
        global.onlygrup = false
        reply(`Successfully Changed Onlygroup To ${text}`)
    }
    break
case 'onlyprivatechat':
case 'onlypc':
    if (!isCreator) return reply('Fitur Khusus owner!')
    if (args.length < 1) return reply(`Contoh: ${prefix + command} on/off`)
    if (text == 'on') {
        global.onlypc = true
        reply(`Successfully Changed Only-Pc To ${text}`)
    } else if (text == 'off') {
        global.onlypc = false
        reply(`Successfully Changed Only-Pc To ${text}`)
    }
    break
case 'addgb':           
case "addgroup": {
if (!isCreator) return
    const inputText = m.text.slice(prefix.length + command.length).trim();
    let groupId;
    if (!inputText && m.isGroup) {
        groupId = m.chat;
    } 
    else if (inputText) {
        groupId = inputText.split(' ')[0];
        if (!groupId.includes('@g.us')) {
            groupId = groupId + '@g.us';
        }
        groupId = groupId.replace(/[^0-9@.usg]/g, '').replace(/(.*?)@g\.us$/, '$1@g.us');
    }
    else {
        return reply(`Penggunaan:\n1. Di dalam grup: ${prefix + command}\n2. Di chat pribadi: ${prefix + command} <id_group>\nContoh: ${prefix + command} 718191010191@g.us`);
    }
    if (pgroup.includes(groupId)) {
        return reply(`❌ Grup dengan ID: ${groupId}\nSudah terdaftar sebagai grup premium!`);
    }
    pgroup.push(groupId);
    fs.writeFileSync("./database/groupadd.json", JSON.stringify(pgroup));
    reply(`✅ *Sukses Menambahkan Grup Premium!*\n┌  *ID Grup:* ${groupId}\n└  *Status:* Aktif Premium`);
}
break;
case 'delgb':
case "delgroup": {
if (!isCreator) return
    const inputText = m.text.slice(prefix.length + command.length).trim();
    let groupId;
    if ((inputText.toLowerCase() === 'me' || !inputText) && m.isGroup) {
        groupId = m.chat;
    }
    else if (inputText && inputText.toLowerCase() !== 'me') {
        groupId = inputText.split(' ')[0];
        if (!groupId.includes('@g.us')) {
            groupId = groupId + '@g.us';
        }
        groupId = groupId.replace(/[^0-9@.usg]/g, '').replace(/(.*?)@g\.us$/, '$1@g.us');
    }
    else {
        return reply(`Penggunaan:\n1. Di dalam grup: ${prefix + command} atau ${prefix + command} me\n2. Di chat pribadi: ${prefix + command} <id_group>\nContoh: ${prefix + command} 718191010191@g.us`);
    }
    if (!pgroup.includes(groupId)) {
        return reply(`❌ Grup dengan ID: ${groupId}\nTidak ditemukan dalam daftar premium!`);
    }
    const index = pgroup.indexOf(groupId);
    pgroup.splice(index, 1);
    fs.writeFileSync("./database/groupadd.json", JSON.stringify(pgroup));
    reply(`✅ *Sukses Menghapus Grup Premium!*\n┌  *ID Grup:* ${groupId}\n└  *Status:* Premium Dihapus`);
}
break;
case "addprem":
case "prem":
case "premium":
{
    if (!isCreator) {
        return reply(mess.owner);
    }
    if (!q) {
        return reply(`Use ${prefix + command} number\nContoh ${prefix + command} 6285813708397`);
    }
    premi = `${q.split("|")[0].replace(/[^0-9]/g, "")}@s.whatsapp.net`;
    let cekprem = await satanic.onWhatsApp(premi);
    if (cekprem.length == 0) {
        return reply(`Masukkan nomor yang valid dan terdaftar di WhatsApp!!!`);
    }
    premium.push(premi);
    fs.writeFileSync("./database/premium.json", JSON.stringify(premium));
    reply(`The Number ${premi} Has Been premium`);
}
break;
case "cekprem":
case "cekpremium":
{
    if (!q) {
        let cek = premium.includes(sender);
        reply(`Status: ${cek ? '✅ Premium' : '❌ Gratis'}`);
        break;
    }
    if (q === 'list') {
        if (!isCreator) return reply(mess.owner);
        if (premium.length === 0) return reply('Tidak ada user premium');
        let txt = '📋 LIST PREMIUM\n\n';
        premium.forEach((v, i) => txt += `${i+1}. ${v.split('@')[0]}\n`);
        return reply(txt);
    }
    let nomor = q.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    let cekUser = await satanic.onWhatsApp(nomor);
    if (!cekUser.length) return reply('Nomor tidak terdaftar di WhatsApp');
    let cek = premium.includes(nomor);
    reply(`📱 ${nomor.split('@')[0]}\nStatus: ${cek ? '✅ Premium' : '❌ Gratis'}`);
}
break;
case "listprem":
case "listpremium":
case "premlist":
{
    if (!isCreator) {
        return reply(mess.owner);
    }

    if (premium.length === 0) {
        return reply("⚠️ Tidak ada pengguna premium saat ini.");
    }

    let listMessage = `📋 *DAFTAR PENGGUNA PREMIUM*\n\n`;
    listMessage += `Total: *${premium.length}* user\n\n`;
    listMessage += `📱 *Nomor WhatsApp:*\n`;

    premium.forEach((user, index) => {
        let number = user.split("@")[0];
        listMessage += `${index + 1}. ${number}\n`;
    });

    reply(listMessage);
}
break;
case "delpremium":
case "delprem":
    if (!isCreator) {
        return reply(mess.owner);
    }
    if (!q) {
        return reply(`Use ${prefix + command} nomor\nContoh ${prefix + command} 6285813708397`);
    }
    yaprem = `${q.split("|")[0].replace(/[^0-9]/g, "")}@s.whatsapp.net`;
    unprem = premium.indexOf(yaprem);
    premium.splice(unprem, 1);
    fs.writeFileSync("./database/premium.json", JSON.stringify(premium));
    reply(`The Number ${ya} Has Been Removed premium!`);
    break;
    case 'autoreadsw':
  if (!isCreator) return reply(mess.owner)
  
  if (text === 'on') {
    global.autoreadsw = true
    reply('✅ Auto read status ON')
  } else if (text === 'off') {
    global.autoreadsw = false
    reply('✅ Auto read status OFF')
  } else {
    reply(`📱 Auto Read Status: ${global.autoreadsw ? 'ON' : 'OFF'}\n\nUse: .readsw on/off`)
  }
break
case "addowner":
{
    if (!isCreator) return reply(mess.owner);
    if (!q) return reply(`Use ${prefix + command} number\nContoh ${prefix + command} 6285813708397`);

    let ownerNum = `${q.split("|")[0].replace(/[^0-9]/g, "")}@s.whatsapp.net`;
    
    let cekOwner = await satanic.onWhatsApp(ownerNum);
    if (cekOwner.length == 0) {
        return reply(`Masukkan nomor yang valid dan terdaftar di WhatsApp!!!`);
    }
    
    if (owner.includes(ownerNum)) {
        return reply(`Nomor ${ownerNum.split("@")[0]} sudah menjadi owner!`);
    }
    
    owner.push(ownerNum);
    fs.writeFileSync("./database/owner.json", JSON.stringify(owner, null, 2));
    reply(`✅ Nomor ${ownerNum.split("@")[0]} telah ditambahkan sebagai owner.`);
}
break;

case "delowner":
case "deleteowner":
{
    if (!isCreator) return reply(mess.owner);
    if (!q) return reply(`Use ${prefix + command} number\nContoh ${prefix + command} 6285813708397`);

    let ownerNum = `${q.split("|")[0].replace(/[^0-9]/g, "")}@s.whatsapp.net`;
    
    let ownerIndex = owner.indexOf(ownerNum);
    if (ownerIndex === -1) {
        return reply(`Nomor ${ownerNum.split("@")[0]} tidak ditemukan dalam daftar owner!`);
    }
    
    owner.splice(ownerIndex, 1);
    fs.writeFileSync("./database/owner.json", JSON.stringify(owner, null, 2));
    reply(`❌ Nomor ${ownerNum.split("@")[0]} telah dihapus dari daftar owner.`);
}
break;

case "listowner":
case "listowners":
{
    if (!isCreator) return reply(mess.owner);
    
    if (owner.length === 0) {
        return reply("⚠️ Belum ada owner selain creator.");
    }
    
    let listMessage = `👑 *DAFTAR OWNER*\n\n`;
    listMessage += `Total: *${owner.length}* owner\n\n`;
    listMessage += `📱 *Nomor WhatsApp:*\n`;
    
    let mentions = [];
    owner.forEach((user, index) => {
        let number = user.split("@")[0];
        listMessage += `${index + 1}. @${number}\n`;
        mentions.push(user);
    });
    
    reply(listMessage, { withTag: true, mentions: mentions });
}
break;
 case 'autoreactsw':
  if (!isCreator) return reply(mess.owner)
  
  if (text === 'on') {
    global.autoreactsw = true
    reply('✅ Auto react status ON')
  } else if (text === 'off') {
    global.autoreactsw = false
    reply('✅ Auto react status OFF')
  } else {
    reply(`📱 Auto Read Status: ${global.autoreactsw ? 'ON' : 'OFF'}\n\nUse: .readsw on/off`)
  }
break
case "resetwarning":
case "resetwarn":
{
    if (!m.isGroup) return satanic.sendMessage(m.chat, { text: "❌ Perintah ini hanya untuk grup!" }, { quoted: fkontak });
    if (!isAdmins && !isOwner) return satanic.sendMessage(m.chat, { text: "❌ Perintah ini hanya untuk admin grup!" }, { quoted: fkontak });
    
    let warnData = {};
    try {
        warnData = JSON.parse(fs.readFileSync("./database/warning.json"));
    } catch (e) {
        warnData = {};
    }
    
    if (warnData[m.chat]) {
        delete warnData[m.chat];
        fs.writeFileSync("./database/warning.json", JSON.stringify(warnData, null, 2));
        satanic.sendMessage(m.chat, { text: "✅ Semua warning di grup ini telah direset!" }, { quoted: fkontak });
    } else {
        satanic.sendMessage(m.chat, { text: "❌ Tidak ada data warning di grup ini." }, { quoted: fkontak });
    }
}
break;
case "listwarning":
case "listwarn":
{
    if (!m.isGroup) return satanic.sendMessage(m.chat, { text: "❌ Perintah ini hanya untuk grup!" }, { quoted: fkontak });
    if (!isAdmins && !isCreator) return satanic.sendMessage(m.chat, { text: "❌ Perintah ini hanya untuk admin grup!" }, { quoted: fkontak });
    
    let warnData = {};
    try {
        warnData = JSON.parse(fs.readFileSync("./database/warning.json"));
    } catch (e) {
        warnData = {};
    }
    
    if (!warnData[m.chat] || Object.keys(warnData[m.chat]).length === 0) {
        return satanic.sendMessage(m.chat, { text: "✅ Tidak ada user yang memiliki warning di grup ini." }, { quoted: fkontak });
    }
    
    let teks = "📋 *DAFTAR WARNING GROUP* 📋\n\n";
    let no = 1;
    let mentions = [];
    
    // Urutkan dari warning terbanyak
    let sortedWarn = Object.entries(warnData[m.chat]).sort((a, b) => b[1] - a[1]);
    
    for (let [user, warn] of sortedWarn) {
        let progress = "";
        for (let i = 1; i <= 3; i++) {
            progress += i <= warn ? "⬛" : "⬜";
        }
        teks += `${no++}. @${user.split('@')[0]} : ${warn} warning ${progress}\n`;
        mentions.push(user);
    }
    
    teks += `\nTotal: ${sortedWarn.length} user terkena warning`;
    
    satanic.sendMessage(m.chat, { 
        text: teks,
        mentions: mentions
    }, { quoted: fkontak });
}
break;
case "cekwarning":
case "cekwarn":
{
    if (!m.isGroup) return satanic.sendMessage(m.chat, { text: "❌ Perintah ini hanya untuk grup!" }, { quoted: fkontak });
    
    let target = m.mentionedJid[0] ? m.mentionedJid[0] : (m.quoted ? m.quoted.sender : sender);
    
    let warnData = {};
    try {
        warnData = JSON.parse(fs.readFileSync("./database/warning.json"));
    } catch (e) {
        warnData = {};
    }
    
    let userWarn = warnData[m.chat]?.[target] || 0;
    
    // Buat progress bar visual
    let progress = "";
    for (let i = 1; i <= 3; i++) {
        progress += i <= userWarn ? "⬛" : "⬜";
    }
    
    let teks = `📊 *CEK WARNING* 📊\n\n`;
    teks += `○ *User* : @${target.split('@')[0]}\n`;
    teks += `○ *Warning* : ${userWarn} / 3\n`;
    teks += `○ *Progress* : ${progress}\n`;
    teks += `○ *Status* : ${userWarn >= 3 ? "🔴 AKAN DIKICK" : "🟢 AMAN"}`;
    
    satanic.sendMessage(m.chat, { 
        text: teks,
        mentions: [target]
    }, { quoted: fkontak });
}
break;
case "delwarning":
case "delwarn":
case "kurangiwarning":
{
    if (!m.isGroup) return satanic.sendMessage(m.chat, { text: "❌ Perintah ini hanya untuk grup!" }, { quoted: fkontak });
    if (!isAdmins && !isCreator) return satanic.sendMessage(m.chat, { text: "❌ Perintah ini hanya untuk admin grup!" }, { quoted: fkontak });
    
    let target = m.mentionedJid[0] ? m.mentionedJid[0] : (m.quoted ? m.quoted.sender : null);
    
    if (!target) {
        return satanic.sendMessage(m.chat, { 
            text: `❌ Tag atau reply pesan user yang ingin dikurangi warningnya!\nContoh: *${prefix + command}* @user` 
        }, { quoted: fkontak });
    }
    
    let warnData = {};
    try {
        warnData = JSON.parse(fs.readFileSync("./database/warning.json"));
    } catch (e) {
        warnData = {};
    }
    
    if (!warnData[m.chat] || !warnData[m.chat][target]) {
        return satanic.sendMessage(m.chat, { 
            text: `✅ User @${target.split('@')[0]} tidak memiliki warning.`,
            mentions: [target]
        }, { quoted: fkontak });
    }
    
    // Kurangi warning
    warnData[m.chat][target] -= 1;
    let sisaWarn = warnData[m.chat][target];
    
    // Hapus jika 0
    if (sisaWarn <= 0) {
        delete warnData[m.chat][target];
        
        // Hapus grup jika kosong
        if (Object.keys(warnData[m.chat]).length === 0) {
            delete warnData[m.chat];
        }
    }
    
    fs.writeFileSync("./database/warning.json", JSON.stringify(warnData, null, 2));
    
    let teks = `✅ *WARNING BERKURANG* ✅\n\n`;
    teks += `○ *User* : @${target.split('@')[0]}\n`;
    teks += `○ *Warning* : -1\n`;
    teks += `○ *Sisa* : ${sisaWarn || 0} warning`;
    
    satanic.sendMessage(m.chat, { 
        text: teks,
        mentions: [target]
    }, { quoted: fkontak });
}
break;
case "warning":
case "warn":
{
    if (!m.isGroup) return satanic.sendMessage(m.chat, { text: "❌ Perintah ini hanya untuk grup!" }, { quoted: fkontak });
    if (!isAdmins && !isCreator) return satanic.sendMessage(m.chat, { text: "❌ Perintah ini hanya untuk admin grup!" }, { quoted: fkontak });
    
    // Cek apakah ada yang di-tag atau reply
    let target = m.mentionedJid[0] ? m.mentionedJid[0] : (m.quoted ? m.quoted.sender : null);
    
    if (!target) {
        return satanic.sendMessage(m.chat, { 
            text: `❌ Tag atau reply pesan user yang ingin diberi warning!\nContoh: *${prefix + command}* @user alasan` 
        }, { quoted: fkontak });
    }
    
    // Ambil alasan (text setelah mention)
    let alasan = text.replace(new RegExp(`@${target.split('@')[0]}\\s*`), '').trim();
    alasan = alasan || "Tidak ada alasan";
    
    // Load data warning
    let warnData = {};
    try {
        warnData = JSON.parse(fs.readFileSync("./database/warning.json"));
    } catch (e) {
        warnData = {};
    }
    
    // Inisialisasi grup jika belum ada
    if (!warnData[m.chat]) {
        warnData[m.chat] = {};
    }
    
    // Inisialisasi user jika belum ada
    if (!warnData[m.chat][target]) {
        warnData[m.chat][target] = 0;
    }
    
    // Tambah warning
    warnData[m.chat][target] += 1;
    let currentWarn = warnData[m.chat][target];
    
    // Simpan ke file
    fs.writeFileSync("./database/warning.json", JSON.stringify(warnData, null, 2));
    
    // Kirim notifikasi
    let teks = `⚠️ *WARNING SYSTEM* ⚠️\n\n`;
    teks += `┌  ○ *User* : @${target.split('@')[0]}\n`;
    teks += `│  ○ *Warning* : +1\n`;
    teks += `│  ○ *Total* : ${currentWarn} warning\n`;
    teks += `│  ○ *Alasan* : ${alasan}\n`;
    teks += `│  ○ *Admin* : @${sender.split('@')[0]}\n`;
    teks += `└  ○ *Batas* : 3 warning = kick\n\n`;
    
    // Cek jika warning mencapai batas (3)
    let batasWarn = 3;
    if (currentWarn >= batasWarn) {
        teks += `⚠️ *PERHATIAN!*\n`;
        teks += `User @${target.split('@')[0]} telah mencapai ${batasWarn} warning!\n`;
        teks += `🔴 *Tindakan: Dikeluarkan dari grup!*\n\n`;
        
        // Hapus data user
        delete warnData[m.chat][target];
        
        // Hapus grup jika kosong
        if (Object.keys(warnData[m.chat]).length === 0) {
            delete warnData[m.chat];
        }
        
        fs.writeFileSync("./database/warning.json", JSON.stringify(warnData, null, 2));
        
        // Kirim pesan sebelum kick
        await satanic.sendMessage(m.chat, { 
            text: teks,
            mentions: [target, sender]
        }, { quoted: fkontak });
        
        // Kick user dari grup
        setTimeout(async () => {
            await satanic.groupParticipantsUpdate(m.chat, [target], "remove");
        }, 2000);
    } else {
        // Kirim notifikasi biasa
        await satanic.sendMessage(m.chat, { 
            text: teks,
            mentions: [target, sender]
        }, { quoted: fkontak });
    }
}
break;
case 'addbadword': {
  if (!isCreator && !isAdmins) return reply('👑 Khusus admin/owner!')
  if (!text) return reply(`⚠️ Masukkan kata yang ingin ditambahkan!\n\nContoh: ${prefix + command} tolol`)
  
  let badwordList = []
  try {
    if (fs.existsSync("./database/badword.json")) {
      badwordList = JSON.parse(fs.readFileSync("./database/badword.json"))
    } else {
      fs.writeFileSync("./database/badword.json", "[]")
    }
  } catch (e) {
    badwordList = []
    fs.writeFileSync("./database/badword.json", "[]")
  }
  
  const word = text.toLowerCase().trim()
  
  if (!badwordList.includes(word)) {
    badwordList.push(word)
    fs.writeFileSync("./database/badword.json", JSON.stringify(badwordList, null, 2))
    reply(`✅ Badword *"${word}"* berhasil ditambahkan!\n\nTotal badword: ${badwordList.length}`)
  } else {
    reply(`❌ Badword *"${word}"* sudah ada dalam daftar!`)
  }
}
break
case 'listbadword': {
  if (!isCreator && !isAdmins) return reply('👑 Khusus admin/owner!')
  
  let badwordList = []
  try {
    if (fs.existsSync("./database/badword.json")) {
      badwordList = JSON.parse(fs.readFileSync("./database/badword.json"))
    }
  } catch (e) {}
  
  if (badwordList.length === 0) return reply('📋 Daftar badword kosong!')
  
  let teks = `📋 *DAFTAR BADWORD*\n\n`
  teks += `Total: ${badwordList.length} kata\n\n`
  
  for (let i = 0; i < badwordList.length; i++) {
    teks += `${i + 1}. ${badwordList[i]}\n`
  }
  
  reply(teks)
}
break

// ==================== DELETE BADWORD ====================
case 'delbadword': {
  if (!isCreator && !isAdmins) return reply('👑 Khusus admin/owner!')
  if (!text) return reply(`⚠️ Masukkan kata yang ingin dihapus!\n\nContoh: ${prefix + command} tolol`)
  
  let badwordList = []
  try {
    if (fs.existsSync("./database/badword.json")) {
      badwordList = JSON.parse(fs.readFileSync("./database/badword.json"))
    } else {
      return reply('📋 Daftar badword masih kosong!')
    }
  } catch (e) {
    return reply('📋 Daftar badword masih kosong!')
  }
  
  const word = text.toLowerCase().trim()
  const index = badwordList.indexOf(word)
  
  if (index !== -1) {
    badwordList.splice(index, 1)
    fs.writeFileSync("./database/badword.json", JSON.stringify(badwordList, null, 2))
    reply(`✅ Badword *"${word}"* berhasil dihapus!\n\nSisa badword: ${badwordList.length}`)
  } else {
    reply(`❌ Badword *"${word}"* tidak ditemukan!`)
  }
}
break

// ==================== ANTIBADWORD ON/OFF ====================
case 'cekbad': {
  const badwordList = getBadwordList()
  const teks = m.body ? m.body.toLowerCase() : ''
  const found = badwordList.some(k => teks.includes(k.toLowerCase()))
  reply(`Pesan: "${m.body}"\nBadword: ${found ? '✅ TERDETEKSI' : '❌ TIDAK'}`)
}
break
case 'antibadword': {
  if (!isCreator && !isAdmins) return reply('👑 Khusus admin/owner!')
  if (!m.isGroup) return reply('⚠️ Perintah ini hanya untuk grup!')
  if (!text) return reply(`⚠️ Gunakan: ${prefix + command} on/off`)
  
  let data = {}
  if (fs.existsSync("./database/antibadword.json")) {
    data = JSON.parse(fs.readFileSync("./database/antibadword.json"))
  }
  
  const option = text.toLowerCase().trim()
  
  if (option === 'on') {
    data[m.chat] = true
    fs.writeFileSync("./database/antibadword.json", JSON.stringify(data, null, 2))
    reply('✅ AntiBadword AKTIF untuk grup ini!')
  } else if (option === 'off') {
    data[m.chat] = false
    fs.writeFileSync("./database/antibadword.json", JSON.stringify(data, null, 2))
    reply('❌ AntiBadword NONAKTIF untuk grup ini!')
  } else {
    reply(`⚠️ Pilihan salah! Gunakan: ${prefix + command} on/off`)
  }
}
break
case 'antionce': {
    if (!m.isGroup) return reply('Fitur Khusus Group!!!')
    if (!isAdmins && !isCreator) return reply('Fitur Khusus admin!')
    
    if (!text) {
        const status = global.db.chats[m.chat].antionce ? '✅ Aktif' : '❌ Nonaktif'
        return reply(`*ANTI VIEW ONCE*\n\nStatus: ${status}\n\nUsage:\n${prefix + command} on - Mengaktifkan\n${prefix + command} off - Menonaktifkan`)
    }
    
    if (text === 'on') {
        global.db.chats[m.chat].antionce = true
        reply('✅ *ANTI VIEW ONCE* telah diaktifkan!\n\nPesan view once yang dikirim akan otomatis diunduh.')
    } else if (text === 'off') {
        global.db.chats[m.chat].antionce = false
        reply('❌ *ANTI VIEW ONCE* telah dinonaktifkan.')
    } else {
        reply(`Command salah!\n\nGunakan:\n${prefix + command} on - Aktifkan\n${prefix + command} off - Nonaktifkan`)
    }
}
break
case 'welcome':
    if (!m.isGroup) return reply('Fitur Khusus Group!!!')
    if (!isAdmins && !isCreator) return reply('Fitur Khusus admin!')
    
    if (!global.db.chats[m.chat]) global.db.chats[m.chat] = {}
    
    if (args[0] === 'on') {
        global.db.chats[m.chat].welcome = true
        reply('✅ Welcome DIACTIVEKAN')
    } else if (args[0] === 'off') {
        global.db.chats[m.chat].welcome = false
        reply('❌ Welcome DINONACTIVEKAN')
    } else {
        const status = global.db.chats[m.chat].welcome ? '✅ AKTIF' : '❌ NONAKTIF'
        reply(`*STATUS WELCOME:* ${status}\n\n!welcome on - Aktifkan\n!welcome off - Nonaktifkan`)
    }
    break
    case 'leave':
    case 'left':
    if (!m.isGroup) return reply('Fitur Khusus Group!!!')
    if (!isAdmins && !isCreator) return reply('Fitur Khusus admin!')
    
    if (!global.db.chats[m.chat]) global.db.chats[m.chat] = {}
    if (args[0] === 'on') {
        global.db.chats[m.chat].left = true
        reply('✅ Left DIACTIVEKAN')
    } else if (args[0] === 'off') {
        global.db.chats[m.chat].left = false
        reply('❌ Left DINONACTIVEKAN')
    } else {
        const status = global.db.chats[m.chat].left ? '✅ AKTIF' : '❌ NONAKTIF'
        reply(`*STATUS LEFT:* ${status}\n\n!left on - Aktifkan\n!left off - Nonaktifkan`)
    }
    break
// ==================== SET WELCOME TEXT ====================
case 'setwelcometext': {
    if (!m.isGroup) return reply('Fitur Khusus Group!!!')
    if (!isAdmins && !isCreator) return reply('Fitur Khusus admin!')
    if (!text) return reply(`Example: ${prefix + command} Welcome @user\n\n@user - tag user\n@subject - group name\n@desc - group description\n@date - date`)
    global.db.chats[m.chat].setWelcome = text
    reply(`✅ Welcome Text berhasil diubah!\n📝 Teks: ${text}`)
}
break

// ==================== SET LEFT TEXT ====================
case 'setlefttext': {
    if (!m.isGroup) return reply('Fitur Khusus Group!!!')
    if (!isAdmins && !isCreator) return reply('Fitur Khusus admin!')
    if (!text) return reply(`Example: ${prefix + command} Goodbye @user\n\n@user - tag user\n@subject - group name\n@desc - group description\n@date - date`)
    global.db.chats[m.chat].setLeft = text
    reply(`✅ Left Text berhasil diubah!\n📝 Teks: ${text}`)
}
break

// ==================== SET WELCOME IMAGE ====================
case 'setwelcomeimage': {
    if (!m.isGroup) return reply('Fitur Khusus Group!!!')
    if (!isAdmins && !isCreator) return reply('Fitur Khusus admin!')
    
    const quoted = m.quoted ? m.quoted : m
    const mime = (quoted.msg || quoted).mimetype || ''
    
    if (!/image/.test(mime)) return reply('Reply gambar dengan command ini!')
    
    try {
        let mediaFile = await satanic.downloadAndSaveMediaMessage(quoted)
        const mediaBuffer = fs.readFileSync(mediaFile)
        const form = new FormData()
        form.append('files[]', mediaBuffer, { filename: 'welcome.jpg' })
        const uploadRes = await axios.post('https://pone.rs/upload.php', form, {
            headers: { ...form.getHeaders(), 'User-Agent': 'Mozilla/5.0' },
            maxBodyLength: Infinity,
            maxContentLength: Infinity
        })
        
        if (!uploadRes.data?.success || !uploadRes.data?.files?.[0]?.url) {
            return reply("❌ Gagal upload gambar!")
        }
        
        let url = uploadRes.data.files[0].url.replace(/\\\//g, '/')
        fs.unlinkSync(mediaFile)
        
        global.db.chats[m.chat].welcomeSetting = { type: 'image', url: url }
        reply(`✅ Welcome Image berhasil diubah!\n📸 URL: ${url}`)
    } catch (err) {
        reply("❌ Error: " + err.message)
    }
}
break

// ==================== SET WELCOME VIDEO ====================
case 'setwelcomevideo': {
    if (!m.isGroup) return reply('Fitur Khusus Group!!!')
    if (!isAdmins && !isCreator) return reply('Fitur Khusus admin!')
    
    const quoted = m.quoted ? m.quoted : m
    const mime = (quoted.msg || quoted).mimetype || ''
    
    if (!/video/.test(mime)) return reply('Reply video dengan command ini!')
    
    try {
        let mediaFile = await satanic.downloadAndSaveMediaMessage(quoted)
        const mediaBuffer = fs.readFileSync(mediaFile)
        const form = new FormData()
        const ext = mime.split('/')[1] || 'mp4'
        form.append('files[]', mediaBuffer, { filename: `welcome.${ext}` })
        const uploadRes = await axios.post('https://pone.rs/upload.php', form, {
            headers: { ...form.getHeaders(), 'User-Agent': 'Mozilla/5.0' },
            maxBodyLength: Infinity,
            maxContentLength: Infinity
        })
        
        if (!uploadRes.data?.success || !uploadRes.data?.files?.[0]?.url) {
            return reply("❌ Gagal upload video!")
        }
        
        let url = uploadRes.data.files[0].url.replace(/\\\//g, '/')
        fs.unlinkSync(mediaFile)
        
        global.db.chats[m.chat].welcomeSetting = { type: 'video', url: url }
        reply(`✅ Welcome Video berhasil diubah!\n🎬 URL: ${url}`)
    } catch (err) {
        reply("❌ Error: " + err.message)
    }
}
break

// ==================== SET LEFT IMAGE ====================
case 'setleftimage': {
    if (!m.isGroup) return reply('Fitur Khusus Group!!!')
    if (!isAdmins && !isCreator) return reply('Fitur Khusus admin!')
    
    const quoted = m.quoted ? m.quoted : m
    const mime = (quoted.msg || quoted).mimetype || ''
    
    if (!/image/.test(mime)) return reply('Reply gambar dengan command ini!')
    
    try {
        let mediaFile = await satanic.downloadAndSaveMediaMessage(quoted)
        const mediaBuffer = fs.readFileSync(mediaFile)
        const form = new FormData()
        form.append('files[]', mediaBuffer, { filename: 'left.jpg' })
        const uploadRes = await axios.post('https://pone.rs/upload.php', form, {
            headers: { ...form.getHeaders(), 'User-Agent': 'Mozilla/5.0' },
            maxBodyLength: Infinity,
            maxContentLength: Infinity
        })
        
        if (!uploadRes.data?.success || !uploadRes.data?.files?.[0]?.url) {
            return reply("❌ Gagal upload gambar!")
        }
        
        let url = uploadRes.data.files[0].url.replace(/\\\//g, '/')
        fs.unlinkSync(mediaFile)
        
        global.db.chats[m.chat].leftSetting = { type: 'image', url: url }
        reply(`✅ Left Image berhasil diubah!\n📸 URL: ${url}`)
    } catch (err) {
        reply("❌ Error: " + err.message)
    }
}
break

// ==================== SET LEFT VIDEO ====================
case 'setleftvideo': {
    if (!m.isGroup) return reply('Fitur Khusus Group!!!')
    if (!isAdmins && !isCreator) return reply('Fitur Khusus admin!')
    
    const quoted = m.quoted ? m.quoted : m
    const mime = (quoted.msg || quoted).mimetype || ''
    
    if (!/video/.test(mime)) return reply('Reply video dengan command ini!')
    
    try {
        let mediaFile = await satanic.downloadAndSaveMediaMessage(quoted)
        const mediaBuffer = fs.readFileSync(mediaFile)
        const form = new FormData()
        const ext = mime.split('/')[1] || 'mp4'
        form.append('files[]', mediaBuffer, { filename: `left.${ext}` })
        const uploadRes = await axios.post('https://pone.rs/upload.php', form, {
            headers: { ...form.getHeaders(), 'User-Agent': 'Mozilla/5.0' },
            maxBodyLength: Infinity,
            maxContentLength: Infinity
        })
        
        if (!uploadRes.data?.success || !uploadRes.data?.files?.[0]?.url) {
            return reply("❌ Gagal upload video!")
        }
        
        let url = uploadRes.data.files[0].url.replace(/\\\//g, '/')
        fs.unlinkSync(mediaFile)
        
        global.db.chats[m.chat].leftSetting = { type: 'video', url: url }
        reply(`✅ Left Video berhasil diubah!\n🎬 URL: ${url}`)
    } catch (err) {
        reply("❌ Error: " + err.message)
    }
}
break

// ==================== SET WELCOME TYPE ====================
case 'setwelcometype': {
    if (!m.isGroup) return reply('Fitur Khusus Group!!!')
    if (!isAdmins && !isCreator) return reply('Fitur Khusus admin!')
    if (!text) return reply(`Pilih type:\n${prefix + command} image\n${prefix + command} video`)
    
    const type = text.toLowerCase()
    if (type !== 'image' && type !== 'video') {
        return reply('❌ Pilihan salah! Gunakan: image atau video')
    }
    
    let setting = global.db.chats[m.chat].welcomeSetting || {}
    if (!setting.url) {
        setting.url = type === 'video' ? global.welcomeVideo : global.welcomeImage
    }
    setting.type = type
    global.db.chats[m.chat].welcomeSetting = setting
    reply(`✅ Welcome type berubah ke: ${type.toUpperCase()}`)
}
break

// ==================== SET LEFT TYPE ====================
case 'setlefttype': {
    if (!m.isGroup) return reply('Fitur Khusus Group!!!')
    if (!isAdmins && !isCreator) return reply('Fitur Khusus admin!')
    if (!text) return reply(`Pilih type:\n${prefix + command} image\n${prefix + command} video`)
    
    const type = text.toLowerCase()
    if (type !== 'image' && type !== 'video') {
        return reply('❌ Pilihan salah! Gunakan: image atau video')
    }
    
    let setting = global.db.chats[m.chat].leftSetting || {}
    if (!setting.url) {
        setting.url = type === 'video' ? global.leftVideo : global.leftImage
    }
    setting.type = type
    global.db.chats[m.chat].leftSetting = setting
    reply(`✅ Left type berubah ke: ${type.toUpperCase()}`)
}
break

// ==================== RESET WELCOME ====================
case 'resetwelcome': {
    if (!m.isGroup) return reply('Fitur Khusus Group!!!')
    if (!isAdmins && !isCreator) return reply('Fitur Khusus admin!')
    delete global.db.chats[m.chat].setWelcome
    delete global.db.chats[m.chat].welcomeSetting
    reply('✅ Welcome reset ke default global')
}
break

// ==================== RESET LEFT ====================
case 'resetleft': {
    if (!m.isGroup) return reply('Fitur Khusus Group!!!')
    if (!isAdmins && !isCreator) return reply('Fitur Khusus admin!')
    delete global.db.chats[m.chat].setLeft
    delete global.db.chats[m.chat].leftSetting
    reply('✅ Left reset ke default global')
}
break
case 'delsetwelcome': {
    if (!m.isGroup) return reply('Fitur Khusus Group!!!')
    if (!isAdmins && !isCreator) return reply('Fitur Khusus admin!')
    delete global.db.chats[m.chat].setWelcome
    reply(`Berhasil menghapus custom welcome message. Sekarang akan menggunakan default.`)
}
break

case 'delsetleft': {
    if (!m.isGroup) return reply('Fitur Khusus Group!!!')
    if (!isAdmins && !isCreator) return reply('Fitur Khusus admin!')
    delete global.db.chats[m.chat].setLeft
    reply(`Berhasil menghapus custom left message. Sekarang akan menggunakan default.`)
}
break
case 'ban':
  if (!isCreator && !isAdmins) return reply('👑 Khusus admin/owner!')
  
  let target = null
  
  if (m.quoted) {
    target = m.quoted.sender
  } else if (m.mentionedJid && m.mentionedJid.length > 0) {
    target = m.mentionedJid[0]
  } else if (text) {
    const nomor = text.replace(/[^0-9]/g, '')
    target = nomor + '@s.whatsapp.net'
  } else {
    return reply(`⚠️ Tag, reply, atau masukkan nomor user yang ingin di-ban!\n\nContoh: ${prefix + command} @user`)
  }
  
  if (target === botNumber) return reply('❌ Tidak bisa memban bot sendiri!')
  if (target === m.sender) return reply('❌ Tidak bisa memban diri sendiri!')
  
  if (!bannedList.includes(target)) {
    bannedList.push(target)
    fs.writeFileSync("./database/banuser.json", JSON.stringify(bannedList))
    reply(`✅ *User berhasil di-ban!*\n\n🚫 @${target.split('@')[0]} tidak dapat menggunakan perintah bot lagi.`, { mentions: [target] })
  } else {
    reply(`❌ User sudah dalam daftar ban!`)
  }
break
case 'unban':
  if (!isCreator && !isAdmins) return reply('👑 Khusus admin/owner!')
  
  let targetUnban = null
  
  if (m.quoted) {
    targetUnban = m.quoted.sender
  } else if (m.mentionedJid && m.mentionedJid.length > 0) {
    targetUnban = m.mentionedJid[0]
  } else if (text) {
    const nomor = text.replace(/[^0-9]/g, '')
    targetUnban = nomor + '@s.whatsapp.net'
  } else {
    return reply(`⚠️ Tag, reply, atau masukkan nomor user yang ingin di-unban!\n\nContoh: .unban 628xxx`)
  }
  
  const index = bannedList.indexOf(targetUnban)
  if (index !== -1) {
    bannedList.splice(index, 1)
    fs.writeFileSync("./database/banuser.json", JSON.stringify(bannedList))
    reply(`✅ *User berhasil di-unban!*\n\n✅ @${targetUnban.split('@')[0]} sekarang dapat menggunakan perintah bot lagi.`, { mentions: [targetUnban] })
  } else {
    reply(`❌ User tidak ditemukan dalam daftar ban!`)
  }
break
case 'listban':
  if (!isCreator && !isAdmins) return reply('👑 Khusus admin/owner!')
  
  if (bannedList.length === 0) {
    reply(`📋 *Daftar Ban*\n\nTidak ada user yang di-ban.`)
  } else {
    let text = `📋 *Daftar User yang Di-Ban*\n\n`
    for (let user of bannedList) {
      text += `👤 @${user.split('@')[0]}\n`
    }
    text += `\n📊 Total: ${bannedList.length} user`
    reply(text, { mentions: bannedList })
  }
break

case 'upswgc':          
 case "swgroup":
case "swgc": {
if (!m.isGroup) return reply(mess.group);
  if (!isAdmins && !isCreator) return reply(mess.admin);

    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || "";

    const body = m.body || "";
    const caption = body
        .replace(new RegExp(`^\\${prefix}${command}\\s*`, "i"), "")
        .trim();

    const jid = m.chat;

    if (/image/.test(mime)) {
        const buffer = await quoted.download();
        await satanic.sendMessage(jid, {
            groupStatusMessage: {
                image: buffer,
                caption
            }
        });
        satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key }})

    } else if (/video/.test(mime)) {
        const buffer = await quoted.download();
        await satanic.sendMessage(jid, {
            groupStatusMessage: {
                video: buffer,
                caption
            }
        });
        satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key }})

    } else if (/audio/.test(mime)) {
        const buffer = await quoted.download();
        await satanic.sendMessage(jid, {
            groupStatusMessage: {
                audio: buffer
            }
        });
        satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key }})

    } else if (caption) {
        await satanic.sendMessage(jid, {
            groupStatusMessage: {
                text: caption
            }
        });
        satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key }})

    } else {
        await reply(
            `Contoh penggunaan:\n` +
            `${prefix + command} halo gais\n` +
            `atau reply media dengan caption`
        );
    }
}
break;

case 'jadwalsholat': {
  let jadwal = `
📅 *JADWAL SHOLAT HARI INI*
━━━━━━━━━━━━━━━━━━
🌙 *Shubuh*: 04:30 WIB
☀️ *Terbit*: 05:44 WIB
🌅 *Dhuha*: 06:16 WIB
🍽️ *Dzuhur*: 12:00 WIB
⌛ *Ashar*: 15:30 WIB
🌇 *Magrib*: 18:00 WIB
🌙 *Isya*: 19:30 WIB
━━━━━━━━━━━━━━━━━━
📢 *AutoSholat aktif akan mengirim notifikasi otomatis*
🕌 *Tetap jaga sholat 5 waktu!*
  `;
  reply(jadwal);
  break;
}
case 'setfitur': {
    if (!isAdmins && !isCreator) return reply('⚠️ *Akses ditolak!*\nHanya admin grup.');
    
    
    if (!args[0]) {
        const status = getMemberStatus(m.chat) ? '✅ Aktif' : '❌ Nonaktif';
        const features = getMemberFeatures(m.chat);
        return reply(`📌 *Fitur Member*\nStatus: ${status}\nFitur: ${features.join(', ')}\n\n📝 Command:\n.setfitur on/off\n.setfitur add [fitur]\n.setfitur del [fitur]\n.setfitur list\n.setfitur reset`);
    }
    
    let sub = args[0].toLowerCase();
    
    if (sub === 'on') {
        setMemberStatus(m.chat, true);
        reply('✅ *Fitur member AKTIF*');
    }
    else if (sub === 'off') {
        setMemberStatus(m.chat, false);
        reply('❌ *Fitur member NONAKTIF*');
    }
    else if (sub === 'add') {
        if (!args[1]) return reply('⚠️ Masukkan fitur!\nContoh: .setfitur add done');
        let fitur = args[1].toLowerCase();
        if (addMemberFeature(m.chat, fitur)) {
            reply(`✅ "${fitur}" ditambahkan!\nFitur: ${getMemberFeatures(m.chat).join(', ')}`);
        } else {
            reply(`⚠️ "${fitur}" sudah ada.`);
        }
    }
    else if (sub === 'del' || sub === 'remove') {
        if (!args[1]) return reply('⚠️ Masukkan fitur!\nContoh: .setfitur del done');
        let fitur = args[1].toLowerCase();
        if (removeMemberFeature(m.chat, fitur)) {
            reply(`✅ "${fitur}" dihapus!\nFitur: ${getMemberFeatures(m.chat).join(', ')}`);
        } else {
            reply(`⚠️ "${fitur}" tidak ditemukan.`);
        }
    }
    else if (sub === 'list' || sub === 'lihat') {
        const status = getMemberStatus(m.chat) ? '✅ Aktif' : '❌ Nonaktif';
        const features = getMemberFeatures(m.chat);
        reply(`📌 *Fitur Member*\nStatus: ${status}\nFitur: ${features.join(', ')}\nTotal: ${features.length} fitur`);
    }
    else if (sub === 'reset') {
        if (global.db.settings.memberFeatures[m.chat]) {
            global.db.settings.memberFeatures[m.chat].features = [...defaultFeatures];
            global.db.settings.memberFeatures[m.chat].status = true;
            reply(`✅ Reset ke default!\nFitur: ${defaultFeatures.join(', ')}`);
        } else {
            reply('⚠️ Belum ada setting.');
        }
    }
    else {
        reply(`⚠️ Command salah!\n.setfitur on/off\n.setfitur add/del [fitur]\n.setfitur list\n.setfitur reset`);
    }
    break;
}
case 'addautogc':
case 'autogroup': {
    let chatsjb = global.db.chats[m.chat];
    
    if (!args[0]) {
        return reply(`⚠️ *Command tidak valid!*\n\n📝 Cara penggunaan:\n\n1. Setting jam:\n.autogroup set [buka] [tutup]\nContoh: .autogroup set 05:00 23:00\n\n2. Setting pesan custom:\n.autogroup setpesan buka [pesan]\n.autogroup setpesan tutup [pesan]\n\n3. Aktif/Nonaktif:\n.autogroup on\n.autogroup off\n\n4. Lihat status:\n.autogroup status\n.autogroup list\n.autogroup info`);
    }

    let arg = args.join(' ').trim();
    let subCommand = args[0]?.toLowerCase();

    if (subCommand === 'set') {
        if (!args[1] || !args[2]) {
            return reply('⚠️ Format salah!\n\nGunakan: `.autogroup set [jam_buka] [jam_tutup]`\nContoh: `.autogroup set 05:00 23:00`\n\nAtau: `.autogroup set 05:00|23:00`');
        }

        let openTime, closeTime;
        
        if (args[1].includes('|')) {
            [openTime, closeTime] = args[1].split('|').map(v => v.trim());
        } else {
            openTime = args[1];
            closeTime = args[2];
        }

        if (!/^([01]?\d|2[0-3]):[0-5]\d$/.test(openTime) || !/^([01]?\d|2[0-3]):[0-5]\d$/.test(closeTime)) {
            return reply('⚠️ Format waktu salah! Gunakan format HH:MM\nContoh: `.autogroup set 05:00 23:00`');
        }

        let [openHour, openMinute] = openTime.split(':').map(Number);
        let [closeHour, closeMinute] = closeTime.split(':').map(Number);

        if (!chatsjb.security) {
            chatsjb.security = {
                closeHour: closeHour,
                closeMinute: closeMinute,
                openHour: openHour,
                openMinute: openMinute,
                closeMsg: `🌙 Grup ditutup otomatis jam ${pad(closeHour)}:${pad(closeMinute)} WIB oleh sistem AutoGroup.`,
                openMsg: `🌅 Grup dibuka otomatis jam ${pad(openHour)}:${pad(openMinute)} WIB oleh sistem AutoGroup.`
            };
        } else {
            chatsjb.security.closeHour = closeHour;
            chatsjb.security.closeMinute = closeMinute;
            chatsjb.security.openHour = openHour;
            chatsjb.security.openMinute = openMinute;
        }

        chatsjb.lastSecurityAction = null;
        
        if (!global.autogroup[m.chat]) {
            global.autogroup[m.chat] = true;
        }

        reply(`✅ *Jam berhasil diatur!*\n\n📅 Jadwal:\n🌅 Buka: ${pad(openHour)}:${pad(openMinute)} WIB\n🌙 Tutup: ${pad(closeHour)}:${pad(closeMinute)} WIB\n\n📝 Pesan buka: ${chatsjb.security.openMsg}\n📝 Pesan tutup: ${chatsjb.security.closeMsg}\n\n🔄 AutoGroup otomatis aktif!`);
        console.log(`⏰ Set jam AutoGroup: ${m.chat} | Buka ${openTime} | Tutup ${closeTime}`);
    }

    else if (subCommand === 'setpesan' || subCommand === 'setmsg') {
        if (!args[1] || !args[2]) {
            return reply('⚠️ Format salah!\n\nGunakan:\n.autogroup setpesan buka [pesan]\n.autogroup setpesan tutup [pesan]\n\nContoh:\n.autogroup setpesan buka Selamat pagi! Grup dibuka.\n.autogroup setpesan tutup Selamat malam! Grup ditutup.');
        }

        let type = args[1].toLowerCase();
        let message = args.slice(2).join(' ');

        if (!chatsjb.security) {
            return reply('⚠️ Atur jam dulu dengan `.autogroup set 05:00 23:00`');
        }

        if (type === 'buka' || type === 'open') {
            chatsjb.security.openMsg = message;
            reply(`✅ *Pesan buka diubah!*\n\n📝 Pesan baru:\n${message}`);
        } else if (type === 'tutup' || type === 'close') {
            chatsjb.security.closeMsg = message;
            reply(`✅ *Pesan tutup diubah!*\n\n📝 Pesan baru:\n${message}`);
        } else {
            reply('⚠️ Pilihan tidak valid!\nGunakan: `buka` atau `tutup`\nContoh: `.autogroup setpesan buka Selamat pagi!`');
        }
    }

    else if (subCommand === 'on') {
        if (!chatsjb.security) {
            chatsjb.security = {
                closeHour: 1,
                closeMinute: 0,
                openHour: 5,
                openMinute: 0,
                closeMsg: '🌙 *Grup Ditutup*\n\nGrup akan dibuka kembali jam 05:00 pagi. Silahkan istirahat! 🥱',
                openMsg: '🌅 *Grup Dibuka*\n\nSelamat pagi! Grup sudah dibuka. Silahkan beraktivitas kembali! ☀️'
            };
            chatsjb.lastSecurityAction = null;
        }
        
        global.autogroup[m.chat] = true;
        reply(`✅ *AutoGroup AKTIF*\n\n📌 Jadwal:\n🌅 Buka: ${pad(chatsjb.security.openHour)}:${pad(chatsjb.security.openMinute)} WIB\n🌙 Tutup: ${pad(chatsjb.security.closeHour)}:${pad(chatsjb.security.closeMinute)} WIB\n\n🔄 Berulang setiap hari`);
        console.log(`➕ AutoGroup ON: ${m.chat}`);
    }

    else if (subCommand === 'off') {
        delete global.autogroup[m.chat];
        reply('❌ *AutoGroup NONAKTIF*');
        console.log(`➖ AutoGroup OFF: ${m.chat}`);
    }

    else if (subCommand === 'list') {
        const list = Object.keys(global.autogroup || {});
        if (list.length === 0) {
            reply('📋 Belum ada grup yang aktif');
        } else {
            let text = '📋 *Daftar Grup AutoGroup:*\n\n';
            list.forEach((id, i) => {
                const chatData = global.db.chats[id];
                const setting = chatData?.security;
                let status = '⏳ Menunggu setting';
                if (setting) {
                    status = `🌅 ${pad(setting.openHour)}:${pad(setting.openMinute)} | 🌙 ${pad(setting.closeHour)}:${pad(setting.closeMinute)}`;
                }
                text += `${i+1}. ${id}\n   ⏰ ${status}\n`;
            });
            text += `\nTotal: ${list.length} grup`;
            reply(text);
        }
    }

    else if (subCommand === 'status') {
        if (!chatsjb.security) {
            return reply('⚠️ Security belum diaktifkan.\n\nGunakan:\n.autogroup set 05:00 23:00 - Setting jam\n.autogroup on - Aktifkan dengan default');
        }
        
        const isActive = global.autogroup[m.chat] ? '✅ Aktif' : '❌ Nonaktif';
        let { closeHour, closeMinute, openHour, openMinute, closeMsg, openMsg } = chatsjb.security;
        return reply(`📌 *Status AutoGroup*\n\n${isActive}\n\n📅 Jadwal:\n🌅 Buka: ${pad(openHour)}:${pad(openMinute)} WIB\n🌙 Tutup: ${pad(closeHour)}:${pad(closeMinute)} WIB\n\n📝 Pesan buka: ${openMsg || 'default'}\n📝 Pesan tutup: ${closeMsg || 'default'}`);
    }

    else if (subCommand === 'info') {
        reply(`📌 *Info AutoGroup*\n\n⏰ Command:\n\n1. Setting jam:\n.autogroup set [buka] [tutup]\nContoh: .autogroup set 05:00 23:00\n\n2. Setting pesan:\n.autogroup setpesan buka [pesan]\n.autogroup setpesan tutup [pesan]\n\n3. Aktif/Nonaktif:\n.autogroup on\n.autogroup off\n\n4. Lihat status:\n.autogroup status\n.autogroup list\n\n📝 Contoh lengkap:\n.autogroup set 06:00 22:00\n.autogroup setpesan buka Selamat pagi! 🥳\n.autogroup setpesan tutup Selamat malam! 😴\n.autogroup on`);
    }

    else {
        reply(`⚠️ *Command tidak dikenal!*\n\n📝 Cara penggunaan:\n\n1. Setting jam:\n.autogroup set [buka] [tutup]\nContoh: .autogroup set 05:00 23:00\n\n2. Setting pesan custom:\n.autogroup setpesan buka [pesan]\n.autogroup setpesan tutup [pesan]\n\n3. Aktif/Nonaktif:\n.autogroup on\n.autogroup off\n\n4. Lihat status:\n.autogroup status\n.autogroup list\n.autogroup info`);
    }
    break;
}
case 'autosholat':
case 'as': {
    let chatData = global.db.chats[m.chat];
    
    if (!args[0]) {
        return reply(`⚠️ *Command tidak valid!*\n\n📝 Cara penggunaan:\n\n1. Setting waktu sholat:\n.autosholat set [waktu]\nContoh: .autosholat set 12:00\n\n2. Setting pesan custom:\n.autosholat setpesan [pesan]\n\n3. Aktif/Nonaktif:\n.autosholat on\n.autosholat off\n\n4. Lihat status:\n.autosholat status\n.autosholat list\n.autosholat info`);
    }

    let subCommand = args[0]?.toLowerCase();

    if (subCommand === 'set') {
        if (!args[1]) {
            return reply('⚠️ Format salah!\n\nGunakan: `.autosholat set [waktu]`\nContoh: `.autosholat set 12:00`');
        }

        let waktu = args[1];
        if (!/^([01]?\d|2[0-3]):[0-5]\d$/.test(waktu)) {
            return reply('⚠️ Format waktu salah! Gunakan format HH:MM\nContoh: `.autosholat set 12:00`');
        }

        if (!chatData.sholat) {
            chatData.sholat = {
                active: true,
                waktu: waktu,
                message: null
            };
        } else {
            chatData.sholat.waktu = waktu;
        }

        if (!global.autoshalat) global.autoshalat = {};
        global.autoshalat[m.chat] = true;

        reply(`✅ *Waktu sholat berhasil diatur!*\n\n⏰ Waktu: ${waktu} WIB\n🔄 AutoSholat otomatis aktif!`);
        console.log(`⏰ Set waktu AutoSholat: ${m.chat} | ${waktu}`);
    }

    else if (subCommand === 'on') {
        if (!chatData.sholat) {
            chatData.sholat = {
                active: true,
                waktu: '12:00',
                message: null
            };
        } else {
            chatData.sholat.active = true;
        }
        
        if (!global.autoshalat) global.autoshalat = {};
        global.autoshalat[m.chat] = true;
        
        reply(`✅ *AutoSholat AKTIF*\n\n🕌 Notifikasi waktu sholat akan dikirim ke grup ini.\n\n📌 Waktu sholat: ${chatData.sholat.waktu || '12:00'} WIB`);
        console.log(`➕ AutoSholat ON: ${m.chat}`);
    }

    else if (subCommand === 'off') {
        if (chatData.sholat) {
            chatData.sholat.active = false;
        }
        if (global.autoshalat) {
            delete global.autoshalat[m.chat];
        }
        reply('❌ *AutoSholat NONAKTIF*');
        console.log(`➖ AutoSholat OFF: ${m.chat}`);
    }

    else if (subCommand === 'setpesan' || subCommand === 'setmsg') {
        if (!args[1]) {
            return reply('⚠️ Format salah!\n\nGunakan: `.autosholat setpesan [pesan]`\n\n📝 Gunakan variabel:\n{{sholat}} - Nama sholat\n{{waktu}} - Waktu sholat\n{{hari}} - Nama hari\n{{tanggal}} - Tanggal lengkap\n\nContoh: `.autosholat setpesan Ayo sholat {{sholat}} jam {{waktu}}!`');
        }
        
        let message = args.slice(1).join(' ');
        
        if (!chatData.sholat) {
            chatData.sholat = {
                active: true,
                waktu: '12:00',
                message: message
            };
        } else {
            chatData.sholat.message = message;
        }
        
        if (!global.autoshalat) global.autoshalat = {};
        global.autoshalat[m.chat] = true;
        
        reply(`✅ *Pesan AutoSholat diubah!*\n\n📝 Pesan baru:\n${message}\n\n💡 Gunakan variabel untuk personalisasi pesan.`);
    }

    else if (subCommand === 'resetpesan' || subCommand === 'reset') {
        if (!chatData.sholat) {
            return reply('⚠️ AutoSholat belum diaktifkan. Gunakan `.autosholat on` terlebih dahulu.');
        }
        
        chatData.sholat.message = null;
        reply(`✅ *Pesan AutoSholat direset ke default!*\n\n📝 Pesan default akan digunakan.`);
    }

    else if (subCommand === 'status') {
        const isActive = chatData.sholat?.active && global.autoshalat[m.chat] ? '✅ Aktif' : '❌ Nonaktif';
        const waktu = chatData.sholat?.waktu || 'Belum diatur';
        const message = chatData.sholat?.message || 'Menggunakan pesan default';
        
        let text = `📌 *Status AutoSholat*\n\n` +
                   `${isActive}\n\n` +
                   `⏰ Waktu: ${waktu} WIB\n` +
                   `📝 Pesan: ${message.substring(0, 50)}${message.length > 50 ? '...' : ''}\n\n`;
        
        if (chatData.sholat?.active) {
            const now = moment.tz('Asia/Jakarta');
            const waktuSholat = chatData.sholat.waktu || '12:00';
            const isPast = now.format('HH:mm') > waktuSholat;
            text += `⏳ Status: ${isPast ? '✅ Sudah lewat' : '⏳ Belum tiba'}`;
        }
        
        reply(text);
    }

    else if (subCommand === 'list') {
        const list = Object.keys(global.autoshalat || {});
        if (list.length === 0) {
            reply('📋 Belum ada grup yang aktif AutoSholat');
        } else {
            let text = '📋 *Daftar Grup AutoSholat:*\n\n';
            list.forEach((id, i) => {
                const chatData = global.db.chats[id];
                const setting = chatData?.sholat;
                const status = setting?.active !== false ? '✅' : '❌';
                const waktu = setting?.waktu || 'Belum diatur';
                text += `${i+1}. ${id}\n   ${status} ⏰ ${waktu} WIB\n`;
            });
            text += `\nTotal: ${list.length} grup`;
            reply(text);
        }
    }

    else if (subCommand === 'info') {
        reply(`📌 *Info AutoSholat*\n\n` +
              `⏰ Fitur notifikasi waktu sholat otomatis.\n\n` +
              `📌 *Command:*\n\n` +
              `1. Setting waktu:\n.autosholat set [waktu]\nContoh: .autosholat set 12:00\n\n` +
              `2. Setting pesan custom:\n.autosholat setpesan [pesan]\n\n` +
              `3. Aktif/Nonaktif:\n.autosholat on\n.autosholat off\n\n` +
              `4. Reset pesan:\n.autosholat resetpesan\n\n` +
              `5. Lihat status:\n.autosholat status\n.autosholat list\n.autosholat info\n\n` +
              `📝 *Variabel pesan:*\n` +
              `{{sholat}} - Nama sholat\n` +
              `{{waktu}} - Waktu sholat\n` +
              `{{hari}} - Nama hari\n` +
              `{{tanggal}} - Tanggal lengkap`);
    }

    else {
        reply(`⚠️ *Command tidak dikenal!*\n\n📝 Cara penggunaan:\n\n1. Setting waktu:\n.autosholat set [waktu]\nContoh: .autosholat set 12:00\n\n2. Setting pesan custom:\n.autosholat setpesan [pesan]\n\n3. Aktif/Nonaktif:\n.autosholat on\n.autosholat off\n\n4. Reset pesan:\n.autosholat resetpesan\n\n5. Lihat status:\n.autosholat status\n.autosholat list\n.autosholat info`);
    }
    break;
}

case 'clearblacklist': {
    if (!isCreator) return reply('❌ Khusus owner!');
    
    let blacklist = JSON.parse(fs.readFileSync('./database/blacklist.json'));
    if (blacklist.length === 0) return m.reply('📭 Blacklist kosong!');
    
    fs.writeFileSync('./database/blacklist.json', JSON.stringify([], null, 2));
    m.reply(`✅ ${blacklist.length} data blacklist berhasil dihapus!`);
}
break;
case 'sider':
case 'siders': {
    const metadata = await satanic.groupMetadata(m.chat);
    const groupName = metadata.subject;
    const lama = 86400000 * 7; // 7 hari
    const now = Date.now();

    const member = metadata.participants.map(v => v.id);
    const pesan = text || "Harap aktif di grup karena akan ada pembersihan anggota setiap saat.";

    let sider = [];

    for (let id of member) {
        const user = metadata.participants.find(u => u.id == id);
        const dbUser = global.db.users[id];

        if (user.isAdmin || user.isSuperAdmin) continue;

        if (!dbUser) {
            sider.push({ id, kategori: 'malas nimbrung' });
        } else if (dbUser.banned) {
            sider.push({ id, kategori: 'Banned' });
        } else if (now - dbUser.lastseen > lama) {
            sider.push({ id, kategori: 'Tidak aktif >7 hari' });
        }
    }

    if (sider.length === 0) return reply("*Tidak ada member sider pada grup ini.*");

    const textSider = sider.map(v => `• @${v.id.split("@")[0]} (${v.kategori})`).join("\n");

    await satanic.sendMessage(m.chat, {
        text: `*${sider.length}/${member.length}* Anggota Grup *${groupName}* menjadi sider:\n_“${pesan}”_\n\n*Anggota Sider:*\n${textSider}`,
        contextInfo: { mentionedJid: sider.map(v => v.id) }
    }, { quoted: fkontak });
}
break;
case 'siderv2':
case 'kicksiderv2': {
    if (!m.isGroup) return reply('❌ Fitur ini khusus grup!')
    await satanic.sendMessage(m.chat, { react: { text: "🔎", key: m.key } })

    let groupMetadata = await satanic.groupMetadata(m.chat)
    let participants = groupMetadata.participants
    let chatData = global.db.chats[m.chat]?.users || {}

    let totalMember = participants.length
    let now = Date.now()
    let oneWeek = 604800000

    let ghosts = []
    let siders = []
    let active = []

    for (let member of participants) {
        let id = member.id
        let finalJid = id

        if (id.includes('@lid')) {
            if (satanic.findJidByLid) {
                let found = satanic.findJidByLid(id)
                if (found) finalJid = found
            }
            if (finalJid.includes('@lid')) {
                let manual = Object.keys(chatData).find(key => chatData[key].lid === id)
                if (manual) finalJid = manual
            }
        } else {
            finalJid = satanic.decodeJid(id)
        }

        let userDB = chatData[finalJid]

        if (!userDB || userDB.total === 0) {
            ghosts.push(finalJid)
        } else {
            let lastSeen = userDB.lastSeen || 0
            let daysNoChat = Math.floor((now - lastSeen) / 86400000)

            let userData = {
                id: finalJid,
                total: userDB.total,
                last: lastSeen,
                days: daysNoChat,
                name: userDB.name || 'Unknown'
            }

            if (now - lastSeen > oneWeek) {
                siders.push(userData)
            } else {
                active.push(userData)
            }
        }
    }

    if (args[0] === 'kick') {
        if (!isAdmins) return reply('❌ Khusus admin grup!')
        if (ghosts.length === 0) return reply('⚠️ Tidak ada ghost sider.')

        await reply(`🚀 Mengeluarkan ${ghosts.length} ghost...`)

        for (let jid of ghosts) {
            await new Promise(r => setTimeout(r, 1500))
            await satanic.groupParticipantsUpdate(m.chat, [jid], 'remove')
        }

        return reply('✅ Berhasil bersih-bersih grup.')
    }

    active.sort((a, b) => b.total - a.total)
    siders.sort((a, b) => a.last - b.last)

    let teks = `📊 *ANALISIS GRUP*\n`
    teks += `👥 Total: ${totalMember}\n`
    teks += `🗣️ Aktif: ${active.length}\n`
    teks += `💤 Sider: ${siders.length}\n`
    teks += `👻 Ghost: ${ghosts.length}\n`
    teks += `━━━━━━━━━━━━━━━\n\n`

    teks += `🏆 *MEMBER AKTIF*\n`
    if (active.length === 0) {
        teks += `- Belum ada data\n`
    } else {
        teks += active.map((v, i) => {
            return `${i + 1}. @${v.id.split('@')[0]} (💬 ${v.total})`
        }).join('\n')
    }
    teks += `\n\n💤 *SIDER 7 HARI+*\n`
    if (siders.length === 0) {
        teks += `- Nihil\n`
    } else {
        teks += siders.map(v => {
            return `@${v.id.split('@')[0]} (${v.days} hari)`
        }).join('\n')
    }
    teks += `\n\n👻 *GHOST 0 CHAT*\n`
    if (ghosts.length === 0) {
        teks += `- Nihil\n`
    } else {
        teks += ghosts.map(v => `@${v.split('@')[0]}`).join('\n')
    }

    teks += `\n\nKetik *${prefix + command} kick* untuk kick ghost`

    let mentions = [
        ...active.map(v => v.id),
        ...siders.map(v => v.id),
        ...ghosts
    ]

    await satanic.sendMessage(m.chat, {
        text: teks,
        mentions
    }, { quoted: fkontak })
}
break
case 'tagadmin': 
    if (!m.isGroup) return satanic.sendMessage(m.chat, { text: mess.only.group });
    let adminList = [];
    let adminNames = [];
    let adminIds = [];
    participants.forEach((participant) => {
        if (participant.admin === "admin" || participant.admin === "superadmin") {
            adminNames.push(participant.id.split('@')[0]);  
            adminIds.push(participant.id);  // ID admin
            adminList.push(`@${participant.id.split('@')[0]}`); 
        }
    });

    const groupPP = 'https://example.com/default-image.jpg'; 
    const groupName = groupMetadata.subject;

    if (adminList.length > 0) {
        let tagMessage = `🌟 *Admin Grup*:\n\n*Nama Grup:* ${groupName}\n\n${adminNames.map((name, i) => `*${name}* (@${adminIds[i].split('@')[0]})`).join('\n')}`;
        satanic.sendMessage(m.chat, {
            text: tagMessage,
            mentions: adminIds,
            caption: 'Daftar admin grup.',
            thumbnail: { url: groupPP }
        });
    } else {
        satanic.sendMessage(m.chat, { text: '😓 Tidak ada admin di grup ini.' });
    }
    break;
case 'setnamegc':
case 'setsubject':
if (!m.isGroup) return reply(mess.group);
if (!isAdmins && !isCreator) return reply(mess.admin)

if (!text) return reply('Mau di namain apa kak grupnya? 🤔');
await satanic.groupUpdateSubject(m.chat, text);
reply(mess.done);
break;

case 'topmember':
case 'totalchat':
case 'totalpesan': {
    if (!m.isGroup) return reply('onlygroup')
    if (!isAdmins) return reply('you are not admin')
    if (!global.db.chats[m.chat]) global.db.chats[m.chat] = {}
    if (!global.db.chats[m.chat].totalChat) global.db.chats[m.chat].totalChat = {}
    
    const metadata = await satanic.groupMetadata(m.chat)
    const groupName = metadata.subject
    const totalMembers = metadata.participants.length
    
    if (text && text.toLowerCase() === 'reset') {
        const chatData = global.db.chats[m.chat];
        if (chatData.totalChat) {
            Object.keys(chatData.totalChat).forEach(key => {
                delete chatData.totalChat[key];
            });
        }
        reply("✅ *Statistik chat berhasil di reset.*");
        return
    }
    
    const entries = Object.entries(global.db.chats[m.chat].totalChat)
        .filter(([jid]) => jid.endsWith('@s.whatsapp.net'))
        .map(([jid, count]) => ({ jid, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 15)
    
    if (entries.length === 0) {
        return reply(`📊 *CHAT INSIGHT*\n\n> Belum ada data chat tercatat.`)
    }
    
    const allActiveMembers = Object.keys(global.db.chats[m.chat].totalChat)
        .filter(jid => jid.endsWith('@s.whatsapp.net')).length;
    const inactiveMembers = totalMembers - allActiveMembers;
    const totalMessages = entries.reduce((sum, el) => sum + el.count, 0);
    
    // Send react
    await satanic.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    // Check skia-canvas
    let skia
    try {
        skia = require('skia-canvas')
    } catch {
        await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
        return reply("❌ Install dulu: npm install skia-canvas")
    }

    const { Canvas, loadImage, FontLibrary } = skia
    const path = require('path')
    const fs = require('fs')
    const axios = require('axios')

    try {
        // Setup canvas - Ukuran 1080x1920
        const W = 1080
        const H = 1920
        
        const canvas = new Canvas(W, H)
        const ctx = canvas.getContext('2d')
        ctx.imageSmoothingEnabled = true
        ctx.imageSmoothingQuality = 'high'
        
        // Background gradient premium
        const gradient = ctx.createLinearGradient(0, 0, 0, H)
        gradient.addColorStop(0, '#0f0c29')
        gradient.addColorStop(0.3, '#302b63')
        gradient.addColorStop(0.6, '#24243e')
        gradient.addColorStop(1, '#0f0c29')
        ctx.fillStyle = gradient
        ctx.fillRect(0, 0, W, H)
        
        // Decorative circles
        ctx.save()
        ctx.globalAlpha = 0.03
        for (let i = 0; i < 4; i++) {
            const x = 100 + (i * 300)
            const y = 200 + (i * 400)
            ctx.beginPath()
            ctx.arc(x, y, 250, 0, Math.PI * 2)
            ctx.fillStyle = '#ffffff'
            ctx.fill()
        }
        ctx.restore()
        
        // Header
        ctx.save()
        ctx.textAlign = 'center'
        ctx.textBaseline = 'top'
        
        // Icon
        ctx.font = '60px Inter, sans-serif'
        ctx.fillText('📊', W / 2, 50)
        
        ctx.font = 'bold 40px Inter, sans-serif'
        ctx.fillStyle = '#ffffff'
        ctx.fillText('CHAT INSIGHT', W / 2, 140)
        
        ctx.font = '20px Inter, sans-serif'
        ctx.fillStyle = 'rgba(255,255,255,0.3)'
        ctx.fillText(groupName, W / 2, 195)
        ctx.restore()
        
        // Card Statistik
        const cardY = 250
        const cardX = 50
        const cardW = W - 100
        const cardH = 160
        
        ctx.save()
        ctx.shadowColor = 'rgba(0,0,0,0.3)'
        ctx.shadowBlur = 40
        ctx.shadowOffsetY = 15
        ctx.fillStyle = 'rgba(255,255,255,0.06)'
        ctx.beginPath()
        ctx.roundRect(cardX, cardY, cardW, cardH, 25)
        ctx.fill()
        ctx.restore()
        
        ctx.save()
        ctx.strokeStyle = 'rgba(255,255,255,0.05)'
        ctx.lineWidth = 1
        ctx.beginPath()
        ctx.roundRect(cardX, cardY, cardW, cardH, 25)
        ctx.stroke()
        ctx.restore()
        
        // Stat items - 4 kolom
        const statItems = [
            { label: 'Total Member', value: totalMembers, icon: '👥' },
            { label: 'Member Aktif', value: allActiveMembers, icon: '✍️' },
            { label: 'Member Tidak Aktif', value: inactiveMembers, icon: '💤' },
            { label: 'Total Pesan', value: totalMessages.toLocaleString('id-ID'), icon: '💬' },
        ]
        
        const colW = cardW / 4
        statItems.forEach((item, i) => {
            const x = cardX + (i * colW) + (colW / 2)
            const y = cardY + 25
            
            ctx.save()
            ctx.textAlign = 'center'
            ctx.textBaseline = 'top'
            
            ctx.font = '28px Inter, sans-serif'
            ctx.fillText(item.icon, x, y)
            
            ctx.font = 'bold 28px Inter, sans-serif'
            ctx.fillStyle = '#ffffff'
            ctx.fillText(item.value, x, y + 45)
            
            ctx.font = '14px Inter, sans-serif'
            ctx.fillStyle = 'rgba(255,255,255,0.4)'
            ctx.fillText(item.label, x, y + 85)
            ctx.restore()
            
            // Separator
            if (i < statItems.length - 1) {
                ctx.save()
                ctx.strokeStyle = 'rgba(255,255,255,0.05)'
                ctx.lineWidth = 1
                ctx.beginPath()
                ctx.moveTo(cardX + ((i + 1) * colW), cardY + 20)
                ctx.lineTo(cardX + ((i + 1) * colW), cardY + cardH - 20)
                ctx.stroke()
                ctx.restore()
            }
        })
        
        // Top Members Title
        const titleY = cardY + cardH + 40
        ctx.save()
        ctx.textAlign = 'left'
        ctx.textBaseline = 'top'
        ctx.font = 'bold 24px Inter, sans-serif'
        ctx.fillStyle = '#ffffff'
        ctx.fillText('🏆 TOP MEMBER PALING AKTIF', 50, titleY)
        ctx.restore()
        
        // List Member
        const listY = titleY + 50
        const medals = ['🥇','🥈','🥉']
        
        // Warna bar berdasarkan peringkat
        const barColors = ['#FFD700', '#C0C0C0', '#CD7F32', '#4A9EF5']
        
        entries.forEach((item, i) => {
            const y = listY + (i * 85)
            const name = item.jid.split('@')[0]
            const percent = ((item.count / totalMessages) * 100)
            const barWidth = Math.min((percent / 100) * (W - 140), W - 140)
            const medal = medals[i] || '🏅'
            
            // Background item
            ctx.save()
            ctx.shadowColor = 'rgba(0,0,0,0.2)'
            ctx.shadowBlur = 20
            ctx.shadowOffsetY = 8
            ctx.fillStyle = 'rgba(255,255,255,0.04)'
            ctx.beginPath()
            ctx.roundRect(40, y, W - 80, 70, 15)
            ctx.fill()
            ctx.restore()
            
            ctx.save()
            ctx.strokeStyle = 'rgba(255,255,255,0.04)'
            ctx.lineWidth = 1
            ctx.beginPath()
            ctx.roundRect(40, y, W - 80, 70, 15)
            ctx.stroke()
            ctx.restore()
            
            // Medal
            ctx.save()
            ctx.textAlign = 'center'
            ctx.textBaseline = 'middle'
            ctx.font = '30px Inter, sans-serif'
            ctx.fillText(medal, 80, y + 35)
            ctx.restore()
            
            // Name
            ctx.save()
            ctx.textAlign = 'left'
            ctx.textBaseline = 'middle'
            ctx.font = 'bold 20px Inter, sans-serif'
            ctx.fillStyle = '#ffffff'
            ctx.fillText('@' + name, 130, y + 20)
            
            // Count
            ctx.font = '16px Inter, sans-serif'
            ctx.fillStyle = 'rgba(255,255,255,0.4)'
            ctx.fillText(`${item.count.toLocaleString('id-ID')} pesan`, 130, y + 48)
            ctx.restore()
            
            // Bar
            const barX = 380
            const barY = y + 25
            const barH = 20
            const maxBarW = W - 420
            
            ctx.save()
            ctx.fillStyle = 'rgba(255,255,255,0.05)'
            ctx.beginPath()
            ctx.roundRect(barX, barY, maxBarW, barH, 10)
            ctx.fill()
            ctx.restore()
            
            // Bar progress
            const progressW = Math.min((percent / 100) * maxBarW, maxBarW)
            const color = i < 3 ? barColors[i] : barColors[3]
            
            ctx.save()
            const barGrad = ctx.createLinearGradient(barX, 0, barX + progressW, 0)
            barGrad.addColorStop(0, color)
            barGrad.addColorStop(1, color + '80')
            ctx.fillStyle = barGrad
            ctx.beginPath()
            ctx.roundRect(barX, barY, progressW, barH, 10)
            ctx.fill()
            ctx.restore()
            
            // Percent
            ctx.save()
            ctx.textAlign = 'right'
            ctx.textBaseline = 'middle'
            ctx.font = 'bold 16px Inter, sans-serif'
            ctx.fillStyle = 'rgba(255,255,255,0.6)'
            ctx.fillText(`${percent.toFixed(1)}%`, W - 70, y + 35)
            ctx.restore()
        })
        
        // Footer - Reset info
        const footerY = listY + (entries.length * 85) + 40
        if (entries.length > 0) {
            ctx.save()
            ctx.textAlign = 'center'
            ctx.textBaseline = 'top'
            
            ctx.font = '14px Inter, sans-serif'
            ctx.fillStyle = 'rgba(255,255,255,0.15)'
            ctx.fillText(`Top ${entries.length} dari ${allActiveMembers} member aktif`, W / 2, footerY)
            
            ctx.font = '12px Inter, sans-serif'
            ctx.fillStyle = 'rgba(255,255,255,0.08)'
            ctx.fillText(`Gunakan ${prefix + command} reset untuk mereset statistik`, W / 2, footerY + 30)
            ctx.restore()
        }
        
        // Border premium
        ctx.save()
        const borderGrad = ctx.createLinearGradient(0, 0, W, 0)
        borderGrad.addColorStop(0, 'rgba(255,255,255,0)')
        borderGrad.addColorStop(0.2, 'rgba(255,255,255,0.02)')
        borderGrad.addColorStop(0.8, 'rgba(255,255,255,0.02)')
        borderGrad.addColorStop(1, 'rgba(255,255,255,0)')
        ctx.strokeStyle = borderGrad
        ctx.lineWidth = 2
        ctx.beginPath()
        ctx.roundRect(30, 30, W - 60, H - 60, 40)
        ctx.stroke()
        ctx.restore()
        
        const buffer = await canvas.png
        
        // Kirim gambar + caption
        let teks = `📊 *CHAT INSIGHT*
🏷️ *Grup* : ${groupName}
👥 *Total Member* : ${totalMembers}
✍️ *Member Mengirim Pesan* : ${allActiveMembers}
💤 *Member Tidak Mengirim Pesan* : ${inactiveMembers}
💬 *Total Pesan* : ${totalMessages.toLocaleString('id-ID')}
🏆 *TOP MEMBER PALING AKTIF*
`
        for (let i = 0; i < entries.length; i++) {
            const { jid, count } = entries[i]
            const name = jid.split('@')[0]
            const medal = medals[i] || '🏅'
            const percent = ((count / totalMessages) * 100).toFixed(1)
            teks += `
${medal} @${name}
💬 ${count.toLocaleString('id-ID')} pesan (${percent}%)
`
        }
        teks += `
📈 *STATISTIK GRUP* 
🔝 Top Chat : ${entries[0]?.count.toLocaleString('id-ID')} pesan
🗂️ Member Aktif : ${allActiveMembers}
💤 Member Tidak Aktif : ${inactiveMembers}
👥 Total Member : ${totalMembers}
⚡ Tracking : Real-time

> Gunakan *${prefix + command} reset* untuk mereset statistik
`
        
        await satanic.sendMessage(m.chat, {
            image: buffer,
            caption: teks
        }, { quoted: m })
        
        await satanic.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
        
    } catch (e) {
        console.error(e)
        await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
        reply(`❌ Error:\n${e.message}`)
    }
}
break
case 'inspect':
case 'cekid': 
case 'idch': 
case 'idgb': 
case 'idgc': 
case 'cekidch': 
case 'cekidgc': 
case 'cekidsaluran': 
case 'cekidgb': 
case 'cekidgroup': {
    if (!text) return reply(`input id nya`)
    const isChannel = text.includes('https://whatsapp.com/channel/')
    const grupRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/i
    const boolStatus = (v) => (v === true ? 'Aktif' : v === false ? 'Tidak Aktif' : (v ?? '-'))

    if (!isChannel && !grupRegex.test(text)) return replytolak(global.mess.query.link)

    try {
        if (isChannel) {
            const code = text.split('https://whatsapp.com/channel/')[1]
            if (!code) return reply('link tidak valid')

            const res = await satanic.newsletterMetadata('invite', code)

            const channelId = res.id || ''
            const channelName = res.name || ''

            const teks = `\`\`\`📢 Informasi Channel WhatsApp\`\`\`

🗒️ *Nama:* ${channelName || '-'}
🆔 *ID:* ${channelId || '-'}
👥 *Total Pengikut:* ${res.subscribers ?? '-'}
📌 *Status:* ${res.state || '-'}
✅ *Verifikasi:* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}`

            const msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                            footer: proto.Message.InteractiveMessage.Footer.create({ text: "" }),
                            header: proto.Message.InteractiveMessage.Header.create({ hasMediaAttachment: false }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: [
                                    {
                                        name: "cta_copy",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "📋 Salin ID",
                                            copy_code: `${channelId}`
                                        })
                                    },
                                    {
                                        name: "cta_copy",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "📋 Salin Nama",
                                            copy_code: `${channelName}`
                                        })
                                    }
                                ]
                            })
                        })
                    }
                }
            }, { quoted: fkontak })

            return satanic.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id })
        }

        const inviteCode = text.match(grupRegex)[1]
        const g = await satanic.groupGetInviteInfo(inviteCode)

        let pp = null
        try {
            pp = await satanic.profilePictureUrl(g.id, 'image')
        } catch {
            pp = null
        }

        const admins = (g.participants || []).filter(v => v.admin)
        const groupId = g.id || ''
        const groupName = g.subject || '-'
        const creator = g.owner ? '@' + g.owner.split('@')[0] : '-'

        const teks = `\`\`\`👥 Informasi Grup WhatsApp\`\`\`

🗒️ *Nama:* ${groupName || '-'}
🆔 *ID:* ${groupId || '-'}
👥 *Total Member:* ${g.size || g.participants?.length || '-'}
📅 *Dibuat:* ${g.creation ? new Date(g.creation * 1000).toLocaleString() : '-'}
👑 *Creator:* ${creator}

⚙️ \`\`\`Pengaturan  Group\`\`\`
🔒 *Restrict:* ${boolStatus(g.restrict)}
📢 *Announce:* ${boolStatus(g.announce)}
🏘️ *Community:* ${boolStatus(g.isCommunity)}
✅ *Join Approval:* ${boolStatus(g.joinApprovalMode)}
➕ *Member Add Mode:* ${boolStatus(g.memberAddMode)}

📝 \`\`\`Deskripsi\`\`\`
${g.desc || '-'}

👮 \`\`\`Admin\`\`\`
${admins.length ? admins.map(a => `- @${a.id.split('@')[0]} (${a.admin})`).join('\n') : '-'}`

        const mentioned = [
            ...(g.owner ? [g.owner] : []),
            ...admins.map(a => a.id)
        ]

        if (pp) {
            const media = await prepareWAMessageMedia(
                { image: { url: pp } },
                { upload: satanic.waUploadToServer }
            )

            const msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                            footer: proto.Message.InteractiveMessage.Footer.create({ text: "" }),
                            header: proto.Message.InteractiveMessage.Header.create({
                                hasMediaAttachment: true,
                                imageMessage: media.imageMessage
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: [
                                    {
                                        name: "cta_copy",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "📋 Salin ID",
                                            copy_code: `${groupId}`
                                        })
                                    },
                                    {
                                        name: "cta_copy",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "📋 Salin Nama",
                                            copy_code: `${groupName !== '-' ? groupName : ''}`
                                        })
                                    }
                                ]
                            })
                        })
                    }
                }
            }, { quoted: fkontak })

            msg.message.viewOnceMessage.message.interactiveMessage.contextInfo = { mentionedJid: mentioned }

            return satanic.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id })
        }

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: "" }),
                        header: proto.Message.InteractiveMessage.Header.create({ hasMediaAttachment: false }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    name: "cta_copy",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "📋 Salin ID",
                                        copy_code: `${groupId}`
                                    })
                                },
                                {
                                    name: "cta_copy",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "📋 Salin Nama",
                                        copy_code: `${groupName !== '-' ? groupName : ''}`
                                    })
                                }
                            ]
                        })
                    })
                }
            }
        }, { quoted: fkontak })

        msg.message.viewOnceMessage.message.interactiveMessage.contextInfo = { mentionedJid: mentioned }
return satanic.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id })
    } catch (err) {
        console.log(err)
        return reply('eror')
    }
}
break

case "rvo": case "readviewonce": {
 if (!isAdmins && !isCreator) return reply(mess.admin)
const quoted = m.quoted ? m.quoted : m;    
await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
let msg = m?.quoted?.message?.imageMessage || m?.quoted?.message?.videoMessage || m?.quoted?.message?.audioMessage || m?.quoted
if (!msg.viewOnce && m.quoted.mtype !== "viewOnceMessageV2" && !msg.viewOnce) return reply("Pesan itu bukan viewonce!")
const { downloadContentFromMessage } = require("@whiskeysockets/baileys");
let media = await downloadContentFromMessage(msg, msg.mimetype == 'image/jpeg' ? 'image' : msg.mimetype == 'video/mp4' ? 'video' : 'audio')
    let type = msg.mimetype
    let buffer = Buffer.from([])
    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
    }
    if (/video/.test(type)) {
        return satanic.sendMessage(m.chat, {video: buffer, caption: msg.caption || ""}, {quoted: fkontak})
    } else if (/image/.test(type)) {
        return satanic.sendMessage(m.chat, {image: buffer, caption: msg.caption || ""}, {quoted: fkontak})
    } else if (/audio/.test(type)) {
        return satanic.sendMessage(m.chat, {audio: buffer, mimetype: "audio/mpeg", ptt: true}, {quoted: fkontak})
    } 
}
break
case 'setdesc':
case 'setdesk':
if (!m.m.isGroup) return reply(mess.group);
if (!isAdmins && !m.isGroupOwner && !isCreator) return reply(mess.admin);
if (!text) return reply('Text ?')
await satanic.groupUpdateDescription(m.chat, text)
reply(mess.done)
break;
case 'cleardesc':
case 'cleardesk':{
if (!m.m.isGroup) return reply('Perintah ini hanya dapat digunakan dalam grup.');
if (!isAdmins && !isCreator) return reply('Perintah ini hanya dapat digunakan oleh admin.');
try {
await satanic.groupUpdateDescription(m.chat, null);
reply('Deskripsi grup berhasil dihapus.');
} catch (err) {
console.error(err);
reply('Gagal menghapus deskripsi grup.');
}
}
break;
case 'getnamegc':
case 'getsubject': {
if (!m.isGroup) return reply(mess.group);
if (!isAdmins && !isCreator) return reply(mess.admin)

try {
reply(groupName);
} catch (error) {
console.log(error);
reply('Gagal saat melakukan tindakan, jika anda pemilik silahkan cek console.');
};
};
break
case 'getdesk':
case 'metadatadesc':
case 'getdesc': {
if (!m.isGroup) return reply(mess.group);
if (!isAdmins && !isCreator) return reply(mess.admin)
try {
reply(groupMetadata.desc)
} catch (error) {
console.log(error);
reply('Gagal saat melakukan tindakan, jika anda pemilik silahkan cek console.');
};
};
break
case 'getppgc': {
if (!m.isGroup) return reply(mess.group);
if (!isAdmins && !isCreator) return reply(mess.admin)

try {
avatarr = await satanic.profilePictureUrl(m.chat, "image")
} catch {
avatarr = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
}
satanic.sendMessage(m.chat, {image: {url: avatarr }, caption: `©satanic` }, {quoted: fkontak })
}
break
case 'setppgc': case 'setppgroup':{
if (!m.isGroup) return reply(mess.group);
if (!isAdmins && !isCreator) return reply(mess.admin)
const { S_WHATSAPP_NET } = require('@whiskeysockets/baileys');
	async function generateProfilePicture(media) {
    const image = await jimp.read(media);
    const min = image.getWidth();
    const max = image.getHeight();
    const cropped = image.crop(0, 0, min, max);
    return {
        img: await cropped.scaleToFit(720, 720).getBufferAsync(jimp.MIME_JPEG),
        preview: await cropped.normalize().getBufferAsync(jimp.MIME_JPEG)
    };
}
if (!quoted) return reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)

				let media = await satanic.downloadAndSaveMediaMessage(quoted);
				const group = m.chat;
				const { img } = await generateProfilePicture(media);
				await satanic.query({
					tag: 'iq',
					attrs: {					
                        target: group,
                        to: S_WHATSAPP_NET,
						type:'set',
						xmlns: 'w:profile:picture'
					},
					content: [
						{
							tag: 'picture',
							attrs: { type: 'image' },
							content: img
						} 
					]
				})
				reply(mess.done);
			}
			break

case "getpp": {
if (!m.isGroup) return reply(mess.group);
if (!isAdmins && !isCreator) return reply(mess.admin)
let target = m.quoted ? m.quoted.sender : m.mentionedJid[0] ? m.mentionedJid[0] : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : null
if (!target) return reply("Reply/@tag target nya")

var ppuser
try {
ppuser = await satanic.profilePictureUrl(target, 'image')
} catch (err) {
ppuser = 'https://files.catbox.moe/ejy4ky.jpg'
}
return satanic.sendMessage(m.chat, {image: {url: ppuser}, caption: `Sukses mengambil profil @${target.split("@")[0]}`, mentions: target}, {quoted: fkontak})
}
break 
case 'afk': {
    if (m.key.fromMe) return
    if (!m.isGroup) return 
    if (!text) return reply(`📌 Example: *${prefix+command}* want to sleep`)

    let user = global.db.users[m.sender]
    user.afkTime = + new Date
    user.afkReason = args.join(" ")

    reply(
`✅ *Kamu telah AFK!*  

👤 ${m.pushName} sekarang AFK.  
💤 Alasan : ${args.length ? args.join(" ") : '-'}  

─────────────────────
💡 Jangan khawatir, status AFK akan hilang otomatis kalau kamu kirim pesan lagi.
`.trim())
}
break
case 'listpc': {
 let anulistp = await store.chats.all().filter(v => v.id.endsWith('.net')).map(v => v.id)
 let teks = ` *PERSONAL CHAT LIST*\n\nTotal Chat : ${anulistp.length} Chat\n\n`
 for (let i of anulistp) {
 let nama = store.messages[i].array[0].pushName
 teks += ` *Name :* ${nama}\n *User :* @${i.split('@')[0]}\n *Chat :* https://wa.me/${i.split('@')[0]}\n\n────────────────────────\n\n`
 }
 reply(teks)
}
break
case 'listgc': {
 let anulistg = await store.chats.all().filter(v => v.id.endsWith('@g.us')).map(v => v.id)
 let teks = ` *GROUP CHAT LIST*\n\nTotal Group : ${anulistg.length} Group\n\n`
 for (let i of anulistg) {
 let metadata = await satanic.groupMetadata(i)
 teks += ` *Name :* ${metadata.subject}\n *Owner :* ${metadata.owner !== undefined ? '@' + metadata.owner.split`@`[0] : 'Unknown'}\n *ID :* ${metadata.id}\n *Made :* ${moment(metadata.creation * 1000).tz('Asia/Kolkata').format('DD/MM/YYYY HH:mm:ss')}\n *Member :* ${metadata.participants.length}\n\n────────────────────────\n\n`
 }
 reply(teks)
}
break
 case 'totag': {
if (!m.isGroup) return reply('only group')
if (!isAdmins) return reply('Khusus Admin!!')
  if (!m.quoted) return reply(`Reply message with caption ${prefix + command}`)
  satanic.sendMessage(m.chat, { forward: m.quoted.fakeObj, mentions: participants.map(a => a.id) })
 }
break
case "hidetag": {
if (!isAdmins && !isCreator) return reply(mess.admin)
if (m.quoted) {
satanic.sendMessage(m.chat, {
forward: m.quoted.fakeObj,
mentions: participants.map(a => a.id)
})
}
if (!m.quoted) {
satanic.sendMessage(m.chat, {
text: text ? text : '',
mentions: participants.map(a => a.id)
}, { quoted: fkontak })
}
}
break
case 'htprem': {
  if (!isPrem && !isCreator) return reply(mess.admin)
  let splitText = text.split('|')
  let pesan = splitText[0] ? splitText[0].trim() : '📢 PENGUMUMAN'
  let linkGroup = splitText[1] ? splitText[1].trim() : ''
  if (linkGroup.includes('chat.whatsapp.com/')) {
    let code = linkGroup.split('chat.whatsapp.com/')[1].split('?')[0]
    let targetGroup = await satanic.groupGetInviteInfo(code)
    await satanic.sendMessage(targetGroup.id, {
      text: pesan,
      mentions: targetGroup.participants.map(a => a.id)
    })
    reply(`✅ Pesan "${pesan}" berhasil dikirim ke group ${targetGroup.subject}`)
  } else {
    reply('❌ Link group tidak valid!')
  }
}
break
case 'totag2': {
  if (!m.isGroup) return reply('only group')
  if (!isPrem && !isCreator) return reply('Khusus Admin!!')
  let linkGroup = text ? text.trim() : ''
  if (linkGroup.includes('chat.whatsapp.com/')) {
    let code = linkGroup.split('chat.whatsapp.com/')[1].split('?')[0]
    let targetGroup = await satanic.groupGetInviteInfo(code)
    if (m.quoted) {
      await satanic.sendMessage(targetGroup.id, {
        forward: m.quoted.fakeObj,
        mentions: targetGroup.participants.map(a => a.id)
      })
      reply(`✅ Pesan berhasil dikirim ke group ${targetGroup.subject}`)
    } else {
      reply('Reply pesan yang mau dikirim!')
    }
  } else {
    reply('❌ Link group tidak valid!')
  }
}
break
case 'intro':
if (!m.isGroup) return reply('Fitur Khusus Group!!!')   
let groupMetadata = await satanic.groupMetadata(m.chat)
    let introCard = `*kartu intro ${groupMetadata.subject}*
─────────────────
*Group:* ${groupMetadata.subject}
*Nama:* 
*Instagram:* 
*TikTok:* 
*Umur:* 
─────────────────
semoga betah ya kak di group ${groupMetadata.subject} jangan lupa nimbrung 👋`
reply(introCard)
break
case 'linkgroup':
case 'linkgc':
case 'gclink':
case 'grouplink': {
    if (!m.isGroup) return reply('Perintah ini hanya bisa digunakan di dalam grup!');    
    let response = await satanic.groupInviteCode(m.chat);
    let groupMetadata = await satanic.groupMetadata(m.chat);
    await satanic.sendMessage(m.chat, { 
        text: `🔗 *GROUP LINK*\n\n📌 *Nama Grup:* ${groupMetadata.subject}\n🔗 *Link:* https://chat.whatsapp.com/${response}\n\n📥 *Download by:* ${namaBot}`,
        detectLink: true
    }, { quoted: fkontak });
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'resetlinkgc':
case 'resetlinkgroup':
case 'resetlinkgrup':
case 'revoke':
case 'resetlink':
case 'resetgrouplink':
case 'resetgclink':
case 'resetgruplink': {
if (!isAdmins && !isCreator) return reply(mess.admin)

satanic.groupRevokeInvite(m.chat)
}
break
case 'joingc': {
 if (!isCreator) return 
 if (!text) return reply(`Contoh penggunaan:\n${prefix + command} https://chat.whatsapp.com/xxx`)
    let link = text.trim()
    const urlRegex = /(https?:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]{22,})/gi
    const match = link.match(urlRegex)
    
    if (match) {
        link = match[0]
    }
    if (!link.includes('chat.whatsapp.com')) {
        return reply('❌ *Link Invalid!*\n\nPastikan link adalah link undangan grup WhatsApp.\nContoh: https://chat.whatsapp.com/xxxxxxxxxxxxx')
    }
    let result = link.split('https://chat.whatsapp.com/')[1]
    if (!result) {
        // Coba method alternatif
        result = link.replace('https://chat.whatsapp.com/', '')
        if (result.includes('/')) {
            result = result.split('/')[0]
        }
    }
    if (!result || result.length < 22) {
        return reply('❌ *Link Invalid!*\n\nKode undangan tidak valid atau terlalu pendek.')
    }
    reply(mess.wait)
    try {
        await satanic.groupAcceptInvite(result)
        reply('✅ *Berhasil join ke grup!*')
    } catch (err) {
        console.error('Join Error:', err)
        let errorStr = String(err)
        
        if (errorStr.includes('400')) return reply('❌ *Grup Tidak Ditemukan!*\n\nPastikan link undangan masih aktif.')
        if (errorStr.includes('401')) return reply('❌ *Bot Di Kick Dari Grup Tersebut!*\n\nBot tidak bisa join karena pernah dikick.')
        if (errorStr.includes('409')) return reply('❌ *Bot Sudah Join!*\n\nBot sudah berada di grup tersebut.')
        if (errorStr.includes('410')) return reply('❌ *Link Kadaluarsa!*\n\nLink undangan telah direset oleh admin grup.')
        if (errorStr.includes('500')) return reply('❌ *Grup Penuh!*\n\nGrup sudah mencapai batas maksimal anggota.')
        
        reply(`❌ *Gagal Join!*\n\nError: ${errorStr.substring(0, 200)}\n\nPastikan:\n1. Link undangan masih aktif\n2. Bot tidak diblokir\n3. Grup tidak penuh`)
    }
}
break
case 'poll': {
 let [poll, opt] = text.split("|")
 if (text.split("|") < 2)
return await reply(
`Sebutkan pertanyaan dan minimal 2 pilihan\nContoh: ${prefix}poll Siapa admin terbaik?|Akbar,Hydro,Furina...`
)
 let options = []
 for (let i of opt.split(',')) {
options.push(i)
}
 await satanic.sendMessage(m.chat, {
poll: {
name: poll,
values: options
}
 })
}
break
case 'promote':
case 'pm': {
if (!m.isGroup) return reply(mess.group);
if (!isAdmins && !isCreator) return reply(mess.admin)

let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
if (!m.mentionedJid[0] && !m.quoted && !text) return reply(`Hmm... Kamu mau ${command} siapa? 🤔`)
await satanic.groupParticipantsUpdate(m.chat, [users], 'promote').then((res) => reply(mess.done)).catch((err) => reply(mess.error))
}
break
case 'demote':
case 'dm': {
if (!m.isGroup) return reply(mess.group);
if (!isAdmins && !isCreator) return reply(mess.admin)

let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
if (!m.mentionedJid[0] && !m.quoted && !text) return reply(`Hmm... Kamu mau ${command} siapa? 🤔`)
await satanic.groupParticipantsUpdate(m.chat, [users], 'demote').then((res) => reply(mess.done)).catch((err) => reply(mess.error))
}
break
case 'opentime': {
if (!m.isGroup) return reply('only group')
if (!isAdmins && !isCreator) return reply('Khusus Admin!!')
if (args[1] == 'second') {
var timer = args[0] * `1000`
} else if (args[1] == 'minute') {
var timer = args[0] * `60000`
} else if (args[1] == 'hour') {
var timer = args[0] * `3600000`
} else if (args[1] == 'day') {
var timer = args[0] * `86400000`
} else {
return reply('*Choose:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
}
reply(`Open Time ${q} Starting from now`)
setTimeout(() => {
var nomor = m.participant
const open = `*On time* Group Opened By Admin\n Now Members Can Send Messages`
satanic.groupSettingUpdate(from, 'not_announcement')
reply(open)
}, timer)
}
break
case 'closetime': {
if (!m.isGroup) return reply('only group')
if (!isAdmins && !isCreator) return reply('Khusus Admin!!')

if (args[1] == 'second') {
var timer = args[0] * `1000`
} else if (args[1] == 'minute') {
var timer = args[0] * `60000`
} else if (args[1] == 'hour') {
var timer = args[0] * `3600000`
} else if (args[1] == 'day') {
var timer = args[0] * `86400000`
} else {
return reply('*Choose:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
}
reply(`Close Time ${q} Starting from now`)
setTimeout(() => {
var nomor = m.participant
const close = `*On time* Group Closed By Admin\nNow Only Admins Can Send Messages`
satanic.groupSettingUpdate(from, 'announcement')
reply(close)
}, timer)
}
break
case 'kick': {
if (!m.isGroup) return reply(mess.group);
if (!isAdmins) return reply(mess.admin)

let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await satanic.groupParticipantsUpdate(m.chat, [users], 'remove')
await reply(`Done`)
}
break
case 'kickme': {
  if (!m.isGroup) return reply(mess.group);
  let sender = m.sender;  
  await satanic.groupParticipantsUpdate(m.chat, [sender], 'remove');
  reply(`Anda telah keluar dari grup ini.`);
}
break;
case 'add': {
if (!m.isGroup) return reply(mess.group);
if (!isAdmins && !isCreator) return reply(mess.admin)

let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await satanic.groupParticipantsUpdate(m.chat, [users], 'add')
await reply(`Done`)
}
break
case "get": case ".g": {
  if (m.key.fromMe) return
  if (!text) return reply("https://example.com");
  try {
    const url = text.trim();
    if (!isUrl(url)) return reply("Link tidak valid.");

    await satanic.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    const res = await axios.get(url, {
      responseType: "arraybuffer",
      validateStatus: () => true
    });

    const headers = res.headers || {};
    const contentType = (headers["content-type"] || "").split(";")[0].toLowerCase();
    const contentDisp = headers["content-disposition"] || "";

    let filename = "download";
    try {
      const u = new URL(url);
      const last = decodeURIComponent(u.pathname.split("/").filter(Boolean).pop() || "");
      if (last) filename = last;
    } catch {}
    const cdMatch = contentDisp.match(/filename\*?=(?:UTF-8'')?"?([^";]+)/i);
    if (cdMatch) filename = decodeURIComponent(cdMatch[1].replace(/"/g, ""));
    if (!/\.[a-z0-9]{2,}$/i.test(filename) && contentType) {
      const ctExt = contentType.includes("/") ? contentType.split("/")[1] : "bin";
      const safeExt = (ctExt || "bin").replace(/[^a-z0-9]/gi, "");
      filename = `${filename}.${safeExt || "bin"}`;
    }

    const buf = Buffer.from(res.data);
    const fileSizeMB = buf.length / (1024 * 1024);

    const sendAs = async (kind, extra = {}) => {
      return satanic.sendMessage(
        m.chat,
        { [kind]: buf, mimetype: contentType || "application/octet-stream", fileName: filename, ...extra },
        { quoted: fkontak }
      );
    };

    if (contentType.startsWith("image/")) {
      await sendAs("image", { caption: filename });
    } else if (contentType.startsWith("video/")) {
      if (fileSizeMB > 100) {
        await sendAs("document");
      } else {
        await sendAs("video");
      }
    } else if (contentType.startsWith("audio/")) {
      await sendAs("audio");
    } else if (
      contentType === "application/octet-stream" ||
      (contentType.startsWith("application/") && !contentType.includes("json"))
    ) {
      await sendAs("document");
    } else if (
      contentType.startsWith("text/") ||
      contentType.includes("json") ||
      contentType === ""
    ) {
      let body;
      try {
        body = buf.toString("utf8");
      } catch {
        body = "(Tidak dapat mendekode konten teks)";
      }
      await reply(body);
    } else {
      await sendAs("document");
    }

    await satanic.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
  } catch (e) {
    console.error("GET error:", e);
    await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
  }
}
break;

/////// STICKER MENU. ////////
  case 'togif': {
  async function webp2GifFile(path) {
    return new Promise(async (resolve, reject) => {
      try {
        const form = new FormData()
        form.append('new-image-url', '')
        form.append('new-image', fs.createReadStream(path))
        
        const { data: firstPage } = await axios({
          method: 'post',
          url: 'https://ezgif.com/webp-to-mp4',
          data: form,
          headers: {
            'Content-Type': `multipart/form-data; boundary=${form._boundary}`
          }
        })
        const $ = cheerio.load(firstPage)
        const file = $('input[name="file"]').attr('value')
        if (!file) {
          throw new Error('Tidak dapat menemukan file input pada halaman')
        }
        const formDataThen = new FormData()
        formDataThen.append('file', file)
        formDataThen.append('convert', "Convert WebP to MP4!")
        
        const { data: secondPage } = await axios({
          method: 'post',
          url: `https://ezgif.com/webp-to-mp4/${file}`,
          data: formDataThen,
          headers: {
            'Content-Type': `multipart/form-data; boundary=${formDataThen._boundary}`
          }
        })
        const $$ = cheerio.load(secondPage)
        let videoSrc = $$('div#output video source').attr('src')
        if (!videoSrc) videoSrc = $$('#output video source').attr('src')
        if (!videoSrc) videoSrc = $$('video source').attr('src')
        if (!videoSrc) videoSrc = $$('.outfile video source').attr('src')
        if (!videoSrc) {
          const downloadLink = $$('a#download').attr('href')
          if (downloadLink) {
            videoSrc = downloadLink
          } else {
            throw new Error('Tidak dapat menemukan URL video hasil konversi')
          }
        }
        let resultUrl = videoSrc
        if (videoSrc.startsWith('//')) {
          resultUrl = 'https:' + videoSrc
        } else if (!videoSrc.startsWith('http')) {
          resultUrl = 'https://ezgif.com' + (videoSrc.startsWith('/') ? videoSrc : '/' + videoSrc)
        }
        resolve({
          status: true,
          message: "SATANIC HAXOR (NEWCODING)",
          result: resultUrl
        })
        
      } catch (err) {
        reject(err)
      }
    })
  }

  if (!quoted) return reply('⚠️ Balas ke stiker untuk dikonversi ke GIF.')
  
  const mime = (quoted.msg || quoted).mimetype || ''
  if (!/webp/i.test(mime)) return reply(`⚠️ Format tidak didukung. Gunakan perintah *${prefix + command}* pada stiker.`)

  reply('wait be processed')

  let media = null
  try {
    media = await satanic.downloadAndSaveMediaMessage(quoted)
    if (!media || !fs.existsSync(media)) {
      throw new Error('Gagal mendownload media')
    }
    
    const webpToGif = await webp2GifFile(media)
    
    if (!webpToGif || !webpToGif.result) {
      throw new Error('Hasil konversi kosong')
    }
    
    await satanic.sendMessage(m.chat, {
      video: { url: webpToGif.result },
      caption: '✅ Berhasil dikonversi dari stiker ke GIF.',
      gifPlayback: true  // true = tampil sebagai GIF (loop, tanpa suara)
    }, { quoted: fkontak })
    
  } catch (err) {
    console.error('togif error:', err.message || err)
    reply(`❌ Terjadi kesalahan: ${err.message || 'Gagal mengonversi stiker ke GIF.'}`)
  } finally {
    if (media && fs.existsSync(media)) {
      try {
        await fs.unlinkSync(media)
      } catch (e) {
        console.error('Gagal hapus file:', e)
      }
    }
  }
}
break
 case 'toimg': {
				if (!quoted) return reply('Reply Image')
				if (!/webp/.test(mime)) return reply(`Reply sticker dengan caption *${prefix + command}*`)
				let media = await satanic.downloadAndSaveMediaMessage(quoted)
				let ran = await getRandom('.png')
				exec(`ffmpeg -i ${media} ${ran}`, (err) => {
					fs.unlinkSync(media)
					if (err) throw err
					let buffer = fs.readFileSync(ran)
					satanic.sendMessage(m.chat, { image: buffer }, { quoted: fkontak })
					fs.unlinkSync(ran)
				})
			}		
			break;		 
case 'toptv': {		
				let q = m.quoted ? m.quoted : m;
				if (!/video|audio/.test(mime)) return reply(`Hmm, Kamu harus balas video atau voice note yang mau dijadikan MP3 ya, jangan lupa pakai caption *${prefix + command}* 😉`);
				try {
					let media = await q.download();
					let dataVideo = {
						ptvMessage: m.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage
					};
					satanic.relayMessage(m.chat, dataVideo, {});
				} catch (error) {
					console.log(error);
					reply("Aduh, ada yang salah nih kak 😟. Coba lagi ya!");
				}
			}
			
			break
case 'toaud': case 'tomp3': case 'toaudio': {
            if (!/video/.test(mime) && !/audio/.test(mime)) return reply(`Send/Reply Video/Audio You Want to Use as Audio With Caption ${prefix + command}`)
            if (!quoted) return reply(`Send/Reply Video/Audio You Want to Use as Audio With Caption ${prefix + command}`)
            reply(mess.wait)
            let media = await quoted.download()
            let { toAudio } = require('./lib/converter')
            let audio = await toAudio(media, 'mp4')
            satanic.sendMessage(m.chat, {audio: audio, mimetype: 'audio/mpeg'}, { quoted : m })
            }
break
            case 'tovn': case 'toptt': {
            if (!/video/.test(mime) && !/audio/.test(mime)) return reply(`Reply Video/Audio That You Want To Be VN With Caption ${prefix + command}`)
            if (!quoted) return reply(`Reply Video/Audio That You Want To Be VN With Caption ${prefix + command}`)
            reply(mess.wait)
            let media = await quoted.download()
            let { toPTT } = require('./lib/converter')
            let audio = await toPTT(media, 'mp4')
            satanic.sendMessage(m.chat, {audio: audio, mimetype:'audio/mpeg', ptt:true }, {quoted:fkontak})
            }
            break
  case 's': case 'sticker': case 'stiker': {
				if (!quoted) return reply(`Kirim atau balas gambar/video/gif dengan caption ${prefix + command}\nDurasi video 1-9 detik ya!`);
				if (!mime) return reply(`Kirim atau balas gambar/video/gif dengan caption ${prefix + command}\nDurasi video 1-9 detik ya!`);
				if (/image/.test(mime)) {
					
					let media = await satanic.downloadAndSaveMediaMessage(quoted);
					await satanic.sendImageAsSticker(m.chat, media, m, { packname: global.packname, author: global.author });
				} else if (/video/.test(mime)) {
					if ((quoted.msg || quoted).seconds > 9) return reply(`Durasi video terlalu panjang! 🕒 Kirim video dengan durasi 1-9 detik ya!`);

					let media = await satanic.downloadAndSaveMediaMessage(quoted);
					await satanic.sendVideoAsSticker(m.chat, media, m, { packname: global.packname, author: global.author });
				} else {
					reply(`Kirim atau balas gambar/video/gif dengan caption ${prefix + command}\nDurasi video 1-9 detik ya!`);
				}
			}		
			break;
case 'swm': case 'steal': case 'stickerwm': case 'take': {
    if (!quoted) return reply(`Kirim atau balas gambar/video/gif dengan caption ${prefix + command}\nDurasi video 1-9 detik ya!`);
    if (!mime) return reply(`Kirim atau balas gambar/video/gif dengan caption ${prefix + command}\nDurasi video 1-9 detik ya!`);
    
    // Ambil text dari pesan utama, bukan args
    const fullText = m.body || "";
    // Hapus prefix dan command dari text
    const textAfterCommand = fullText.replace(new RegExp(`^${prefix}${command}\\s*`), "").trim();
    
    // Split berdasarkan pipe (|)
    const swn = textAfterCommand || "";
    const pcknm = swn.split("|")[0]?.trim() || "";
    const atnm = swn.split("|")[1]?.trim() || "";
    
    // Default values jika tidak ada input
    const packName = pcknm || "Sticker";
    const authorName = atnm || "Bot";
    
    if (m.quoted.isAnimated === true) {
        let media = await satanic.downloadAndSaveMediaMessage(quoted);
        satanic.sendMessage(m.chat, { 
            sticker: media 
        }, m, { 
            packname: packName, 
            author: authorName 
        });
    } else if (/image/.test(mime)) {
        let media = await satanic.downloadAndSaveMediaMessage(quoted);
        await satanic.sendImageAsSticker(m.chat, media, m, { 
            packname: packName, 
            author: authorName 
        });
    } else if (/video/.test(mime)) {
        if ((quoted.msg || quoted).seconds > 9) return reply('Video terlalu panjang, maksimal 9 detik ya! ⏳');
        let media = await satanic.downloadAndSaveMediaMessage(quoted);
        await satanic.sendVideoAsSticker(m.chat, media, m, { 
            packname: packName, 
            author: authorName 
        });
    } else {
        reply(`Kirim foto/video untuk dipakai ya, kak!`);
    }
    break;
}	

case 'tts': case 'texttospeech': case 'say':
case 'ttsgoku': case 'ttseminem': case 'ttsmickey':
case 'ttsnahida': case 'ttselon': case 'ttsoptimus': {
    const _ttsT=text?.trim();
    if (!_ttsT) return reply(`🎤 *ᴛᴛs*\n\nVoice tersedia: tts, ttsgoku, ttseminem, ttsmickey, ttsnahida, ttselon\nFormat: \`${prefix}tts <teks>\`\n\nContoh: \`${prefix}ttsgoku Hai semuanya!\``);
    const _ttsVK={ttsgoku:'goku',ttseminem:'eminem',ttsmickey:'mickey_mouse',ttsnahida:'nahida',ttselon:'elon_musk',ttsoptimus:'optimus_prime'};
    const _ttsVoice=_ttsVK[command]||null;
    satanic.sendMessage(m.chat,{react:{text:'🎤',key:m.key}});
    await reply(`⏳ *Generating ${_ttsVoice||'random'} voice...*\n_Teks: ${_ttsT}_`);
    if (!fs.existsSync('./temp')) fs.mkdirSync('./temp',{recursive:true});
    const _ttsTs=Date.now(),_ttsWav=`./temp/tts_${_ttsTs}.wav`,_ttsOgg=`./temp/tts_${_ttsTs}.ogg`;
    try {
        const _ttsR=await axios.get(`https://api.emiliabot.my.id/tools/text-to-speech?text=${encodeURIComponent(_ttsT)}`,{timeout:60000});
        if (!_ttsR.data?.status||!_ttsR.data?.result?.length) throw new Error('API tidak merespon atau kosong');
        const _ttsVoices=_ttsR.data.result.filter(v=>!v.error);
        if (!_ttsVoices.length) throw new Error('Semua model TTS error');
        let _ttsObj=_ttsVoice?_ttsVoices.find(v=>v[_ttsVoice]):null;
        if (!_ttsObj) _ttsObj=_ttsVoices[Math.floor(Math.random()*_ttsVoices.length)];
        const _ttsAK=Object.keys(_ttsObj).find(k=>!['channel_id','voice_name','voice_id'].includes(k)&&String(_ttsObj[k]).startsWith('https://'));
        if (!_ttsAK) throw new Error('Audio URL tidak ditemukan dari API');
        const _ttsAR=await axios.get(_ttsObj[_ttsAK],{responseType:'arraybuffer',timeout:30000});
        fs.writeFileSync(_ttsWav,Buffer.from(_ttsAR.data));
        execSync(`ffmpeg -y -i "${_ttsWav}" -c:a libopus -b:a 64k "${_ttsOgg}"`,{stdio:'ignore',timeout:30000});
        await satanic.sendMessage(m.chat,{audio:fs.readFileSync(_ttsOgg),mimetype:'audio/ogg; codecs=opus',ptt:true},{quoted:fkontak});
        satanic.sendMessage(m.chat,{react:{text:'✅',key:m.key}});
    } catch(e){satanic.sendMessage(m.chat,{react:{text:'❌',key:m.key}});reply(`❌ *TTS Gagal!*\n\n${e.message.slice(0,150)}`);}
    finally{try{if(fs.existsSync(_ttsWav))fs.unlinkSync(_ttsWav);}catch{}try{if(fs.existsSync(_ttsOgg))fs.unlinkSync(_ttsOgg);}catch{}}}
    break;   
case 'ttsbella':    
case 'ttsjokowi':
case 'ttsprabowo':   
case 'ttsechilling':
case 'ttsmegawati': {
    try {
        let text = args.join(' ');
        if (!text && m.quoted?.text) text = m.quoted.text;
        if (!text) {
            m.reply("Masukkan kata");
            return;
        }

        await satanic.sendMessage(m.chat, { 
            react: { text: '⏱️', key: m.key } 
        });

        let voice = command.replace('tts', '');

        const { data } = await axios.get(
            'https://api.termai.cc/api/text2speech/elevenlabs',
            {
                params: {
                    text: text,
                    key: 'Bell409',
                    voice: voice,
                    speed: 1,
                },
                responseType: 'arraybuffer'
            }
        );

        await satanic.sendMessage(m.chat,{
                    audio: data,
                    mimetype:'audio/mpeg',
                    ptt:false
                },{quoted:fkontak});

        await satanic.sendMessage(m.chat, { 
            react: { text: '✅', key: m.key } 
        });

    } catch (error) {
        await satanic.sendMessage(m.chat, { 
            react: { text: '❌', key: m.key } 
        });
        m.reply(`Error: ${error.message}`);
    }
}
break;
case 'bass': case 'blown': case 'deep': case 'earrape': case 'fast': case 'fat': case 'nightcore': case 'reverse': case 'robot': case 'slow': case 'smooth': case 'squirrel':
    try {
        let set;
        if (/bass/.test(command)) set = '-af equalizer=f=54:width_type=o:width=2:g=20';
        else if (/blown/.test(command)) set = '-af acrusher=.1:1:64:0:log';
        else if (/deep/.test(command)) set = '-af atempo=4/4,asetrate=44500*2/3';
        else if (/earrape/.test(command)) set = '-af volume=12';
        else if (/fast/.test(command)) set = '-filter:a "atempo=1.63,asetrate=44100"';
        else if (/fat/.test(command)) set = '-filter:a "atempo=1.6,asetrate=22100"';
        else if (/nightcore/.test(command)) set = '-filter:a atempo=1.06,asetrate=44100*1.25';
        else if (/reverse/.test(command)) set = '-filter_complex "areverse"';
        else if (/robot/.test(command)) set = '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75"';
        else if (/slow/.test(command)) set = '-filter:a "atempo=0.7,asetrate=44100"';
        else if (/smooth/.test(command)) set = '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"';
        else if (/squirrel/.test(command)) set = '-filter:a "atempo=0.5,asetrate=65100"';
        if (set) {
            if (/audio/.test(mime)) {
                await reply(mess.wait);
                let media = await satanic.downloadAndSaveMediaMessage(quoted);
                let ran = getRandom('.mp3');
                console.log(`Running ffmpeg command: ffmpeg -i ${media} ${set} ${ran}`);
                exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
                    fs.unlinkSync(media);
                    if (err) {
                        console.error(`ffmpeg error: ${err}`);
                        return reply(err);
                    }                 
                    let buff = fs.readFileSync(ran);
                    satanic.sendMessage(m.chat, { audio: buff, mimetype: 'audio/mpeg' }, { quoted: fkontak });
                    fs.unlinkSync(ran);
                });
            } else {
                reply(`Reply to the audio you want to change with a caption *${prefix + command}*`);
            }
        } else {
            reply('Invalid command');
        }
    } catch (e) {
        reply(e);
    }
break    		           
case 'brat':
case 'bratgambar':
case 'bratimg': {
  if (!text) return reply('teksnya')
  const brat = `https://free-restapi.biz.id/api/brat?text=${encodeURIComponent(text)}&apikey=${global.sakey}`
  const response = await axios.get(brat, { responseType: 'arraybuffer' })
  await satanic.sendImageAsSticker(m.chat, response.data, m, { packname: global.packname })
}
break

case "emojimix":
        {
          let [emoji1, emoji2] = text.split`+`;
          if (!emoji1) {
            return reply(`Contoh : ${prefix + command} 😅+🤔`);
          }
          if (!emoji2) {
            return reply(`Contoh : ${prefix + command} 😅+🤔`);
          }
          let anumojimix = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`);
          for (let res of anumojimix.results) {
            let encmedia = await satanic.sendImageAsSticker(m.chat, res.url, m, {
              packname: global.packname,
              author: global.author,
              categories: res.tags
            });
          }
        }
        break;
case 'bratbahlil':
case 'bahlil':
case 'bratlil': {
 
    if (!text) return satanic.sendMessage(m.chat, { text: `❌ Masukkan teks!\nContoh: .bratbahlil Hayolo` }, { quoted: fkontak });

    await satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });

    const url = `https://api.ourin.my.id/api/bratbahlil?text=${encodeURIComponent(text)}`;
    const response = await axios.get(url, { responseType: 'arraybuffer' });
    
    await satanic.sendImageAsSticker(m.chat, response.data, m, { packname: global.packname, author: global.author });
}
break;

// BRAT CEWE
case 'bratcewe':
case 'cewebrat':
case 'bratgirl': {

    if (!text) return satanic.sendMessage(m.chat, { text: `❌ Masukkan teks!\nContoh: .bratcewe Hayolo` }, { quoted: fkontak });

    await satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });

    const url = `https://api.deline.web.id/maker/cewekbrat?text=${encodeURIComponent(text)}`;
    const response = await axios.get(url, { responseType: 'arraybuffer' });
    
    await satanic.sendImageAsSticker(m.chat, response.data, m, { packname: global.packname, author: global.author });
}
break;
case 'carbonify':
if (!text) return reply(`Example: ${prefix + command} story wa anime`);   
    try {
        const response = await fetch("https://carbonara.solopov.dev/api/cook", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ "code": text })
        });

        if (!response.ok) throw new Error(`API error: ${response.status}`);

        const blob = await response.blob();
        const arrayBuffer = await blob.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);

        await satanic.sendMessage(m.chat, { 
            image: buffer 
        }, { 
            quoted: fkontak 
        });
        
    } catch (error) {
        console.error('Carbonify error:', error);
        reply('❌ Gagal membuat gambar carbon. Coba lagi nanti.');
}
 break;
case 'brathd':
case 'hdbrat':
case 'bratkualitas': {
    if (!text) return satanic.sendMessage(m.chat, { text: `❌ Masukkan teks!\nContoh: .brathd Hayolo` }, { quoted: fkontak });

    await satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });

    const url = `https://api.ourin.my.id/api/brat-hd?text=${encodeURIComponent(text)}`;
    const response = await axios.get(url, { responseType: 'arraybuffer' });
    
    await satanic.sendImageAsSticker(m.chat, response.data, m, { packname: global.packname, author: global.author });
}
break;

// BRAT PATRICK
case 'bratpatrick':
case 'patrickbrat':
case 'bratspongebob': {

    if (!text) return satanic.sendMessage(m.chat, { text: `❌ Masukkan teks!\nContoh: .bratpatrick Hayolo` }, { quoted: fkontak });

    await satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });

    const url = `https://api.ourin.my.id/api/bratpatrick?text=${encodeURIComponent(text)}`;
    const response = await axios.get(url, { responseType: 'arraybuffer' });
    
    await satanic.sendImageAsSticker(m.chat, response.data, m, { packname: global.packname, author: global.author });
}
break;
case 'bratsquidward':
case 'squidwardbrat':
case 'bratcumi': {
    if (!text) return satanic.sendMessage(m.chat, { text: `❌ Masukkan teks!\nContoh: .bratsquidward Hayolo` }, { quoted: fkontak });
    await satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });
    const url = `https://api.ourin.my.id/api/bratsquidward?text=${encodeURIComponent(text)}`;
    const response = await axios.get(url, { responseType: 'arraybuffer' });
    
    await satanic.sendImageAsSticker(m.chat, response.data, m, { packname: global.packname, author: global.author });
}
break;
case 'bratanime':
case 'animebrat': {
    let text = m.text.trim();
    if (!text) return satanic.sendMessage(m.chat, { text: `❌ Masukkan teks!\nContoh: .bratanime Hayolo` }, { quoted: fkontak });

    await satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });

    const url = `https://api.nexray.web.id/maker/bratanime?text=${encodeURIComponent(text)}`;
    const response = await axios.get(url, { responseType: 'arraybuffer' });
    
    await satanic.sendImageAsSticker(m.chat, response.data, m, { packname: global.packname, author: global.author });
}
break;
case 'ttp':
case 'attp': {
    if (!text) return satanic.sendMessage(m.chat, { text: `❌ Masukkan teks!\nContoh: .bratsquidward Hayolo` }, { quoted: fkontak });
    await satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });
    const url = `https://api.nexray.eu.cc/maker/${command}?text=${encodeURIComponent(text)}`;
    const response = await axios.get(url, { responseType: 'arraybuffer' });
    
    await satanic.sendImageAsSticker(m.chat, response.data, m, { packname: global.packname, author: global.author });
}
break;
case 'pornhub':
case 'comic':
case 'wolf-galaxy':
case 'write-grafitty':
case 'wetglass':
case 'typogrpahy':
case 'pixel-glitch':
case 'pavement':
case 'painting':
case 'naruto':
case 'mascot':
case 'marvel':
case 'glitch':
case 'devil-wings':
case 'dragonball':
case 'foggy-glass':
case 'bear':
case 'blackpink':
case 'avengers': {
    if (!text) return satanic.sendMessage(m.chat, { text: `❌ Masukkan teks!\nContoh: .bratsquidward Hayolo` }, { quoted: fkontak });
    await satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });
    const url = `https://api.nexray.eu.cc/textpro/${command}?text=${encodeURIComponent(text)}`;
    const response = await axios.get(url, { responseType: 'arraybuffer' });
    
    await satanic.sendImageAsSticker(m.chat, response.data, m, { packname: global.packname, author: global.author });
}
break;

case 'pakustad':
case 'ustad':
case 'ustadz': {
    if (!text) return satanic.sendMessage(m.chat, { text: `❌ Masukkan teks!\nContoh: .pakustad Jangan putus asa` }, { quoted: fkontak });

    await satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });
    
    const apiUrl = `https://api.cuki.biz.id/api/canvas/ustadz?apikey=cuki-x&text=${encodeURIComponent(text)}`;
    const { data } = await axios.get(apiUrl);
    
    await satanic.sendMessage(m.chat, { image: { url: data.results.url }, caption: `“${text}”` }, { quoted: fkontak });
}
break;
	case 'nikparse':
	case 'ceknik': {
    if (!text) return reply(`Contoh:\n${prefix + command} 181005415784847`);
    const nik = text.trim();
    if (nik.length !== 16 || !/^\d+$/.test(nik)) {
        return reply("❌ NIK harus 16 digit angka!");
    }
    satanic.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    try {
        const api = `https://api.siputzx.my.id/api/tools/nik-checker?nik=${nik}`;
        const res = await fetchJson(api);
        if (!res.status || !res.data) {
            return reply("❌ Tidak dapat mengambil data dari server!");
        }

        const d = res.data.data;     
        const meta = res.data.metadata; 
        const lhp = res.data.data_lhp?.[0]; 

        let teks = `*🔍 HASIL CEK NIK*\n`;
        teks += `──────────────────────\n`;
        teks += `👤 *Nama*: ${d.nama}\n`;
        teks += `🆔 *NIK*: ${res.data.nik}\n`;
        teks += `👨‍⚕️ *Jenis Kelamin*: ${d.kelamin}\n`;
        teks += `🎂 *Tanggal Lahir*: ${d.tempat_lahir}\n`;
        teks += `📅 *Usia*: ${d.usia}\n`;
        teks += `⭐ *Zodiak*: ${d.zodiak}\n`;
        teks += `🎉 *Ultah Mendatang*: ${d.ultah_mendatang}\n`;
        teks += `🗓️ *Pasaran*: ${d.pasaran}\n\n`;

        teks += `*📍 ALAMAT & WILAYAH*\n`;
        teks += `• Provinsi: ${d.provinsi}\n`;
        teks += `• Kabupaten/Kota: ${d.kabupaten}\n`;
        teks += `• Kecamatan: ${d.kecamatan}\n`;
        teks += `• Kelurahan: ${d.kelurahan}\n`;
        teks += `• TPS: ${d.tps}\n`;
        teks += `• Alamat: ${d.alamat}\n\n`;

        teks += `*🌍 KOORDINAT*\n`;
        teks += `• Lat: ${d.koordinat.lat}\n`;
        teks += `• Lon: ${d.koordinat.lon}\n\n`;

        teks += `*📌 METADATA*\n`;
        teks += `• Kode Wilayah: ${meta.kode_wilayah}\n`;
        teks += `• Nomor Urut: ${meta.nomor_urut}\n`;
        teks += `• Kategori Usia: ${meta.kategori_usia}\n`;
        teks += `• Jenis Wilayah: ${meta.jenis_wilayah}\n`;
        teks += `• Metode: ${meta.metode_pencarian}\n\n`;

        if (lhp) {
            teks += `*🗂️ DATA LHP*\n`;
            teks += `• Nama: ${lhp.nama}\n`;
            teks += `• Kecamatan: ${lhp.kecamatan}\n`;
            teks += `• Kelurahan: ${lhp.kelurahan}\n`;
            teks += `• TPS: ${lhp.tps}\n`;
            teks += `• Sumber: ${lhp.source}\n`;
            teks += `• Alamat: ${lhp.alamat}\n`;
        }
        reply(teks)
        satanic.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    } catch (e) {
        console.log(e);
        reply("❌ Terjadi kesalahan server!");
    }
}
break;
case 'fakeff':
case 'lobyff':
case 'lobbyff': {
   
    if (!text || !text.includes('|')) {
        return reply(`🎮 *FREE FIRE LOBBY MAKER*

Contoh:
${prefix + command} 1|Jagoan FF
${prefix + command} random|Jagoan FF

Pilihan template: 1 - 22 atau ketik *random*`)
    }

    let [numStr, name] = text.split('|').map(v => v.trim())
    numStr = numStr.toLowerCase()

    const imageUrls = {
        1: 'https://cloud-fukushima.vercel.app/uploader/8fjhd6ftps.jpg',
        2: 'https://cloud-fukushima.vercel.app/uploader/oz8hb4ow75.jpg',
        3: 'https://cloud-fukushima.vercel.app/uploader/tvz1cie8df.jpg',
        4: 'https://cloud-fukushima.vercel.app/uploader/yo9sg4vmo3.jpg',
        5: 'https://i.ibb.co/twtSvQXv/image.jpg',
        6: 'https://i.ibb.co/n80Bc1wV/image.jpg',
        7: 'https://i.ibb.co/mCwmt019/image.jpg',
        8: 'https://i.ibb.co/JwG60TwF/image.jpg',
        9: 'https://i.ibb.co/zWNLw6bV/image.jpg',
        10: 'https://i.ibb.co/d4DvnHw6/image.jpg',
        11: 'https://i.ibb.co/hxMGbx9v/image.jpg',
        12: 'https://i.ibb.co/jvd5xfvK/image.jpg',
        13: 'https://i.ibb.co/KxTQ0r0x/image.jpg',
        14: 'https://i.ibb.co/rRyxvrJW/image.jpg',
        15: 'https://i.ibb.co/PG5jwG6S/image.jpg',
        16: 'https://i.ibb.co/MDdH7kjG/image.jpg',
        17: 'https://i.ibb.co/6cnHvL31/image.jpg',
        18: 'https://i.ibb.co/dwg4CGdf/image.jpg',
        19: 'https://i.ibb.co/pvx1PZyW/image.jpg',
        20: 'https://i.ibb.co/kVkbxhwg/image.jpg',
        21: 'https://i.ibb.co/rK8ZTPbt/image.jpg',
        22: 'https://i.ibb.co/vC3p8NjP/image.jpg'
    }

    const max = Object.keys(imageUrls).length
    let num

    if (numStr === 'random') {
        num = Math.floor(Math.random() * max) + 1
    } else {
        num = parseInt(numStr)
        if (isNaN(num) || num < 1 || num > max) {
            return reply(`❌ Template tidak valid!\nPilih 1 - ${max} atau random`)
        }
    }

    await satanic.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })

    try {
        const imgUrl = imageUrls[num]
        const temp = `./temp_${Date.now()}.jpg`
        const out = `./out_${Date.now()}.jpg`
        const font = './lib/AGENCYB.TTF'

        if (!fs.existsSync(font)) {
            await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
            return reply('❌ Font AGENCYB.TTF tidak ditemukan di folder /lib')
        }

        // PERBAIKAN: Menggunakan Axios
        const axios = require('axios')
        const response = await axios({
            method: 'get',
            url: imgUrl,
            responseType: 'arraybuffer'
        })
        
        fs.writeFileSync(temp, Buffer.from(response.data))

        let fontSize
        if (name.length <= 6) fontSize = 'w*0.055'
        else if (name.length <= 10) fontSize = 'w*0.045'
        else if (name.length <= 15) fontSize = 'w*0.038'
        else fontSize = 'w*0.030'

        const safeText = name.replace(/'/g, "\\'")
        const safeFont = font.replace(/\\/g, '/')

        const cmd = `ffmpeg -i "${temp}" -vf "drawtext=fontfile='${safeFont}':text='${safeText}':x=(w-text_w)/2:y=h*0.80-(text_h/2):fontsize=${fontSize}:fontcolor=yellow:shadowcolor=black:shadowx=3:shadowy=3" "${out}"`

        exec(cmd, async (err) => {
            if (err) {
                console.error(err)
                if (fs.existsSync(temp)) fs.unlinkSync(temp)
                await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
                return reply('❌ FFMPEG error! Pastikan sudah terinstall.')
            }

            await satanic.sendMessage(m.chat, {
                image: fs.readFileSync(out),
                caption: `🎮 *FREE FIRE LOBBY*

👤 Name : ${name.toUpperCase()}
🖼️ Template : ${num}`
            }, { quoted: fkontak })

            if (fs.existsSync(temp)) fs.unlinkSync(temp)
            if (fs.existsSync(out)) fs.unlinkSync(out)

            await satanic.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
        })

    } catch (e) {
        console.error(e)
        await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
        reply('❌ Terjadi error saat proses gambar!')
    }
}
break

case 'qc': {
    if (!text) return reply('teksnya')
    
    // Ambil pushName dari pengirim atau dari pesan yang di-quote
    const senderJid = m.quoted ? m.quoted.sender : m.sender;
    const username = m.quoted ? m.quoted.pushName : m.pushName || senderJid.split('@')[0];
    
    // Ambil avatar
    const avatar = await satanic.profilePictureUrl(senderJid, "image")
        .catch(() => 'https://8030.us.kg/file/P2LpaOHxWlJt.jpg');
    
    const qchat = `https://free-restapi.biz.id/api/qc?text=${encodeURIComponent(text)}&name=${encodeURIComponent(username)}&ppurl=${encodeURIComponent(avatar)}&apikey=${global.sakey}`;
    const response = await axios.get(qchat, { responseType: 'arraybuffer' });
    await satanic.sendImageAsSticker(m.chat, response.data, m, { packname: global.packname });
}
break;
case 'fakewafat': {
    satanic.sendMessage(m.chat, { react: { text: '⚰️', key: m.key } });
    try {
        const quoted = m.quoted ? m.quoted : m;
        const mime = (quoted.msg || quoted).mimetype || '';
        let fotoUrl = "https://telegra.ph/file/default.jpg";
        if (/image/.test(mime)) {
            let media = await quoted.download();
            const form = new FormData();
            form.append('files[]', media, { filename: 'image.jpg' });
            const uploadRes = await axios.post('https://pone.rs/upload.php', form, {
                headers: {
                    ...form.getHeaders(),
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
                    'Referer': 'https://pone.rs/',
                    'Origin': 'https://pone.rs'
                },
                maxBodyLength: Infinity,
                maxContentLength: Infinity
            });
            if (uploadRes.data?.success && uploadRes.data?.files?.[0]?.url) {
                fotoUrl = uploadRes.data.files[0].url.replace(/\\\//g, '/');
            }
        }
        let parts = text ? text.split("|").map(v => v.trim()) : [];
        const [nama = "", lahir = "", wafat = ""] = parts;
        if (!nama || !lahir || !wafat) {
            return reply(`⚠️ Format salah!\n\nGunakan format:\n${prefix + command} Nama|Tanggal Lahir|Tanggal Wafat\n\nContoh:\n${prefix + command} John Doe|01-01-1990|01-01-2024`);
        }
        const params = new URLSearchParams({
            apikey: global.sakey,
            fotourl: fotoUrl,
            nama: nama,
            lahir: lahir,
            wafat: wafat
        });
        const response = await fetch(`https://free-restapi.biz.id/api/fakewafat?${params}`);
        const buffer = Buffer.from(await response.arrayBuffer());
        await satanic.sendMessage(m.chat, {
            image: buffer,
            caption: `⚰️ *Fake Wafat Berhasil Dibuat!*\n\n👤 Nama: *${nama}*\n📅 Lahir: *${lahir}*\n🕊️ Wafat: *${wafat}*`
        }, { quoted: fkontak });
    } catch (e) {
        console.error('Error fakewafat:', e);
        reply(`❌ Error:\n${e.message}`);
    }
}
break;
case 'ttqc': {
    try {
        if (!text) return reply('❌ *Masukkan teks!*\n\n📝 *Contoh:* .ttqc kamu bodoh');
        
        await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        const username = m.pushName || 'User';
        
        let avatar = global.thumbnail || '';
        try {
            const ppUser = await satanic.profilePictureUrl(m.sender, 'image').catch(() => null);
            if (ppUser) {
                avatar = ppUser;
            }
        } catch (e) {}
        
        const apiUrl = `https://free-restapi.biz.id/api/ttqc?text=${encodeURIComponent(text)}&username=${encodeURIComponent(username)}&avatar=${encodeURIComponent(avatar)}&apikey=${global.sakey}`;
        
        const response = await axios({
            method: 'get',
            url: apiUrl,
            responseType: 'arraybuffer',
            timeout: 30000
        });
        
        const imageBuffer = Buffer.from(response.data);
        
        await satanic.sendMessage(m.chat, {
            image: imageBuffer,
            caption: `✅ *Done!*\n📝 "${text}"\n👤 ${username}`
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (e) {
        console.error('Error in case:', e);
        reply('❌ *Error:* ' + (e.message || 'Terjadi kesalahan'));
    }
}
break;
case 'ttqc2': {
    try {
        if (!text) return reply('❌ *Masukkan teks!*\n\n📝 *Contoh:* .ttqc2 kamu bodoh');
        
        await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        const username = m.pushName || 'User';
        
        let avatar = global.thumbnail || '';
        let url = global.thumbnail || '';
        
        const quoted = m.quoted ? m.quoted : m;
        const mime = (quoted.msg || quoted).mimetype || '';
        
        if (/image/.test(mime)) {
            try {
                let media = await quoted.download();
                const form = new FormData();
                form.append('files[]', media, { filename: 'image.jpg' });
                const uploadRes = await axios.post('https://pone.rs/upload.php', form, {
                    headers: {
                        ...form.getHeaders(),
                        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
                        'Referer': 'https://pone.rs/',
                        'Origin': 'https://pone.rs'
                    },
                    maxBodyLength: Infinity,
                    maxContentLength: Infinity
                });
                if (uploadRes.data?.success && uploadRes.data?.files?.[0]?.url) {
                    url = uploadRes.data.files[0].url.replace(/\\\//g, '/');
                }
            } catch (e) {
                console.log('Gagal upload gambar:', e);
            }
        } else {
            try {
                const ppUser = await satanic.profilePictureUrl(m.sender, 'image').catch(() => null);
                if (ppUser) {
                    avatar = ppUser;
                }
            } catch (e) {}
        }
        
        const apiUrl = `https://free-restapi.biz.id/api/ttqc2?text=${encodeURIComponent(text)}&username=${encodeURIComponent(username)}&avatar=${encodeURIComponent(avatar)}&url=${encodeURIComponent(url)}&apikey=${global.sakey}`;
        
        const response = await axios({
            method: 'get',
            url: apiUrl,
            responseType: 'arraybuffer',
            timeout: 30000
        });
        
        const imageBuffer = Buffer.from(response.data);
        
        await satanic.sendMessage(m.chat, {
            image: imageBuffer,
            caption: `✅ *Done!*\n📝 "${text}"\n👤 ${username}`
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (e) {
        console.error('Error in case:', e);
        reply('❌ *Error:* ' + (e.message || 'Terjadi kesalahan'));
    }
}
break;
case 'bratvid':
case 'bratvideo': {
  if (!text) return reply('Mana Text Nya')
  var image = `https://free-restapi.biz.id/api/bratvid?text=${encodeURIComponent(text)}&apikey=${global.sakey}`
  const response = await axios.get(image, { responseType: 'arraybuffer' })
  await satanic.sendImageAsSticker(m.chat, response.data, m, { packname: foother })
  satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
}
break
case 'qcwa': {
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    const isImage = /image/.test(mime);
    
    if (!text && !isImage) {
        return reply(`❌ Masukkan pesan atau kirim/reply gambar!\n\nContoh:\n.qcwa Halo\n.qcwa Halo|nama|tag|phone\n.qcwa (dengan gambar)`);
    }
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let userText = text || '';
        let customUsername = '';
        let customTag = '';
        let customPhone = '';
        let imageUrl = '';
        
        if (userText && userText.includes('|')) {
            const parts = userText.split('|');
            userText = parts[0] || '';
            customUsername = parts[1] || '';
            customTag = parts[2] || '';
            customPhone = parts[3] || '';
        }
        
        const username = customUsername || m.pushName || 'User';
        const tag = customTag || username.toLowerCase().replace(/\s/g, '');
        let phone = customPhone || m.sender?.split('@')[0] || '628123456789';
        
        if (isImage) {
            const media = await quoted.download();
            
            const form = new FormData();
            form.append('files[]', media, { filename: 'image.jpg' });
            const uploadRes = await axios.post('https://pone.rs/upload.php', form, {
                headers: {
                    ...form.getHeaders(),
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
                    'Referer': 'https://pone.rs/',
                    'Origin': 'https://pone.rs'
                },
                maxBodyLength: Infinity,
                maxContentLength: Infinity
            });
            
            if (!uploadRes.data?.success || !uploadRes.data?.files?.[0]?.url) {
                await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return reply(`❌ Gagal upload gambar! Silahkan coba lagi.`);
            }
            
            imageUrl = uploadRes.data.files[0].url;
        }
        
        let avatarUrl = '';
        if (!customUsername && !customTag && !customPhone) {
            try {
                const ppUrl = await satanic.profilePictureUrl(m.sender, 'image');
                if (ppUrl) {
                    avatarUrl = ppUrl;
                }
            } catch (err) {
                console.log('Gagal mengambil foto profil:', err);
            }
        }
        
        let apiUrl = `https://free-restapi.biz.id/api/qcwa?apikey=${global.sakey}`;
        if (userText) apiUrl += `&text=${encodeURIComponent(userText)}`;
        apiUrl += `&username=${encodeURIComponent(username)}`;
        
        const phoneClean = phone.replace(/[^0-9]/g, '');
        apiUrl += `&phone=${encodeURIComponent(phoneClean)}`;
        
        apiUrl += `&tag=${encodeURIComponent(tag)}`;
        if (avatarUrl) apiUrl += `&ppUrl=${encodeURIComponent(avatarUrl)}`;
        if (imageUrl) apiUrl += `&imUrl=${encodeURIComponent(imageUrl)}`;
        
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        const formattedPhone = phoneClean.replace(/(\d{2})(\d{3})(\d{4})(\d{4})/, '+$1 $2-$3-$4');
        
        let caption = `✅ QR Code WhatsApp berhasil dibuat!\n\n👤 Username: ${username}\n📱 Phone: ${formattedPhone || phoneClean}\n🏷️ Tag: ${tag}`;
        if (userText) caption += `\n📝 Pesan: ${userText}`;
        if (imageUrl) caption += `\n🖼️ Gambar: Terdeteksi`;
        if (customUsername || customTag || customPhone) caption += `\n📌 Mode: Manual`;
        
        await satanic.sendMessage(m.chat, {
            image: Buffer.from(response.data),
            caption: caption
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error('Error QCWA:', err);
        reply('❌ Terjadi kesalahan saat membuat QR Code WhatsApp.');
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;


/////// BATAS STICKER MENU. ////////
//////// STALK MENU /////////
case 'stalkig2':
case 'igstalk2': {
  satanic.sendMessage(m.chat, { react: { text: `📸`, key: m.key } });
  
  if (!text) return reply('masukin username ')
  
  let apiUrl = `https://free-restapi.biz.id/api/instagramstalker?username=${encodeURIComponent(text)}&apikey=${global.sakey}`;
  
  let response = await fetch(apiUrl);
  let data = await response.json();
  
  if (data.status !== 200 || !data.result) {
    return satanic.sendMessage(m.chat, { text: '❌ Username tidak ditemukan atau terjadi kesalahan.' });
  }
  
  let profile = data.result.profile;
  let recentPosts = data.result.recent_posts || [];
  
  let resultText = `*📸 INSTAGRAM STALKER*\n\n`;
  resultText += `*👤 Username:* ${profile.username}\n`;
  resultText += `*📛 Nama:* ${profile.full_name}\n`;
  resultText += `*📝 Bio:* ${profile.bio || '-'}\n`;
  resultText += `*📊 Postingan:* ${profile.formatted_posts}\n`;
  resultText += `*👥 Followers:* ${profile.formatted_followers}\n`;
  resultText += `*👣 Following:* ${profile.formatted_following}\n`;
  resultText += `*🔒 Private:* ${profile.is_private ? 'Ya' : 'Tidak'}\n`;
  resultText += `*✅ Verifikasi:* ${profile.is_verified ? 'Ya' : 'Tidak'}\n\n`;
  
  if (recentPosts.length > 0) {
    resultText += `*🖼️ 3 Postingan Terbaru:*\n\n`;
    for (let i = 0; i < Math.min(recentPosts, 3); i++) {
      let post = recentPosts[i];
      resultText += `${i+1}. *Tipe:* ${post.type}\n`;
      resultText += `   *Caption:* ${post.caption.substring(0, 100)}${post.caption.length > 100 ? '...' : ''}\n`;
      resultText += `   *❤️ Likes:* ${post.formatted_likes}\n`;
      resultText += `   *💬 Comments:* ${post.formatted_comments}\n`;
      resultText += `   *🔗 Link:* ${post.post_url}\n\n`;
    }
  }
  if (profile.profile_pic_url) {
    await satanic.sendMessage(m.chat, {
      image: { url: profile.profile_pic_url },
      caption: resultText
    });
  } else {
    await satanic.sendMessage(m.chat, { text: resultText });
  }
}
break
case 'igsearch':
case 'searchig':
case 'igcari': {
    await satanic.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
    
    if (!text) {
        return satanic.sendMessage(m.chat, { 
            text: `📸 *INSTAGRAM SEARCH*\n\n🔍 Cari akun Instagram berdasarkan keyword.\n\n📌 *Penggunaan:*\n${prefix}igsearch [keyword]\n\n📌 *Contoh:*\n${prefix}igsearch jokowi\n${prefix}igsearch goldapple\n\n📌 *Fitur:*\n• Menampilkan username, nama, followers, posts\n• Bio lengkap, profile ID\n• Avatar, link profil`
        });
    }

    try {
        await satanic.sendMessage(m.chat, { 
            text: `⏳ *Mencari akun Instagram...*\n🔍 *${text}*`
        });

        // ============ SCRAPING ENGINE ============
        const baseUrl = 'https://inflact.com/tools/instagram-search/';
        const cookieJar = {};
        
        const getCookies = () => Object.entries(cookieJar).map(([k, v]) => `${k}=${v}`).join('; ');
        const parseCookies = (res) => {
            (res.headers['set-cookie'] || []).forEach(c => {
                const [name, ...parts] = c.split(';')[0].split('=');
                cookieJar[name.trim()] = parts.join('=');
            });
        };

        // ============ GET CSRF ============
        const getRes = await axios.get(baseUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Cookie': getCookies()
            },
            timeout: 30000
        });
        parseCookies(getRes);
        
        // Extract CSRF
        let csrfToken = getRes.data.match(/name=["']_csrf["']\s+value=["']([^"']+)["']/)?.[1] ||
                        getRes.data.match(/csrf-token["']?\s*content=["']([^"']+)["']/i)?.[1];

        if (!csrfToken) {
            const $ = cheerio.load(getRes.data);
            csrfToken = $('meta[name="csrf-token"]').attr('content') || 
                        $('input[name="_csrf"]').val();
        }

        if (!csrfToken) {
            throw new Error('CSRF token tidak ditemukan');
        }

        // ============ POST SEARCH ============
        const form = new URLSearchParams();
        form.append('_csrf', csrfToken);
        form.append('keyword', text);
        form.append('search', 'true');

        const postRes = await axios.post(baseUrl, form.toString(), {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36',
                'Accept': 'text/html, */*; q=0.01',
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-CSRF-Token': csrfToken,
                'X-PJAX': 'true',
                'X-PJAX-Container': '#account-pjax',
                'X-Requested-With': 'XMLHttpRequest',
                'Cookie': getCookies(),
                'Origin': 'https://inflact.com',
                'Referer': 'https://inflact.com/tools/instagram-search/'
            },
            timeout: 30000
        });
        parseCookies(postRes);

        // ============ PARSE RESPONSE ============
        let html = postRes.data;
        let total = 0;
        
        try {
            const json = JSON.parse(postRes.data);
            if (json.html) html = json.html;
            if (json.total) total = json.total;
        } catch (e) {}

        // ============ PARSING ============
        const $ = cheerio.load(html);
        const results = [];
        const seen = new Set();

        // Ambil total dari halaman
        const totalMatch = html.match(/(\d+)\s*results?\s*from\s*(\d+)/i);
        if (totalMatch) {
            total = parseInt(totalMatch[2]) || parseInt(totalMatch[1]) || 0;
        }

        // Parse setiap item
        $('.search-item, .item-container, .item, .result-item').each((_, el) => {
            const $el = $(el);
            
            // Cari link profile
            const link = $el.find('a[href*="profile="]').first();
            if (!link.length) return;

            // === USERNAME ===
            let username = link.attr('href')?.match(/profile=([^&]+)/)?.[1] || 
                           link.find('.profile-name').text().trim() || 
                           link.text().trim();
            username = username.replace(/[^a-zA-Z0-9._]/g, '');
            if (!username || seen.has(username)) return;
            seen.add(username);

            // === FULL NAME ===
            const fullName = $el.find('.item-title, .fullname, .display-name').first().text().trim() || username;
            
            // === FOLLOWERS & POSTS ===
            let followers = 'N/A', posts = 'N/A';
            $el.find('.item-stats').each((_, stat) => {
                const $stat = $(stat);
                const title = $stat.find('.stats-title').text().trim().toLowerCase();
                const value = $stat.find('.stats-value').text().trim();
                if (value?.match(/^[\d.]+[km]?$/i)) {
                    if (title.includes('follower')) followers = value;
                    else if (title.includes('post')) posts = value;
                }
            });

            // === BIO ===
            let bio = 'N/A';
            const bioEl = $el.find('.item-text, .bio, .description, [class*="bio"], [class*="desc"]').first();
            if (bioEl.length) {
                bio = bioEl.text().trim().replace(/\s+/g, ' ');
            }

            // === AVATAR ===
            let avatar = 'N/A';
            const imgEl = $el.find('.item-image, img').first();
            if (imgEl.length) {
                avatar = imgEl.attr('src') || imgEl.attr('data-src') || 'N/A';
                if (avatar && avatar.startsWith('/')) {
                    avatar = 'https://inflact.com' + avatar;
                }
            }

            // === PROFILE ID ===
            let profileId = 'N/A';
            const imgId = $el.find('.item-image').attr('id');
            if (imgId) {
                profileId = imgId;
            }

            // === CONTACTS ===
            const contacts = [];
            $el.find('.item-contact .contact-text, .item-contacts span, .item-contacts .contact-text').each((_, c) => {
                const text = $(c).text().trim();
                if (text && text.length > 3 && !text.includes('blur') && !text.includes('****')) {
                    contacts.push(text);
                }
            });

            // === KATEGORI ===
            let category = 'N/A';
            const catEl = $el.find('[class*="category"], [class*="categ"], .item-category');
            if (catEl.length) {
                category = catEl.first().text().trim();
            }

            // === STATUS ===
            const isVerified = $el.find('[class*="verified"], [class*="badge"]').length > 0;
            const isPrivate = $el.find('[class*="private"], [class*="locked"]').length > 0;
            const accountType = $el.find('[class*="business"], [class*="professional"]').length > 0 ? 'Business' : 'Personal';

            results.push({
                username,
                fullName,
                followers,
                posts,
                bio,
                profileId,
                category,
                accountType,
                isVerified,
                isPrivate,
                profileUrl: `https://instagram.com/${username}`,
                avatar,
                contacts
            });
        });

        // ============ FORMAT HASIL ============
        if (results.length === 0) {
            return satanic.sendMessage(m.chat, { 
                text: `❌ Tidak ditemukan hasil untuk *"${text}"*.\n\n💡 Coba keyword lain atau periksa ejaan.\n\n📌 Contoh:\n${prefix}igsearch goldapple\n${prefix}igsearch natashawilona`
            });
        }

        let resultText = `📸 *INSTAGRAM SEARCH RESULTS*\n`;
        resultText += `━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        resultText += `🔍 *Keyword:* ${text}\n`;
        resultText += `📊 *Total:* ${total || results.length} akun\n`;
        resultText += `📋 *Ditampilkan:* ${Math.min(results.length, 15)} akun\n`;
        resultText += `━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

        const display = results.slice(0, 15);
        display.forEach((item, i) => {
            resultText += `*${i+1}. @${item.username}*\n`;
            resultText += `📛 *Nama:* ${item.fullName}\n`;
            resultText += `👥 *Followers:* ${item.followers}\n`;
            resultText += `📝 *Posts:* ${item.posts}\n`;
            resultText += `🆔 *Profile ID:* ${item.profileId}\n`;
            if (item.category && item.category !== 'N/A') {
                resultText += `📂 *Kategori:* ${item.category}\n`;
            }
            resultText += `🔒 *Private:* ${item.isPrivate ? 'Ya' : 'Tidak'}\n`;
            resultText += `✅ *Verified:* ${item.isVerified ? 'Ya' : 'Tidak'}\n`;
            resultText += `🏷️ *Tipe:* ${item.accountType}\n`;
            if (item.bio && item.bio !== 'N/A') {
                resultText += `📖 *Bio:* ${item.bio.substring(0, 100)}${item.bio.length > 100 ? '...' : ''}\n`;
            }
            resultText += `🔗 *Link:* ${item.profileUrl}\n`;
            if (item.contacts && item.contacts.length > 0) {
                resultText += `📧 *Contact:* ${item.contacts.join(', ')}\n`;
            }
            resultText += `━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
        });

        if (results.length > 15) {
            resultText += `_*${results.length - 15} akun lainnya...*_\n`;
        }

        // ============ KIRIM HASIL ============
        // Cari avatar yang valid
        let validAvatar = null;
        for (const item of display) {
            if (item.avatar && item.avatar !== 'N/A' && item.avatar.includes('http')) {
                validAvatar = item.avatar;
                break;
            }
        }

        if (validAvatar) {
            try {
                await satanic.sendMessage(m.chat, {
                    image: { url: validAvatar },
                    caption: resultText
                });
            } catch {
                await satanic.sendMessage(m.chat, { text: resultText });
            }
        } else {
            await satanic.sendMessage(m.chat, { text: resultText });
        }

    } catch (error) {
        console.error('Error igsearch:', error);
        await satanic.sendMessage(m.chat, { 
            text: `❌ *Error:* ${error.message || 'Terjadi kesalahan'}\n\nSilakan coba lagi nanti.`
        });
    }
}
break;
case 'igstalk':
case 'instagramstalk': {
    if (!text) return reply('Masukkan username Instagram!\n\nContoh: .igstalk jokowi');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/igstalk2?username=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (!response.data || response.data.status !== 200 || !response.data.result) {
            return reply('Gagal mengambil data dari Instagram');
        }
        const user = response.data.result;
        let info = `*INSTAGRAM STALKER*\n\n`;
        info += `Username: ${user.username}\n`;
        info += `Full Name: ${user.full_name || '-'}\n`;
        info += `Bio: ${user.bio || '-'}\n`;
        info += `Followers: ${user.followers_count || 0}\n`;
        info += `Following: ${user.follows_count || 0}\n`;
        info += `Posts: ${user.posts_count || 0}\n`;
        info += `ID: ${user.id || '-'}\n`;
        info += `Link: https://instagram.com/${user.username}\n`;
        if (user.is_professional) info += `Verified: ✅ Professional Account\n`;
        info += `\nProject By: ${namaBot}`;
        if (user.profile_pic_url_hd || user.profile_pic_url) {
            const profilePic = user.profile_pic_url_hd || user.profile_pic_url;
            await satanic.sendMessage(m.chat, {
                image: { url: profilePic },
                caption: info
            }, { quoted: fkontak });
        } else {
            await satanic.sendMessage(m.chat, { text: info }, { quoted: fkontak });
        }
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil data Instagram.silahkan mencoba kembali');
    }
}
break;
case 'githubstalk':
case 'ghstalk': {
if (!text) return reply(`Kirim perintah ${prefix + command} username\nContoh: ${prefix + command} whiskeysockets`);
try {
 const res = await axios.get(`https://api.github.com/users/${text}`);
const user = res.data;
let txt = `*GITHUB PROFILE STALK*\n👤 *Username:* ${user.login}\n🆔 *ID:* ${user.id}\n🏷️ *Name:* ${user.name || '-'}\n📝 *Bio:* ${user.bio || '-'}\n📦 *Repos: ${user.public_repos}\n👥 *Followers:* ${user.followers}\n👣 *Following:* ${user.following}\n📍 *Location:* ${user.location || '-'}\n🔗 *URL:* ${user.html_url}`;
 await satanic.sendMessage(from, { image: { url: user.avatar_url }, caption: txt }, { quoted: fkontak });
} catch (e) {
console.error(e);
  reply("Username tidak ditemukan atau terjadi kesalahan.");
}
}
break;
case 'ytstalk':
case 'youtubestalk': {
    if (!text) return reply('Masukkan username atau handle YouTube!\n\nContoh: .ytstalk Dhot\nAtau: .ytstalk @Dhot');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    const apiUrl = `https://free-restapi.biz.id/api/ytstalk?q=${encodeURIComponent(text)}&apikey=${global.sakey}`;
    const response = await axios.get(apiUrl);
    
    const result = response.data.result;
    
    let info = `🎥 *YOUTUBE STALKER*\n\n`;
    info += `📛 *Nama:* ${result.nama}\n`;
    info += `🆔 *Channel ID:* ${result.channelId}\n`;
    info += `🔗 *Handle:* ${result.handle}\n`;
    info += `👥 *Subscribers:* ${result.subscriberCount}\n`;
    info += `✅ *Verified:* ${result.verified || 'Tidak'}\n`;
    info += `🔗 *URL:* ${result.url}\n`;
    info += `\n📥 *Project By:* ${namaBot}`;
    
    if (result.avatar) {
        await satanic.sendMessage(m.chat, {
            image: { url: result.avatar },
            caption: info
        }, { quoted: fkontak });
    } else {
        await satanic.sendMessage(m.chat, { text: info }, { quoted: fkontak });
    }
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'ttstalk':
case 'tiktokstalk': {
    if (!text) return reply('Masukkan username TikTok!\n\nContoh: .ttstalk jokowi');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/ttstalk?username=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status !== 200) {
            return reply('Gagal mengambil data dari TikTok');
        }
        
        const result = response.data.result;
        
        let info = `🎵 *TIKTOK STALKER*\n\n`;
        info += `👤 *Username:* ${result.username}\n`;
        info += `📛 *Nama:* ${result.nama || '-'}\n`;
        info += `📝 *Bio:* ${result.bio || '-'}\n`;
        info += `✅ *Verifikasi:* ${result.verifikasi ? 'Ya' : 'Tidak'}\n`;
        info += `👥 *Followers:* ${result.totalfollowers.toLocaleString()}\n`;
        info += `❤️ *Total Disukai:* ${result.totaldisukai.toLocaleString()}\n`;
        info += `🎬 *Total Video:* ${result.totalvideo.toLocaleString()}\n`;
        info += `🔗 *Link:* https://tiktok.com/@${result.username}\n`;
        info += `📥 *Project By:* ${namaBot}`;
        
        // Kirim avatar dan info
        if (result.avatar) {
            await satanic.sendMessage(m.chat, {
                image: { url: result.avatar },
                caption: info
            }, { quoted: fkontak });
        } else {
            await satanic.sendMessage(m.chat, { text: info }, { quoted: fkontak });
        }
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil data TikTok.');
    }
}
break;
case 'robloxstalk':
case 'rblxstalk': {
    if (!text) return reply('Masukkan username Roblox!\n\nContoh: .robloxstalk Simoon68');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/robloxstalk?username=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status !== 200) {
            return reply('Gagal mengambil data dari Roblox');
        }
        
        const result = response.data.result;
        const account = result.account;
        const stats = result.stats;
        const presence = result.presence;
        
        let info = `🎮 *ROBLOX STALKER*\n\n`;
        info += `🆔 *User ID:* ${result.userId}\n`;
        info += `👤 *Username:* ${account.username}\n`;
        info += `📛 *Display Name:* ${account.displayName}\n`;
        info += `📝 *Bio:* ${account.description || '-'}\n`;
        info += `📅 *Bergabung:* ${account.created}\n`;
        info += `✅ *Verifikasi:* ${account.hasVerifiedBadge ? '✅ Ya' : '❌ Tidak'}\n`;
        info += `🚫 *Banned:* ${account.isBanned ? '⚠️ Ya' : '✅ Tidak'}\n\n`;
        
        info += `📊 *STATISTIK*\n`;
        info += `👥 *Teman:* ${stats.friendCount.toLocaleString()}\n`;
        info += `👣 *Followers:* ${stats.followers.toLocaleString()}\n`;
        info += `👤 *Following:* ${stats.following.toLocaleString()}\n`;
        info += `📦 *Inventory:* ${stats.inventoryCount.toLocaleString()}\n\n`;
        
        info += `🟢 *PRESENCE*\n`;
        info += `📱 *Online:* ${presence.isOnline ? '🟢 Online' : '⚫ Offline'}\n`;
        if (presence.recentGame && presence.recentGame !== 'Studio') {
            info += `🎮 *Game Terakhir:* ${presence.recentGame}\n`;
        }
        
        // Tambahkan groups
        if (result.groups && result.groups.groups && result.groups.groups.length > 0) {
            info += `\n👥 *GROUP (${result.groups.total} total)*\n`;
            info += `━━━━━━━━━━━━━━━━━━━━━\n`;
            for (let i = 0; i < Math.min(result.groups.groups.length, 15); i++) {
                const group = result.groups.groups[i];
                const roleName = group.role?.name || 'Member';
                const rank = group.role?.rank || 0;
                info += `${i+1}. ${group.name}\n`;
                info += `   👑 Role: ${roleName} (Rank ${rank})\n`;
                if (group.url) info += `   🔗 ${group.url}\n`;
                info += `\n`;
            }
            if (result.groups.groups.length > 15) {
                info += `*dan ${result.groups.groups.length - 15} grup lainnya...*\n`;
            }
        } else {
            info += `\n👥 *Group:* Tidak ada grup\n`;
        }
        
        info += `━━━━━━━━━━━━━━━━━━━━━\n`;
        info += `🔗 *Link Profile:* https://www.roblox.com/users/${result.userId}/profile\n`;
        info += `📥 *Project By:* ${namaBot}`;
        
        // Kirim avatar dan info dalam satu pesan
        if (account.profilePicture) {
            await satanic.sendMessage(m.chat, {
                image: { url: account.profilePicture },
                caption: info
            }, { quoted: fkontak });
        } else {
            // Jika caption terlalu panjang, kirim teks terpisah
            if (info.length > 4000) {
                await satanic.sendMessage(m.chat, { text: info.substring(0, 4000) }, { quoted: fkontak });
                await satanic.sendMessage(m.chat, { text: info.substring(4000) }, { quoted: fkontak });
            } else {
                await satanic.sendMessage(m.chat, { text: info }, { quoted: fkontak });
            }
        }
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil data Roblox.');
    }
}
break;
case 'npmstalk':
case 'stalknpm': {
    if (!text) return reply('Masukkan nama package NPM!\n\nContoh: .npmstalk axios');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/npmstalk?package=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status !== 200) {
            return reply('Gagal mengambil data dari NPM');
        }
        
        const result = response.data.result;
        
        let info = `📦 *NPM PACKAGE STALKER*\n\n`;
        info += `📌 *Package:* ${result.name}\n`;
        info += `⭐ *Version Latest:* ${result.versionLatest}\n`;
        info += `📅 *Latest Publish:* ${new Date(result.latestPublishTime).toLocaleDateString('id-ID')} ${new Date(result.latestPublishTime).toLocaleTimeString('id-ID')}\n`;
        info += `🔧 *Version Publish:* ${result.versionPublish || '-'}\n`;
        info += `📆 *Publish Time:* ${new Date(result.publishTime).toLocaleDateString('id-ID')}\n`;
        info += `🔄 *Version Update:* ${result.versionUpdate}\n`;
        info += `📦 *Latest Dependencies:* ${result.latestDependencies}\n`;
        info += `📦 *Publish Dependencies:* ${result.publishDependencies}\n\n`;
        info += `📥 *Project By:* ${namaBot}`;
        
        await satanic.sendMessage(m.chat, { text: info }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil data NPM.');
    }
}
break;
case 'ffstalk':
case 'freefirestalk': {
    if (!text) return reply('Masukkan UID Free Fire!\n\nContoh: .ffstalk 946716486');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/ffstalk?uid=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status !== 200) {
            return reply('Gagal mengambil data dari Free Fire');
        }
        
        const result = response.data.result;
        
        let info = `🔥 *FREE FIRE STALKER*\n\n`;
        info += `🆔 *UID:* ${result.uid}\n`;
        info += `👤 *Nickname:* ${result.name}\n`;
        info += `⭐ *Level:* ${result.level}\n`;
        info += `📊 *Exp:* ${result.exp.toLocaleString()}\n`;
        info += `🌍 *Region:* ${result.region}\n`;
        info += `❤️ *Likes:* ${result.likes.toLocaleString()}\n`;
        info += `📅 *Bergabung:* ${new Date(result.created_at).toLocaleDateString('id-ID')}\n`;
        info += `🕐 *Last Login:* ${new Date(result.last_login).toLocaleDateString('id-ID')}\n`;
        info += `📝 *Signature:* ${result.signature || '-'}\n\n`;
        
        info += `🎮 *RANK*\n`;
        info += `🏆 *BR Max Rank:* ${result.br_max_rank}\n`;
        info += `🏆 *CS Max Rank:* ${result.cs_max_rank}\n`;
        info += `🎯 *BR Rank Point:* ${result.br_rank_point}\n\n`;
        
        info += `🦎 *PET*\n`;
        info += `🐾 *Nama Pet:* ${result.pet_name || '-'}\n`;
        info += `⭐ *Level Pet:* ${result.pet_level}\n`;
        info += `📊 *Exp Pet:* ${result.pet_exp.toLocaleString()}\n\n`;
        
        info += `👥 *GUILD*\n`;
        info += `🏷️ *Nama Guild:* ${result.guild_name || '-'}\n`;
        info += `🆔 *Guild ID:* ${result.guild_id || '-'}\n`;
        if (result.guild_level) info += `⭐ *Guild Level:* ${result.guild_level}\n`;
        if (result.guild_members) info += `👥 *Anggota:* ${result.guild_members}\n`;
        
        info += `\n📥 *Project By:* ${namaBot}`;
        
        await satanic.sendMessage(m.chat, { text: info }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil data Free Fire.');
    }
}
break;
case 'twstalk':
case 'twitterstalk': {
    if (!text) return reply('Masukkan username Twitter!\n\nContoh: .twstalk jokowi');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/twstalk?username=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status !== 200) {
            return reply('Gagal mengambil data dari Twitter');
        }
        
        const result = response.data.result;
        
        let info = `🐦 *TWITTER STALKER*\n\n`;
        info += `👤 *Username:* @${result.username}\n`;
        info += `📛 *Name:* ${result.name}\n`;
        info += `📝 *Bio:* ${result.bio || '-'}\n`;
        info += `📍 *Location:* ${result.location || '-'}\n`;
        info += `✅ *Verified:* ${result.verified ? 'Ya' : 'Tidak'}\n`;
        if (result.verification_type) {
            info += `🔐 *Verification Type:* ${result.verification_type}\n`;
        }
        info += `🔒 *Protected:* ${result.protected ? 'Ya' : 'Tidak'}\n`;
        info += `📅 *Joined:* ${new Date(result.joined).toLocaleDateString('id-ID')}\n`;
        info += `\n📊 *STATISTIK*\n`;
        info += `👥 *Followers:* ${result.followers.toLocaleString()}\n`;
        info += `👣 *Following:* ${result.following.toLocaleString()}\n`;
        info += `❤️ *Likes:* ${result.likes.toLocaleString()}\n`;
        info += `🐦 *Tweets:* ${result.tweets.toLocaleString()}\n`;
        info += `📷 *Media Count:* ${result.media_count.toLocaleString()}\n`;
        info += `\n🔗 *Link:* ${result.url}\n`;
        info += `📥 *Project By:* ${namaBot}`;
        
        // Kirim avatar dan info
        if (result.avatar_url) {
            await satanic.sendMessage(m.chat, {
                image: { url: result.avatar_url },
                caption: info
            }, { quoted: fkontak });
        } else {
            await satanic.sendMessage(m.chat, { text: info }, { quoted: fkontak });
        }
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil data Twitter.');
    }
}
break;





/////// BATAS AKHIR STALK MENU /////////
/////// SEARCH MENU /////////
case 'douyinsearch': {
    if (!text) return reply('Masukkan kata kunci pencarian!\n\nContoh: .douyinsearch naruto');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/douyinsearch?query=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (!response.data || response.data.status !== 200 || !response.data.results || response.data.results.length === 0) {
            return reply('❌ Tidak ditemukan hasil untuk pencarian tersebut.');
        }
        
        const results = response.data.results;
        let replyText = `🔍 *Hasil Pencarian TikTok/Douyin*\n`;
        replyText += `📌 Query: ${response.data.query}\n`;
        replyText += `📊 Total: ${response.data.total} video\n\n`;
        
        for (let i = 0; i < Math.min(results.length, 5); i++) {
            const video = results[i];
            replyText += `*${i + 1}. ${video.author.nickname}*\n`;
            replyText += `📝 ${video.desc || 'Tidak ada deskripsi'}\n`;
            replyText += `❤️ ${video.stats.digg_count || 0} | 💬 ${video.stats.comment_count || 0} | 🔗 ${video.stats.share_count || 0}\n`;
            replyText += `🔗 https://www.tiktok.com/@${video.author.unique_id}/video/${video.id}\n\n`;
        }
        
        if (results.length > 5) {
            replyText += `\n📌 Dan ${results.length - 5} video lainnya...`;
        }
        
        await satanic.sendMessage(m.chat, { text: replyText }, { quoted: fkontak });
        
        const firstVideo = results[0];
        if (firstVideo && firstVideo.video && firstVideo.video.download_addr) {
            await satanic.sendMessage(m.chat, { 
                react: { text: '📥', key: m.key } 
            });
            
            const videoUrl = firstVideo.video.download_addr || firstVideo.video.play_addr;
            
            if (videoUrl) {
                const videoResponse = await axios.get(videoUrl, { 
                    responseType: 'arraybuffer',
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36'
                    }
                });
                
                const caption = `🎬 *${firstVideo.author.nickname}*\n📝 ${firstVideo.desc || 'Tidak ada deskripsi'}\n❤️ ${firstVideo.stats.digg_count || 0} likes\n💬 ${firstVideo.stats.comment_count || 0} komentar\n🔗 https://www.tiktok.com/@${firstVideo.author.unique_id}/video/${firstVideo.id}`;
                
                await satanic.sendMessage(m.chat, {
                    video: Buffer.from(videoResponse.data),
                    caption: caption
                }, { quoted: fkontak });
            }
        }
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error('Error DouyinSearch:', err);
        reply('❌ Terjadi kesalahan saat mencari video.');
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'spotifysearch':
case 'spsearch': {
    if (!text) return reply(`Contoh: ${prefix}spotifysearch dhyo haw`);
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/spotifysearch?query=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status !== 200 || !response.data.result.tracks || response.data.result.tracks.length === 0) {
            return reply('Lagu tidak ditemukan.');
        }
        
        const tracks = response.data.result.tracks.slice(0, 10);
        
        // Simpan hasil search untuk digunakan di spotifyget
        global.spotifySearchResults = {};
        
        let cards = await Promise.all(tracks.map(async (item, i) => {
            const index = (i + 1).toString();
            global.spotifySearchResults[index] = {
                name: item.name,
                url: item.url,
                artist: item.artists.map(a => a.name).join(', ')
            };
            
            const albumImage = item.album.images && item.album.images.length > 0 ? item.album.images[0].url : 'https://i.scdn.co/image/ab67616d00001e02c7ef9493c18667b50745b811';
            
            const imageData = await prepareWAMessageMedia({ 
                image: { url: albumImage } 
            }, { 
                upload: satanic.waUploadToServer 
            });
            
            const durationSec = Math.floor(item.duration_ms / 1000);
            const minutes = Math.floor(durationSec / 60);
            const seconds = durationSec % 60;
            
            const trackInfo = `*${item.name}*\n\n👤 Artist: ${item.artists.map(a => a.name).join(', ')}\n⏱️ Durasi: ${minutes}:${seconds.toString().padStart(2, '0')}\n💿 Album: ${item.album.name}\n\n🔗 Link: ${item.url}\n\nKetik .spotifyget ${index} untuk download`;
            
            return {
                header: proto.Message.InteractiveMessage.Header.create({
                    ...imageData,
                    title: '',
                    subtitle: `Lagu ${i + 1} dari ${tracks.length}`,
                    hasMediaAttachment: true
                }),
                body: { text: trackInfo },
                nativeFlowMessage: {
                    buttons: [{
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📋 Copy Link",
                            copy_code: item.url
                        })
                    }]
                }
            };
        }));
        
        let msg = generateWAMessageFromContent(
            m.chat,
            {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: `Hasil pencarian lagu Spotify untuk *${text}*` },
                            carouselMessage: {
                                cards: cards,
                                messageVersion: 1
                            }
                        }
                    }
                }
            },
            { quoted: fkontak }
        );
        
        await satanic.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mencari lagu.');
    }
}
break;
case 'spotifyget':
case 'spget': {
    if (!text) return reply('Masukkan URL Spotify atau angka dari hasil pencarian!\n\nContoh: .spotifyget 1');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    // Cek apakah input berupa angka (pilihan dari search)
    if (!isNaN(text) && global.spotifySearchResults && global.spotifySearchResults[text]) {
        const selectedTrack = global.spotifySearchResults[text];
        const apiUrl = `https://free-restapi.biz.id/api/spotify?url=${encodeURIComponent(selectedTrack.url)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            audio: response.data, 
            mimetype: 'audio/mpeg',
            fileName: `${selectedTrack.name}.mp3`
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } 
    // Jika input berupa link langsung
    else if (text.includes('spotify.com')) {
        const apiUrl = `https://free-restapi.biz.id/api/spotify?url=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            audio: response.data, 
            mimetype: 'audio/mpeg'
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } 
    else {
        reply('Format salah! Gunakan .spotifyget 1 (dari hasil search) atau .spotifyget link_spotify');
    }
}
break;
case 'alquran': {
    if (!text) return reply(`📖 *AL-QURAN*\n\nContoh:\n.alquran al-baqarah\n.alquran yasin\n.alquran al-baqarah 1-5\n.alquran yasin 1`)

    let query = text.replace(/^[.!?]alquran\s*/i, '').trim()
    if (!query) return reply(`📖 *AL-QURAN*\n\nContoh:\n.alquran al-baqarah\n.alquran yasin`)

    let [surahName, ayatRange] = query.split(/\s+(\d+[-–]\d+|\d+)/).filter(Boolean)

    try {
        const slug = surahName.toLowerCase().replace(/\s+/g, "-")
        const url = `https://quran.nu.or.id/${slug}`
        
        const res = await fetch(url)
        const html = await res.text()
        const $ = cheerio.load(html)

        const title = $("h1").first().text().trim()
        const info = $("h1").next("span").text().trim()

        const hasil = []

        $('div[id]').each((i, el) => {
            const id = $(el).attr('id')
            if (!/^\d+$/.test(id)) return

            const arab = $(el).find('[dir="rtl"]').first().text().trim()
            const latin = $(el).find('.text-primary-500').first().text().trim()
            const arti = $(el).find('.text-neutral-700').first().text().trim()

            if (arab && latin && arti) {
                hasil.push({ ayat: Number(id), arab, latin, arti })
            }
        })

        if (!hasil.length) return reply('❌ Surah tidak ditemukan!')

        let teks = `📖 *AL-QURAN*\n\n`
        teks += `📝 *${title}*\n`
        teks += `ℹ️ ${info}\n`
        teks += `📊 Total Ayat: ${hasil.length}\n\n`

        if (ayatRange) {
            if (ayatRange.includes('-') || ayatRange.includes('–')) {
                let [start, end] = ayatRange.split(/[-–]/).map(Number)
                hasil.filter(v => v.ayat >= start && v.ayat <= end).forEach(v => {
                    teks += `━━━━━━━━━━━━━━━\n`
                    teks += `🕌 *Ayat ${v.ayat}*\n\n`
                    teks += `${v.arab}\n\n`
                    teks += `🔤 ${v.latin}\n\n`
                    teks += `🇮🇩 ${v.arti}\n\n`
                })
            } else {
                let ayat = hasil.find(v => v.ayat == Number(ayatRange))
                if (!ayat) return reply('❌ Ayat tidak ditemukan!')
                teks += `${ayat.arab}\n\n`
                teks += `🔤 ${ayat.latin}\n\n`
                teks += `🇮🇩 ${ayat.arti}\n`
            }
        } else {
            hasil.forEach(v => {
                teks += `${v.arab}\n\n`
                teks += `🔤 ${v.latin}\n\n`
                teks += `🇮🇩 ${v.arti}\n\n`
                teks += `━━━━━━━━━━━━━━━\n\n`
            })
        }

        await reply(teks)

    } catch (error) {
        console.error(error)
        reply('❌ Gagal mengambil data. Coba lagi nanti.')
    }
}
break
case 'murotal': {
    if (!text) return reply(`📻 *MUROTAL*\n\nContoh:\n.murotal al-fatihah\n.murotal yasin\n.murotal al-baqarah`)

    let query = text.replace(/^[.!?]murotal\s*/i, '').trim()
    if (!query) return reply(`📻 *MUROTAL*\n\nContoh:\n.murotal al-fatihah\n.murotal yasin`)

    try {
        const res = await fetch("https://islamipedia.id/murottal/")
        const html = await res.text()
        const $ = cheerio.load(html)
        
        const data = $(".surah-item").map((i, el) => ({
            no: parseInt($(el).find("h5").text().split(".")[0]),
            surah: ($(el).attr("data-title") || "").toLowerCase(),
            arti: $(el).find("p").text().trim(),
            audio: $(el).attr("data-audio") || ""
        })).get()
        
        const q = query.toLowerCase()
        const find = data.find(v => v.surah.replace(/[^a-z0-9]/g, "").includes(q.replace(/[^a-z0-9]/g, "")))
        
        if (!find) return reply('❌ Surah tidak ditemukan!')
        
        await satanic.sendMessage(m.chat, { 
            audio: { url: find.audio }, 
            mimetype: "audio/mpeg",
            ptt: false
        }, { quoted: fkontak })
        
    } catch (e) {
        console.error(e)
        reply('❌ Gagal mengambil murotal. Coba lagi nanti.')
    }
}
break
case 'applemusic':
case 'applemusicsearch':
case 'amsearch': {
    if (!text) return reply(`Contoh: ${prefix}applemusicsearch dhyo haw`);
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/applemusic?query=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status !== 200 || !response.data.result.data.results || response.data.result.data.results.length === 0) {
            return reply('Lagu tidak ditemukan.');
        }
        
        const tracks = response.data.result.data.results.slice(0, 10);
        
        // Simpan hasil search untuk digunakan di applemusicdl
        global.appleMusicSearchResults = {};
        
        let cards = await Promise.all(tracks.map(async (item, i) => {
            const index = (i + 1).toString();
            
            // Simpan data track
            global.appleMusicSearchResults[index] = {
                title: item.title,
                artist: item.artist,
                songLink: item.songLink,
                albumName: item.albumName
            };
            
            // Ambil artwork dari Apple Music (gunakan placeholder)
            const artworkUrl = `https://c.termai.cc/i101/xvVZ.jpg`;
            
            const imageData = await prepareWAMessageMedia({ 
                image: { url: artworkUrl } 
            }, { 
                upload: satanic.waUploadToServer 
            });
            
            const trackInfo = `*${item.title}*\n\n👤 Artist: ${item.artist}\n💿 Album: ${item.albumName}\n\n🔗 Link: ${item.songLink}\n\nKetik .amdl ${index} untuk download`;
            
            return {
                header: proto.Message.InteractiveMessage.Header.create({
                    ...imageData,
                    title: '',
                    subtitle: `Lagu ${i + 1} dari ${tracks.length}`,
                    hasMediaAttachment: true
                }),
                body: { text: trackInfo },
                nativeFlowMessage: {
                    buttons: [{
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📋 Copy Link",
                            copy_code: item.songLink
                        })
                    }]
                }
            };
        }));
        
        let msg = generateWAMessageFromContent(
            m.chat,
            {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: `Hasil pencarian lagu Apple Music untuk *${text}*` },
                            carouselMessage: {
                                cards: cards,
                                messageVersion: 1
                            }
                        }
                    }
                }
            },
            { quoted: fkontak }
        );
        
        await satanic.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mencari lagu.');
    }
}
break;
case 'ytsearch':
case 'youtube': {
    if (!text) return reply(`Contoh: ${prefix}ytsearch anime`);
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const search = require('yt-search');
        const results = await search(text);
        const videos = results.videos.slice(0, 10);
        
        if (!videos || videos.length === 0) {
            return reply('Video tidak ditemukan.');
        }
        
        let cards = await Promise.all(videos.map(async (item, i) => {
            const thumb = item.thumbnail || 'https://i.ytimg.com/vi/default.jpg';
            const imageData = await prepareWAMessageMedia({ 
                image: { url: thumb } 
            }, { 
                upload: satanic.waUploadToServer 
            });
            
            const videoInfo = `*${item.title}*\n\n🕐 Durasi: ${item.timestamp}\n👤 Channel: ${item.author.name}\n👁️ Views: ${item.views.toLocaleString()}\n🔗 Link: ${item.url}`;
            
            return {
                header: proto.Message.InteractiveMessage.Header.create({
                    ...imageData,
                    title: '',
                    subtitle: `Video ${i + 1} dari ${videos.length}`,
                    hasMediaAttachment: true
                }),
                body: { text: videoInfo },
                nativeFlowMessage: {
                    buttons: [{
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📺 Watch on YouTube",
                            url: item.url
                        })
                    }]
                }
            };
        }));
        
        let msg = generateWAMessageFromContent(
            m.chat,
            {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: `🎬 Hasil pencarian YouTube untuk *${text}*` },
                            carouselMessage: {
                                cards: cards,
                                messageVersion: 1
                            }
                        }
                    }
                }
            },
            { quoted: fkontak }
        );
        
        await satanic.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mencari video.');
    }
}
break;
case 'npmsearch':
case 'npmsearch': {
    if (!text) return reply(`Contoh: ${prefix}npmsearch axios`);
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://registry.npmjs.org/-/v1/search?text=${encodeURIComponent(text)}&size=20`;
        const response = await axios.get(apiUrl);
        
        if (!response.data || !response.data.objects || response.data.objects.length === 0) {
            return reply('Package NPM tidak ditemukan.');
        }
        
        let info = `📦 *NPM SEARCH RESULTS*\n\n`;
        info += `🔍 *Keyword:* ${text}\n`;
        info += `📊 *Total Found:* ${response.data.total || response.data.objects.length}\n`;
        info += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
        
        for (let i = 0; i < response.data.objects.length; i++) {
            const pkg = response.data.objects[i].package;
            const score = response.data.objects[i].score;
            
            info += `*${i+1}. ${pkg.name}*\n`;
            info += `📝 *Description:* ${pkg.description || '-'}\n`;
            info += `🔖 *Latest Version:* ${pkg.version}\n`;
            info += `📅 *Published:* ${pkg.date ? new Date(pkg.date).toLocaleDateString('id-ID') + ' ' + new Date(pkg.date).toLocaleTimeString('id-ID') : '-'}\n`;
            info += `🔗 *NPM Link:* https://www.npmjs.com/package/${pkg.name}\n`;
            
            if (pkg.publisher && pkg.publisher.username) {
                info += `👤 *Publisher:* ${pkg.publisher.username}\n`;
            }
            
            if (pkg.keywords && pkg.keywords.length > 0) {
                info += `🏷️ *Keywords:* ${pkg.keywords.join(', ')}\n`;
            }
            
            if (score && score.final) {
                info += `⭐ *Score:* ${(score.final * 100).toFixed(1)}%\n`;
            }
            
            info += `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
        }
        
        info += `📥 *Project By:* ${namaBot}`;
        
        await satanic.sendMessage(m.chat, { text: info }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mencari package NPM.');
    }
}
break;
case "sixtynine": 
case "pussy": 
case "dick": 
case "anal": 
case "boobs": 
case "bdsm":
case "black": 
case "easter": 
case "bottomless": 
case "blowjub": 
case "collared": 
case "cum": 
case "cumsluts": 
case "dp": 
case "dom": 
case "extreme": 
case "feet": 
case "finger": 
case "fuck": 
case "futa": 
case "gay": 
case "gif": 
case "group": 
case "hentai": 
case "kiss": 
case "lesbian": 
case "lick": 
case "pegged": 
case "phgif": 
case "puffies": 
case "real": 
case "suck": 
case "tattoo": 
case "tiny": 
case "toys":
 case "xmas":
 if (!isPrem) return reply('you are not premium')
    try {
        // Kirim reply "wait" dulu
        await reply(mess.wait || 'Tunggu sebentar...')
        
const { data } = await axios.get(`https://free-restapi.biz.id/api/${command}?&apikey=${global.sakey}`, {
    responseType: 'arraybuffer'
})

// Kirim gambar dengan viewOnce
const sendMsg2 = await satanic.sendMessage(m.chat, {
    image: Buffer.from(data),
    caption: 'Done',
    viewOnce: true
}, { quoted: fkontak });

// Hapus pesan setelah 30 detik
setTimeout(() => {
    satanic.sendMessage(m.chat, {
        delete: {
            remoteJid: m.chat,
            fromMe: true,
            id: sendMsg2.key.id,
            participant: m.sender
        }
    }).catch(() => {}) // Abaikan error jika gagal hapus
}, 30000); // 30 detik = 30000ms
    } catch (error) {
        console.error('Error fetching waifu image:', error)
        let errorMessage = 'Gagal mengambil gambar'
        if (error.response) {
            errorMessage = `API Error: ${error.response.status}`
        } else if (error.request) {
            errorMessage = 'Tidak ada response dari server'
        }
        
        await reply(errorMessage)
    }
    break        
case 'pin':
case 'pinterest': {
    async function getCookies() {
      try {
        const response = await axios.get('https://www.pinterest.com/csrf_error/');
        const setCookieHeaders = response.headers['set-cookie'];
        if (setCookieHeaders) {
          const cookies = setCookieHeaders.map(cookieString => {
            const cookieParts = cookieString.split(';');
            const cookieKeyValue = cookieParts[0].trim();
            return cookieKeyValue;
          });
          return cookies.join('; ');
        } else {
          console.warn('No set-cookie headers found in the response.');
          return null;
        }
      } catch (error) {
        console.error('Error fetching cookies:', error);
        return null;
      }
    }
    
 async function pinterest(query) {
      try {
        const cookies = await getCookies();
        if (!cookies) {
          console.log('Failed to retrieve cookies. Exiting.');
          return;
        }

        const url = 'https://www.pinterest.com/resource/BaseSearchResource/get/';

        const params = {
          source_url: `/search/pins/?q=${query}`,
          data: JSON.stringify({
            "options": {
              "isPrefetch": false,
              "query": query,
              "scope": "pins",
              "no_fetch_context_on_resource": false
            },
            "context": {}
          }),
          _: Date.now()
        };

        const headers = {
          'accept': 'application/json, text/javascript, */*, q=0.01',
          'accept-encoding': 'gzip, deflate',
          'accept-language': 'en-US,en;q=0.9',
          'cookie': cookies,
          'dnt': '1',
          'referer': 'https://www.pinterest.com/',
          'sec-ch-ua': '"Not(A:Brand";v="99", "Microsoft Edge";v="133", "Chromium";v="133"',
          'sec-ch-ua-full-version-list': '"Not(A:Brand";v="99.0.0.0", "Microsoft Edge";v="133.0.3065.92", "Chromium";v="133.0.6943.142"',
          'sec-ch-ua-mobile': '?0',
          'sec-ch-ua-model': '""',
          'sec-ch-ua-platform': '"Windows"',
          'sec-ch-ua-platform-version': '"10.0.0"',
          'sec-fetch-dest': 'empty',
          'sec-fetch-mode': 'cors',
          'sec-fetch-site': 'same-origin',
          'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0',
          'x-app-version': 'c056fb7',
          'x-pinterest-appstate': 'active',
          'x-pinterest-pws-handler': 'www/[username]/[slug].js',
          'x-pinterest-source-url': '/hargr003/cat-pictures/',
          'x-requested-with': 'XMLHttpRequest'
        };

        const {
          data
        } = await axios.get(url, {
          headers: headers,
          params: params
        })

        const container = [];
        const results = data.resource_response.data.results.filter((v) => v.images?.orig);
        results.forEach((result) => {
          container.push({
            upload_by: result.pinner.username,
            fullname: result.pinner.full_name,
            followers: result.pinner.follower_count,
            caption: result.grid_title,
            image: result.images.orig.url,
            source: "https://id.pinterest.com/pin/" + result.id,
          });
        });

        return container;
      } catch (error) {
        console.log(error);
        return [];
      }
    }
    
      if (!text) return reply(`Format salah, contoh: \n${prefix + command} Anime`)
      
      await satanic.sendMessage(m.chat, {
        react: {
          text: '⏳',
          key: m.key
        }
      })

      let anutrest = await pinterest(text) // Ambil hasil pencarian
      if (!anutrest || anutrest.length === 0) return reply("Error, Foto Tidak Ditemukan")

      // Ambil maksimal 10 gambar biar nggak terlalu panjang
      let selectedImages = anutrest.slice(0, 10);
      let anu = []

      for (let i = 0; i < selectedImages.length; i++) {
        let imgsc = await prepareWAMessageMedia({
          image: {
            url: selectedImages[i].image
          }
        }, {
          upload: satanic.waUploadToServer
        })

        anu.push({
          header: proto.Message.InteractiveMessage.Header.fromObject({
            title: `Gambar ke *${i + 1}*`,
            hasMediaAttachment: true,
            ...imgsc
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
            buttons: [{
              name: "cta_url",
              buttonParamsJson: JSON.stringify({
                display_text: "Lihat di Pinterest",
                url: selectedImages[i].source || selectedImages[i].image
              })
            }]
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: "© Satanic Haxor"
          })
        })
      }

      // Buat format `carouselMessage`
      const msg = await generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `🔎 Berikut hasil pencarian gambar untuk *${text}*`
              }),
              carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                cards: anu
              })
            })
          }
        }
      }, {
        userJid: sender,
        quoted: fkontak
      })
      satanic.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id
      })
    }
break
case "bingimage":
case "bingimg":
{
    if (!text) return reply(`❌ *Cara penggunaan:* ${prefix + command} kata kunci\nContoh: ${prefix + command} kucing lucu`);

    await satanic.sendMessage(m.chat, {
        react: {
            text: '⏳',
            key: m.key
        }
    });

    try {
        const query = text.trim();
        const limit = 10; // Jumlah gambar yang diambil
        const headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36'
        };

        // Format query untuk URL
        const q = query.split(/\s+/).join('+');
        const url = `https://www.bing.com/images/search?q=${q}&FORM=HDRSC2`;

        // Request ke Bing
        const res = await axios.get(url, { headers });
        const $ = cheerio.load(res.data);

        let images = [];

        // Scrape gambar dari elemen a.iusc
        $('a.iusc').each((i, el) => {
            if (i >= limit) return false; // Batasi sesuai limit

            try {
                const mRaw = $(el).attr('m') || '{}';
                const madRaw = $(el).attr('mad') || '{}';

                const m = JSON.parse(mRaw);
                const mad = JSON.parse(madRaw);

                const original_url = m?.murl;
                const preview_url = mad?.turl;
                const title = m?.t || 'Gambar';

                if (!original_url) return;

                images.push({
                    title: title,
                    preview_url: preview_url || original_url,
                    original_url: original_url,
                    source: original_url
                });
            } catch (e) {
                // Abaikan error parsing
            }
        });

        // Cek apakah ada gambar ditemukan
        if (images.length === 0) {
            return reply(`❌ Tidak ditemukan gambar untuk *${query}*`);
        }

        // Ambil maksimal 10 gambar
        let selectedImages = images.slice(0, 10);
        let anu = [];

        for (let i = 0; i < selectedImages.length; i++) {
            let imgsc = await prepareWAMessageMedia({
                image: {
                    url: selectedImages[i].original_url
                }
            }, {
                upload: satanic.waUploadToServer
            });

            anu.push({
                header: proto.Message.InteractiveMessage.Header.fromObject({
                    title: `Gambar ke *${i + 1}*`,
                    hasMediaAttachment: true,
                    ...imgsc
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [{
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "Lihat Gambar",
                            url: selectedImages[i].original_url
                        })
                    }]
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                    text: "© Bing Image Search"
                })
            });
        }

        // Buat format `carouselMessage`
        const msg = await generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        body: proto.Message.InteractiveMessage.Body.fromObject({
                            text: `🔎 *Hasil Pencarian Gambar dari Bing*\n📝 *Query:* ${query}\n📊 *Ditemukan:* ${images.length} gambar`
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                            cards: anu
                        })
                    })
                }
            }
        }, {
            userJid: sender,
            quoted: fkontak
        });

        await satanic.relayMessage(m.chat, msg.message, {
            messageId: msg.key.id
        });

    } catch (error) {
        console.error("Error BingImage:", error);
        reply(`❌ Gagal mengambil gambar: ${error.message}`);
    }
}
break;
case 'ttsearch':
case 'tiktoksearch': {
    if (!text) return reply(`Contoh: ${prefix}ttsearch Furina`);
    try {
        const { TikTokSearch } = require('./lib/tiktoksearch');
        const result = await TikTokSearch.search(text);        
        if (!result.success || !result.payload || result.payload.length === 0) {
            return reply('Video tidak ditemukan.');
        }
        const videos = result.payload.slice(0, 10);
        let cards = await Promise.all(videos.map(async (item, i) => {
            const videoData = await prepareWAMessageMedia({ 
                video: { url: item.media.no_watermark } 
            }, { 
                upload: satanic.waUploadToServer 
            });
            const videoInfo = `*${item.title}*      
🕐 Durasi: ${item.duration}s
👤 Creator: ${item.author.nickname} (@${item.author.unique_id})
👍 Likes: ${item.stats.digg_count}
💬 Komentar: ${item.stats.comment_count}
📨 Shares: ${item.stats.share_count}`;

            return {
                header: proto.Message.InteractiveMessage.Header.create({
                    ...videoData,
                    title: '',
                    subtitle: `Video ${i + 1} dari ${videos.length}`,
                    hasMediaAttachment: true
                }),
                body: { text: videoInfo },
                nativeFlowMessage: { buttons: [] }
            };
        }));
        let msg = generateWAMessageFromContent(
            m.chat,
            {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: `Hasil pencarian video TikTok untuk *${text}*` },
                            carouselMessage: {
                                cards: cards,
                                messageVersion: 1
                            }
                        }
                    }
                }
            },
            { quoted: fkontak }
        );
        await satanic.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil video.');
    }
}
break;
case 'xnxxsearch': {
if (!isPrem) return reply('you are not premium')
    if (!text) return reply(`Enter Query`);
    const apiUrlxnxx = `https://free-restapi.biz.id/api/xnxxsearch?query=${encodeURIComponent(text)}&apikey=${global.sakey}`;
    const resxnx = await axios.get(apiUrlxnxx);
    const results = resxnx.data?.result?.result;
    if (!results || !Array.isArray(results) || results.length === 0) {
        return reply(`No results found for: ${text}`);
    }
    let ffxnx = results.map((v, i) => 
        `${i + 1}┃ *Title:* ${v.title}\n*Link:* ${v.link}\n*Info:* ${v.info.trim()}`
    ).join('\n\n');
    reply(ffxnx);
}
break;
case 'xvideosearch': {
if (!isPrem) return reply('you are not premium')
    if (!text) return reply(`Enter Query`);
    const apiUrlxvideos = `https://free-restapi.biz.id/api/xvideosearch?query=${encodeURIComponent(text)}&apikey=${global.sakey}`;
    const resxvids = await axios.get(apiUrlxvideos);
    const results = resxvids.data?.result;
    if (!results || !Array.isArray(results) || results.length === 0) {
        return reply(`No results found for: ${text}`);
    }
    let ffxvids = results.map((v, i) => 
        `${i + 1}┃ *Title:* ${v.title}\n*Duration:* ${v.duration}\n*Link:* ${v.url}\n*Quality:* ${v.quality || '-'}`
    ).join('\n\n');
    reply(ffxvids);
}
break;  
case 'xnxxdl': {
if (!isPrem) return reply('you are not premium')
    if (!text) return reply(`Enter URL`);    
    const apiUrldl = `https://free-restapi.biz.id/api/xnxxdl?url=${encodeURIComponent(text)}&apikey=${global.sakey}`;
    const resdl = await axios.get(apiUrldl);    
    const data = resdl.data?.result?.result;    
    if (!data) {
        return reply(`Failed to get download link`);
    }    
    const videoUrl = data.files?.high || data.files?.low || data.files?.HLS;    
    if (!videoUrl) {
        return reply(`No video URL found`);
    }    
    let msg = `*Title:* ${data.title}\n`;
    msg += `*Duration:* ${Math.floor(data.duration / 60)}min ${data.duration % 60}detik\n`;
    msg += `*Info:* ${(data.info || '').trim()}\n\n`;
    msg += `*Download Links:*\n`;
    msg += `📱 Low (240p): ${data.files?.low || '-'}\n`;
    msg += `🎥 High (360p): ${data.files?.high || '-'}\n`;
    msg += `📺 HLS: ${data.files?.HLS || '-'}`;
    await satanic.sendMessage(m.chat, { 
        video: { url: videoUrl }, 
        caption: msg 
    }, { quoted: fkontak });
}
break;
case 'xvideodl': {
if (!isPrem) return reply('you are not premium')
    if (!text) return reply(`Enter URL`);    
    const apiUrldl = `https://free-restapi.biz.id/api/xvideodl?url=${encodeURIComponent(text)}&apikey=${global.sakey}`;
    const resdl = await axios.get(apiUrldl);    
    const data = resdl.data?.result?.result;
    if (!data) {
        return reply(`Failed to get download link`);
    }    
    let msg = `*Title:* ${data.title}\n`;
    msg += `*Tags:* ${data.keyword}`;       
    await satanic.sendMessage(m.chat, { 
        video: { url: data.url }, 
        caption: msg 
    }, { quoted: fkontak });
}
break;







/////// SEARCH MENU /////////
//////////// TOOLS MENU //////
case 'kodepos':
case 'kode_pos': {
    if (!text) return reply('Masukkan nama kota atau kecamatan!\n\nContoh: .kodepos jakarta');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/kodepos?kodepos=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status !== 200) {
            return reply('Kode pos tidak ditemukan.');
        }
        
        const result = response.data.result;
        const data = result.data.slice(0, 15);
        
        let info = `📍 *KODE POS INDONESIA*\n\n`;
        info += `🔍 *Pencarian:* ${text}\n`;
        info += `📊 *Total Ditemukan:* ${result.total}\n`;
        info += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
        
        for (let i = 0; i < data.length; i++) {
            const item = data[i];
            info += `${i+1}. *${item.kodepos}*\n`;
            info += `   📍 Desa/Kel: ${item.desa}\n`;
            info += `   🏘️ Kecamatan: ${item.kecamatan}\n`;
            info += `   🏙️ Kota: ${item.kota}\n`;
            info += `   🌏 Provinsi: ${item.provinsi}\n\n`;
        }
        
        if (result.total > 15) {
            info += `*dan ${result.total - 15} data lainnya...*\n\n`;
        }
        
        info += `📥 *Project By:* ${namaBot}`;
        
        await satanic.sendMessage(m.chat, { text: info }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mencari kode pos.');
    }
}
break;
case 'cekresi':
case 'resi': {
    if (!text) return reply('📦 *CEK RESI*\n\nMasukkan kurir dan nomor resi!\n\nContoh: .cekresi jne 123456789\n\n*Daftar Kurir:*\n• jne\n• pos\n• tiki\n• wahana\n• jnt\n• sicepat\n• ninja\n• spx (shopee express)\n• anteraja\n• lionparcel\n• ncs\n• pcp\n• rpx\n• sap\n• jet\n• indahlogistik\n• dse\n• firstlogistics\n• idexpress\n• lalamove\n• paxel\n• pandu\n• sentral\n• star\n• tiki\n• cargo\n• etc');   
    if (args.length < 2) return reply('⚠️ Format salah!\n\nContoh: .cekresi jne 123456789');   
    const kurir = args[0].toLowerCase();
    const noResi = args[1];
    const listKurir = ['jne', 'pos', 'tiki', 'wahana', 'jnt', 'sicepat', 'ninja', 'spx', 'anteraja', 'lionparcel', 'ncs', 'pcp', 'rpx', 'sap', 'jet', 'indahlogistik', 'dse', 'firstlogistics', 'idexpress', 'lalamove', 'paxel', 'pandu', 'sentral', 'star', 'cargo', 'etc'];
    if (!listKurir.includes(kurir)) {
        return reply(`❌ Kurir *${kurir}* tidak dikenal!\n\n📋 *Daftar Kurir:*\n${listKurir.join(', ')}`);
    }
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        const apiUrl = `https://free-restapi.biz.id/api/cekresi?kurir=${kurir}&resi=${noResi}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        if (response.data.status !== 200) {
            return reply(`❌ Resi tidak ditemukan untuk kurir *${kurir.toUpperCase()}* dengan nomor *${noResi}*`);
        }
        const result = response.data.result;
        let info = `📦 *CEK RESI*\n\n`;
        info += `🚚 *Expedisi:* ${result.expedisi || kurir.toUpperCase()}\n`;
        info += `📝 *No Resi:* ${result.no_resi}\n`;
        info += `✅ *Status:* ${result.status}\n`;
        if (result.tanggal_kirim) {
            info += `📅 *Tanggal Kirim:* ${result.tanggal_kirim}\n`;
        }
        info += `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        info += `📜 *RIWAYAT PENGIRIMAN*\n\n`;
        if (result.riwayat && result.riwayat.length > 0) {
            for (let i = 0; i < result.riwayat.length; i++) {
                const r = result.riwayat[i];
                info += `${i+1}. ${r.waktu || '-'}\n`;
                info += `   📍 ${r.deskripsi || r.deskripsi_original || '-'}\n`;
                if (r.lokasi) info += `   📌 Lokasi: ${r.lokasi}\n`;
                info += `\n`;
            }
        } else {
            info += `Tidak ada riwayat pengiriman.\n`;
        }
        info += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        info += `📥 *Project By:* ${namaBot}`;
        if (info.length > 4096) {
            let parts = info.match(/[\s\S]{1,4096}/g) || [];
            for (let part of parts) {
                await satanic.sendMessage(m.chat, { text: part }, { quoted: fkontak });
            }
        } else {
            await satanic.sendMessage(m.chat, { text: info }, { quoted: fkontak });
        }     
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('❌ Terjadi kesalahan saat melacak resi.');
    }
}
break;
case 'google': {
  satanic.sendMessage(m.chat, { react: { text: `🔍`, key: m.key } });
  if (!text) {
    return satanic.sendMessage(m.chat, { 
      text: `*🔎 GOOGLE SEARCH*\n\nContoh: ${prefix}google indonesia\n\nMasukkan kata kunci pencarian setelah perintah.`
    });
  }
  let apiUrl = `https://free-restapi.biz.id/api/google?query=${encodeURIComponent(text)}&apikey=${global.sakey}`;
  let response = await fetch(apiUrl);
  let data = await response.json();
  if (!data || data.length === 0) {
    return satanic.sendMessage(m.chat, { text: '❌ Tidak ada hasil ditemukan.' });
  }
  let resultText = `*🔎 HASIL PENCARIAN: ${text}*\n\n`;
  for (let i = 0; i < Math.min(data.length, 5); i++) {
    resultText += `*${i+1}. ${data[i].title}*\n`;
    resultText += `📝 ${data[i].description}\n`;
    resultText += `🔗 ${data[i].url}\n\n`;
  }
  await satanic.sendMessage(m.chat, { text: resultText });
}
break
case "kalkulator":{
 val = text
.replace(/[^0-9\-\/+*×÷πEe()piPI/]/g, '')
.replace(/×/g, '*')
.replace(/÷/g, '/')
.replace(/π|pi/gi, 'Math.PI')
.replace(/e/gi, 'Math.E')
.replace(/\/+/g, '/')
.replace(/\++/g, '+')
.replace(/-+/g, '-')
let format = val
.replace(/Math\.PI/g, 'π')
.replace(/Math\.E/g, 'e')
.replace(/\//g, '÷')
.replace(/\*×/g, '×')
try {
let result = (new Function('return ' + val))()
if (!result) return reply(result)
reply(`*${format}* = _${result}_`)
} catch (e) {
if (e == undefined) return reply('Isinya?')
reply('Format salah, hanya 0-9 dan Simbol -, +, *, /, ×, ÷, π, e, (, ) yang disupport')
}
}
break
case 'balogo': {
    if (!text) return reply('*Contoh:*\n' + prefix + command + ' sata ganz');
    
    try {
        const encodedText = encodeURIComponent(text);
        const url = `https://api.nexray.eu.cc/maker/balogo?text=${encodedText}`;
        
        const response = await axios({
            method: 'GET',
            url: url,
            responseType: 'arraybuffer'
        });
        
        const buffer = Buffer.from(response.data, 'binary');
        
        await satanic.sendMessage(m.chat, {
            image: buffer,
            caption: `✅ Logo: ${text}`
        }, { quoted: fkontak });
        
    } catch (error) {
        console.error('Error:', error.message);
        reply('❌ Gagal mengambil gambar dari API');
    }
    break;
}
// ===== CASE SKIPLINK2 (BYPASS LINK) =====
case 'skiplink': {
    if (!text) return reply('Masukkan URL yang ingin di-skip!\n\nContoh: .skiplink https://example.com');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const url = text.trim();
        
        const { data: res } = await axios.get(
            "https://api.theresav.biz.id/bypass/universal",
            {
                params: { url, apikey: global.thesera },
                timeout: 30000
            }
        );
        
        if (!res.status || !res.result) {
            return reply('❌ Gagal memproses link! Pastikan URL valid.');
        }
        
        let replyText = `*Link Berhasil Di-skip!*\n\n`;
        replyText += `*Original URL:*\n${url}\n\n`;
        replyText += `*Result URL:*\n${res.result}`;
        
        await satanic.sendMessage(m.chat, { text: replyText }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error('Error Skiplink:', err);
        if (err.code === 'ECONNABORTED') {
            reply('⏰ Waktu habis! Coba lagi nanti.');
        } else {
            reply('❌ Terjadi kesalahan saat memproses link.');
        }
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'skiplink2':
case 'bypass2': {
    if (!text) return reply('Masukkan URL shortener!\n\nContoh: .skiplink https://sfl.gl/xxx');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    const apiUrl = `https://fgsi.dpdns.org/api/tools/skip/tutwuri?apikey=fgsiapi-266582c1-6d&url=${encodeURIComponent(text)}`;
    const response = await axios.get(apiUrl);
    
    if (!response.data.status) {
        return reply('Gagal melewati link!');
    }
    
    const resultUrl = response.data.data.url;
    
    let info = `🔗 *SKIP LINK BYPASSER*\n\n`;
    info += `📌 *Original URL:* ${text}\n`;
    info += `✅ *Destination URL:* ${resultUrl}\n\n`;
    info += `📥 *Download by:* ${namaBot}`;
    
    await satanic.sendMessage(m.chat, { text: info }, { quoted: fkontak });
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'whatmusic':
case 'whatsong':
case 'identify': {
    if (!quoted) return reply(`🎵 *WHAT MUSIC - Identify Song* 🎵\n\n> Mengidentifikasi lagu dari file audio/video\n\n📌 *Cara penggunaan:*\n\n1️⃣ *Dengan URL audio:*\n\`\`\`${prefix + command} <url_audio>\`\`\`\n\n2️⃣ *Reply ke pesan audio/video:*\n\`\`\`Reply ke pesan audio/vn/video lalu kirim ${prefix + command}\`\`\``);
    
    let mime = quoted.mimetype || '';
    let audioUrl = null;
    
    // Fungsi upload ke Litterbox
    async function uploadToLitterbox(fileBuffer, filename) {
        try {
            const form = new FormData();
            form.append('reqtype', 'fileupload');
            form.append('time', '72h');
            form.append('fileToUpload', Buffer.from(fileBuffer), {
                filename: filename,
                contentType: require('mime').lookup(filename) || 'application/octet-stream'
            });

            const response = await axios.post('https://litterbox.catbox.moe/resources/internals/api.php', form, {
                headers: form.getHeaders(),
                timeout: 30000
            });

            if (response.status !== 200) throw new Error('Litterbox gagal');
            const url = response.data;
            if (!url.startsWith('http')) throw new Error('Invalid response');
            return url;
        } catch (err) {
            console.error("Litterbox Error:", err.message);
            return null;
        }
    }
    
    // Jika command langsung dengan URL
    let directUrl = text;
    if (directUrl && (directUrl.includes('http') || directUrl.includes('cdn'))) {
        audioUrl = directUrl;
    }
    // Jika reply ke pesan audio/video
    else if (quoted && (/audio/.test(mime) || /video/.test(mime))) {
        const mediaBuffer = await quoted.download();
        
        // Upload ke Litterbox
        const extension = mime.split('/')[1] || 'mp3';
        const filename = `audio.${extension}`;
        audioUrl = await uploadToLitterbox(mediaBuffer, filename);
        
        if (!audioUrl) {
            return reply('Gagal upload audio ke Litterbox');
        }
    }
    else {
        return reply(`Kirim atau reply file audio/video!`);
    }
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    const identifyEndpoint = `https://api.neoxr.eu/api/whatmusic?url=${encodeURIComponent(audioUrl)}&apikey=${global.neoxr}`;
    const identifyResponse = await axios.get(identifyEndpoint);
    const identifyResult = identifyResponse.data;
    
    if (!identifyResult.status) return reply('Gagal mengidentifikasi lagu');
    
    const songData = identifyResult.data;
    
    let balasan = `🎵 *WHAT MUSIC - SONG IDENTIFIER* 🎵\n\n`;
    balasan += `━━━━━━━━━━━━━━━━━━━━━━\n`;
    balasan += `🎤 *Judul:* ${songData.title}\n`;
    balasan += `👨‍🎤 *Artis:* ${songData.artist}\n`;
    balasan += `💿 *Album:* ${songData.album}\n`;
    balasan += `📅 *Rilis:* ${songData.release}\n`;
    balasan += `━━━━━━━━━━━━━━━━━━━━━━\n\n`;
    
    balasan += `🔗 *TAUTAN MUSIK:*\n\n`;
    
    if (songData.links?.spotify) {
        balasan += `🎧 *Spotify*\n`;
        balasan += `   • 🔗 https://open.spotify.com/track/${songData.links.spotify.track.id}\n\n`;
    }
    
    if (songData.links?.deezer) {
        balasan += `🎵 *Deezer*\n`;
        balasan += `   • 🔗 https://deezer.com/track/${songData.links.deezer.track.id}\n\n`;
    }
    
    if (songData.links?.youtube) {
        balasan += `📺 *YouTube*\n`;
        balasan += `   • 🔗 https://youtu.be/${songData.links.youtube.vid}\n\n`;
    }
    
    if (songData.links?.soundcloud) {
        balasan += `🎙️ *SoundCloud*\n`;
        balasan += `   • 🔗 ${songData.links.soundcloud.url || 'https://soundcloud.com/'}\n\n`;
    }
    
    balasan += `━━━━━━━━━━━━━━━━━━━━━━\n`;
    balasan += `📥 *Project By:* ${namaBot}`;
    
    await satanic.sendMessage(m.chat, { text: balasan }, { quoted: fkontak });
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'ocr':
case 'readtext': {
 const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Hanya support gambar!');    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    async function uploadToLitterbox(fileBuffer, filename) {
        try {
            const FormData = require('form-data');
            const form = new FormData();
            form.append('reqtype', 'fileupload');
            form.append('time', '72h');
            form.append('fileToUpload', Buffer.from(fileBuffer), {
                filename: filename,
                contentType: require('mime').lookup(filename) || 'image/jpeg'
            });

            const response = await axios.post('https://litterbox.catbox.moe/resources/internals/api.php', form, {
                headers: form.getHeaders(),
                timeout: 30000
            });
            if (response.status !== 200) throw new Error('Litterbox gagal');
            const url = response.data;
            if (!url.startsWith('http')) throw new Error('Invalid response');
            return url;
        } catch (err) {
            console.error("Litterbox Error:", err.message);
            return null;
        }
    }
    let mediaBuffer = await quoted.download();
    let extension = mime.split('/')[1] || 'jpg';
    let imageUrl = await uploadToLitterbox(mediaBuffer, `image.${extension}`);
    if (!imageUrl) {
        return reply('Gagal upload gambar ke Litterbox');
    }
    const apiUrl = `https://free-restapi.biz.id/api/ocr?image_url=${encodeURIComponent(imageUrl)}&apikey=${global.sakey}`;
    const response = await axios.get(apiUrl);
    
    if (response.data.status !== 200) {
        return reply('Gagal membaca teks dari gambar.');
    }
    const result = response.data.result;
    let info = `🔍 *OCR - TEXT EXTRACTOR*\n\n`;
    info += `📊 *Total Karakter:* ${result.total_characters}\n`;
    info += `📄 *Total Baris:* ${result.total_lines}\n`;
    info += `🎯 *Confidence:* ${result.ocr_confidence}\n\n`;
    info += `━━━━━━━━━━━━━━━━━━━━━━\n`;
    info += `📝 *HASIL TEKS:*\n\n${result.text}\n`;
    info += `━━━━━━━━━━━━━━━━━━━━━━\n`;
    info += `📥 *Project By:* ${namaBot}`;
    
    await satanic.sendMessage(m.chat, { text: info }, { quoted: fkontak });
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'translate': {
  async function translate(query = "", lang) {
    if (!query.trim()) return "";
    const url = new URL("https://translate.googleapis.com/translate_a/single");
    url.searchParams.append("client", "gtx");
    url.searchParams.append("sl", "auto");
    url.searchParams.append("dt", "t");
    url.searchParams.append("tl", lang);
    url.searchParams.append("q", query);
    try {
      const response = await fetch(url.href);
      const data = await response.json();
      if (data && data[0]) {
        return data[0].map(item => item[0].trim()).join("\n");
      }
      return "";
    } catch (err) {
      throw err;
    }
  }
  let textToTranslate = "";
  let targetLang = "id";
  if (text && text.trim()) {
    const firstWord = text.trim().split(" ")[0];
    if (firstWord.length === 2 && /^[a-z]{2}$/i.test(firstWord)) {
      targetLang = firstWord.toLowerCase();
      textToTranslate = text.trim().split(" ").slice(1).join(" ");
    } else {
      textToTranslate = text;
    }
  }
  if (!textToTranslate && m.quoted && m.quoted.text) {
    textToTranslate = m.quoted.text;
  }
  if (!textToTranslate || !textToTranslate.trim()) {
    return reply(`⚠️ *Contoh penggunaan semua bahasa:*\n\n\
🌏 *ASIA*\n\
└ .translate id Good morning → selamat pagi\n\
└ .translate en Selamat pagi → good morning\n\
└ .translate ja Selamat pagi → おはようございます\n\
└ .translate ko Selamat pagi → 좋은 아침이에요\n\
└ .translate zh Selamat pagi → 早上好\n\
└ .translate th Selamat pagi → อรุณสวัสดิ์\n\
└ .translate vi Selamat pagi → chào buổi sáng\n\
└ .translate hi Selamat pagi → सुप्रभात\n\
└ .translate ms Selamat pagi → selamat pagi\n\
└ .translate tl Selamat pagi → magandang umaga\n\n\
🇪🇺 *EROPA*\n\
└ .translate es Selamat pagi → buenos días\n\
└ .translate fr Selamat pagi → bonjour\n\
└ .translate de Selamat pagi → guten morgen\n\
└ .translate it Selamat pagi → buongiorno\n\
└ .translate pt Selamat pagi → bom dia\n\
└ .translate ru Selamat pagi → доброе утро\n\
└ .translate nl Selamat pagi → goedemorgen\n\
└ .translate pl Selamat pagi → dzień dobry\n\n\
🌍 *TIMUR TENGAH & AFRIKA*\n\
└ .translate ar Selamat pagi → صباح الخير\n\
└ .translate tr Selamat pagi → günaydın\n\
└ .translate sw Selamat pagi → habari za asubuhi\n\n\
📝 *Cara pakai:*\n\
└ Ketik: .translate [kode] [teks]\n\
└ Atau reply pesan + .translate [kode]`);
  }
  try {
    const result = await translate(textToTranslate, targetLang);
    if (!result) return reply("❌ Gagal menerjemahkan teks.");
    reply(result);
  } catch (error) {
    reply(`❌ Error: ${error.message}`);
  }
  break;
}

case 'ssweb':
case 'screenshotweb': {
    if (!text) return reply('Masukkan URL website!\n\nContoh: .ssweb https://google.com\n\nDevice: desktop, tablet, mobile\nContoh: .ssweb https://google.com tablet');
    const url = args[0];
    let device = args[1] ? args[1].toLowerCase() : 'desktop';
    if (!['desktop', 'tablet', 'mobile'].includes(device)) {
        return reply('Device tidak valid! Gunakan: desktop, tablet, atau mobile');
    }
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
        return reply('URL harus lengkap dengan http:// atau https://');
    }
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        const apiUrl = `https://free-restapi.biz.id/api/ssweb?url=${encodeURIComponent(url)}&device=${device}&apikey=${global.sakey}`
         await satanic.sendMessage(m.chat, {
            image: { url: apiUrl },
            caption: `*SSWEB RESULT*\n\nURL: ${url}\nDevice: ${device}\n\nProject By: ${namaBot}`
        }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil screenshot website.');
    }
}
break;

///////// BATAS AKHIR ////////
////////// DOWNLOAD MENU /////////
case 'tt':
case 'ttdl':
case 'tiktok':
case 'tiktokdl': {
if (!text) return reply('Masukkan URL TikToknya!\n\nContoh: .tt https://www.tiktok.com/@username/video/xxx')
await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
 const apiUrl = `https://free-restapi.biz.id/api/ttdl?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl)
    if (response.data.status !== 200) {
        return reply('Gagal mengambil data dari TikTok')
    }
    const result = response.data.result
    let info = `TIKTOK DOWNLOADER\n\n`
    info += `Title: ${result.title}\n`
    info += `Duration: ${result.duration}\n`
    info += `Region: ${result.region}\n`
    info += `Taken At: ${result.taken_at}\n\n`
    info += `AUTHOR\n`
    info += `Nickname: ${result.author.nickname}\n`
    info += `Username: ${result.author.id}\n\n`
    info += `STATS\n`
    info += `Views: ${result.stats.views}\n`
    info += `Likes: ${result.stats.likes}\n`
    info += `Comments: ${result.stats.comment}\n`
    info += `Shares: ${result.stats.share}\n`
    info += `Downloads: ${result.stats.download}\n\n`
    info += `Project By: ${global.namaBot}`
    const videoUrl = result.videos.find(v => v.type === 'nowatermark')?.url || result.videos[0]?.url
    await satanic.sendMessage(m.chat, { 
        video: { url: videoUrl }, 
        caption: info 
    }, { quoted: fkontak })
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break
case 'play':{
    if(!text) return reply('Masukkan judul lagu!');
    try{
        await satanic.sendMessage(m.chat,{react:{text:'🎵',key:m.key}});
        const SavetubeDownloader = require('./lib/savetube'); 
        const downloader = new SavetubeDownloader();
        const yts = require('yt-search');
        const search = await yts(text);
        if(!search.all.length) return reply('❌ Lagu tidak ditemukan');
        
        const video = search.all[0];
        const videoUrl = video.url;
        const title = video.title;
        const thumbnail = video.thumbnail;
        const duration = video.timestamp;
        const views = video.views;
        
        await satanic.sendMessage(m.chat,{
            image:{url:thumbnail},
            caption:`🎵 *${title}*\n\n⏱️ *Durasi:* ${duration}\n👁️ *Views:* ${views.toLocaleString()}\n🔗 *Link:* ${videoUrl}\n\n📥 *Mengunduh audio...*`
        },{quoted:fkontak});
        
        let audioSent = false;
        
        // Fallback 1: Coba SavetubeDownloader
        try {
            const result = await downloader.ytmp3(videoUrl, "128");
            if (result && result.success && result.data && result.data.downloadUrl) {
                await satanic.sendMessage(m.chat,{
                    audio:{url:result.data.downloadUrl},
                    mimetype:'audio/mpeg',
                    ptt:false
                },{quoted:fkontak});
                audioSent = true;
            } else {
                throw new Error('Savetube gagal');
            }
        } catch (err) {
            console.log('[FALLBACK] Savetube error:', err.message);
            
            // Fallback 2: Coba y2mate
            try {
                const y2mateResult = await y2mate(videoUrl);
                if (y2mateResult && y2mateResult.status === 'tunnel' && y2mateResult.url) {
                    await satanic.sendMessage(m.chat, {
                        audio: { url: y2mateResult.url },
                        mimetype: 'audio/mpeg',
                        filename: y2mateResult.filename || `${title}.mp3`,
                        ptt: false
                    }, { quoted: fkontak });
                    audioSent = true;
                } else {
                    throw new Error('y2mate gagal');
                }
            } catch (err2) {
                console.log('[FALLBACK] y2mate error:', err2.message);
                // Fallback 3: Kirim link saja
                await satanic.sendMessage(m.chat, {
                    text: `⚠️ Gagal mengunduh audio.\n\nSilahkan download manual:\n${videoUrl}\n\nAtau coba perintah:\n.ytmp3 ${videoUrl}`
                }, { quoted: fkontak });
            }
        }
        
        if (audioSent) {
            await satanic.sendMessage(m.chat,{react:{text:'✅',key:m.key}});
        } else {
            await satanic.sendMessage(m.chat,{react:{text:'⚠️',key:m.key}});
        }
        
    } catch(error){
        console.error('[ERROR]', error);
        await satanic.sendMessage(m.chat, {
            text: '❌ Terjadi kesalahan, silahkan coba lagi nanti.'
        }, { quoted: fkontak });
        await satanic.sendMessage(m.chat,{react:{text:'❌',key:m.key}});
    }
    break;
}

case 'ytmp3': {
    if (!text) return reply('Masukkan URL YouTube!');
    try {
        await satanic.sendMessage(m.chat, { react: { text: '🎵', key: m.key } });
        
        const SavetubeDownloader = require('./lib/savetube');
        const downloader = new SavetubeDownloader();
        
        if (!text.includes('youtube.com') && !text.includes('youtu.be')) {
            return reply('❌ Masukkan URL YouTube yang valid!');
        }
        
        let audioSent = false;
        
        // Fallback 1: Coba SavetubeDownloader
        try {
            const result = await downloader.ytmp3(text, "128");
            if (result && result.success && result.data && result.data.downloadUrl) {
                const data = result.data;
                let viewsText = 'Tidak diketahui';
                if (data.videoInfo && data.videoInfo.views) {
                    viewsText = typeof data.videoInfo.views === 'number' 
                        ? data.videoInfo.views.toLocaleString() 
                        : data.videoInfo.views;
                }
                
                await satanic.sendMessage(m.chat, {
                    image: { url: data.thumbnail },
                    caption: `🎵 *${data.title}*\n\n⏱️ *Durasi:* ${data.duration || 'Tidak diketahui'}\n🎚️ *Kualitas:* ${data.quality} kbps\n📦 *Ukuran:* ${data.size || 'Tidak diketahui'}\n👤 *Channel:* ${data.videoInfo?.channel || 'Tidak diketahui'}\n👁️ *Views:* ${viewsText}\n\n📥 *Mengunduh audio...*`
                }, { quoted: fkontak });
                
                await satanic.sendMessage(m.chat, {
                    audio: { url: data.downloadUrl },
                    mimetype: 'audio/mpeg',
                    ptt: false,
                    fileName: `${data.title}.mp3`
                }, { quoted: fkontak });
                audioSent = true;
            } else {
                throw new Error('Savetube gagal');
            }
        } catch (err) {
            console.log('[FALLBACK] Savetube error:', err.message);
            
            // Fallback 2: Coba y2mate
            try {
                const result = await y2mate(text);
                if (result && result.status === 'tunnel' && result.url) {
                    const filename = result.filename || 'audio.mp3';
                    await satanic.sendMessage(m.chat, {
                        audio: { url: result.url },
                        mimetype: 'audio/mpeg',
                        filename: filename,
                        ptt: false
                    }, { quoted: fkontak });
                    audioSent = true;
                } else {
                    throw new Error('y2mate gagal');
                }
            } catch (err2) {
                console.log('[FALLBACK] y2mate error:', err2.message);
                // Fallback 3: Kirim link saja
                await satanic.sendMessage(m.chat, {
                    text: `⚠️ Gagal mengunduh audio.\n\nSilahkan download manual:\n${text}\n\nAtau coba layanan lain.`
                }, { quoted: fkontak });
            }
        }
        
        if (audioSent) {
            await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            await satanic.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
        }
        
    } catch (error) {
        console.error('[ERROR]', error);
        await satanic.sendMessage(m.chat, {
            text: '❌ Terjadi kesalahan, silahkan coba lagi nanti.'
        }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
    break;
}

// Fungsi y2mate (tetap seperti kode Anda)
async function y2mate(input) {
    let videoUrl = input
    
    // Cek apakah input adalah link atau judul
    if (!input.includes('youtube.com') && !input.includes('youtu.be')) {
      console.log(`[Search] "${input}" ...`)
      const searchResults = await yts(input)
      
      if (!searchResults.videos.length) {
        throw new Error('Tidak ada video ditemukan untuk pencarian tersebut.')
      }

      const topResult = searchResults.videos[0]
      videoUrl = topResult.url     
    }

    try {
      // Ambil key converter
      const sanityRes = await axios.get('https://cnv.cx/v2/sanity/key', {
        headers: {
          'sec-ch-ua-platform': '"Android"',
          'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Mobile Safari/537.36 EdgA/144.0.0.0',
          'sec-ch-ua': '"Not(A:Brand";v="8", "Chromium";v="144", "Microsoft Edge";v="144"',
          'content-type': 'application/json',
          'sec-ch-ua-mobile': '?1',
          'accept': '*/*',
          'origin': 'https://frame.y2meta-uk.com',
          'sec-fetch-site': 'cross-site',
          'sec-fetch-mode': 'cors',
          'sec-fetch-dest': 'empty',
          'referer': 'https://frame.y2meta-uk.com/',
          'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
          'priority': 'u=1, i'
        }
      })

      const key = sanityRes.data?.key
      if (!key) throw new Error('Gagal mengambil key converter')
      
      // Konversi ke MP3
      const body = new URLSearchParams({
        link: videoUrl,
        format: 'mp3',
        audioBitrate: '128',
        videoQuality: '720',
        filenameStyle: 'pretty',
        vCodec: 'h264'
      }).toString()

      const convertRes = await axios.post('https://cnv.cx/v2/converter', body, {
        headers: {
          'key': key,
          'sec-ch-ua-platform': '"Android"',
          'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Mobile Safari/537.36 EdgA/144.0.0.0',
          'accept': '*/*',
          'sec-ch-ua': '"Not(A:Brand";v="8", "Chromium";v="144", "Microsoft Edge";v="144"',
          'content-type': 'application/x-www-form-urlencoded',
          'sec-ch-ua-mobile': '?1',
          'origin': 'https://frame.y2meta-uk.com',
          'sec-fetch-site': 'cross-site',
          'sec-fetch-mode': 'cors',
          'sec-fetch-dest': 'empty',
          'referer': 'https://frame.y2meta-uk.com/',
          'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
          'priority': 'u=1, i'
        }
      })

      return convertRes.data

    } catch (err) {
      console.error('[ERROR]', err.message)
      if (err.response) {
        console.error('Status:', err.response.status)
        console.error('Data:', err.response.data)
      }
      throw err
    }
}
case 'ytmp4': {
    if (!text) return reply('Masukkan URL YouTube!');
    try {
        await satanic.sendMessage(m.chat, { react: { text: '📹', key: m.key } });
        
        const SavetubeDownloader = require('./lib/savetube');
        const downloader = new SavetubeDownloader();
        
        if (!text.includes('youtube.com') && !text.includes('youtu.be')) {
            return reply('❌ Masukkan URL YouTube yang valid!');
        }
        
        let quality = "360";
        if (text.includes('quality=')) {
            const match = text.match(/quality=(\d+)/);
            if (match) quality = match[1];
            text = text.split('?')[0];
        }
        
        const result = await downloader.ytmp4(text, quality);
        
        if (!result.success) {
            throw new Error(result.error);
        }
        
        const data = result.data;
        
        let viewsText = 'Tidak diketahui';
        if (data.videoInfo && data.videoInfo.views) {
            viewsText = typeof data.videoInfo.views === 'number' 
                ? data.videoInfo.views.toLocaleString() 
                : data.videoInfo.views;
        }
        
        await satanic.sendMessage(m.chat, {
            image: { url: data.thumbnail },
            caption: `📹 *${data.title}*\n\n⏱️ *Durasi:* ${data.duration || 'Tidak diketahui'}\n🎚️ *Kualitas:* ${data.quality}\n📦 *Ukuran:* ${data.size || 'Tidak diketahui'}\n👤 *Channel:* ${data.videoInfo?.channel || 'Tidak diketahui'}\n👁️ *Views:* ${viewsText}\n\n📥 *Mengunduh video...*`
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, {
            video: { url: data.downloadUrl },
            mimetype: 'video/mp4',
            fileName: `${data.title}.mp4`,
            caption: `✅ Sukses download video: ${data.title}`
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (error) {
        reply('❌ Gagal download video: ' + error.message);
    }
    break;
}

case 'ttmp3':
case 'tiktokmp3': {
    if (!text) return reply('Masukkan URL TikTok!\n\nContoh: .ttmp3 https://www.tiktok.com/@username/video/xxx');
 await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    const apiUrl = `https://free-restapi.biz.id/api/ttdl?url=${encodeURIComponent(text)}&apikey=${global.sakey}`;
    const response = await axios.get(apiUrl);
    if (response.data.status !== 200) {
        return reply('Gagal mengambil data dari TikTok');
    }
    const result = response.data.result;
    const videoUrl = result.videos.find(v => v.type === 'nowatermark')?.url || result.videos[0]?.url;
    await satanic.sendMessage(m.chat, { 
        audio: { url: videoUrl },
        mimetype: 'audio/mpeg'
    }, { quoted: fkontak });
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;

case 'mediafire':
case 'mediafiredl': {
if (!text || !text.includes("mediafire.com"))
        return reply(`📌 Contoh penggunaan:\n${prefix + command} https://www.mediafire.com/file/abc123/example.zip/file`);
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    const cheerio = require("cheerio");
    const mime = require("mime-types");
    const fs = require("fs");
    const path = require("path");
    async function getDirectMediaFireLink(pageUrl) {
        try {
            const res = await fetch(pageUrl);
            const html = await res.text();
            const $ = cheerio.load(html);
            const directLink = $("a#downloadButton").attr("href");
            const fileName = $("div.filename").text().trim() || "mediafire_file";

            if (!directLink) throw new Error("Link unduhan tidak ditemukan.");
            return { fileName, directLink };
        } catch (err) {
            return { error: true, message: err.message };
        }
    }
    function getFileType(mimeType) {
        if (mimeType.startsWith('image/')) return 'image';
        if (mimeType.startsWith('video/')) return 'video';
        if (mimeType.startsWith('audio/')) return 'audio';
        return 'document';
    }
    try {
        const result = await getDirectMediaFireLink(text.trim());
        if (!result || result.error || !result.directLink) {
            await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return reply(`❌ Gagal mengambil link download.\n${result?.message || "Link tidak valid atau server error."}`);
        }
        const fileName = result.fileName;
        const fileUrl = result.directLink;
        const mimeType = mime.lookup(fileName) || "application/octet-stream";
        const fileType = getFileType(mimeType);
        const caption = `📦 *MediaFire Downloader*\n\n📁 *Nama File:* ${fileName}\n✅ *Status:* Siap diunduh`;
        const tempDir = path.join(__dirname, 'temp');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
        const safeName = fileName.replace(/[^a-z0-9._-]/gi, "_");
        const tempPath = path.join(tempDir, `mf_${Date.now()}_${safeName}`);
        const res = await fetch(fileUrl);
        if (!res.ok) throw new Error("Gagal mengunduh file dari MediaFire.");
        const fileStream = fs.createWriteStream(tempPath);
        await new Promise((resolve, reject) => {
            res.body.pipe(fileStream);
            res.body.on("error", reject);
            fileStream.on("finish", resolve);
        });
        const buffer = fs.readFileSync(tempPath);
        if (fileType === 'image') {
            await satanic.sendMessage(m.chat, {
                image: buffer,
                caption: caption,
                mimetype: mimeType
            }, { quoted: fkontak });
        } 
        else if (fileType === 'video') {
            await satanic.sendMessage(m.chat, {
                video: buffer,
                caption: caption,
                mimetype: mimeType
            }, { quoted: fkontak });
        }
        else if (fileType === 'audio') {
            await satanic.sendMessage(m.chat, {
                audio: buffer,
                mimetype: mimeType,
                ptt: false // set true jika ingin jadi voice note
            }, { quoted: fkontak });
        }
        else {
            await satanic.sendMessage(m.chat, {
                document: buffer,
                fileName: fileName,
                mimetype: mimeType,
                caption: caption
            }, { quoted: fkontak });
        }
        fs.unlinkSync(tempPath); 
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply(`❌ Gagal mengirim file:\n${err.message}`);
    }
break;
}
case 'git': case 'github': case 'gitclone': {
if (!args[0]) return reply(`Mana linknya?\nExample :\n${prefix}${command} https://github.com/DGXeon/XeonMedia`)
if (!isUrl(args[0]) && !args[0].includes('github.com')) return reply(`Link invalid!!`)
await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
    let [, user, repo] = args[0].match(regex1) || []
    repo = repo.replace(/.git$/, '')
    let url = `https://api.github.com/repos/${user}/${repo}/zipball`
    let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
    satanic.sendMessage(m.chat, { document: { url: url }, fileName: filename+'.zip', mimetype: 'application/zip' }, { quoted: fkontak })
}
break
case 'capcut':
case 'cc': {
if (!text) return reply('Masukkan URL CapCutnya!\n\nContoh: .capcut https://www.capcut.com/t/xxx')
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    const apiUrl = `https://free-restapi.biz.id/api/capcut?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl)
    if (!response.data.success) {
        return reply('Gagal mengambil data dari CapCut')
    }
    const result = response.data
    let info = `CAPCUT DOWNLOADER\n\n`
    info += `Title: ${result.title}\n`
    info += `Author: ${result.author}\n`
    info += `Project By: ${namaBot}`
    
    await satanic.sendMessage(m.chat, { 
        video: { url: result.videoUrl }, 
        caption: info 
    }, { quoted: fkontak })
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break
case 'terabox':
case 'teraboxdl': {
    if (!text) return reply('Masukkan URL Teraboxnya!\n\nContoh: .terabox https://www.terabox.com/xxx')
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    const apiUrl = `https://free-restapi.biz.id/api/terabox?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl)
    if (response.data.status !== 200) {
        return reply('Gagal mengambil data dari Terabox')
    }
    const result = response.data.result
    const file = result.list[0]
    let info = `TERABOX DOWNLOADER\n\n`
    info += `Name: ${file.name}\n`
    info += `Size: ${file.size_formatted}\n`
    info += `Type: ${file.type}\n`
    info += `Duration: ${file.duration}\n`
    info += `Quality: ${file.quality}\n`
    info += `Project By: ${namaBot}`
    const zipUrl = file.zip_dlink
    await satanic.sendMessage(m.chat, { 
        document: { url: zipUrl }, 
        mimetype: 'application/zip',
        fileName: `${file.name}.zip`,
        caption: info 
    }, { quoted: fkontak })
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break
case 'spotify':
case 'spotifydl': {
    if (!text) return reply('Masukkan URL Spotifynya!\n\nContoh: .spotify https://open.spotify.com/track/xxx')
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    const apiUrl = `https://free-restapi.biz.id/api/spotify?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl, { responseType: 'arraybuffer' })
    await satanic.sendMessage(m.chat, { 
        audio: response.data, 
        mimetype: 'audio/mpeg'
    }, { quoted: fkontak })
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break
case 'threads':
case 'th': {
    if (!text) return reply('Masukkan URL Threadsnya!\n\nContoh: .threads https://www.threads.net/@username/post/id')
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    
    const apiUrl = `https://free-restapi.biz.id/api/threads?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl)
    
    if (response.data.status !== 200) {
        return reply('Gagal mengambil data dari Threads')
    }
    
    const result = response.data.result
    
    let info = `THREADS DOWNLOADER\n\n`
    info += `Username: ${result.user.username}\n`
    info += `Text: ${result.text}\n`
    info += `Project By: ${namaBot}`
    
    // Jika ada video, kirim langsung tanpa button
    if (result.videos && result.videos.length > 0) {
        for (let i = 0; i < result.videos.length; i++) {
            let videoUrl = result.videos[i]
            await satanic.sendMessage(m.chat, { 
                video: { url: videoUrl },
                caption: info
            }, { quoted: fkontak })
        }
    }
    
    // Jika ada gambar, pake button carousel
    if (result.images && result.images.length > 0) {
        let selectedImages = result.images.slice(0, 10);
        let anu = []
        
        for (let i = 0; i < selectedImages.length; i++) {
            let imgUrl = selectedImages[i][0].url
            let imgsc = await prepareWAMessageMedia({
                image: { url: imgUrl }
            }, {
                upload: satanic.waUploadToServer
            })

            anu.push({
                header: proto.Message.InteractiveMessage.Header.fromObject({
                    title: `Gambar ke *${i + 1}*`,
                    hasMediaAttachment: true,
                    ...imgsc
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [{
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "Lihat di Threads",
                            url: result.url
                        })
                    }]
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                    text: info
                })
            })
        }
        
        const msg = await generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        body: proto.Message.InteractiveMessage.Body.fromObject({
                            text: `📱 Hasil Threads dari @${result.user.username}`
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                            cards: anu
                        })
                    })
                }
            }
        }, {
            userJid: sender,
            quoted: fkontak
        })
        satanic.relayMessage(m.chat, msg.message, {
            messageId: msg.key.id
        })
    }
    
    if (!result.videos && !result.images) {
        return reply('Tidak ada video atau gambar yang ditemukan')
    }
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break
case 'snackvideo':
async function snackvideo(url) {
  let data = qs.stringify({
    'ic-request': 'true',
    'id': url,
    'locale': 'id',
    'ic-element-id': 'main_page_form',
    'ic-id': '1',
    'ic-target-id': 'active_container',
    'ic-trigger-id': 'main_page_form',
    'ic-current-url': '/id/how-to-download-snack-video',
    'ic-select-from-response': '#id1',
    '_method': 'POST'
  });
  let config = {
    method: 'POST',
    url: 'https://getsnackvideo.com/results',
    headers: {
      'User-Agent': 'Mozilla/5.0 (Linux; Android 8.1.0; CPH1803; Build/OPM1.171019.026) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.4280.141 Mobile Safari/537.36 KiToBrowser/124.0',
      'Accept': 'text/html-partial, */*; q=0.9',
      'accept-language': 'id-ID',
      'referer': 'https://getsnackvideo.com/id/how-to-download-snack-video',
      'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
      'x-ic-request': 'true',
      'x-http-method-override': 'POST',
      'x-requested-with': 'XMLHttpRequest',
      'origin': 'https://getsnackvideo.com',
      'alt-used': 'getsnackvideo.com',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      'priority': 'u=0',
      'te': 'trailers',
      'Cookie': '_ga_TBLWJYRGPZ=GS1.1.1736227224.1.1.1736227279.0.0.0; _ga=GA1.1.1194697262.1736227224'
    },
    data: data
  };
  try {
    const response = await axios.request(config);
    const $ = cheerio.load(response.data);
    const downloadUrl = $('.download_link.without_watermark').attr('href');
    const thumbnail = $('.img_thumb img').attr('src');
    return {
      thumbnail: thumbnail || 'Thumbnail not found',
      downloadUrl: downloadUrl || 'Download URL not found'
    };
  } catch (error) {
    console.error('Error:', error);
  }
}
  if (!text) return reply('masukan link SnackVideo')
  try {
    const resultn = await snackvideo(text)
    if (!resultn?.downloadUrl) return reply('❌ Gagal mengambil video')
    const videoRes = await axios.get(resultn.downloadUrl, { 
      responseType: 'arraybuffer',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; RMX2185 Build/QP1A.190711.020) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.7103.60 Mobile Safari/537.36',
        'Referer': 'https://www.snackvideo.com/'
      }
    })
    await satanic.sendMessage(m.chat, { 
      video: Buffer.from(videoRes.data),
      caption: '✅ *Video Snack berhasil didownload*'
    }, { quoted: fkontak })
  } catch (error) {
    reply('❌ Error: ' + error.message)
  }
  break
case 'cocofun':
case 'coco': {
    if (!text) return reply('Masukkan URL Cocofunnya!\n\nContoh: .cocofun https://www.cocofun.com/xxx')
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    const apiUrl = `https://free-restapi.biz.id/api/cocofun?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl)
    if (!response.data.success) {
        return reply('Gagal mengambil data dari Cocofun')
    }
    const result = response.data
    let info = `COCOFUN DOWNLOADER\n\n`
    info += `Topic: ${result.topic}\n`
    info += `Caption: ${result.caption}\n`
    info += `Duration: ${result.statistic.duration} detik\n`
    info += `Play: ${result.statistic.play}\n`
    info += `Like: ${result.statistic.like}\n`
    info += `Share: ${result.statistic.share}\n`
    info += `Project By: ${namaBot}`
    const videoUrl = result.videoUrl || result.watermark
    await satanic.sendMessage(m.chat, { 
        video: { url: videoUrl },
        caption: info
    }, { quoted: fkontak })
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break
case 'igphoto':
case 'igslide': {
    if (!text) return reply('Masukkan URL Instagram slide!\n\nContoh: .igslid https://www.instagram.com/p/xxx');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const endpoint = `https://free-restapi.biz.id/api/igdl?url=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const hasil = await axios.get(endpoint);
        
        if (hasil.data.status !== 200) {
            return reply('Gagal mengambil data dari Instagram');
        }
        
        const datas = hasil.data;
        const mediaUrls = datas.url;
        const infoAkun = datas.metadata;
        
        
        const hanyaGambar = mediaUrls.filter(url => !infoAkun?.isVideo);
        

        
        let daftarCard = await Promise.all(hanyaGambar.map(async (gambar, index) => {
            const mediaGambar = await prepareWAMessageMedia({ 
                image: { url: gambar } 
            }, { 
                upload: satanic.waUploadToServer 
            });
            
            const keterangan = `Powerred By SatanicHaxor`;
            
            return {
                header: proto.Message.InteractiveMessage.Header.create({
                    ...mediaGambar,
                    title: '',
                    subtitle: `Slide ${index+1}`,
                    hasMediaAttachment: true
                }),
                body: { text: keterangan },
                nativeFlowMessage: {
                    buttons: [{
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📥 Download",
                            url: gambar
                        })
                    }]
                }
            };
        }));
        
        let pesan = generateWAMessageFromContent(
            m.chat,
            {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: `📸 Instagram Slide dari @${infoAkun?.username || 'user'}` },
                            carouselMessage: {
                                cards: daftarCard,
                                messageVersion: 1
                            }
                        }
                    }
                }
            },
            { quoted: fkontak }
        );
        
        await satanic.relayMessage(m.chat, pesan.message, { messageId: pesan.key.id });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil data Instagram.');
    }
}
break;
case 'ttslide':
case 'tiktokslide': {
    if (!text) return reply('Masukkan URL TikTok slide/photo!\n\nContoh: .ttslide https://www.tiktok.com/@username/video/xxx');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const endpoint = `https://free-restapi.biz.id/api/ttdl?url=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const hasil = await axios.get(endpoint);
        
        if (hasil.data.status !== 200) {
            return reply('Gagal mengambil data dari TikTok');
        }
        
        const datas = hasil.data;
        const result = datas.result;
        
        if (!result.videos || result.videos.length === 0) {
            return reply('Tidak ada foto/video yang ditemukan');
        }
        
        // Filter hanya photo
        const photos = result.videos.filter(v => v.type === 'photo');
        
        if (photos.length === 0) {
            return reply('Tidak ada slide foto yang ditemukan');
        }
        
        let daftarCard = await Promise.all(photos.map(async (photo, index) => {
            const mediaFoto = await prepareWAMessageMedia({ 
                image: { url: photo.url } 
            }, { 
                upload: satanic.waUploadToServer 
            });
            
            const keterangan = `📸 *Slide ${index+1} dari ${photos.length}*\n\n📝 Title: ${result.title || '-'}\n👤 Author: ${result.author?.nickname || '-'} (@${result.author?.id || '-'})\n❤️ Likes: ${result.stats?.likes?.toLocaleString() || '-'}\n💬 Comments: ${result.stats?.comment?.toLocaleString() || '-'}\n📨 Shares: ${result.stats?.share?.toLocaleString() || '-'}`;
            
            return {
                header: proto.Message.InteractiveMessage.Header.create({
                    ...mediaFoto,
                    title: '',
                    subtitle: `Slide ${index+1}`,
                    hasMediaAttachment: true
                }),
                body: { text: keterangan },
                nativeFlowMessage: {
                    buttons: [{
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📥 Download",
                            url: photo.url
                        })
                    }]
                }
            };
        }));
        
        let pesan = generateWAMessageFromContent(
            m.chat,
            {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: `🎵 TikTok Slide dari @${result.author?.id || 'user'}` },
                            carouselMessage: {
                                cards: daftarCard,
                                messageVersion: 1
                            }
                        }
                    }
                }
            },
            { quoted: fkontak }
        );
        
        await satanic.relayMessage(m.chat, pesan.message, { messageId: pesan.key.id });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil data TikTok.');
    }
}
break;
case 'igdl2': {
    if (!text) return reply('Masukkan link Instagram! Contoh: .igdl2 https://www.instagram.com/p/CONTOSH/');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    async function indown(url) {
        try {
            const { data: pageData, headers } = await axios.get('https://indown.io/en1', {
                headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36' }
            });
            
            const $ = cheerio.load(pageData);
            const token = $('input[name="_token"]').val();
            const cookies = headers['set-cookie'] ? headers['set-cookie'].map(v => v.split(';')[0]).join('; ') : '';

            if (!token) throw new Error('Token Indown not found');
            
            const params = new URLSearchParams();
            params.append('referer', 'https://indown.io/en1');
            params.append('locale', 'en');
            params.append('_token', token);
            params.append('link', url);
            params.append('p', 'i');

            const { data: resultData } = await axios.post('https://indown.io/download', params, {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Cookie': cookies,
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36'
                }
            });
            
            const $result = cheerio.load(resultData);
            let videoUrl = null;
            
            // Ambil video dari source
            $result('video source[src]').each((i, e) => {
                let link = $result(e).attr('src');
                if (link && !videoUrl) videoUrl = link;
            });
            
            // Ambil video dari tag video
            if (!videoUrl) {
                $result('video').each((i, e) => {
                    let link = $result(e).attr('src');
                    if (link && !videoUrl) videoUrl = link;
                });
            }
            
            // Ambil dari link download
            if (!videoUrl) {
                $result('a[href*="indown.io/fetch"]').each((i, e) => {
                    let link = $result(e).attr('href');
                    if (link && link.includes('indown.io/fetch')) {
                        try {
                            const decoded = decodeURIComponent(new URL(link).searchParams.get('url'));
                            if (decoded && /\.(mp4|mov|avi|mkv)$/i.test(decoded)) {
                                videoUrl = decoded;
                            }
                        } catch (err) {}
                    }
                });
            }
            
            if (!videoUrl) {
                throw new Error('Video tidak ditemukan');
            }
            
            return { 
                status: true, 
                video: videoUrl
            };
            
        } catch (e) {
            return { status: false, message: e.message };
        }
    }
    
    try {
        const result = await indown(text);
        
        if (!result.status) {
            throw new Error(result.message || 'Gagal mengambil video');
        }
        
        // Kirim video
        await satanic.sendMessage(m.chat, {
            video: { url: result.video },
            caption: '📹 Video Instagram'
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { 
            react: { text: '✅', key: m.key } 
        });
        
    } catch (err) {
        console.error(err);
        reply(`❌ Gagal mengunduh: ${err.message || 'Link mungkin private atau invalid'}`);
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'instagram':
case 'igdl':
case 'ig': {
    if (!text) return reply('Masukkan URL Instagramnya!\n\nContoh: .ig https://www.instagram.com/reel/xxx')
  await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    const apiUrl = `https://free-restapi.biz.id/api/igdl?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl)   
    const data = response.data
    const urls = data.url
    const metadata = data.metadata   
    let info = `INSTAGRAM VIDEO DOWNLOADER\n\n`
    for (let url of urls) {
        await satanic.sendMessage(m.chat, { 
            video: { url: url }, 
            caption: info 
        }, { quoted: fkontak })
    }
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break

case 'igmp3':
case 'igaudio': {
    if (!text) return reply('Masukkan URL Instagramnya!\n\nContoh: .igmp3 https://www.instagram.com/reel/xxx')
  await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    const apiUrl = `https://free-restapi.biz.id/api/igdl?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl)   
    const data = response.data
    const urls = data.url
    const metadata = data.metadata   
    let info = `INSTAGRAM VIDEO DOWNLOADER\n\n`
    for (let url of urls) {
        await satanic.sendMessage(m.chat, { 
            audio: { url: url }, 
            mimetype: 'audio/mpeg',
            caption: info 
        }, { quoted: fkontak })
    }
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break
case 'fbdl':
case 'fb': {
    if (!text) return reply('Masukkan URL Facebooknya!\n\nContoh: .fb https://www.facebook.com/xxx')
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })  
    const apiUrl = `https://free-restapi.biz.id/api/fbdl?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl)    
    if (response.data.status !== 200) {
        return reply('Gagal mengambil data dari Facebook')
    }
    const result = response.data.result
    let info = `FACEBOOK DOWNLOADER\n\n`
    info += `Title: ${result.title}\n`
    info += `Project By: ${namaBot}`
    await satanic.sendMessage(m.chat, { 
        video: { url: result.hd }, 
        caption: info 
    }, { quoted: fkontak })
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break
case 'videydl':
case 'videy': {
  async function videydl(url) {
    try {
      const objcturl = new URL(url);
      const videoId = objcturl.searchParams.get('id');
      if (!videoId) throw new Error('Invalid Videy URL');
      const ext = videoId.length === 9 && videoId[8] === '2' ? '.mov' : '.mp4';
      const urlvideo = `https://cdn.videy.co/${videoId}${ext}`;
      return urlvideo;
    } catch (error) {
      throw new Error(`Download failed: ${error.message}`);
    }
  }
  let url = text || (m.quoted && m.quoted.text);
  if (!url) {
    return reply(`⚠️ *Cara penggunaan:*\n\nKirim link Videy:\n>.videy https://videy.co/xxx\n\nAtau reply pesan yang berisi link Videy`);
  }
  try {
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    const videoUrl = await videydl(url);
    await satanic.sendMessage(m.chat, {
      video: { url: videoUrl },
      caption: `> *Video berhasil diunduh*\n🔗 Link: ${url}`
    }, { quoted: fkontak });
    
  } catch (error) {
    console.error('[Videy Error]:', error);
    reply(`❌ *Gagal mengunduh:*\n${error.message}`);
  }
  break;
}
case 'twitter':
case 'tw':
case 'x': {
    if (!text) return reply('Masukkan URL Twitter/X nya!\n\nContoh: .twitter https://twitter.com/xxx/status/xxx')
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    const apiUrl = `https://free-restapi.biz.id/api/twitter?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl)
    if (response.data.status !== 200) {
        return reply('Gagal mengambil data dari Twitter')
    }
    const result = response.data.result
    if (result.type !== 'video') {
        return reply('URL ini bukan video Twitter')
    }
    const videoUrl = result.variants[0]
    await satanic.sendMessage(m.chat, { 
        video: { url: videoUrl },
        caption: result.full_text ? result.full_text : ''
    }, { quoted: fkontak })
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break
case 'scdl':
case 'soundcloud': {
    if (!text) return reply('Masukkan URL SoundCloudnya!\n\nContoh: .scdl https://soundcloud.com/xxx/xxx')
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    const apiUrl = `https://free-restapi.biz.id/api/scdl?url=${encodeURIComponent(text)}&apikey=${global.sakey}`
    const response = await axios.get(apiUrl)
    if (!response.data.success) {
        return reply('Gagal mengambil data dari SoundCloud')
    }
    const result = response.data
    const audioUrl = result.audioUrl
    const title = result.title
    const audioBuffer = await axios.get(audioUrl, { 
        responseType: 'arraybuffer'
    })
    await satanic.sendMessage(m.chat, { 
        audio: audioBuffer.data,
        mimetype: 'audio/mpeg',
        fileName: `${title}.mp3`
    }, { quoted: fkontak })
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
break
/////// BATAS DOWNLOAD VIDEO ////))
//////// IMAGE EDITOR //////))
case 'hdr':
case 'hd':
case 'enhance': {
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .hdr');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
        let ImageUrlaja = mem.url || mem;
        const apiUrl = `https://free-restapi.biz.id/api/hd?url=${encodeURIComponent(ImageUrlaja)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil diupgrade ke HD!'
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        reply('Gagal mengupgrade gambar.');
    }
}
break;
case 'upscale': {
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .upscale');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const apiUrl = `https://free-restapi.biz.id/api/upscale?url=${encodeURIComponent(ImageUrlaja)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil diupgrade ke HD!'
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti.');
    }
}
break;
case 'esrgan':
case '4k': {
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .esrgan');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const apiUrl = `https://free-restapi.biz.id/api/esrgan?url=${encodeURIComponent(ImageUrlaja)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil diupgrade ke 4K dengan ESRGAN!'
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti.');
    }
}
break;
 case 'removebg':
case 'rmbg': {
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .removebg');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const apiUrl = `https://free-restapi.biz.id/api/removebg?url=${encodeURIComponent(ImageUrlaja)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Background berhasil dihapus!'
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Gagal menghapus background. Coba lagi nanti.');
    }
}
break;
case 'removebg2':
case 'rmbg2': {
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .removebg2');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const apiUrl = `https://free-restapi.biz.id/api/removebg?url=${encodeURIComponent(ImageUrlaja)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Background berhasil dihapus!'
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Gagal menghapus background. Coba lagi nanti.');
    }
}
break;
case 'tocatbox': {
    try {
        const quoted = m.quoted ? m.quoted : m;
        const mime = (quoted.msg || quoted).mimetype || '';
        if (!/image|video|audio/.test(mime)) {
            return reply('❌ Hanya support gambar, video, atau audio!');
        }
        await satanic.sendMessage(m.chat, { 
            react: { text: '⏳', key: m.key } 
        }); 
        const mediaBuffer = await quoted.download();
        if (!mediaBuffer) {
            throw new Error('Gagal mendownload media');
        }
        const resultUrl = await uploadToAliceCdn(mediaBuffer, mime);
        const fileType = getFileTypeFromMime(mime);
        const typeIcon = {
            'gambar': '🖼️',
            'video': '🎥',
            'audio': '🎵',
            'gif': '🎞️'
        }[fileType];        
        await satanic.sendMessage(m.chat, {
            text: `✅ *Upload Berhasil!*\n\n${typeIcon} *Tipe:* ${fileType}\n🔗 *Link:* ${resultUrl}\n\n📌 *Catatan:* Link akan expire sesuai kebijakan Catbox`
        }, { quoted: fkontak });        
        await satanic.sendMessage(m.chat, { 
            react: { text: '✅', key: m.key } 
        });
        
    } catch (error) {
        console.error('[Upload Error]', error);
        await satanic.sendMessage(m.chat, { 
            react: { text: '❌', key: m.key } 
        }).catch(() => {});
        let errorMsg = '❌ Gagal upload: ';
        if (error.code === 'ECONNABORTED') {
            errorMsg += 'Timeout, file terlalu besar atau koneksi lambat';
        } else if (error.response?.status === 413) {
            errorMsg += 'File terlalu besar';
        } else {
            errorMsg += error.message;
        }        
        reply(errorMsg);
    }
}
break;
case 'tourl': {
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!mime) return reply('Reply/kirim media (foto/video/file) yang ingin diupload.');
    
    const FormData = require("form-data");
    const mimeTypes = require("mime-types");
    const fs = require("fs");
    const path = require("path");
    const { fromBuffer } = require("file-type");
    const axios = require("axios");
    const cheerio = require("cheerio");
    
    const termaiKey = "AIzaBj7z2z3xBjsk";
    const termaiDomain = 'https://c.termai.cc';
    const imgbbApiKey = '06fd47f20c573d4795a47af91f081932';
    
    async function aquaUpload(filePath) {
        try {
            if (!fs.existsSync(filePath)) throw new Error("File tidak ditemukan");
            const form = new FormData();
            form.append("media", fs.createReadStream(filePath));
            const response = await axios.post("https://aqua-upload.vercel.app/api/v1/upload", form, {
                headers: {
                    ...form.getHeaders(),
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
                    'Referer': 'https://aqua-upload.vercel.app/'
                },
                timeout: 30000
            });
            if (response.data && response.data.success) return response.data.url;
            throw new Error("Upload ke aqua-upload gagal");
        } catch (err) {
            return null;
        }
    }
    
    async function uploadTermai(fileBuffer) {
        try {
            const { ext } = await fromBuffer(fileBuffer);
            const formData = new FormData();
            formData.append('file', fileBuffer, { filename: 'file.' + ext });
            const res = await axios.post(`${termaiDomain}/api/upload?key=${termaiKey}`, formData, {
                headers: formData.getHeaders(),
                timeout: 30000
            });
            if (res.data && res.data.status && res.data.path) return res.data.path;
            throw new Error("Upload ke Termai gagal");
        } catch (err) {
            return null;
        }
    }
    
    async function uploadToPoneRs(fileBuffer) {
        try {
            const form = new FormData();
            form.append('files[]', fileBuffer, { filename: 'file.jpg' });
            const res = await axios.post('https://pone.rs/upload.php', form, {
                headers: {
                    ...form.getHeaders(),
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
                    'Referer': 'https://pone.rs/',
                    'Origin': 'https://pone.rs'
                },
                maxBodyLength: Infinity,
                maxContentLength: Infinity,
                timeout: 30000
            });
            if (res.data?.success && res.data?.files?.[0]?.url) {
                return res.data.files[0].url.replace(/\\\//g, '/');
            }
            throw new Error("Upload ke pone.rs gagal");
        } catch (err) {
            return null;
        }
    }
    
    async function pomf2(filePath) {
        try {
            if (!fs.existsSync(filePath)) throw new Error("File tidak ditemukan");
            const contentType = mimeTypes.lookup(filePath) || "application/octet-stream";
            const fileName = path.basename(filePath);
            const form = new FormData();
            form.append("files[]", fs.createReadStream(filePath), {
                contentType,
                filename: fileName,
            });
            const response = await axios.post("https://qu.ax/upload.php", form, {
                headers: { ...form.getHeaders() },
                timeout: 30000
            });
            if (!response.data.success || !response.data.files?.length) throw new Error("Upload ke qu.ax gagal");
            return response.data.files[0].url;
        } catch (err) {
            return null;
        }
    }
    
    async function uploadTmpFiles(filePath, expire = 172800) {
        try {
            if (!fs.existsSync(filePath)) throw new Error("File tidak ditemukan");
            const form = new FormData();
            form.append("file", fs.createReadStream(filePath));
            form.append("expire", expire);
            const res = await axios.post("https://tmpfiles.org/api/v1/upload", form, {
                headers: form.getHeaders(),
                timeout: 30000
            });
            if (res.data && res.data.status === "success") return res.data;
            throw new Error("Upload ke tmpfiles.org gagal");
        } catch (err) {
            return { status: "error", message: "gagal" };
        }
    }
    
    async function uploadPutIcu(filePath) {
        try {
            if (!fs.existsSync(filePath)) throw new Error("File tidak ditemukan");
            const contentType = mimeTypes.lookup(filePath) || "application/octet-stream";
            const res = await axios.put(`https://put.icu/upload/`, fs.createReadStream(filePath), {
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': contentType
                },
                maxBodyLength: Infinity,
                maxContentLength: Infinity,
                timeout: 30000
            });
            if (res.data && res.data.direct_url) return res.data.direct_url;
            if (res.data && res.data.url) return res.data.url;
            throw new Error("Upload ke put.icu gagal");
        } catch (err) {
            return null;
        }
    }
    
    async function uploadUgu(filePath) {
        try {
            const form = new FormData();
            form.append("files[]", fs.createReadStream(filePath));
            const response = await axios.post("https://uguu.se/upload.php", form, {
                headers: {
                    ...form.getHeaders(),
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                },
                timeout: 30000
            });
            if (response.data && response.data.success && response.data.files && response.data.files[0]) {
                return response.data.files[0].url;
            }
            throw new Error("Upload ke uguu.se gagal");
        } catch (err) {
            return null;
        }
    }
    
    async function uploadUploadEE(filePath) {
        try {
            const baseUrl = "https://www.upload.ee";
            const response = await axios.get(`${baseUrl}/ubr_link_upload.php?rnd_id=${Date.now()}`, { timeout: 30000 });
            const uploadId = (response.data.match(/startUpload\("(.+?)"/) || [])[1];
            if (!uploadId) throw new Error("Unable to obtain Upload ID");
            const formData = new FormData();
            formData.append("upfile_0", fs.createReadStream(filePath));
            formData.append("link", "");
            formData.append("email", "");
            formData.append("category", "cat_file");
            formData.append("big_resize", "none");
            formData.append("small_resize", "120x90");
            const uploadResponse = await axios.post(`${baseUrl}/cgi-bin/ubr_upload.pl?X-Progress-ID=${encodeURIComponent(uploadId)}&upload_id=${encodeURIComponent(uploadId)}`, formData, {
                headers: { ...formData.getHeaders(), Referer: baseUrl },
                timeout: 30000
            });
            const $ = cheerio.load(uploadResponse.data);
            const viewUrl = $("input#file_src").val() || "";
            if (!viewUrl) throw new Error("File upload failed");
            const viewResponse = await axios.get(viewUrl, { timeout: 30000 });
            const downUrl = cheerio.load(viewResponse.data)("#d_l").attr("href") || "";
            if (!downUrl) throw new Error("File upload failed");
            return downUrl;
        } catch (error) {
            return null;
        }
    }
    
    async function uploadToImgBB(filePath) {
        try {
            if (!fs.existsSync(filePath)) throw new Error("File not found");
            const form = new FormData();
            form.append('image', fs.createReadStream(filePath));
            const response = await axios.post(`https://api.imgbb.com/1/upload?key=${imgbbApiKey}`, form, {
                headers: { ...form.getHeaders() },
                timeout: 30000
            });
            if (response.status === 200 && response.data.data && response.data.data.url) {
                return response.data.data.url;
            }
            throw new Error(`Upload failed with status: ${response.status}`);
        } catch (err) {
            return null;
        }
    }
    
    async function uploadToLitterbox(fileBuffer, filename) {
        try {
            const form = new FormData();
            form.append('reqtype', 'fileupload');
            form.append('time', '72h');
            form.append('fileToUpload', fileBuffer, {
                filename: filename,
                contentType: mimeTypes.lookup(filename) || 'application/octet-stream'
            });
            const response = await axios.post('https://litterbox.catbox.moe/resources/internals/api.php', form, {
                headers: form.getHeaders(),
                timeout: 30000
            });
            if (response.status !== 200) throw new Error('Litterbox gagal');
            const url = response.data;
            if (!url.startsWith('http')) throw new Error('Invalid response');
            return { host: 'Litterbox', url, expires: '72 jam' };
        } catch (err) {
            return null;
        }
    }
    
    try {
        const media = await satanic.downloadAndSaveMediaMessage(quoted);
        const buffer = fs.readFileSync(media);
        const { ext } = await fromBuffer(buffer) || {};
        const filename = `file_${Date.now()}.${ext || 'bin'}`;
        
        const results = await Promise.allSettled([
            aquaUpload(media),
            pomf2(media),
            uploadTmpFiles(media),
            uploadPutIcu(media),
            uploadTermai(buffer),
            uploadUgu(media),
            uploadUploadEE(media),
            uploadToImgBB(media),
            uploadToPoneRs(buffer),
            uploadToLitterbox(buffer, filename)
        ]);
        
        const [
            aquaResult,
            quaxResult,
            tmpFilesResult,
            putIcuResult,
            termaiResult,
            uguResult,
            uploadEEResult,
            imgbbResult,
            poneRsResult,
            litterboxResult
        ] = results;
        
        const aquaLink = aquaResult.status === 'fulfilled' ? aquaResult.value : null;
        const quaxLink = quaxResult.status === 'fulfilled' ? quaxResult.value : null;
        const tmpFilesLink = tmpFilesResult.status === 'fulfilled' ? tmpFilesResult.value?.data?.url || null : null;
        const putIcuLink = putIcuResult.status === 'fulfilled' ? putIcuResult.value : null;
        const termaiLink = termaiResult.status === 'fulfilled' ? termaiResult.value : null;
        const uguLink = uguResult.status === 'fulfilled' ? uguResult.value : null;
        const uploadEELink = uploadEEResult.status === 'fulfilled' ? uploadEEResult.value : null;
        const imgbbLink = imgbbResult.status === 'fulfilled' ? imgbbResult.value : null;
        const poneRsLink = poneRsResult.status === 'fulfilled' ? poneRsResult.value : null;
        const litterboxLink = litterboxResult.status === 'fulfilled' ? litterboxResult.value?.url : null;
        const litterboxExpiry = litterboxResult.status === 'fulfilled' ? litterboxResult.value?.expires : null;
        
        const successLinks = [aquaLink, quaxLink, tmpFilesLink, putIcuLink, termaiLink, uguLink, uploadEELink, imgbbLink, poneRsLink, litterboxLink].filter(link => link);
        
        if (successLinks.length === 0) {
            fs.unlinkSync(media);
            return;
        }
        
        const formatLink = (link) => link ? link : '❌ Gagal';
        let caption = `╭─ 「 UPLOAD SUCCESS 」
📂 Size: ${(buffer.length / 1024).toFixed(2)} KB
📁 Format: ${ext || 'unknown'}
📊 Berhasil: ${successLinks.length} dari 10 uploader
────────────────
🌊 Aqua: ${formatLink(aquaLink)}
🦊 Qu.ax: ${formatLink(quaxLink)}
📁 TmpFiles: ${formatLink(tmpFilesLink)} ( *2 Days* )
☁️ Put.icu: ${formatLink(putIcuLink)} ( *1 Day* )
⚡ Termai: ${formatLink(termaiLink)}
📤 Uguu.se: ${formatLink(uguLink)}
📎 Upload.ee: ${formatLink(uploadEELink)}
🖼️ ImgBB: ${formatLink(imgbbLink)}
📦 Pone.rs: ${formatLink(poneRsLink)}
📥 Litterbox: ${formatLink(litterboxLink)} ${litterboxExpiry ? `( *${litterboxExpiry}* )` : ''}
╰───────────────`;
        
        await reply(caption);
        fs.unlinkSync(media);
    } catch (err) {
    }
}
break;
case 'hdvid2':
case 'enhancevideo2': {
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';   
    if (!/video/.test(mime)) return reply('Kirim/reply video dengan caption .hdvid');    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });    
    let mee = await satanic.downloadAndSaveMediaMessage(quoted);
    let mem = await UploadFileUgu(mee);   
      let ImageUrlaja = mem.url || mem;
    const apiUrl = `https://api.nexray.eu.cc/tools/hdvideo?url=${encodeURIComponent(ImageUrlaja)}`;
    const response = await axios.get(apiUrl);
    if (!response.data.status) {
        return reply('Gagal mengupgrade video. Coba lagi nanti.');
    }    
    const videoUrl = response.data.result;
    await satanic.sendMessage(m.chat, { 
        video: { url: videoUrl },
        caption: '✨ Video berhasil diupgrade ke HD!'
    }, { quoted: fkontak });
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'hdvid': {
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .hdvid');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const apiUrl = `https://free-restapi.biz.id/api/hdvid?url=${encodeURIComponent(ImageUrlaja)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { 
            video: response.data,
            caption: '✨ Gambar berhasil!'
        }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. silahkan update premium untuk menggunakan fitur ini');
    }
}
break;

case 'smeme': case 'stickermeme': case 'stickmeme': {
    await satanic.sendMessage(m.chat, {react: {text: '🚀', key: m.key}})
    if (!text) return reply(`Usage: ${cmd} text1|text2`)
    let atas = text.split('|')[0] ? text.split('|')[0] : '-'
    let bawah = text.split('|')[1] ? text.split('|')[1] : '-'
const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || '';
    let memeUrl = ''
    if (/image/.test(mime)) {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted)
        let mem = await UploadFileUgu(mee)
          let ImageUrlaja = mem.url || mem;
        memeUrl = `https://free-restapi.biz.id/api/smeme?atas=${encodeURIComponent(atas)}&bawah=${encodeURIComponent(bawah)}&background=${ImageUrlaja}&apikey=SK-F68D971CC86742FDF2A923BA`
    }
    else if (/webp/.test(mime)) {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted)
        let mem = await UploadFileUgu(mee)
          let ImageUrlaja = mem.url || mem;
        memeUrl = `https://free-restapi.biz.id/api/smeme?atas=${encodeURIComponent(atas)}&bawah=${encodeURIComponent(bawah)}&background=${ImageUrlaja}&apikey=SK-F68D971CC86742FDF2A923BA`
    }
    else {
        return reply(`Hanya bisa menerima gambar atau sticker`)
    }
    const response = await axios.get(memeUrl, { responseType: 'arraybuffer' })
    await satanic.sendImageAsSticker(m.chat, response.data, m, {
        packname: `satanic`,
    })
}
break
case 'removecloth': {
    if (!isPrem) return reply('you are not premium, Updated premium open this feature');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .removecloth');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const apiUrl = `https://free-restapi.biz.id/api/removecloth?url=${encodeURIComponent(ImageUrlaja)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil '
        }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti silahkan update premium untuk menggunakan fitur ini.');
    }
}
break;
case 'jadibugil': {
    if (!isPrem) return reply('you are not premium, Updated premium open this feature');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .jadibugil');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const apiUrl = `https://free-restapi.biz.id/api/jadibugil?url=${encodeURIComponent(ImageUrlaja)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil '
        }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti silahkan update premium untuk menggunakan fitur ini.');
    }
}
break;
case 'jadimacbook': {
    if (!isPrem) return reply('you are not premium, Updated premium open this feature');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .jadimacbook');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const apiUrl = `https://free-restapi.biz.id/api/jadimacebook?url=${encodeURIComponent(ImageUrlaja)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil '
        }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti silahkan update premium untuk menggunakan fitur ini.');
    }
}
break;
case 'text2img':
case 'generate': {
    if (!text) return reply('Masukkan deskripsi gambar!\n\nContoh: .text2img kucing lucu');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    const apiUrl = `https://free-restapi.biz.id/api/text2img?text=${encodeURIComponent(text)}&apikey=${global.sakey}`;
    const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
    
    await satanic.sendMessage(m.chat, { 
        image: response.data,
        caption: `🎨 *TEXT TO IMAGE*\n\nPrompt: ${text}`
    }, { quoted: fkontak });
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'texttoimg':
case 'generate': {
    if (!text) return reply('Masukkan deskripsi gambar!\n\nContoh: .texttoimg kucing lucu');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    const apiUrl = `https://free-restapi.biz.id/api/texttoimg?prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
    const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
    
    await satanic.sendMessage(m.chat, { 
        image: response.data,
        caption: `🎨 *TEXT TO IMAGE*\n\nPrompt: ${text}`
    }, { quoted: fkontak });
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;
case 'flux':
case 'fluxschnell':
case 'flux-img': {
    if (!text) return reply('Masukkan deskripsi gambar!\n\nContoh: .flux kucing lucu');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    const apiUrl = `https://free-restapi.biz.id/api/flux-img?prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
    const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
    
    await satanic.sendMessage(m.chat, { 
        image: response.data,
        caption: `🎨 *FLUX SCHNELL*\n\nPrompt: ${text}`
    }, { quoted: fkontak });
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;

case 'jadibiliard': {
    if (!isPrem) return reply('you are not premium, Updated premium open this feature');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .jadibiliard');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const prompt = `buat gambar realistis tanpa merubah wajah sedikit pun, lalu bergaya sedang berdiri dalam ruangan billiard ,sedang bersandar pada meja billiard, sambil memang stik Billiard,iya menggunakan pakaian keren seperti kaos atau kemeja, menggunakan kalung celana jeans hitam,kaus kaki putih polos pendek,dan sepatu putih new balance 530 putih silver, suasana terang dengan lampu gantung, beberapa meja billiard di latar belakang, dan beberapa org sendang bermain billiard, nuansa yang di tampilkan santai, urban dan sporty.saran gaya (opsional): gaya fotografi:sinematik,kedalam bidang dangkel, percayaan cerah, sudut kamera: seluruh tubuh,dari depan secara langsung gaya model meliat ke bawah suasana: percaya diri,keren,santai seperti nongkrong tone warna: seimbang,campuran percayaan hangat dan dingin, note : jangan ubah object muka aslinya  pertahankan muka asli saya`;
        const apiUrl = `https://free-restapi.biz.id/api/nanobanana?url=${encodeURIComponent(ImageUrlaja)}&prompt=${encodeURIComponent(prompt)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil!'
        }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. silahkan update premium untuk menggunakan fitur ini');
    }
}
break;
case 'removecloth2': {
    if (!isPrem) return reply('you are not premium, Updated premium open this feature');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .removecloth2');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const apiUrl = `https://free-restapi.biz.id/api/removecloth?url=${encodeURIComponent(ImageUrlaja)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil!'
        }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. silahkan update premium untuk menggunakan fitur ini');
    }
}
break;
case 'jadipresiden': {
    if (!isPrem) return reply('you are not premium, Updated premium open this feature');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .jadipresiden');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const apiUrl = `https://free-restapi.biz.id/api/jadipresiden?url=${encodeURIComponent(ImageUrlaja)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil!'
        }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. silahkan update premium untuk menggunakan fitur ini');
    }
}
break;
case 'gita': {
    if (!text) return reply('Masukkan pertanyaan atau bab/ayat Gita!\n\nContoh: .gita Karma\nAtau: .gita bab 2');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/ai/gita?prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status === 200 && response.data.result) {
            const result = response.data.result;
            
            await satanic.sendMessage(m.chat, { text: result }, { quoted: fkontak });
            await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            return reply('Gagal mendapatkan kutipan dari Bhagavad Gita.');
        }
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat mengambil kutipan Gita.');
    }
}
break;
case 'epsilon':
case 'search': {
    if (!text) return reply('Masukkan kata kunci pencarian!\n\nContoh: .epsilon Indonesia');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/epsilon?message=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (!response.data.success) {
            return reply('Gagal mendapatkan hasil pencarian dari Epsilon.');
        }
        
        const result = response.data.result;
        
        await satanic.sendMessage(m.chat, { text: result }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat menghubungi Epsilon.');
    }
}
break;
case 'gemini': {
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    const isImage = /image/.test(mime);
    
    if (!text && !isImage) {
        return reply(`❌ Masukkan pertanyaan atau kirim/reply gambar!\n\nContoh:\n.gemini Halo, apa kabar?\n.gemini (dengan gambar)`);
    }
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let userMessage = text || '';
        let imageUrl = '';
        
        if (isImage) {
            let media = await quoted.download();
            
            const form = new FormData();
            form.append('files[]', media, { filename: 'image.jpg' });
            const uploadRes = await axios.post('https://pone.rs/upload.php', form, {
                headers: {
                    ...form.getHeaders(),
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
                    'Referer': 'https://pone.rs/',
                    'Origin': 'https://pone.rs'
                },
                maxBodyLength: Infinity,
                maxContentLength: Infinity
            });
            
            if (!uploadRes.data?.success || !uploadRes.data?.files?.[0]?.url) {
                await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return reply(`❌ Gagal upload foto! Silahkan coba lagi.`);
            }
            
            imageUrl = uploadRes.data.files[0].url;
        }
        
        const userId = m.sender || m.key.remoteJid;
        let sessionId = global.geminiSessions?.[userId] || '';
        
        let apiUrl = `https://free-restapi.biz.id/api/gemini-chat2?apikey=${global.sakey}`;
        
        if (userMessage) {
            apiUrl += `&message=${encodeURIComponent(userMessage)}`;
        }
        if (imageUrl) {
            apiUrl += `&image=${encodeURIComponent(imageUrl)}`;
        }
        if (sessionId) {
            apiUrl += `&session=${sessionId}`;
        }
        
        const response = await axios.get(apiUrl);
        
        if (!response.data || response.data.status !== 'success') {
            return reply('❌ Gagal mendapatkan respons dari Gemini.');
        }
        
        if (response.data.sessions) {
            if (!global.geminiSessions) global.geminiSessions = {};
            global.geminiSessions[userId] = response.data.sessions;
        }
        
        let replyText = response.data.result || 'Tidak ada respons.';
        
        if (imageUrl) {
            replyText = `🖼️ *Gambar terdeteksi*\n\n${replyText}`;
        }
        
        await satanic.sendMessage(m.chat, { text: replyText }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error('Error Gemini:', err);
        reply('❌ Terjadi kesalahan saat menghubungi Gemini.');
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;

case 'unlimitedai': {
    if (!text) return reply('Masukkan pertanyaan!\n\nContoh: .unlimitedai Halo, apa kabar?');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/unlimitedai/chat?prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (!response.data || response.data.status !== 'success') {
            return reply('❌ Gagal mendapatkan respons dari UnlimitedAI.');
        }
        
        const result = response.data.result;
        const model = response.data.model || 'UnlimitedAI';
        
        let replyText = `*${model}*\n\n${result}`;
        
        await satanic.sendMessage(m.chat, { text: replyText }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error('Error UnlimitedAI:', err);
        reply('❌ Terjadi kesalahan saat menghubungi UnlimitedAI.');
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'qwen': {
    if (!text) return reply('Masukkan pertanyaan!\n\nContoh: .qwen Halo, apa kabar?');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/overchatai?prompt=${encodeURIComponent(text)}&model=qwen&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (!response.data || response.data.status !== 'success') {
            return reply('Gagal mendapatkan respons dari Qwen.');
        }
        
        const result = response.data.result;
        const model = response.data.model || 'Qwen';
        
        await satanic.sendMessage(m.chat, { text: `*${model}*\n\n${result}` }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error('Error Qwen:', err);
        reply('Terjadi kesalahan saat menghubungi Qwen.');
    }
}
break;
case 'claude': {
    if (!text) return reply('Masukkan pertanyaan!\n\nContoh: .qwen Halo, apa kabar?');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/overchatai?prompt=${encodeURIComponent(text)}&model=claude&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (!response.data || response.data.status !== 'success') {
            return reply('Gagal mendapatkan respons dari claude');
        }
        
        const result = response.data.result;
        const model = response.data.model || 'Qwen';
        
        await satanic.sendMessage(m.chat, { text: `*${model}*\n\n${result}` }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error('Error Qwen:', err);
        reply('Terjadi kesalahan saat menghubungi Qwen.');
    }
}
break;
case 'chatgpt': {
    if (!text) return reply('Masukkan pertanyaan!\n\nContoh: .chatgpt Halo, apa kabar?');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/overchatai?prompt=${encodeURIComponent(text)}&model=gpt&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (!response.data || response.data.status !== 'success') {
            return reply('Gagal mendapatkan respons dari chatgpt');
        }
        
        const result = response.data.result;
        const model = response.data.model || 'Qwen';
        
        await satanic.sendMessage(m.chat, { text: `*${model}*\n\n${result}` }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error('Error Qwen:', err);
        reply('Terjadi kesalahan saat menghubungi Qwen.');
    }
}
break;
case 'deepseek': {
    if (!text) return reply('Masukkan pertanyaan!\n\nContoh: .deepseek Halo, apa kabar?');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/deepseek?prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (!response.data || response.data.status !== 'success') {
            return reply('Gagal mendapatkan respons dari chatgpt');
        }
        
        const result = response.data.result;
        const model = response.data.model || 'Qwen';
        
        await satanic.sendMessage(m.chat, { text: `*${model}*\n\n${result}` }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error('Error Qwen:', err);
        reply('Terjadi kesalahan saat menghubungi');
    }
}
break;
case 'publicai': {
    if (!text) return reply('Masukkan pertanyaan!\n\nContoh: .publicai Halo, apa kabar?');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/publicai/chat?prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (!response.data || response.data.status !== 'success') {
            return reply('❌ Gagal mendapatkan respons dari PublicAI.');
        }
        
        const result = response.data.result;
        const id = response.data.id || '';
        
        let replyText = `*PublicAI*\n\n${result}`;
        if (id) {
            replyText += `\n\n🆔 Session: ${id}`;
        }
        
        await satanic.sendMessage(m.chat, { text: replyText }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error('Error PublicAI:', err);
        reply('❌ Terjadi kesalahan saat menghubungi PublicAI.');
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'ai':
case 'openai':
case 'aqua': {
    if (!text) return reply('Masukkan pertanyaan!\n\nContoh: .publicai Halo, apa kabar?');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/aqua-chat?prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (!response.data || response.data.status !== 'success') {
            return reply('❌ Gagal mendapatkan respons dari PublicAI.');
        }
        
        const result = response.data.result;
        const id = response.data.id || '';
        
        let replyText = `*PublicAI*\n\n${result}`;
        if (id) {
            replyText += `\n\n🆔 Session: ${id}`;
        }
        
        await satanic.sendMessage(m.chat, { text: replyText }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error('Error PublicAI:', err);
        reply('❌ Terjadi kesalahan saat menghubungi PublicAI.');
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'copilot': {
    if (!text) return reply('Masukkan pertanyaan!\n\nContoh: .copilot Halo, apa kabar?');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/copilot?message=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (!response.data.success) {
            return reply('Gagal mendapatkan respons dari Copilot.');
        }
        
        const result = response.data.result;
        
        await satanic.sendMessage(m.chat, { text: result }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat menghubungi Copilot.');
    }
}
break;
case 'webpilot':
case 'browse': {
    if (!text) return reply('Masukkan URL atau pertanyaan!\n\nContoh: .webpilot https://example.com\nAtau: .webpilot apa itu hai');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/ai/webpilot?prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.status === 200 && response.data.result) {
            const result = response.data.result;
            
            await satanic.sendMessage(m.chat, { text: result }, { quoted: fkontak });
            await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            return reply('Gagal mendapatkan hasil dari WebPilot.');
        }
        
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat menghubungi WebPilot.');
    }
}
break;
case 'gpt-oss2b': {
    if (!text) return reply('Masukkan pertanyaan untuk GPT-OSS2B!\n\nContoh: .gpt-oss2b apa itu JavaScript\nAtau: .gpt-oss2b jelaskan tentang AI');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const apiUrl = `https://free-restapi.biz.id/api/gpt-oss2b?prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { timeout: 1200000 });
        if (response.data?.status === "success" && response.data?.result) {
            const result = response.data.result;
            const finalResult = result.length > 65500 ? result.substring(0, 65500) + '\n\n... [Pesan terpotong karena terlalu panjang]' : result;
            await satanic.sendMessage(m.chat, { text: finalResult }, { quoted: fkontak });
            await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            return reply('❌ Gagal mendapatkan hasil dari GPT-OSS2B.\n' + (response.data?.result || 'Unknown error'));
        }
    } catch (err) {
        console.error('GPT-OSS2B Error:', err);
        if (err.code === 'ECONNABORTED') {
            reply('⏰ Waktu habis! GPT-OSS2B membutuhkan waktu lebih lama. Silakan coba lagi.');
        } else if (err.response?.status === 500) {
            reply('❌ Server GPT-OSS2B mengalami error. Silakan coba lagi nanti.');
        } else if (err.response?.status === 401 || err.response?.status === 403) {
            reply('🔑 API Key tidak valid atau tidak memiliki akses ke GPT-OSS2B.');
        } else {
            reply('❌ Terjadi kesalahan saat menghubungi GPT-OSS2B: ' + (err.message || 'Unknown error'));
        }
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'glm47': {
    if (!text) return reply('Masukkan pertanyaan untuk GLM47!\n\nContoh: .glm47 apa itu kecerdasan buatan');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        const apiUrl = `https://free-restapi.biz.id/api/glm47?prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { timeout: 1200000 });
        if (response.data?.status === "success" && response.data?.result) {
            const result = response.data.result;
            await satanic.sendMessage(m.chat, { text: result }, { quoted: fkontak });
            await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            return reply('Gagal mendapatkan hasil dari GLM47.\n' + (response.data?.result || 'Unknown error'));
        }
    } catch (err) {
        console.error('GLM47 Error:', err);
        if (err.code === 'ECONNABORTED') {
            reply('⏰ Waktu habis! GLM47 membutuhkan waktu lebih lama. Silakan coba lagi.');
        } else if (err.response?.status === 500) {
            reply('❌ Server GLM47 mengalami error. Silakan coba lagi nanti.');
        } else {
            reply('Terjadi kesalahan saat menghubungi GLM47: ' + (err.message || 'Unknown error'));
        }
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'meta-ai': {
    if (!text) return reply('Masukkan pertanyaan untuk Meta AI!\n\nContoh: .Meta AI apa itu kecerdasan buatan');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        const apiUrl = `https://free-restapi.biz.id/api/meta-ai?prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { timeout: 1200000 });
        if (response.data?.status === "success" && response.data?.result) {
            const result = response.data.result;
            await satanic.sendMessage(m.chat, { text: result }, { quoted: fkontak });
            await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            return reply('Gagal mendapatkan hasil dari META AI.\n' + (response.data?.result || 'Unknown error'));
        }
    } catch (err) {
        console.error('GLM47 Error:', err);
        if (err.code === 'ECONNABORTED') {
            reply('⏰ Waktu habis! META AI membutuhkan waktu lebih lama. Silakan coba lagi.');
        } else if (err.response?.status === 500) {
            reply('❌ Server META AI mengalami error. Silakan coba lagi nanti.');
        } else {
            reply('Terjadi kesalahan saat menghubungi GLM47: ' + (err.message || 'Unknown error'));
        }
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'claude-45': {
    if (!text) return reply('Masukkan pertanyaan untuk Meta AI!\n\nContoh: . Claude apa itu kecerdasan buatan');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        const apiUrl = `https://free-restapi.biz.id/api/claude-4-5?prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { timeout: 60000 });
        if (response.data?.status === "success" && response.data?.result) {
            const result = response.data.result;
            await satanic.sendMessage(m.chat, { text: result }, { quoted: fkontak });
            await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            return reply('Gagal mendapatkan hasil dari CLAUDE 4.5.\n' + (response.data?.result || 'Unknown error'));
        }
    } catch (err) {
        console.error('CLUADE 45Error:', err);
        if (err.code === 'ECONNABORTED') {
            reply('⏰ Waktu habis! CLAUDE 45membutuhkan waktu lebih lama. Silakan coba lagi.');
        } else if (err.response?.status === 500) {
            reply('❌ Server CLAUDE 4.5 mengalami error. Silakan coba lagi nanti.');
        } else {
            reply('Terjadi kesalahan saat menghubungi GLM47: ' + (err.message || 'Unknown error'));
        }
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'deepseek-pro': {
    if (!text) return reply('Masukkan pertanyaan untuk Deepseek AI!\n\nContoh: . deepseek apa itu kecerdasan buatan');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        const apiUrl = `https://free-restapi.biz.id/api/deepseek-pro?prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { timeout: 1200000 });
        if (response.data?.status === "success" && response.data?.result) {
            const result = response.data.result;
            await satanic.sendMessage(m.chat, { text: result }, { quoted: fkontak });
            await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            return reply('Gagal mendapatkan hasil dari CLAUDE 4.5.\n' + (response.data?.result || 'Unknown error'));
        }
    } catch (err) {
        console.error('CLUADE 45Error:', err);
        if (err.code === 'ECONNABORTED') {
            reply('⏰ Waktu habis! CLAUDE 45membutuhkan waktu lebih lama. Silakan coba lagi.');
        } else if (err.response?.status === 500) {
            reply('❌ Server CLAUDE 4.5 mengalami error. Silakan coba lagi nanti.');
        } else {
            reply('Terjadi kesalahan saat menghubungi GLM47: ' + (err.message || 'Unknown error'));
        }
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'kimi-vision': {
    if (!text) return reply('Gunakan: .kimi-vision https://urlgambar.jpg pertanyaanmu\nAtau reply gambar dengan .kimi-vision pertanyaanmu');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    reply('⏳ await be processed...')
    
    let imageUrl = '';
    let prompt = '';
    
    // Cek reply gambar
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    
    if (/image/.test(mime)) {
        let media = await quoted.download();
        
        // Upload ke pone.rs
        const form = new FormData();
        form.append('files[]', media, { filename: 'image.jpg' });
        const uploadRes = await axios.post('https://pone.rs/upload.php', form, {
            headers: {
                ...form.getHeaders(),
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
                'Referer': 'https://pone.rs/',
                'Origin': 'https://pone.rs'
            },
            maxBodyLength: Infinity,
            maxContentLength: Infinity
        });
        
        if (!uploadRes.data?.success || !uploadRes.data?.files?.[0]?.url) {
            return reply('Gagal upload gambar ke pone.rs');
        }
        
        imageUrl = uploadRes.data.files[0].url.replace(/\\\//g, '/');
        prompt = text || 'jelaskan gambar ini';
    } else {
        let parts = text.split(' ');
        for (let p of parts) {
            if (p.match(/^https?:\/\//i)) imageUrl = p;
            else prompt += p + ' ';
        }
        prompt = prompt.trim();
        if (!imageUrl) return reply('Masukkan URL gambar');
        if (!prompt) prompt = 'jelaskan gambar ini';
    }
    
    try {
        let res = await axios.get(`https://free-restapi.biz.id/api/kimi-vision?url=${encodeURIComponent(imageUrl)}&prompt=${encodeURIComponent(prompt)}&apikey=${global.sakey}`, { timeout: 60000 });
        
        if (res.data?.status === 'success') {
            await satanic.sendMessage(m.chat, { text: res.data.result }, { quoted: fkontak });
            await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            reply('Gagal dapat hasil');
        }
    } catch (err) {
        reply('Error: ' + err.message);
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'illama-vision': {
    if (!text && !m.quoted) return reply('Kirim/reply gambar KTP dengan command!\n\nContoh: .illama-vision');
    const command = '.illama-vision';
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply(`❌ Kirim/reply gambar dengan command: ${command}`);
    await satanic.sendMessage(m.chat, { react: { text: '📸', key: m.key } });
    reply('⏳ await be processed...')
    
    try {
        let media = await quoted.download();
        
        // Upload ke pone.rs
        const form = new FormData();
        form.append('files[]', media, { filename: 'image.jpg' });
        const uploadRes = await axios.post('https://pone.rs/upload.php', form, {
            headers: {
                ...form.getHeaders(),
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
                'Referer': 'https://pone.rs/',
                'Origin': 'https://pone.rs'
            },
            maxBodyLength: Infinity,
            maxContentLength: Infinity
        });
        
        if (!uploadRes.data?.success || !uploadRes.data?.files?.[0]?.url) {
            return reply(`❌ Gagal upload foto! Silahkan coba lagi.`);
        }
        
        let imageUrl = uploadRes.data.files[0].url.replace(/\\\//g, '/');
        let prompt = text || "gambar apa ini";
        const apiUrl = `https://api.qasimdev.dpdns.org/api/mistral/vision?text=${encodeURIComponent(prompt)}&image_url=${encodeURIComponent(imageUrl)}&apiKey=qasim-dev&model=pixtral-12b-2409`;
        const response = await axios.get(apiUrl, { timeout: 60000 });
        if (response.data?.success === true && response.data?.data?.result) {
            const result = response.data.data.result;
            const finalText = `*Hasil OCR / Visi AI:*\n\n${result}\n\n_© SatanicHaxor_`;
            await satanic.sendMessage(m.chat, { text: finalText }, { quoted: fkontak });
            await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            return reply('❌ Gagal memproses gambar. Pastikan gambar jelas dan terbaca.');
        }
    } catch (err) {
        console.error('Illama Vision Error:', err);
        if (err.code === 'ECONNABORTED') {
            reply('⏰ Waktu habis! Silakan coba lagi dengan gambar yang lebih kecil.');
        } else {
            reply(`❌ Terjadi kesalahan: ${err.message || 'Unknown error'}`);
        }
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;

case 'ahegao': case 'akira': case 'akiyama': case 'ana': case 'asuna': case 'ayuzawa': case 'boruto': case 'chitanda': case 'chitoge': case 'deidara': case 'doraemon': case 'elaina': case 'emilia': case 'erza': case 'gremory': case 'hestia': case 'hinata': case 'hitorigottoh': case 'inori': case 'isuzu': case 'itachi': case 'itori': case 'kaga': case 'kagura': case 'kakasih': case 'kaori': case 'keneki': case 'kosaki': case 'kotori': case 'kuriyama': case 'kuroha': case 'kurumi': case 'loli': case 'madara': case 'megumin': case 'mikasa': case 'miku': case 'minato': case 'naruto': case 'natsukawa': case 'neko': case 'nekonime': case 'nezuko': case 'nishimiya': case 'onepiece': case 'pokemon': case 'ppcouple': case 'rem': case 'rize': case 'sagiri': case 'sakura': case 'sasuke': case 'shina': case 'shinka': case 'shizuka': case 'shota': case 'tomori': case 'toukachan': case 'tsunade': case 'waifu': case 'waifu2': case 'wallhp2': case 'yatogami': case 'yuki': case 'yuri': {
    reply('await be processed');
    
    let heyy;
    const urlMap = {
        ahegao: 'https://raw.githubusercontent.com/satanicid/database/main/anime/ahegao.json',
        akira: 'https://raw.githubusercontent.com/satanicid/database/main/anime/akira.json',
        akiyama: 'https://raw.githubusercontent.com/satanicid/database/main/anime/akiyama.json',
        ana: 'https://raw.githubusercontent.com/satanicid/database/main/anime/ana.json',
        asuna: 'https://raw.githubusercontent.com/satanicid/database/main/anime/asuna.json',
        ayuzawa: 'https://raw.githubusercontent.com/satanicid/database/main/anime/ayuzawa.json',
        boruto: 'https://raw.githubusercontent.com/satanicid/database/main/anime/boruto.json',
        chitanda: 'https://raw.githubusercontent.com/satanicid/database/main/anime/chitanda.json',
        chitoge: 'https://raw.githubusercontent.com/satanicid/database/main/anime/chitoge.json',
        deidara: 'https://raw.githubusercontent.com/satanicid/database/main/anime/deidara.json',
        doraemon: 'https://raw.githubusercontent.com/satanicid/database/main/anime/doraemon.json',
        elaina: 'https://raw.githubusercontent.com/satanicid/database/main/anime/elaina.json',
        emilia: 'https://raw.githubusercontent.com/satanicid/database/main/anime/emilia.json',
        erza: 'https://raw.githubusercontent.com/satanicid/database/main/anime/erza.json',
        gremory: 'https://raw.githubusercontent.com/satanicid/database/main/anime/gremory.json',
        hestia: 'https://raw.githubusercontent.com/satanicid/database/main/anime/hestia.json',
        hinata: 'https://raw.githubusercontent.com/satanicid/database/main/anime/hinata.json',
        hitorigottoh: 'https://raw.githubusercontent.com/satanicid/database/main/anime/hitorigottoh.json',
        inori: 'https://raw.githubusercontent.com/satanicid/database/main/anime/inori.json',
        isuzu: 'https://raw.githubusercontent.com/satanicid/database/main/anime/isuzu.json',
        itachi: 'https://raw.githubusercontent.com/satanicid/database/main/anime/itachi.json',
        itori: 'https://raw.githubusercontent.com/satanicid/database/main/anime/itori.json',
        kaga: 'https://raw.githubusercontent.com/satanicid/database/main/anime/kaga.json',
        kagura: 'https://raw.githubusercontent.com/satanicid/database/main/anime/kagura.json',
        kakasih: 'https://raw.githubusercontent.com/satanicid/database/main/anime/kakasih.json',
        kaori: 'https://raw.githubusercontent.com/satanicid/database/main/anime/kaori.json',
        keneki: 'https://raw.githubusercontent.com/satanicid/database/main/anime/keneki.json',
        kosaki: 'https://raw.githubusercontent.com/satanicid/database/main/anime/kosaki.json',
        kotori: 'https://raw.githubusercontent.com/satanicid/database/main/anime/kotori.json',
        kuriyama: 'https://raw.githubusercontent.com/satanicid/database/main/anime/kuriyama.json',
        kuroha: 'https://raw.githubusercontent.com/satanicid/database/main/anime/kuroha.json',
        kurumi: 'https://raw.githubusercontent.com/satanicid/database/main/anime/kurumi.json',
        loli: 'https://raw.githubusercontent.com/satanicid/database/main/anime/loli.json',
        madara: 'https://raw.githubusercontent.com/satanicid/database/main/anime/madara.json',
        megumin: 'https://raw.githubusercontent.com/satanicid/database/main/anime/megumin.json',
        mikasa: 'https://raw.githubusercontent.com/satanicid/database/main/anime/mikasa.json',
        miku: 'https://raw.githubusercontent.com/satanicid/database/main/anime/miku.json',
        minato: 'https://raw.githubusercontent.com/satanicid/database/main/anime/minato.json',
        naruto: 'https://raw.githubusercontent.com/satanicid/database/main/anime/naruto.json',
        natsukawa: 'https://raw.githubusercontent.com/satanicid/database/main/anime/natsukawa.json',
        neko: 'https://raw.githubusercontent.com/satanicid/database/main/anime/neko.json',
        nekonime: 'https://raw.githubusercontent.com/satanicid/database/main/anime/nekonime.json',
        nezuko: 'https://raw.githubusercontent.com/satanicid/database/main/anime/nezuko.json',
        nishimiya: 'https://raw.githubusercontent.com/satanicid/database/main/anime/nishimiya.json',
        onepiece: 'https://raw.githubusercontent.com/satanicid/database/main/anime/onepiece.json',
        pokemon: 'https://raw.githubusercontent.com/satanicid/database/main/anime/pokemon.json',
        ppcouple: 'https://raw.githubusercontent.com/satanicid/database/main/anime/ppcouple.json',
        rem: 'https://raw.githubusercontent.com/satanicid/database/main/anime/rem.json',
        rize: 'https://raw.githubusercontent.com/satanicid/database/main/anime/rize.json',
        sagiri: 'https://raw.githubusercontent.com/satanicid/database/main/anime/sagiri.json',
        sakura: 'https://raw.githubusercontent.com/satanicid/database/main/anime/sakura.json',
        sasuke: 'https://raw.githubusercontent.com/satanicid/database/main/anime/sasuke.json',
        shina: 'https://raw.githubusercontent.com/satanicid/database/main/anime/shina.json',
        shinka: 'https://raw.githubusercontent.com/satanicid/database/main/anime/shinka.json',
        shizuka: 'https://raw.githubusercontent.com/satanicid/database/main/anime/shizuka.json',
        shota: 'https://raw.githubusercontent.com/satanicid/database/main/anime/shota.json',
        tomori: 'https://raw.githubusercontent.com/satanicid/database/main/anime/tomori.json',
        toukachan: 'https://raw.githubusercontent.com/satanicid/database/main/anime/toukachan.json',
        tsunade: 'https://raw.githubusercontent.com/satanicid/database/main/anime/tsunade.json',
        waifu: 'https://raw.githubusercontent.com/satanicid/database/main/anime/waifu.json',
        waifu2: 'https://raw.githubusercontent.com/satanicid/database/main/anime/waifu2.json',
        wallhp2: 'https://raw.githubusercontent.com/satanicid/database/main/anime/wallhp2.json',
        yatogami: 'https://raw.githubusercontent.com/satanicid/database/main/anime/yatogami.json',
        yuki: 'https://raw.githubusercontent.com/satanicid/database/main/anime/yuki.json',
        yuri: 'https://raw.githubusercontent.com/satanicid/database/main/anime/yuri.json'
    };
    
    const url = urlMap[command];
    if (url) {
        const response = await axios.get(url);
        heyy = response.data;
        let yeha = heyy[Math.floor(Math.random() * heyy.length)];
        satanic.sendMessage(m.chat, { image: { url: yeha }, caption: 'done' }, { quoted: fkontak });
    }
    break;
}
case 'randomass': case 'randombdsm': case 'randomblowjob': case 'randomcuckold': case 'randomcum': case 'randomeba': case 'randomero': case 'randomfemdom': case 'randomfoot': case 'randomgangbang': case 'randomgifs': case 'randomglasses': case 'randohentai2': case 'randomhentaivid': case 'randomjahy': case 'randommanga': case 'masturbation': case 'randommilf': case 'randomneko2': case 'neko2': case 'nsfwloli': case 'randomorgy': case 'randompanties': case 'randompussy': case 'randomtentacles': case 'randomthighs': case 'randomyuri': case 'randomzettai': {
    reply('await be processed');
    
    let heyy;
    const urlMap = {
        ass: 'https://raw.githubusercontent.com/satanicid/database/main/anime/ass.json',
        bdsm: 'https://raw.githubusercontent.com/satanicid/database/main/anime/bdsm.json',
        blowjob: 'https://raw.githubusercontent.com/satanicid/database/main/anime/blowjob.json',
        cuckold: 'https://raw.githubusercontent.com/satanicid/database/main/anime/cuckold.json',
        cum: 'https://raw.githubusercontent.com/satanicid/database/main/anime/cum.json',
        eba: 'https://raw.githubusercontent.com/satanicid/database/main/anime/eba.json',
        ero: 'https://raw.githubusercontent.com/satanicid/database/main/anime/ero.json',
        femdom: 'https://raw.githubusercontent.com/satanicid/database/main/anime/femdom.json',
        foot: 'https://raw.githubusercontent.com/satanicid/database/main/anime/foot.json',
        gangbang: 'https://raw.githubusercontent.com/satanicid/database/main/anime/gangbang.json',
        gifs: 'https://raw.githubusercontent.com/satanicid/database/main/anime/gifs.json',
        glasses: 'https://raw.githubusercontent.com/satanicid/database/main/anime/glasses.json',
        hentai: 'https://raw.githubusercontent.com/satanicid/database/main/anime/hentai.json',
        hentaivid: 'https://raw.githubusercontent.com/satanicid/database/main/anime/hentaivid.json',
        jahy: 'https://raw.githubusercontent.com/satanicid/database/main/anime/jahy.json',
        manga: 'https://raw.githubusercontent.com/satanicid/database/main/anime/manga.json',
        masturbation: 'https://raw.githubusercontent.com/satanicid/database/main/anime/masturbation.json',
        milf: 'https://raw.githubusercontent.com/satanicid/database/main/anime/milf.json',
        neko: 'https://raw.githubusercontent.com/satanicid/database/main/anime/neko.json',
        neko2: 'https://raw.githubusercontent.com/satanicid/database/main/anime/neko2.json',
        nsfwloli: 'https://raw.githubusercontent.com/satanicid/database/main/anime/nsfwloli.json',
        orgy: 'https://raw.githubusercontent.com/satanicid/database/main/anime/orgy.json',
        panties: 'https://raw.githubusercontent.com/satanicid/database/main/anime/panties.json',
        pussy: 'https://raw.githubusercontent.com/satanicid/database/main/anime/pussy.json',
        tentacles: 'https://raw.githubusercontent.com/satanicid/database/main/anime/tentacles.json',
        thighs: 'https://raw.githubusercontent.com/satanicid/database/main/anime/thighs.json',
        yuri: 'https://raw.githubusercontent.com/satanicid/database/main/anime/yuri.json',
        zettai: 'https://raw.githubusercontent.com/satanicid/database/main/anime/zettai.json'
    };
    
    const url = urlMap[command];
    if (url) {
        heyy = await fetchJson(url);
        let yeha = heyy[Math.floor(Math.random() * heyy.length)];
        satanic.sendMessage(m.chat, { image: { url: yeha }, caption: 'done' }, { quoted: m });
    }
    break;
}


case 'google-gemini': {
    if (!text) return reply('❌ Mohon masukkan pertanyaan!\n\nContoh: .google-gemini Jelaskan tentang ombak laut');
    
    reply('await be processed');
    
    try {
        const crypto = require("crypto");
        
        const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0";
        const HOME = "https://gemini.google.com/app";
        const ENDPOINT = "https://gemini.google.com/_/BardChatUi/data/assistant.lamda.BardFrontendService/StreamGenerate";
        
        const hex = n => crypto.randomBytes(n).toString("hex");
        const uuid = () => crypto.randomUUID().toUpperCase();
        const reqid = () => Math.floor(Math.random() * 900000) + 100000;
        const pack = obj => Buffer.from(JSON.stringify(obj)).toString("base64");
        const unpack = s => { try { return JSON.parse(Buffer.from(s, "base64").toString()) } catch { return null } };
        
        async function bootstrap() {
            const res = await fetch(HOME, { headers: { "user-agent": UA, "accept-language": "en-US,en;q=0.9" } });
            const setc = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
            const cookie = setc.map(c => c.split(";")[0]).join("; ");
            const html = await res.text();
            return {
                cookie,
                bl: (html.match(/"cfb2h":"(.*?)"/) || [])[1] || "",
                fsid: (html.match(/"FdrFJe":"(.*?)"/) || [])[1] || "",
                uid: uuid()
            };
        }
        
        function buildBody(message, resume, uid) {
            const inner = [
                [message, 0, null, null, null, null, 0],
                ["en-US"],
                resume,
                "",
                hex(16),
                null, [1], 1, null, null, 1, 0, null, null, null, null, null,
                [[0]], 0, null, null, null, null, null, null, null, null, 1, null, null, [4],
                null, null, null, null, null, null, null, null, null, null, [2],
                null, null, null, null, null, null, null, null, null, null, null, 0,
                null, null, null, null, null, uid, null, [], null, null, null, null, null, null, 2,
                null, null, null, null, null, null, null, null, null, null, 1
            ];
            return "f.req=" + encodeURIComponent(JSON.stringify([null, JSON.stringify(inner)])) + "&";
        }
        
        function parseReply(raw) {
            const out = { text: "", conversationId: null, responseId: null, replyId: null };
            let best = "";
            for (const line of (raw || "").split("\n")) {
                const s = line.trim();
                if (!s.startsWith('[["wrb.fr"')) continue;
                let outer;
                try { outer = JSON.parse(s); } catch { continue; }
                for (const row of outer) {
                    if (!Array.isArray(row) || row[0] !== "wrb.fr" || typeof row[2] !== "string") continue;
                    let body;
                    try { body = JSON.parse(row[2]); } catch { continue; }
                    const ids = body[1];
                    if (Array.isArray(ids)) {
                        if (typeof ids[0] === "string" && ids[0].startsWith("c_")) out.conversationId = ids[0];
                        if (typeof ids[1] === "string" && ids[1].startsWith("r_")) out.responseId = ids[1];
                    }
                    const seg = Array.isArray(body[4]) ? body[4][0] : null;
                    if (seg) {
                        if (seg[0]) out.replyId = seg[0];
                        if (Array.isArray(seg[1])) {
                            const piece = seg[1].join("");
                            if (piece.length > best.length) best = piece;
                        }
                    }
                }
            }
            out.text = best.trim();
            return out;
        }
        
        async function geminiChat(message, options = {}) {
            const sess = options.sessionId ? unpack(options.sessionId) : null;
            const ctx = sess && sess.cookie ? sess : await bootstrap();
            const resume = sess && sess.resume
                ? [sess.resume[0] || "", sess.resume[1] || "", sess.resume[2] || "", null, null, null, null, null, null, ""]
                : ["", "", "", null, null, null, null, null, null, ""];
            
            const url = `${ENDPOINT}?bl=${encodeURIComponent(ctx.bl)}&f.sid=${encodeURIComponent(ctx.fsid)}&hl=en-US&_reqid=${reqid()}&rt=c`;
            const res = await fetch(url, {
                method: "POST",
                headers: {
                    "content-type": "application/x-www-form-urlencoded;charset=UTF-8",
                    "user-agent": UA,
                    "origin": "https://gemini.google.com",
                    "referer": "https://gemini.google.com/",
                    "x-same-domain": "1",
                    "x-goog-ext-525001261-jspb": JSON.stringify([1, null, null, null, hex(8), null, null, 0, [4, 6], null, null, 1, null, null, 1, null, uuid()]),
                    "x-goog-ext-525005358-jspb": JSON.stringify([ctx.uid, 1]),
                    "x-goog-ext-73010990-jspb": "[0,0,0]",
                    "x-goog-ext-73010989-jspb": "[0]",
                    cookie: ctx.cookie
                },
                body: buildBody(String(message), resume, ctx.uid)
            });
            
            const raw = await res.text();
            const reply = parseReply(raw);
            const ok = reply.text && reply.text.length > 0;
            
            return {
                status: res.status,
                response: reply.text || null,
                sessionId: ok ? pack({
                    cookie: ctx.cookie,
                    bl: ctx.bl,
                    fsid: ctx.fsid,
                    uid: ctx.uid,
                    resume: [reply.conversationId, reply.responseId, reply.replyId]
                }) : (options.sessionId || null)
            };
        }
        
        const response = await geminiChat(text);
        
        if (response && response.response) {
            satanic.sendMessage(m.chat, { text: response.response }, { quoted: m });
        } else {
            reply('❌ Gagal mendapatkan respons dari Google Gemini');
        }
        
    } catch (error) {
        console.error('Google Gemini Error:', error);
        reply('❌ Terjadi kesalahan: ' + error.message);
    }
    break;
}
case 'feelbetter': {
    await satanic.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });

    // Ambil teks pertanyaan dari user
    let query = m.text.trim();

    if (!query) {
        return satanic.sendMessage(m.chat, { text: `❌ Masukkan pertanyaan!\nContoh: .aqua Halo, apa kabar?` }, { quoted: fkontak });
    }

    // Kirim pesan loading
    await satanic.sendMessage(m.chat, { text: `💙 *Aqua AI sedang mendengarkan...*\n\n"${query.substring(0, 50)}${query.length > 50 ? '...' : ''}"` }, { quoted: fkontak });

    const API_AQUA = "https://feelbetterbot.com/";

    const SYSTEM_MESSAGE = "Kamu adalah asisten AQUA AI yang dibuat oleh Satanic Haxor ciptaan satanic Haxor. Ikuti bahasa yang digunakan user dalam percakapan. Jika user memakai bahasa Indonesia, jawab dalam bahasa Indonesia yang natural, santai, jelas, dan mudah dipahami. Jangan tiba-tiba pindah bahasa kecuali user memintanya. Jika user bertanya siapa pembuatmu, penciptamu, developermu, atau siapa yang membuatmu, jawab bahwa pembuatmu adalah satanic Haxor.";

    const DEFAULT_ASSISTANT = "Hi, I'm Aqua AI — I'm here to listen and help you carry whatever feels heavy, without judgment. I draw on gentle, proven ways of working through hard things, but mostly I just want to understand what you're going through. So, how are you doing right now?";

    function makeMemoryId() {
        const animals = ["owl", "fox", "cat", "wolf", "bear", "lion", "deer", "bird"];
        const words = ["safe", "calm", "soft", "kind", "warm", "bright", "gentle"];
        const word = words[Math.floor(Math.random() * words.length)];
        const animal = animals[Math.floor(Math.random() * animals.length)];
        const number = Math.floor(1000 + Math.random() * 9000);
        return `${word}-${animal}-${number}`;
    }

    function parseChunk(line) {
        let data = line.trim();
        if (!data || data === "[DONE]") return "";
        if (data.startsWith("data:")) data = data.slice(5).trim();
        if (!data || data === "[DONE]") return "";

        try {
            const json = JSON.parse(data);
            if (typeof json === "string") return json;
            if (typeof json.content === "string") return json.content;
            if (typeof json.text === "string") return json.text;
            if (typeof json.delta === "string") return json.delta;
            if (typeof json.message === "string") return json.message;
            if (typeof json.response === "string") return json.response;
            if (typeof json.answer === "string") return json.answer;
            const openAiContent = json.choices?.[0]?.delta?.content;
            if (typeof openAiContent === "string") return openAiContent;
            return "";
        } catch {
            return data;
        }
    }

    async function FeelBetter(prompt, options = {}) {
        const memoryId = options.memoryId || makeMemoryId();
        const history = options.history || [];

        const messages = [
            { role: "system", content: SYSTEM_MESSAGE },
            { role: "assistant", content: DEFAULT_ASSISTANT },
            ...history.map((item) => ({
                role: item.role,
                content: item.content,
            })),
            { role: "user", content: prompt },
        ];

        const headers = {
            "sec-ch-ua-platform": `"Android"`,
            "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36",
            "sec-ch-ua": `"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"`,
            "content-type": "application/json",
            "sec-ch-ua-mobile": "?1",
            accept: "*/*",
            origin: "https://feelbetterbot.com",
            referer: "https://feelbetterbot.com/",
            "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
            cookie: `feelbet-memory=${memoryId}`,
            priority: "u=1, i",
        };

        try {
            const response = await fetch(API_AQUA, {
                method: "POST",
                headers,
                body: JSON.stringify({ messages }),
            });

            if (!response.ok) {
                const text = await response.text();
                return { status: false, code: response.status, memoryId, error: text };
            }

            // Ambil response sebagai text
            const text = await response.text();
            
            // Parse response - coba parse sebagai JSON dulu
            let answer = "";
            
            try {
                // Coba parse sebagai JSON langsung
                const json = JSON.parse(text);
                if (typeof json === "string") {
                    answer = json;
                } else if (typeof json.content === "string") {
                    answer = json.content;
                } else if (typeof json.text === "string") {
                    answer = json.text;
                } else if (typeof json.response === "string") {
                    answer = json.response;
                } else if (typeof json.answer === "string") {
                    answer = json.answer;
                } else if (json.choices?.[0]?.delta?.content) {
                    answer = json.choices[0].delta.content;
                } else if (json.choices?.[0]?.message?.content) {
                    answer = json.choices[0].message.content;
                } else {
                    // Jika tidak ada field yang dikenal, coba parse sebagai SSE
                    const lines = text.split('\n');
                    for (const rawLine of lines) {
                        const chunk = parseChunk(rawLine);
                        if (chunk) answer += chunk;
                    }
                }
            } catch (e) {
                // Jika bukan JSON, parse sebagai SSE
                const lines = text.split('\n');
                for (const rawLine of lines) {
                    const chunk = parseChunk(rawLine);
                    if (chunk) answer += chunk;
                }
            }

            // Jika masih kosong, gunakan teks asli
            if (!answer.trim()) {
                answer = text;
            }

            return { 
                status: true, 
                code: response.status, 
                memoryId, 
                question: prompt, 
                answer: answer.trim() 
            };
        } catch (error) {
            return { 
                status: false, 
                code: 500, 
                memoryId, 
                error: error.message 
            };
        }
    }

    // Panggil fungsi FeelBetter
    const result = await FeelBetter(query);

    if (!result.status) {
        return satanic.sendMessage(m.chat, { text: `❌ Error: ${result.error || result.code}` }, { quoted: fkontak });
    }

    // Kirim jawaban
    let reply = `💙 *Aqua AI*\n\n`;
    reply += `${result.answer}\n\n`;
    reply += `📝 *Pertanyaan:* ${result.question.substring(0, 100)}${result.question.length > 100 ? '...' : ''}\n`;
    reply += `🆔 *Memory ID:* ${result.memoryId}`;

    // Jika jawaban kepanjangan, kirim sebagai pesan terpisah
    if (reply.length > 65500) {
        await satanic.sendMessage(m.chat, { text: result.answer }, { quoted: fkontak });
    } else {
        await satanic.sendMessage(m.chat, { text: reply }, { quoted: fkontak });
    }
}
break;

case 'gpt-5.1':
case 'gpt-5-online':
case 'gpt-5':
case 'gpt-5-nano':
case 'gpt-5-mini':
case 'openai-o1':
case 'openai-o3':
case 'openai-o3-mini':
case 'gpt-4o':
case 'openai-o4-mini':
case 'gpt-4.1-mini':
case 'gpt-4.1-nano':
case 'gpt-5.3':
case 'gpt-5.4':
case 'gpt-5.5': {
    if (!text) return reply(`*Example :* .${command} Apa itu AI`);
    reply('wait be processed')
    let web = false;
    let image = false;
    let deep = false;
    let agent = false;
    if (command.includes('/')) {
        let parts = command.split('/');
        for (let i of parts.slice(1)) {
            if (i === 'websearch') web = true;
            if (i === 'imagegen') image = true;
            if (i === 'deep') deep = true;
            if (i === 'agent') agent = true;
        }
    }
    let model;
    switch (command.split('/')[0]) {
        case 'gpt-5.1':
            model = 'openai/gpt-5.1-thinking';
            break;
        case 'gpt-5-online':
            model = 'openai/gpt-5-chat:online';
            break;
        case 'gpt-5':
            model = 'openai/gpt-5-chat';
            break;
        case 'gpt-5-nano':
            model = 'openai/gpt-5-nano';
            break;
        case 'gpt-5-mini':
            model = 'openai/gpt-5-mini';
            break;
        case 'openai-o1':
            model = 'openai/o1';
            break;
        case 'openai-o3':
            model = 'openai/o3';
            break;
        case 'openai-o3-mini':
            model = 'openai/o3-mini';
            break;
        case 'gpt-4o':
            model = 'openai/gpt-4o';
            break;
        case 'openai-o4-mini':
            model = 'openai/o4-mini';
            break;
        case 'gpt-4.1-mini':
            model = 'openai/gpt-4-1-mini';
            break;
        case 'gpt-4.1-nano':
            model = 'openai/gpt-4-1-nano';
            break;
        case 'gpt-5.3':
            model = 'openai/gpt-5.3-chat';
            break;
        case 'gpt-5.4':
            model = 'openai/gpt-5.4';
            break;
        case 'gpt-5.5':
            model = 'openai/gpt-5.5';
            break;
        default:
            model = 'openai/gpt-5.3-chat';
            break;
    }
    
    const res = await fetch("https://fgsi.dpdns.org/api/ai/chatgpt", {
        method: "POST",
        headers: {
            "accept": "application/json",
            "content-type": "application/json"
        },
        body: JSON.stringify({
            apikey: global.fgsi,
            model: model,
            messages: [
                {
                    id: "",
                    role: "user",
                    parts: [
                        {
                            type: "text",
                            text: text
                        }
                    ]
                }
            ],
            isDeepResearchMode: deep,
            isWebSearchMode: web,
            isImageGenerationMode: image,
            isAgenticMode: agent
        })
    });
    
    const data = await res.json();
    
    if (data?.data?.images?.length) {
        return satanic.sendMessage(m.chat, { image: { url: data.data.images[0].url } }, { quoted: fkontak });
    }
    reply(data?.data?.text);
}
break;
case 'ektp':
case 'fakektp': {
    satanic.sendMessage(m.chat, { react: { text: '🪪', key: m.key } });
    
    try {
        const quoted = m.quoted ? m.quoted : m;
        const mime = (quoted.msg || quoted).mimetype || '';
        if (!/image/.test(mime)) return reply(`❌ Kirim/reply gambar dengan command: ${command}`);

        // Download gambar
        let media = await quoted.download();
        
        // Upload ke pone.rs
        const form = new FormData();
        form.append('files[]', media, { filename: 'image.jpg' });
        const uploadRes = await axios.post('https://pone.rs/upload.php', form, {
            headers: {
                ...form.getHeaders(),
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
                'Referer': 'https://pone.rs/',
                'Origin': 'https://pone.rs'
            },
            maxBodyLength: Infinity,
            maxContentLength: Infinity
        });
        
        if (!uploadRes.data?.success || !uploadRes.data?.files?.[0]?.url) {
            return reply(`❌ Gagal upload foto! Silahkan coba lagi.`);
        }
        
        let pasPhotoURL = uploadRes.data.files[0].url.replace(/\\\//g, '/');

        let parts = text ? text.split("|").map(v => v.trim()) : [];

        const [
            provinsi = "",
            kota = "",
            nik = "",
            nama = "",
            ttl = "",
            jenis_kelamin = "",
            golongan_darah = "",
            alamat = "",
            rt_rw = "",
            kel_desa = "",
            kecamatan = "",
            agama = "",
            status = "",
            pekerjaan = "",
            kewarganegaraan = "",
            masa_berlaku = "",
            terbuat = ""
        ] = parts;

        if (!provinsi || !kota || !nik || !nama || !ttl) {
            return reply(
                `⚠️ *Format salah!*\n\nGunakan format:\n` +
                `${prefix + command} Provinsi|Kota|NIK|Nama|TTL|JK|GolDar|Alamat|RT/RW|Kel/Desa|Kecamatan|Agama|Status|Pekerjaan|Kewarganegaraan|Masa Berlaku|Terbuat\n\n` +
                `Contoh:\n${prefix + command} JAWA BARAT|BANDUNG|1234567890123456|JOHN DOE|Bandung, 01-01-1990|Laki-laki|O|Jl. Contoh No. 123|001/002|Sukajadi|Sukajadi|Islam|Belum Kawin|Pegawai Swasta|WNI|Seumur Hidup|01-01-2023`
            );
        }

        // Panggil API
        const params = new URLSearchParams({
            provinsi, kota, nik, nama, ttl,
            jenis_kelamin, golongan_darah, alamat,
            "rt/rw": rt_rw,
            "kel/desa": kel_desa,
            kecamatan, agama, status, pekerjaan,
            kewarganegaraan, masa_berlaku, terbuat,
            pas_photo: pasPhotoURL
        });

        const response = await fetch(`https://api.siputzx.my.id/api/canvas/ektp?${params}`);
        const buffer = Buffer.from(await response.arrayBuffer());

        await satanic.sendMessage(
            m.chat,
            {
                image: buffer,
                caption: `🪪 *eKTP Berhasil Dibuat!*\n\n👤 Nama: *${nama}*\n🆔 NIK: *${nik}*`
            },
            { quoted: fkontak }
        );

    } catch (e) {
        reply(`❌ Error:\n${e.message}`);
    }
}
break;
case 'nanobanana2': {
    satanic.sendMessage(m.chat, { react: { text: `🍌`, key: m.key } });
    if (!text) return reply(`*🍌 NANO BANANA*\n\nContoh: ${prefix}nanobanana menjerit\n\nBalas gambar dengan command dan teks prompt.`);
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('❌ Kirim/reply gambar dengan command: .nanobanana + teks prompt');
    try {
        const imgBuffer = await satanic.downloadMediaMessage(quoted);
        
        // Upload ke pone.rs
        const form = new FormData();
        form.append('files[]', imgBuffer, { filename: 'image.jpg' });
        const uploadRes = await axios.post('https://pone.rs/upload.php', form, {
            headers: {
                ...form.getHeaders(),
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
                'Referer': 'https://pone.rs/',
                'Origin': 'https://pone.rs'
            },
            maxBodyLength: Infinity,
            maxContentLength: Infinity
        });
        
        if (!uploadRes.data?.success || !uploadRes.data?.files?.[0]?.url) {
            return reply('❌ Gagal upload gambar ke pone.rs');
        }
        
        const link = uploadRes.data.files[0].url.replace(/\\\//g, '/');
        const apiUrl = `https://api-faa.my.id/faa/nanobanana?url=${encodeURIComponent(link)}&prompt=${text}`;
        const res = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        const ct = res.headers['content-type'] || '';
        if (ct.startsWith('image/')) {
            return satanic.sendMessage(m.chat, { image: Buffer.from(res.data), caption: '🍌 Nano Banana berhasil diproses!' }, { quoted: fkontak });
        }
        const json = JSON.parse(res.data.toString());
        const imageUrl = json.url || json.result || json.image || json.data?.url;
        if (!imageUrl) return reply('❌ API tidak mengembalikan gambar');
        const img = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        satanic.sendMessage(m.chat, { image: Buffer.from(img.data), caption: '🍌 Nano Banana berhasil diproses!' }, { quoted: fkontak });
    } catch (e) { reply(e?.response?.status === 500 ? "⚠️ API maintenance, tunggu beberapa saat untuk mencoba kembali" : `⚠️ Error: ${e.message}`); }
}
break;
case 'tosad':
case 'tosatan':
case 'tosdmtinggi':
case 'toreal':
case 'tomoai':
case 'tomaya':
case 'tolego':
case 'tokamboja':
case 'tokacamata':
case 'tojepang':
case 'toghibli':
case 'todubai':
case 'todpr':
case 'totua':
case 'tohitam':
case 'totato':
case 'topeci':
case 'tovintage':
case 'topolaroid':
case 'tochibi':
case 'tobrewok':
case 'tobabi':
case 'tofigura':
case 'tofigurav2':
case 'tofigurav3':
case 'topacar':
case 'topacarv2':
case 'tozombie':
case 'topenjara':
case 'tojapanese':
case 'toblonde':
case 'tobotak':
case 'tohijab':
case 'topejabat':
case 'tomekah':
case 'tomirror':
case 'toanime': {
    reply('⏳ await be processed...')
    const quoted = m.quoted ? m.quoted : m
    const mime = (quoted.msg || quoted).mimetype || ''
    if (!/image/.test(mime)) return reply(`❌ Kirim/reply gambar dengan command: ${command}`)
    try {
        const imgBuffer = await satanic.downloadMediaMessage(quoted)
        const form = new FormData()
        form.append('files[]', imgBuffer, { filename: 'image.jpg' })
        const uploadRes = await axios.post('https://pone.rs/upload.php', form, {
            headers: {
                ...form.getHeaders(),
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
                'Referer': 'https://pone.rs/',
                'Origin': 'https://pone.rs'
            },
            maxBodyLength: Infinity,
            maxContentLength: Infinity
        })
        if (!uploadRes.data?.success || !uploadRes.data?.files?.[0]?.url) return reply('❌ Gagal upload gambar')
        const link = uploadRes.data.files[0].url.replace(/\\\//g, '/')
        const apiUrl = `https://api-faa.my.id/faa/${command}?url=${encodeURIComponent(link)}`
        const res = await axios.get(apiUrl, { responseType: 'arraybuffer' })
        const ct = res.headers['content-type'] || ''
        if (ct.startsWith('image/')) {
            return satanic.sendMessage(m.chat, { image: Buffer.from(res.data), caption: '🧿 berhasil!' }, { quoted: fkontak })
        }
        const json = JSON.parse(res.data.toString())
        const imageUrl = json.url || json.result || json.image || json.data?.url
        if (!imageUrl) return reply('❌ API tidak mengembalikan gambar')
        const img = await axios.get(imageUrl, { responseType: 'arraybuffer' })
        satanic.sendMessage(m.chat, { image: Buffer.from(img.data), caption: '🧿 Berhasil!' }, { quoted: fkontak })
    } catch (e) {
        reply(e?.response?.status === 500 ? "⚠️ API maintenance, tunggu beberapa saat untuk mencoba kembali" : `⚠️ Error: ${e.message}`)
    }
}
break

case 'jadianime': {
    if (!isPrem) return reply('Anda bukan pengguna premium. Update premium untuk membuka fitur ini.');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .jadianime');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const prompt = `change to anime realistic`;
        const apiUrl = `https://free-restapi.biz.id/api/nanobanana?url=${encodeURIComponent(ImageUrlaja)}&prompt=${encodeURIComponent(prompt)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { image: response.data, caption: '✨ Gambar berhasil.' }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. Silakan update premium untuk menggunakan fitur ini.');
    }
}
break;

case 'jadihitam': {
    if (!isPrem) return reply('Anda bukan pengguna premium. Update premium untuk membuka fitur ini.');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .jadianime');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const prompt = `ubah warna kulit nya menjadi hitam seperti orang afrika`;
        const apiUrl = `https://free-restapi.biz.id/api/nanobanana?url=${encodeURIComponent(ImageUrlaja)}&prompt=${encodeURIComponent(prompt)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { image: response.data, caption: '✨ Gambar berhasil.' }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. Silakan update premium untuk menggunakan fitur ini.');
    }
}
break;
case 'jadichibi': {
    if (!isPrem) return reply('Anda bukan pengguna premium. Update premium untuk membuka fitur ini.');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .jadianime');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const prompt = `Transform the person in the image into a cute anime chibi version. 
    Keep the same hairstyle, outfit style, and recognizable features, 
    but make the head slightly larger and the body smaller for a chibi proportion. 
    Use soft anime colors, expressive eyes, and a clean illustration look. 
    The final result should look like a high-quality anime chibi artwork.`;
        const apiUrl = `https://free-restapi.biz.id/api/nanobanana?url=${encodeURIComponent(ImageUrlaja)}&prompt=${encodeURIComponent(prompt)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { image: response.data, caption: '✨ Gambar berhasil.' }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. Silakan update premium untuk menggunakan fitur ini.');
    }
}
break;
case 'jaditangkappolisi': {
    if (!isPrem) return reply('Anda bukan pengguna premium. Update premium untuk membuka fitur ini.');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .jadianime');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const prompt = `Ultra-photorealistic cinematic photograph tentang diriku yang sedang ditahan oleh dua petugas polisi indonesia dan berseragam polisi lengkap, beberapa detik sebelum dimasukkan ke dalam mobil polisi. Dua polisi berdiri di kiri dan kanan, memegang lenganku dengan kuat. Tanganku diborgol di belakang. Aku menoleh ke belakang ke arah kamera, melakukan kontak mata langsung dengan kamera, dengan ekspresi tersenyum namun misterius (senyum natural, tidak berlebihan, terasa ambigu dan penuh makna). SYARAT KRITIS (WAJIB): Wajah harus 100% identik dengan foto referensi asliku tidak boleh ada perubahan pada struktur wajah, proporsi, tekstur kulit, ekspresi dasar, atau identitas.High-fidelity face.Untuk wilayah berada di wilayah indonesia sekitar nya`;
        const apiUrl = `https://free-restapi.biz.id/api/nanobanana?url=${encodeURIComponent(ImageUrlaja)}&prompt=${encodeURIComponent(prompt)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { image: response.data, caption: '✨ Gambar berhasil.' }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. Silakan update premium untuk menggunakan fitur ini.');
    }
}
break;
case 'jadiblonde': {
    if (!isPrem) return reply('Anda bukan pengguna premium. Update premium untuk membuka fitur ini.');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .jadianime');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const prompt = `ubah warna rambut nya menjadi warna rambut pirang blonde, warna blonde nya ganti ganti`;
        const apiUrl = `https://free-restapi.biz.id/api/nanobanana?url=${encodeURIComponent(ImageUrlaja)}&prompt=${encodeURIComponent(prompt)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { image: response.data, caption: '✨ Gambar berhasil.' }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. Silakan update premium untuk menggunakan fitur ini.');
    }
}
break;
case 'jaditobrut': {
    if (!isPrem) return reply('Anda bukan pengguna premium. Update premium untuk membuka fitur ini.');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .jadianime');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const prompt = `ubah body nya menjadi sexy payudara sedikit besar`;
        const apiUrl = `https://free-restapi.biz.id/api/nanobanana?url=${encodeURIComponent(ImageUrlaja)}&prompt=${encodeURIComponent(prompt)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { image: response.data, caption: '✨ Gambar berhasil.' }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. Silakan update premium untuk menggunakan fitur ini.');
    }
}
break;
case 'jadiputih': {
    if (!isPrem) return reply('Anda bukan pengguna premium. Update premium untuk membuka fitur ini.');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .jadianime');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const prompt = `ubah warna kulit nya menjadi sedikit putih mirip seperti warna kulit orang china`;
        const apiUrl = `https://free-restapi.biz.id/api/nanobanana?url=${encodeURIComponent(ImageUrlaja)}&prompt=${encodeURIComponent(prompt)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { image: response.data, caption: '✨ Gambar berhasil.' }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. Silakan update premium untuk menggunakan fitur ini.');
    }
}
break;
case 'jadizombie': {
    if (!isPrem) return reply('Anda bukan pengguna premium. Update premium untuk membuka fitur ini.');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .jadizombie');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const prompt = `change to zombie realistic`;
        const apiUrl = `https://free-restapi.biz.id/api/nanobanana?url=${encodeURIComponent(ImageUrlaja)}&prompt=${encodeURIComponent(prompt)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { image: response.data, caption: '✨ Gambar berhasil.' }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. Silakan update premium untuk menggunakan fitur ini.');
    }
}
break;
case 'jadibotak': {
    if (!isPrem) return reply('Anda bukan pengguna premium. Update premium untuk membuka fitur ini.');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .jadibotak');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const prompt = `buat karakter ini tidak memiliki rambut atau jadikan karakter ini botak`;
        const apiUrl = `https://free-restapi.biz.id/api/nanobanana?url=${encodeURIComponent(ImageUrlaja)}&prompt=${encodeURIComponent(prompt)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { image: response.data, caption: '✨ Gambar berhasil.' }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. Silakan update premium untuk menggunakan fitur ini.');
    }
}
break;
case 'deteksiumur':
case 'agedetection':
case 'cekumur': {
    if (!isPrem) return reply('you are not premium, update premium untuk menggunakan fitur ini');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .cekumur');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mediaPath = await satanic.downloadAndSaveMediaMessage(quoted);
        let uploadResult = await UploadFileUgu(mediaPath);
          let ImageUrlaja = UploadResult.url || UploadResult;
        const apiUrl = `https://free-restapi.biz.id/api/age-detection?url=${encodeURIComponent(ImageUrlaja)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl);
        if (response.data.status === 'success' && response.data.result?.age) {
            const umur = response.data.result.age;
            await satanic.sendMessage(m.chat, {
                text: `👤 *Hasil Deteksi Umur*\n\n📸 Berdasarkan foto yang dikirim, usia terdeteksi: *${umur} tahun*`,
                contextInfo: { mentionedJid: [m.sender] }
            }, { quoted: fkontak });
        } else {
            throw new Error('Gagal mendeteksi umur');
        }
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error(err);
        reply('❌ Gagal mendeteksi umur. Pastikan foto wajah terlihat jelas dan coba lagi nanti.');
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
break;
case 'jadifigure': {
    if (!isPrem) return reply('Anda bukan pengguna premium. Update premium untuk membuka fitur ini.');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .jadifigure');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const prompt = `Using the model, create a 1/7 scale commercialized figurine of the characters in the picture, in a realistic style, in a real environment. The figurine is placed on a computer desk. The figurine has a round transparent acrylic base, with no text on the base. The content on the computer screen is the ZBrush modeling process of this figurine. Next to the computer screen is a BANDAI-style toy packaging box printed with the original artwork. The packaging features two-dimensional flat illustrations`;
        const apiUrl = `https://free-restapi.biz.id/api/nanobanana?url=${encodeURIComponent(ImageUrlaja)}&prompt=${encodeURIComponent(prompt)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { image: response.data, caption: '✨ Gambar berhasil.' }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. Silakan update premium untuk menggunakan fitur ini.');
    }
}
break;
case 'veo3':
case 'texttovideo': {
if (!isPrem) return reply('you are not premium, Updated premium open this feature')
    let prompttt = args.join(' ').trim();
    if (!prompttt) return reply('Contoh: .texttovideo a beautiful girls sunset');    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });    
    try {
        let apiUrl = `https://free-restapi.biz.id/api/texttovideo?prompt=${encodeURIComponent(prompttt)}&ratio=16:9&apikey=${global.sakey}`;
        let response = await axios.get(apiUrl);        
        if (response.data.status !== 200) throw new Error('Gagal');        
        let videoUrl = response.data.result.video_url;
        let video = await axios.get(videoUrl, { responseType: 'arraybuffer' });        
        await satanic.sendMessage(m.chat, { 
            video: video.data,
            caption: `✅ Berhasil!\n📝 ${prompttt}`
        }, { quoted: fkontak });        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });        
    } catch (err) {
        reply('❌ Gagal!');
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'gpt2image': {
    if (!isPrem) return reply('you are not premium, Updated premium open this feature');
    if (!text) return reply('input prompt');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .gpt2image + prompt');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const apiUrl = `https://free-restapi.biz.id/api/gpt2image?url=${encodeURIComponent(ImageUrlaja)}&prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil!'
        }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. silahkan update premium untuk menggunakan fitur ini');
    }
}
break;
case 'nanobananapro': {
    if (!isPrem) return reply('you are not premium, Updated premium open this feature');
    if (!text) return reply('input prompt');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .nanobananapro + prompt');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const apiUrl = `https://free-restapi.biz.id/api/nanobanana-editor?image=${encodeURIComponent(ImageUrlaja)}&prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil!'
        }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. silahkan update premium untuk menggunakan fitur ini');
    }
}
break;
case 'fakelobyml':
case 'fakeml': {
    
    if (!text) return reply('input username');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .fakeml + username');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const apiUrl = `https://api.nexray.eu.cc/maker/fakelobyml?avatar=${encodeURIComponent(ImageUrlaja)}&nickname=${encodeURIComponent(text)}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil!'
        }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. silahkan update premium untuk menggunakan fitur ini');
    }
}
break;
case 'editimg': {
    if (!isPrem) return reply('you are not premium, Updated premium open this feature');
    if (!text) return reply('input prompt');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .nanobananapro + prompt');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const apiUrl = `https://free-restapi.biz.id/api/editimg?url=${encodeURIComponent(ImageUrlaja)}&prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil!'
        }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. silahkan update premium untuk menggunakan fitur ini');
    }
}
break;
case 'fakestoryig': {
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    const isImage = /image/.test(mime);
    
    if (!text && !isImage) {
        return reply(`❌ Masukkan caption atau kirim/reply gambar!\n\nContoh:\n.fakestoryig Halo ini caption\n.fakestoryig (dengan gambar)`);
    }
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let caption = text || '';
        let imageUrl = '';
        
        if (isImage) {
            let media = await quoted.download();
            
            const form = new FormData();
            form.append('files[]', media, { filename: 'image.jpg' });
            const uploadRes = await axios.post('https://pone.rs/upload.php', form, {
                headers: {
                    ...form.getHeaders(),
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
                    'Referer': 'https://pone.rs/',
                    'Origin': 'https://pone.rs'
                },
                maxBodyLength: Infinity,
                maxContentLength: Infinity
            });
            
            if (!uploadRes.data?.success || !uploadRes.data?.files?.[0]?.url) {
                await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return reply(`❌ Gagal upload foto! Silahkan coba lagi.`);
            }
            
            imageUrl = uploadRes.data.files[0].url;
        }
        
        const username = m.pushName || 'User';
        let avatarUrl = '';
        
        try {
            const ppUrl = await satanic.profilePictureUrl(m.sender, 'image');
            if (ppUrl) {
                const ppForm = new FormData();
                const ppResponse = await axios.get(ppUrl, { responseType: 'arraybuffer' });
                ppForm.append('files[]', Buffer.from(ppResponse.data), { filename: 'avatar.jpg' });
                const ppUpload = await axios.post('https://pone.rs/upload.php', ppForm, {
                    headers: {
                        ...ppForm.getHeaders(),
                        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
                        'Referer': 'https://pone.rs/',
                        'Origin': 'https://pone.rs'
                    },
                    maxBodyLength: Infinity,
                    maxContentLength: Infinity
                });
                if (ppUpload.data?.success && ppUpload.data?.files?.[0]?.url) {
                    avatarUrl = ppUpload.data.files[0].url;
                }
            }
        } catch (err) {
            console.log('Gagal mengambil foto profil:', err);
        }
        
        let apiUrl = `https://free-restapi.biz.id/api/fakestoryig?apikey=${global.sakey}`;
        if (imageUrl) apiUrl += `&image=${encodeURIComponent(imageUrl)}`;
        if (avatarUrl) apiUrl += `&avatar=${encodeURIComponent(avatarUrl)}`;
        if (username) apiUrl += `&username=${encodeURIComponent(username)}`;
        if (caption) apiUrl += `&caption=${encodeURIComponent(caption)}`;
        
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        await satanic.sendMessage(m.chat, {
            image: Buffer.from(response.data),
            caption: `✅ Fake Story Instagram berhasil dibuat!\n\nUsername: ${username}\nCaption: ${caption || 'Tidak ada caption'}`
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error('Error FakeStoryIG:', err);
        reply('❌ Terjadi kesalahan saat membuat fake story Instagram.');
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'iqc': {
    try {
        if (!text) return reply('❌ *Masukkan teks!*\n\n📝 *Contoh:* .iqc kamu bodoh');
        
        await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        const apiUrl = `https://api.nexray.eu.cc/maker/iqc?text=${encodeURIComponent(text)}`;
        
        const response = await fetch(apiUrl);
        
        if (!response.ok) {
            throw new Error(`HTTP Error ${response.status}`);
        }
        
        const buffer = await response.arrayBuffer();
        const imageBuffer = Buffer.from(buffer);
        
        await satanic.sendMessage(m.chat, {
            image: imageBuffer,
            caption: `done \n📝 "${text}"`
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (e) {
        console.error('Error in iqc case:', e);
        reply('❌ *Error:* ' + (e.message || 'Gagal membuat IQ Challenge'));
    }
}
break;
case 'qcwin': {
    try {
        if (!text) return reply('❌ *Masukkan teks!*\n\n📝 *Contoh:* .qcwin kamu bodoh');
        
        await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        const apiUrl = `https://free-restapi.biz.id/api/qcwin?text=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        
        const response = await fetch(apiUrl);
        
        if (!response.ok) {
            throw new Error(`HTTP Error ${response.status}`);
        }
        
        const buffer = await response.arrayBuffer();
        const imageBuffer = Buffer.from(buffer);
        
        await satanic.sendMessage(m.chat, {
            image: imageBuffer,
            caption: `done \n📝 "${text}"`
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (e) {
        console.error('Error in qcwin case:', e);
        reply('❌ *Error:* ' + (e.message || 'Gagal membuat IQ Challenge'));
    }
}
break;
case 'iqc2': {
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    const isImage = /image/.test(mime);
    
    if (!text && !isImage) {
        return reply(`❌ Masukkan teks atau kirim/reply gambar!\n\nContoh:\n.iqc23 Halo\n.iqc23 (dengan gambar)`);
    }
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let userText = text || '';
        let imageUrl = '';
        
        if (isImage) {
            let media = await quoted.download();
            
            const form = new FormData();
            form.append('files[]', media, { filename: 'image.jpg' });
            const uploadRes = await axios.post('https://pone.rs/upload.php', form, {
                headers: {
                    ...form.getHeaders(),
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
                    'Referer': 'https://pone.rs/',
                    'Origin': 'https://pone.rs'
                },
                maxBodyLength: Infinity,
                maxContentLength: Infinity
            });
            
            if (!uploadRes.data?.success || !uploadRes.data?.files?.[0]?.url) {
                await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return reply(`❌ Gagal upload foto! Silahkan coba lagi.`);
            }
            
            imageUrl = uploadRes.data.files[0].url;
        }
        
        const now = new Date();
        const wibTime = now.toLocaleString('en-US', { 
            timeZone: 'Asia/Jakarta',
            hour12: false,
            hour: '2-digit',
            minute: '2-digit'
        });
        
        let apiUrl = `https://free-restapi.biz.id/api/iqc3?apikey=${global.sakey}`;
        if (userText) apiUrl += `&text=${encodeURIComponent(userText)}`;
        if (imageUrl) apiUrl += `&url=${encodeURIComponent(imageUrl)}`;
        apiUrl += `&time=${encodeURIComponent(wibTime)}`;
        
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        let caption = `*IQC3*\n\n`;
        caption += `⏰ Waktu: ${wibTime} WIB\n`;
        if (userText) caption += `📝 Teks: ${userText}\n`;
        if (imageUrl) caption += `🖼️ Gambar: Terdeteksi`;
        
        await satanic.sendMessage(m.chat, {
            image: Buffer.from(response.data),
            caption: caption
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error('Error IQC3:', err);
        reply('❌ Terjadi kesalahan saat menghubungi IQC3.');
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'fakedj': {
    try {
        if (!text) return reply('❌ *Masukkan teks!*\n\n📝 *Contoh:* .iqc kamu bodoh');
        
        await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        const apiUrl = `https://free-restapi.biz.id/api/fakedj?text=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        
        const response = await fetch(apiUrl);
        
        if (!response.ok) {
            throw new Error(`HTTP Error ${response.status}`);
        }
        
        const buffer = await response.arrayBuffer();
        const imageBuffer = Buffer.from(buffer);
        
        await satanic.sendMessage(m.chat, {
            image: imageBuffer,
            caption: `done \n📝 "${text}"`
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (e) {
        console.error('Error in  case:', e);
        reply('❌ *Error:* ' + (e.message || 'Gagal membuat '));
    }
}
break;
case 'qcwa': {
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    const isImage = /image/.test(mime);
    
    if (!text && !isImage) {
        return reply(`❌ Masukkan pesan atau kirim/reply gambar!\n\nContoh:\n.qcwa Halo\n.qcwa Halo|nama|tag|phone\n.qcwa (dengan gambar)`);
    }
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        let userText = text || '';
        let customUsername = '';
        let customTag = '';
        let customPhone = '';
        let imageUrl = '';
        
        if (userText && userText.includes('|')) {
            const parts = userText.split('|');
            userText = parts[0] || '';
            customUsername = parts[1] || '';
            customTag = parts[2] || '';
            customPhone = parts[3] || '';
        }
        
        const username = customUsername || m.pushName || 'User';
        const tag = customTag || username.toLowerCase().replace(/\s/g, '');
        let phone = customPhone || m.sender?.split('@')[0] || '628123456789';
        
        if (isImage) {
            const media = await quoted.download();
            
            const form = new FormData();
            form.append('files[]', media, { filename: 'image.jpg' });
            const uploadRes = await axios.post('https://pone.rs/upload.php', form, {
                headers: {
                    ...form.getHeaders(),
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
                    'Referer': 'https://pone.rs/',
                    'Origin': 'https://pone.rs'
                },
                maxBodyLength: Infinity,
                maxContentLength: Infinity
            });
            
            if (!uploadRes.data?.success || !uploadRes.data?.files?.[0]?.url) {
                await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return reply(`❌ Gagal upload gambar! Silahkan coba lagi.`);
            }
            
            imageUrl = uploadRes.data.files[0].url;
        }
        
        let avatarUrl = '';
        if (!customUsername && !customTag && !customPhone) {
            try {
                const ppUrl = await satanic.profilePictureUrl(m.sender, 'image');
                if (ppUrl) {
                    avatarUrl = ppUrl;
                }
            } catch (err) {
                console.log('Gagal mengambil foto profil:', err);
            }
        }
        
        let apiUrl = `https://free-restapi.biz.id/api/qcwa?apikey=${global.sakey}`;
        if (userText) apiUrl += `&text=${encodeURIComponent(userText)}`;
        apiUrl += `&username=${encodeURIComponent(username)}`;
        
        const phoneClean = phone.replace(/[^0-9]/g, '');
        apiUrl += `&phone=${encodeURIComponent(phoneClean)}`;
        
        apiUrl += `&tag=${encodeURIComponent(tag)}`;
        if (avatarUrl) apiUrl += `&ppUrl=${encodeURIComponent(avatarUrl)}`;
        if (imageUrl) apiUrl += `&imUrl=${encodeURIComponent(imageUrl)}`;
        
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        const formattedPhone = phoneClean.replace(/(\d{2})(\d{3})(\d{4})(\d{4})/, '+$1 $2-$3-$4');
        
        let caption = `✅ QR Code WhatsApp berhasil dibuat!\n\n👤 Username: ${username}\n📱 Phone: ${formattedPhone || phoneClean}\n🏷️ Tag: ${tag}`;
        if (userText) caption += `\n📝 Pesan: ${userText}`;
        if (imageUrl) caption += `\n🖼️ Gambar: Terdeteksi`;
        if (customUsername || customTag || customPhone) caption += `\n📌 Mode: Manual`;
        
        await satanic.sendMessage(m.chat, {
            image: Buffer.from(response.data),
            caption: caption
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (err) {
        console.error('Error QCWA:', err);
        reply('❌ Terjadi kesalahan saat membuat QR Code WhatsApp.');
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'igqc': {
    try {
        if (!text) return reply('❌ *Masukkan teks!*\n\n📝 *Contoh:* .iqc kamu bodoh');
        
        await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        const apiUrl = `https://free-restapi.biz.id/api/igqc?text=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        
        const response = await fetch(apiUrl);
        
        if (!response.ok) {
            throw new Error(`HTTP Error ${response.status}`);
        }
        
        const buffer = await response.arrayBuffer();
        const imageBuffer = Buffer.from(buffer);
        
        await satanic.sendMessage(m.chat, {
            image: imageBuffer,
            caption: `done \n📝 "${text}"`
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (e) {
        console.error('Error in iqc case:', e);
        reply('❌ *Error:* ' + (e.message || 'Gagal membuat IQ Challenge'));
    }
}
break;
case 'fakedj': {
    try {
        if (!text) return reply('❌ *Masukkan teks!*\n\n📝 *Contoh:* .iqc kamu bodoh');
        
        await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        const apiUrl = `https://free-restapi.biz.id/api/fakedj?text=${encodeURIComponent(text)}`;
        
        const response = await fetch(apiUrl);
        
        if (!response.ok) {
            throw new Error(`HTTP Error ${response.status}`);
        }
        
        const buffer = await response.arrayBuffer();
        const imageBuffer = Buffer.from(buffer);
        
        await satanic.sendMessage(m.chat, {
            image: imageBuffer,
            caption: `done \n📝 "${text}"`
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (e) {
        console.error('Error in  case:', e);
        reply('❌ *Error:* ' + (e.message || 'Gagal membuat '));
    }
}
break;
case 'fakedana': {
    try {
        if (!text) return reply('❌ *Masukkan teks!*\n\n📝 *Contoh:* .iqc kamu bodoh');
        
        await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        const apiUrl = `https://free-restapi.biz.id/fakedana?text=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        
        const response = await fetch(apiUrl);
        
        if (!response.ok) {
            throw new Error(`HTTP Error ${response.status}`);
        }
        
        const buffer = await response.arrayBuffer();
        const imageBuffer = Buffer.from(buffer);
        
        await satanic.sendMessage(m.chat, {
            image: imageBuffer,
            caption: `Done "${text}"`
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (e) {
        console.error('Error in iqc case:', e);
        reply('❌ *Error:* ' + (e.message || 'Gagal membuat IQ Challenge'));
    }
}
break;
case 'fakeovo': {
    try {
        if (!text) return reply('❌ *Masukkan teks!*\n\n📝 *Contoh:* .iqc kamu bodoh');
        
        await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        const apiUrl = `https://free-restapi.biz.id/fakeovo?saldo=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        
        const response = await fetch(apiUrl);
        
        if (!response.ok) {
            throw new Error(`HTTP Error ${response.status}`);
        }
        
        const buffer = await response.arrayBuffer();
        const imageBuffer = Buffer.from(buffer);
        
        await satanic.sendMessage(m.chat, {
            image: imageBuffer,
            caption: `Done "${text}"`
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (e) {
        console.error('Error in iqc case:', e);
        reply('❌ *Error:* ' + (e.message || 'Gagal membuat IQ Challenge'));
    }
}
break;
case 'fakegopay': {
    try {
        if (!text) return reply('❌ *Masukkan teks!*\n\n📝 *Contoh:* .iqc kamu bodoh');
        
        await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        const apiUrl = `https://free-restapi.biz.id/fakegopay?saldo=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        
        const response = await fetch(apiUrl);
        
        if (!response.ok) {
            throw new Error(`HTTP Error ${response.status}`);
        }
        
        const buffer = await response.arrayBuffer();
        const imageBuffer = Buffer.from(buffer);
        
        await satanic.sendMessage(m.chat, {
            image: imageBuffer,
            caption: `Done "${text}"`
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (e) {
        console.error('Error in iqc case:', e);
        reply('❌ *Error:* ' + (e.message || 'Gagal membuat IQ Challenge'));
    }
}
break;
case 'fakebangjago': {
if (!text || !text.includes(',')) {
        return reply(`❌ *Format salah!* Contoh:
${prefix + command} Ryuu, 1000000`)
    }
     await satanic.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })    
    let skia
    try {
        skia = require('skia-canvas')
    } catch (e) {
        return reply('❌ Module *skia-canvas* belum terinstall!\n\nKetik di panel:\n```npm install skia-canvas```')
    }

    const { Canvas, loadImage, FontLibrary } = skia

    async function ensureFile(url, file) {
        const dir = path.dirname(file)
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })

        if (!fs.existsSync(file)) {
            const res = await axios.get(url, { responseType: 'arraybuffer' })
            fs.writeFileSync(file, res.data)
        }
    }

    async function generateImage(saldo, greet) {
        const bgUrl = "https://raw.githubusercontent.com/uploader762/dat2/main/uploads/52e39f-1773064858080.jpg"
        const fontUrl = "https://raw.githubusercontent.com/uploader762/dat2/main/uploads/49bbd8-1773045557233.otf"
        const font2Url = "https://raw.githubusercontent.com/uploader762/dat1/main/uploads/203827-1773063086445.ttf"

        const font1 = "./media/fonts/ceraroundpro-medium.otf"
        const font2 = "./media/fonts/Roboto_Medium.ttf"

        await ensureFile(fontUrl, font1)
        await ensureFile(font2Url, font2)

        FontLibrary.use("CustomFont", font1)
        FontLibrary.use("GreetingFont", font2)

        const bgRes = await axios.get(bgUrl, { responseType: 'arraybuffer' })
        const bg = await loadImage(bgRes.data)

        const canvas = new Canvas(bg.width, bg.height)
        const ctx = canvas.getContext("2d")

        ctx.drawImage(bg, 0, 0, bg.width, bg.height)

        ctx.font = "125px CustomFont"
        ctx.fillStyle = "black"

        const numberWidth = ctx.measureText(saldo).width
        const numberX = 2470 - numberWidth

        ctx.fillText(saldo, numberX, 894)

        const rpWidth = ctx.measureText("Rp").width
        const rpX = numberX - rpWidth - 4

        ctx.fillText("Rp", rpX, 894)

        ctx.font = "93px GreetingFont"
        ctx.fillStyle = "gray"
        ctx.fillText(greet, 98, 86)

        return await canvas.toBuffer("image/png")
    }

    try {
        const args = text.split(',')
        const nama = args[0].trim()
        const saldoRaw = args[1].trim()

        const saldo = Number(saldoRaw.replace(/[^0-9]/g, ''))
            .toLocaleString('id-ID')

        const moment = require('moment-timezone')
        const h = parseInt(moment.tz('Asia/Jakarta').format('HH'))

        let waktu = 'Malam'
        if (h >= 4 && h < 11) waktu = 'Pagi'
        else if (h >= 11 && h < 15) waktu = 'Siang'
        else if (h >= 15 && h < 18) waktu = 'Sore'

        const buffer = await generateImage(
            saldo,
            `Selamat ${waktu}, ${nama}`
        )
        await satanic.sendMessage(m.chat, {
            image: buffer,
            caption: `🎨 *Fake Saldo bank Jago Berhasil Dibuat!*`
        }, { quoted: fkontak })

        await satanic.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        })

    } catch (err) {
        console.error(err)

        await satanic.sendMessage(m.chat, {
            react: { text: "❌", key: m.key }
        })

        reply('❌ Gagal membuat gambar.')
    }
}
break
case 'qc': {
    if (!text) return reply('teksnya')
    
    // Ambil pushName dari pengirim atau dari pesan yang di-quote
    const senderJid = m.quoted ? m.quoted.sender : m.sender;
    const username = m.quoted ? m.quoted.pushName : m.pushName || senderJid.split('@')[0];
    
    // Ambil avatar
    const avatar = await satanic.profilePictureUrl(senderJid, "image")
        .catch(() => 'https://8030.us.kg/file/P2LpaOHxWlJt.jpg');
    
    const qchat = `https://free-restapi.biz.id/api/qc?text=${encodeURIComponent(text)}&name=${encodeURIComponent(username)}&ppurl=${encodeURIComponent(avatar)}&apikey=${global.sakey}`;
    const response = await axios.get(qchat, { responseType: 'arraybuffer' });
    await satanic.sendImageAsSticker(m.chat, response.data, m, { packname: global.packname });
}
break;
case 'jadiroblox':
case 'jadipunk':
case 'jadidpr':
case 'jadisad': {
    if (!isPrem) return reply('Anda bukan pengguna premium. Update premium untuk membuka fitur ini.');
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || '';

    if (!/^image\//.test(mime))
        return reply('❌ reply atau kirim gambar!');

    try {
        await satanic.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
        reply(mess.wait);

        let mediaPath = await satanic.downloadAndSaveMediaMessage(q);
        if (!mediaPath) {
            return reply('❌ Gagal download gambar!');
        }

        let uploadResult = await UploadFileUgu(mediaPath);
        let imageUrl = uploadResult.url || uploadResult;
        
        if (!imageUrl) {
            return reply('❌ Gagal upload gambar!');
        }

        const PROMPT = {
            toroblox: `Transform the person in the image into a Roblox-style 3D character. Preserve the original face shape, facial features, skin tone, hairstyle, and clothing exactly as in the original image. Do not change outfit design, colors, or accessories. Only adapt the person into Roblox proportions and style. Clean lighting, studio background, high quality, sharp focus.`,
            topunk: `Create a realistic gangster-style scene. Preserve the original face shape, facial features, skin tone, hairstyle, and clothing exactly as in the original image. Do not change the outfit or add new clothing. Add realistic tattoos on visible skin only. Add gritty urban atmosphere, dark alley background, cinematic lighting. Intimidating mood, ultra realistic photography.`,
            todpr: `Create a realistic scene of the person sitting on an Indonesian DPR parliament chair. Preserve the original face shape, facial features, skin tone, hairstyle, and clothing exactly as in the original image. Do not change outfit or appearance. Formal indoor environment, realistic lighting, professional photography.`,
            tosad: `Create a realistic sad portrait. Preserve the original face shape, facial features, skin tone, hairstyle, and clothing exactly as in the original image. Do not change outfit or identity. Add emotional sadness through facial expression, lighting, and atmosphere only. Soft dramatic lighting, cinematic depth of field, ultra realistic.`
        };

        const apiUrl = `https://free-restapi.biz.id/api/nanobanana?url=${encodeURIComponent(imageUrl)}&prompt=${encodeURIComponent(PROMPT[command])}&apikey=${global.sakey}`;
        
        const response = await axios.get(apiUrl, { 
            responseType: 'arraybuffer',
            timeout: 60000
        });
        
        const resultBuffer = Buffer.from(response.data);

        await satanic.sendMessage(
            m.chat,
            { image: resultBuffer, caption: mess.done },
            { quoted: m }
        );

        try {
            if (fs.existsSync(mediaPath)) {
                fs.unlinkSync(mediaPath);
            }
        } catch (e) {}

    } catch (e) {
        console.error('Error:', e);
        reply('❌ Gagal memproses gambar!');
        await satanic.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    }
    break;
}
 
         

case 'jadimanhwa':
case 'jadidonghua':
case 'jadimanga': {
    if (!isPrem) return reply('you are not premium, Updated premium open this feature');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .nanobananapro + prompt');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const apiUrl = `https://free-restapi.biz.id/api/${command}?url=${encodeURIComponent(ImageUrlaja)}&prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil!'
        }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. silahkan update premium untuk menggunakan fitur ini');
    }
}
break;

case 'totalfitur':
reply(`total fitur : ${satanFitur()}`)
break

case 'remowm':
case 'removewm':
case 'rwm': {
    // ========== FUNGSI INTERNAL ==========
    const axios = require('axios');
    const fs = require('fs');
    const path = require('path');

    const UA = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36";
    const ORIGIN = "https://ezremove.ai";

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    function getMime(filePath) {
        const ext = path.extname(filePath).toLowerCase();
        if (ext === ".png") return "image/png";
        if (ext === ".webp") return "image/webp";
        if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
        return "application/octet-stream";
    }

    async function removeWatermark(buffer, filename) {
        const mime = getMime(filename);
        const boundary = `----FormBoundary${Math.random().toString(36).slice(2)}`;

        const body = Buffer.concat([
            Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="image_file"; filename="${filename}"\r\nContent-Type: ${mime}\r\n\r\n`),
            buffer,
            Buffer.from(`\r\n--${boundary}--\r\n`)
        ]);

        const create = await axios.post(
            "https://api.ezremove.ai/api/ez-remove/watermark-remove/create-job",
            body,
            {
                headers: {
                    "User-Agent": UA,
                    "Accept": "application/json, text/plain, */*",
                    "Origin": ORIGIN,
                    "Referer": `${ORIGIN}/`,
                    "product-serial": `sr-${Date.now()}`,
                    "Content-Type": `multipart/form-data; boundary=${boundary}`,
                    "Content-Length": body.length
                },
                timeout: 30000,
                validateStatus: () => true,
                maxBodyLength: Infinity,
                maxContentLength: Infinity
            }
        );

        if (create.status < 200 || create.status >= 300) {
            throw { code: create.status };
        }

        const jobId = create.data?.result?.job_id;
        if (!jobId) {
            throw { code: create.status };
        }

        for (let i = 0; i < 30; i++) {
            await sleep(2000);

            const check = await axios.get(
                `https://api.ezremove.ai/api/ez-remove/watermark-remove/get-job/${jobId}`,
                {
                    headers: {
                        "User-Agent": UA,
                        "Accept": "application/json, text/plain, */*",
                        "Origin": ORIGIN,
                        "Referer": `${ORIGIN}/`,
                        "product-serial": `sr-${Date.now()}`
                    },
                    timeout: 15000,
                    validateStatus: () => true
                }
            );

            if (check.status < 200 || check.status >= 300) {
                throw { code: check.status };
            }

            const resultUrl = check.data?.result?.output?.[0];

            if (check.data?.code === 100000 && resultUrl) {
                return resultUrl;
            }

            if (check.data?.code !== 300001) {
                throw { code: check.status };
            }
        }

        throw { code: 202 };
    }

    // ========== MAIN ==========
    // Cek apakah ada gambar
    const quoted = m.quoted || m;
    const mimeType = (quoted.msg || quoted).mimetype || '';
    const isImage = /image\/(jpe?g|png|webp)/i.test(mimeType);

    if (!isImage) {
        return reply(`*🖼️ REMOVE WATERMARK*

Cara pakai:
Reply gambar .remowm

Contoh:
Reply gambar dengan caption .remowm

*Fitur:*
✅ Menghapus watermark dari gambar
✅ Support JPG, PNG, WEBP
✅ Hasil berkualitas tinggi

*Note:* Proses membutuhkan waktu 30-60 detik`);
    }

    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        // Download gambar
        let buffer;
        let filename = 'image.jpg';
        try {
            buffer = await quoted.download();
            // Ekstensi dari mime
            const ext = mimeType.split('/')[1] || 'jpg';
            filename = `image.${ext}`;
        } catch (e) {
            const mediaPath = await satanic.downloadAndSaveMediaMessage(quoted);
            buffer = fs.readFileSync(mediaPath);
            filename = path.basename(mediaPath);
            fs.unlinkSync(mediaPath);
        }

        if (!buffer) throw new Error('Gagal mengunduh gambar');

        // Kirim pesan proses
        await satanic.sendMessage(m.chat, {
            text: '⏳ *Sedang menghapus watermark...*\nMohon tunggu 30-60 detik.'
        }, { quoted: m });

        // Proses remove watermark
        const resultUrl = await removeWatermark(buffer, filename);

        // Download hasil
        const imageRes = await axios.get(resultUrl, {
            responseType: 'arraybuffer'
        });

        await satanic.sendMessage(m.chat, {
            image: Buffer.from(imageRes.data),
            caption: `✅ *Watermark berhasil dihapus!*\n\n📌 *Info:* Hasil tanpa watermark siap digunakan.`
        }, { quoted: m });

        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (err) {
        console.error('[REMOWM]', err);
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        
        let errorMsg = 'Coba lagi nanti';
        if (err.code === 202) {
            errorMsg = 'Timeout! Server terlalu lama merespon.';
        } else if (err.code === 429) {
            errorMsg = 'Terlalu banyak request! Tunggu beberapa saat.';
        } else if (err.code) {
            errorMsg = `Error ${err.code}`;
        }
        
        reply(`❌ Gagal menghapus watermark: ${errorMsg}`);
    }
}
break;
case 'img2img': {
    if (!isPrem) return reply('you are not premium, Updated premium open this feature');
    if (!text) return reply('input prompt');
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .img2img + prompt');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        const apiUrl = `https://free-restapi.biz.id/api/img2img?image_url=${encodeURIComponent(ImageUrlaja)}&prompt=${encodeURIComponent(text)}&apikey=${global.sakey}`;
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { 
            image: response.data,
            caption: '✨ Gambar berhasil!'
        }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('Gagal mengupgrade gambar. Coba lagi nanti. silahkan update premium untuk menggunakan fitur ini');
    }
}
break;
case 'talkphoto':
case 'talkingphoto': {
    if (!isPrem) return reply('you are not premium, Updated premium open this feature');
    let argsFull = args.join(' ');
    let voice = 'woman1';
    let voiceMatch = argsFull.match(/\|\s*(woman1|woman2|man1|man2)\s*$/i);
    if (voiceMatch) {
        voice = voiceMatch[1].toLowerCase();
        argsFull = argsFull.replace(/\|\s*(woman1|woman2|man1|man2)\s*$/i, '').trim();
    }
    let prompt = argsFull.replace(/^\.talkingphoto\s*/i, '').trim();
    if (!prompt) return reply(`*📢 TALKING PHOTO*\n\nContoh:\n.talkingphoto aku adalah aqua ai asisten satanic haxor yang akan membantu anda | woman1\n.talkingphoto aku adalah aquai\n\n*List Voice:*\n👩 woman1 (default)\n👩 woman2\n👨 man1\n👨 man2\n\n*Note:* Gunakan format *| voice* di akhir kalimat`);
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';
    if (!/image/.test(mime)) return reply('Kirim/reply gambar dengan caption .talkingphoto + teks');
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
        let mee = await satanic.downloadAndSaveMediaMessage(quoted);
        let mem = await UploadFileUgu(mee);
          let ImageUrlaja = mem.url || mem;
        let apiUrl = `https://free-restapi.biz.id/api/talkingphoto?url=${encodeURIComponent(ImageUrlaja)}&text=${encodeURIComponent(prompt)}&voice=${voice}&apikey=${global.sakey}`;
        let response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        await satanic.sendMessage(m.chat, { 
            video: response.data, 
            caption: `✅ Berhasil!\n📝 Teks: ${prompt.substring(0, 50)}${prompt.length > 50 ? '...' : ''}\n🎤 Voice: ${voice}` 
        }, { quoted: fkontak });
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        reply('❌ Gagal membuat talking photo! Coba lagi nanti.');
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'rolling': {
    if (!text) return reply(`🎁 *ROLLING GIVEAWAY*\n\n.rolling Andi, Budi, Caca | Hadiah: Saldo 100k`);
    
    let peserta = [];
    let hadiah = 'Giveaway';
    
    if (text.includes('|')) {
        let [p, h] = text.split('|');
        hadiah = h.replace('Hadiah:', '').trim();
        peserta = p.includes(',') ? p.split(',').map(v=>v.trim()) : p.split(' ').map(v=>v.trim());
    } else {
        peserta = text.includes(',') ? text.split(',').map(v=>v.trim()) : text.split(' ').map(v=>v.trim());
    }
    
    peserta = peserta.filter(p => p);
    if (peserta.length < 2) return reply('Minimal 2 peserta');
    
    await satanic.sendMessage(m.chat, { react: { text: '🎲', key: m.key } });
    
    const winner = peserta[Math.floor(Math.random() * peserta.length)];
    const totalRolls = 30;
    
    let msg = await satanic.sendMessage(m.chat, { text: `🎲 *ROLLING GIVEAWAY* 🎲\n\n━━━━━━━━━━━━━━━━━━━━\n\n👉 *${peserta[0]}* 👈\n\n━━━━━━━━━━━━━━━━━━━━\n\n⚡ Memulai...` }, { quoted: fkontak });
    
    for (let i = 0; i <= totalRolls; i++) {
        let randomName = peserta[Math.floor(Math.random() * peserta.length)];
        
        let delay, speedText, speedIcon;
        
        if (i < 8) {
            delay = 70;
            speedText = 'SUPER CEPAT';
            speedIcon = '⚡⚡⚡';
        } else if (i < 15) {
            delay = 130;
            speedText = 'CEPAT';
            speedIcon = '⚡⚡';
        } else if (i < 21) {
            delay = 220;
            speedText = 'SEDANG';
            speedIcon = '⚡🐢';
        } else if (i < 26) {
            delay = 380;
            speedText = 'LAMBAT';
            speedIcon = '🐢🐢';
        } else {
            delay = 600;
            speedText = 'HAMPIR BERHENTI';
            speedIcon = '🎯🎯';
        }
        
        let persen = Math.floor((i / totalRolls) * 100);
        let barLength = Math.floor(persen / 5);
        let progressBar = '█'.repeat(barLength) + '░'.repeat(20 - barLength);
        
        let rollingText = `🎲 *ROLLING GIVEAWAY* 🎲\n\n━━━━━━━━━━━━━━━━━━━━\n\n👉 *${randomName}* 👈\n\n━━━━━━━━━━━━━━━━━━━━\n\n📊 ${progressBar} ${persen}%\n${speedIcon} ${speedText}`;
        
        await satanic.sendMessage(m.chat, { text: rollingText, edit: msg.key });
        await new Promise(resolve => setTimeout(resolve, delay));
    }
    
    let resultText = `🏆 *PEMENANG GIVEAWAY* 🏆\n\n━━━━━━━━━━━━━━━━━━━━\n\n🎁 ${hadiah}\n\n👑 *${winner}* 👑\n\n━━━━━━━━━━━━━━━━━━━━\n\n🎉 SELAMAT! 🎉`;
    
    await satanic.sendMessage(m.chat, { text: resultText, edit: msg.key });
    await satanic.sendMessage(m.chat, { react: { text: '🏆', key: m.key } });
    
    let tagWinner = winner.replace(/[^0-9]/g, '');
    if (tagWinner.length > 5 && tagWinner.length < 15) {
        await satanic.sendMessage(m.chat, {
            text: `🎉 Selamat @${tagWinner}! 🎉\n\nKamu memenangkan ${hadiah}`,
            mentions: [tagWinner + '@s.whatsapp.net']
        }, { quoted: fkontak });
    }
}
break;
case 'investasi':
case 'trading': {
    if (!global.tradingSaldo) global.tradingSaldo = {};
    if (!global.tradingSaldo[m.sender]) global.tradingSaldo[m.sender] = 1000000;
    
    // Inisialisasi statistik user
    if (!global.tradingStat) global.tradingStat = {};
    if (!global.tradingStat[m.sender]) {
        global.tradingStat[m.sender] = { win: 0, loss: 0, total: 0, profitTotal: 0 };
    }
    
    // Inisialisasi posisi aktif user
    if (!global.tradingPosition) global.tradingPosition = {};
    
    if (!text) return reply(`╔══════════════════════════════════════════════════════════════╗
║                      📊 *TRADING PRO* 📊                       ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  💰 *MODAL AWAL: Rp 1.000.000*                              ║
║                                                              ║
║  📌 *PERINTAH LENGKAP:*                                     ║
║  ────────────────────────────────────────────────────────── ║
║  .trading analisa     → Analisa pasar + Fibonacci           ║
║  .trading buy 100rb   → BUY dengan TP/SL otomatis           ║
║  .trading sell 50rb   → SELL dengan TP/SL otomatis          ║
║  .trading position    → Cek posisi aktif                    ║
║  .trading close       → Tutup posisi (ambil profit/loss)    ║
║  .trading saldo       → Cek saldo & profit                  ║
║  .trading stat        → Lihat winrate & performa            ║
║  .trading claim       → Claim modal Rp 1.000.000            ║
║  .trading reset       → Reset statistik                     ║
║                                                              ║
║  📈 *INSTRUMEN:* BTC, ETH, SOL, BNB, XRP                    ║
║  📊 *INDIKATOR:* RSI, MACD, MA, FIBONACCI, SUPPORT/RESISTANCE║
║  🛑 *RISK MANAGEMENT:* TP (Take Profit) & SL (Stop Loss)     ║
║                                                              ║
║  🎯 *CARA MAIN:*                                            ║
║  1️⃣ .trading analisa → Lihat kondisi pasar + level Fibonacci║
║  2️⃣ Tentukan entry berdasarkan analisa                     ║
║  3️⃣ .trading buy/sell [jumlah] → Eksekusi dengan TP/SL     ║
║  4️⃣ Pantau posisi dengan .trading position                 ║
║  5️⃣ .trading close → Tutup posisi ambil profit/loss        ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝`);
    
    const args = text.split(' ');
    const cmd = args[0].toLowerCase();
    
    const formatRp = (angka) => {
        return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(angka);
    };
    
    // ========== RESET STATISTIK ==========
    if (cmd === 'reset') {
        global.tradingStat[m.sender] = { win: 0, loss: 0, total: 0, profitTotal: 0 };
        return reply(`✅ *STATISTIK TELAH DIRESET!*\n\n📊 Mulai trading baru dengan catatan bersih!`);
    }
    
    // ========== CEK SALDO ==========
    if (cmd === 'saldo') {
        let statWin = global.tradingStat[m.sender].win;
        let statLoss = global.tradingStat[m.sender].loss;
        let winrate = statWin + statLoss > 0 ? Math.floor((statWin / (statWin + statLoss)) * 100) : 0;
        let profitTotal = global.tradingStat[m.sender].profitTotal;
        let profitStatus = profitTotal >= 0 ? '🟢' : '🔴';
        
        let profitChart = '';
        let profitPercent = Math.min(Math.abs(Math.floor(profitTotal / 100000)), 20);
        if (profitTotal >= 0) {
            profitChart = '🟢' + '█'.repeat(profitPercent) + '░'.repeat(20 - profitPercent);
        } else {
            profitChart = '🔴' + '█'.repeat(profitPercent) + '░'.repeat(20 - profitPercent);
        }
        
        // Cek posisi aktif
        let posisiAktif = global.tradingPosition[m.sender] ? true : false;
        let posisiText = posisiAktif ? `🟡 Ada posisi aktif! Ketik .trading position` : `🟢 Tidak ada posisi aktif`;
        
        return reply(`╔══════════════════════════════════════════════════════════════╗
║                         💰 *SALDO TRADING* 💰                       ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  💵 *SALDO ANDA:*                                            ║
║  ${formatRp(global.tradingSaldo[m.sender])}                               ║
║                                                              ║
║  📊 *PERFORMA TRADING:*                                      ║
║  ────────────────────────────────────────────────────────── ║
║  🏆 WIN: ${statWin} kali                                          ║
║  💀 LOSS: ${statLoss} kali                                         ║
║  📈 WINRATE: ${winrate}%                                            ║
║  ${profitStatus} PROFIT TOTAL: ${formatRp(profitTotal)}                         ║
║  ${profitChart}                                              ║
║                                                              ║
║  📍 *STATUS POSISI:* ${posisiText}                           ║
║                                                              ║
║  💡 *TIPS:*                                                  ║
║  Selalu analisa pasar dan gunakan TP/SL!                    ║
║  Ketik .trading analisa                                     ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝`);
    }
    
    // ========== CEK POSISI AKTIF ==========
    if (cmd === 'position') {
        let posisi = global.tradingPosition[m.sender];
        if (!posisi) {
            return reply(`📭 *TIDAK ADA POSISI AKTIF*\n\n💡 Mulai trading dengan .trading buy/sell [jumlah]`);
        }
        
        let hargaSekarang = posisi.hargaSekarang || posisi.entryPrice;
        let perubahan = ((hargaSekarang - posisi.entryPrice) / posisi.entryPrice) * 100;
        let profitLoss = (hargaSekarang - posisi.entryPrice) * posisi.jumlah / posisi.entryPrice;
        
        let statusIcon = profitLoss >= 0 ? '🟢' : '🔴';
        let statusText = profitLoss >= 0 ? 'PROFIT' : 'LOSS';
        
        // Hitung jarak ke TP/SL
        let jarakTP = posisi.tp - hargaSekarang;
        let jarakSL = hargaSekarang - posisi.sl;
        let tpPersen = ((posisi.tp - hargaSekarang) / hargaSekarang) * 100;
        let slPersen = ((hargaSekarang - posisi.sl) / hargaSekarang) * 100;
        
        return reply(`╔══════════════════════════════════════════════════════════════╗
║                      📍 *POSISI AKTIF* 📍                       ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  🪙 ASET: ${posisi.asset.emoji} ${posisi.asset.nama}                                 ║
║  🎯 POSISI: ${posisi.type.toUpperCase()}                                      ║
║  💰 JUMLAH: ${formatRp(posisi.jumlah)}                                   ║
║                                                              ║
║  📊 *HARGA:*                                                ║
║  ▸ Entry: ${formatRp(posisi.entryPrice)}                              ║
║  ▸ Current: ${formatRp(hargaSekarang)}                              ║
║                                                              ║
║  🎯 *TAKE PROFIT:* ${formatRp(posisi.tp)} (${tpPersen > 0 ? '+' : ''}${tpPersen.toFixed(2)}%)            ║
║  🛑 *STOP LOSS:* ${formatRp(posisi.sl)} (${slPersen > 0 ? '+' : ''}${slPersen.toFixed(2)}%)             ║
║                                                              ║
║  💰 *${statusIcon} ${statusText}:* ${formatRp(Math.abs(profitLoss))} (${perubahan > 0 ? '+' : ''}${perubahan.toFixed(2)}%)          ║
║                                                              ║
║  📌 *CARA TUTUP POSISI:*                                     ║
║  Ketik .trading close                                       ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝`);
    }
    
    // ========== TUTUP POSISI ==========
    if (cmd === 'close') {
        let posisi = global.tradingPosition[m.sender];
        if (!posisi) {
            return reply(`❌ *TIDAK ADA POSISI AKTIF!*\n\n💡 Mulai trading dengan .trading buy/sell [jumlah]`);
        }
        
        let hargaSekarang = posisi.hargaSekarang || posisi.entryPrice;
        let profitLoss = (hargaSekarang - posisi.entryPrice) * posisi.jumlah / posisi.entryPrice;
        let perubahan = ((hargaSekarang - posisi.entryPrice) / posisi.entryPrice) * 100;
        let menang = profitLoss > 0;
        
        // Update saldo
        global.tradingSaldo[m.sender] += profitLoss;
        global.tradingStat[m.sender].profitTotal += profitLoss;
        
        if (menang) {
            global.tradingStat[m.sender].win++;
        } else {
            global.tradingStat[m.sender].loss++;
        }
        global.tradingStat[m.sender].total++;
        
        let winrateBaru = Math.floor((global.tradingStat[m.sender].win / global.tradingStat[m.sender].total) * 100);
        
        // Hapus posisi
        delete global.tradingPosition[m.sender];
        
        let resultIcon = menang ? '✅✅✅' : '❌❌❌';
        let resultText = menang ? 'TAKE PROFIT!' : 'STOP LOSS!';
        
        return reply(`╔══════════════════════════════════════════════════════════════╗
║                    ${resultIcon} *${resultText}* ${resultIcon}                     ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  🪙 ${posisi.asset.emoji} ${posisi.asset.nama}                                        ║
║  🎯 POSISI: ${posisi.type.toUpperCase()}                                      ║
║                                                              ║
║  📊 *HASIL CLOSE:*                                          ║
║  ▸ Entry: ${formatRp(posisi.entryPrice)}                              ║
║  ▸ Close: ${formatRp(hargaSekarang)}                               ║
║  ▸ Perubahan: ${perubahan > 0 ? '+' : ''}${perubahan.toFixed(2)}%                            ║
║                                                              ║
║  💰 ${menang ? 'PROFIT' : 'LOSS'}: ${formatRp(Math.abs(profitLoss))}                                ║
║                                                              ║
║  ────────────────────────────────────────────────────────── ║
║  💵 SALDO AKHIR: ${formatRp(global.tradingSaldo[m.sender])}                       ║
║  📈 WINRATE: ${winrateBaru}%                                            ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝`);
    }
    
    // ========== CLAIM SALDO ==========
    if (cmd === 'claim') {
        global.tradingSaldo[m.sender] = 1000000;
        return reply(`✅ *CLAIM BERHASIL!*\n\n💰 Modal awal: ${formatRp(1000000)}\n\n📌 Jangan lupa analisa pasar sebelum trading!`);
    }
    
    // ========== ANALISA PASAR LENGKAP DENGAN FIBONACCI ==========
    if (cmd === 'analisa') {
        const assetList = [
            { nama: 'BTC', emoji: '₿', harga: 685000000, perubahan24h: 0 },
            { nama: 'ETH', emoji: '⟠', harga: 48500000, perubahan24h: 0 },
            { nama: 'SOL', emoji: '◎', harga: 1850000, perubahan24h: 0 },
            { nama: 'BNB', emoji: '🔶', harga: 5850000, perubahan24h: 0 },
            { nama: 'XRP', emoji: '💱', harga: 8500, perubahan24h: 0 }
        ];
        
        const asset = assetList[Math.floor(Math.random() * assetList.length)];
        const perubahan24h = (Math.random() * 12) - 6;
        asset.perubahan24h = parseFloat(perubahan24h.toFixed(2));
        
        global.analisaSession = global.analisaSession || {};
        global.analisaSession[m.sender] = { asset: asset, timestamp: Date.now() };
        
        await satanic.sendMessage(m.chat, { react: { text: '📊', key: m.key } });
        
        let msg = await satanic.sendMessage(m.chat, { 
            text: `╔══════════════════════════════════════════════════════════════╗
║                    📈 *ANALISA PASAR PRO* 📉                    ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  🪙 ASET: ${asset.emoji} ${asset.nama} / USDT                                ║
║  💰 HARGA: ${formatRp(asset.harga)}                                   ║
║  📊 24H CHANGE: ${asset.perubahan24h > 0 ? '+' : ''}${asset.perubahan24h}%                              ║
║                                                              ║
║  🔍 MENGUMPULKAN DATA PASAR...                               ║
║  ⏰ 5 detik                                                  ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝`
        }, { quoted: fkontak });
        
        // Loading animasi
        for (let i = 1; i <= 4; i++) {
            await satanic.sendMessage(m.chat, { 
                text: `╔══════════════════════════════════════════════════════════════╗
║                    📈 *ANALISA PASAR PRO* 📉                    ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  🪙 ${asset.emoji} ${asset.nama}                                            ║
║  📡 ${i*25}% Memuat data...                                       ║
║  ${'█'.repeat(i)}${'░'.repeat(4-i)}                                                      ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝`, 
                edit: msg.key 
            });
            await new Promise(r => setTimeout(r, 1000));
        }
        
        // ========== INDIKATOR TEKNIKAL ==========
        
        // 1. TREND
        let trendArah = '';
        let trendIcon = '';
        if (asset.perubahan24h > 3) {
            trendArah = 'BULLISH KUAT';
            trendIcon = '📈🟢🟢🟢';
        } else if (asset.perubahan24h > 0) {
            trendArah = 'BULLISH LEMAH';
            trendIcon = '📈🟢🟢';
        } else if (asset.perubahan24h > -3) {
            trendArah = 'SIDEWAYS';
            trendIcon = '📊🟡';
        } else {
            trendArah = 'BEARISH';
            trendIcon = '📉🔴🔴';
        }
        
        // 2. RSI
        let rsi = Math.floor(Math.random() * 100);
        let rsiStatus = rsi > 70 ? 'OVERBOUGHT 🔴' : (rsi < 30 ? 'OVERSOLD 🟢' : 'NEUTRAL ⚪');
        
        // 3. MACD
        let histogram = (Math.random() * 2 - 1).toFixed(2);
        let macdSignal = histogram > 0 ? 'BULLISH 🟢' : 'BEARISH 🔴';
        
        // 4. MOVING AVERAGE
        let maPosition = Math.random() > 0.5 ? 'GOLDEN CROSS 🟢' : 'DEATH CROSS 🔴';
        
        // 5. VOLUME
        let volume = Math.random() > 0.6 ? 'TINGGI 🔥' : (Math.random() > 0.3 ? 'SEDANG 📊' : 'RENDAH 💤');
        
        // ========== FIBONACCI RETRACEMENT LEVELS ==========
        let high = asset.harga * (1 + (Math.random() * 0.1));
        let low = asset.harga * (1 - (Math.random() * 0.1));
        let range = high - low;
        
        let fibLevels = {
            '0.236': low + range * 0.236,
            '0.382': low + range * 0.382,
            '0.5': low + range * 0.5,
            '0.618': low + range * 0.618,
            '0.786': low + range * 0.786
        };
        
        // ========== SUPPORT & RESISTANCE ==========
        let support = Math.floor(asset.harga * 0.95);
        let resistance = Math.floor(asset.harga * 1.05);
        let support2 = Math.floor(asset.harga * 0.92);
        let resistance2 = Math.floor(asset.harga * 1.08);
        
        // ========== REKOMENDASI ==========
        let rekomendasi = '';
        let rekomendasiIcon = '';
        let confidence = 0;
        
        if (rsi < 35 && asset.perubahan24h > 0) {
            rekomendasi = 'BUY';
            rekomendasiIcon = '🟢';
            confidence = 80;
        } else if (rsi > 65 && asset.perubahan24h < 0) {
            rekomendasi = 'SELL';
            rekomendasiIcon = '🔴';
            confidence = 80;
        } else if (asset.perubahan24h > 2) {
            rekomendasi = 'BUY';
            rekomendasiIcon = '🟢';
            confidence = 65;
        } else if (asset.perubahan24h < -2) {
            rekomendasi = 'SELL';
            rekomendasiIcon = '🔴';
            confidence = 65;
        } else {
            rekomendasi = 'WAIT';
            rekomendasiIcon = '⚪';
            confidence = 50;
        }
        
        // ========== LEVEL ENTRY BERDASARKAN FIBONACCI ==========
        let entryBuy = Math.floor(fibLevels['0.382']);
        let entrySell = Math.floor(resistance);
        let tpBuy = Math.floor(resistance);
        let tpSell = Math.floor(support);
        let slBuy = Math.floor(support);
        let slSell = Math.floor(resistance2);
        
        let analisaText = `╔══════════════════════════════════════════════════════════════╗
║                 📈 *HASIL ANALISA PASAR* 📉                 ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  🪙 ${asset.emoji} ${asset.nama} / USDT                                    ║
║  💰 HARGA: ${formatRp(asset.harga)}                                   ║
║  📊 24H: ${asset.perubahan24h > 0 ? '+' : ''}${asset.perubahan24h}% | TREND: ${trendArah} ${trendIcon}        ║
║                                                              ║
║  ────────────────────────────────────────────────────────── ║
║  📊 *INDIKATOR TEKNIKAL:*                                   ║
║  ▸ RSI: ${rsi} (${rsiStatus})                                        ║
║  ▸ MACD: ${macdSignal} (Histogram: ${histogram})                            ║
║  ▸ MA: ${maPosition}                                            ║
║  ▸ VOLUME: ${volume}                                             ║
║                                                              ║
║  ────────────────────────────────────────────────────────── ║
║  📐 *FIBONACCI RETRACEMENT LEVELS:*                         ║
║  ▸ HIGH: ${formatRp(high)}                                          ║
║  ▸ LOW: ${formatRp(low)}                                           ║
║                                                              ║
║  📍 *FIB LEVELS:*                                            ║
║  ▸ 0.236 → ${formatRp(fibLevels['0.236'])}                           ║
║  ▸ 0.382 → ${formatRp(fibLevels['0.382'])} ⭐ SUPPORT ZONE          ║
║  ▸ 0.500 → ${formatRp(fibLevels['0.5'])}                             ║
║  ▸ 0.618 → ${formatRp(fibLevels['0.618'])} ⭐ RESISTANCE ZONE       ║
║  ▸ 0.786 → ${formatRp(fibLevels['0.786'])}                           ║
║                                                              ║
║  ────────────────────────────────────────────────────────── ║
║  🛡️ *SUPPORT & RESISTANCE:*                                 ║
║  ▸ S1: ${formatRp(support)} | S2: ${formatRp(support2)}                   ║
║  ▸ R1: ${formatRp(resistance)} | R2: ${formatRp(resistance2)}                ║
║                                                              ║
║  ────────────────────────────────────────────────────────── ║
║  💡 *REKOMENDASI:* ${rekomendasiIcon} ${rekomendasi} (Confidence: ${confidence}%)                 ║
║                                                              ║
║  🎯 *LEVEL ENTRY (BUY):* ${formatRp(entryBuy)}                            ║
║  🎯 *LEVEL ENTRY (SELL):* ${formatRp(entrySell)}                           ║
║                                                              ║
║  ⚠️ *RISK MANAGEMENT:*                                      ║
║  Gunakan TP (Take Profit) dan SL (Stop Loss)!              ║
║  Rasio Risk:Reward minimal 1:2                             ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝`;
        
        await satanic.sendMessage(m.chat, { text: analisaText, edit: msg.key });
        return;
    }
    
    // ========== CEK STATISTIK LENGKAP ==========
    if (cmd === 'stat') {
        let statWin = global.tradingStat[m.sender].win;
        let statLoss = global.tradingStat[m.sender].loss;
        let total = statWin + statLoss;
        let winrate = total > 0 ? Math.floor((statWin / total) * 100) : 0;
        let profitTotal = global.tradingStat[m.sender].profitTotal;
        
        let barWin = '█'.repeat(Math.min(Math.floor(statWin / 2), 15)) + '░'.repeat(Math.max(0, 15 - Math.floor(statWin / 2)));
        let barLoss = '█'.repeat(Math.min(Math.floor(statLoss / 2), 15)) + '░'.repeat(Math.max(0, 15 - Math.floor(statLoss / 2)));
        
        let rating = '';
        if (winrate >= 70) rating = '⭐ LEGENDARY TRADER ⭐';
        else if (winrate >= 55) rating = '🔥 PROFESSIONAL TRADER 🔥';
        else if (winrate >= 45) rating = '📊 AVERAGE TRADER 📊';
        else rating = '📚 NEED MORE PRACTICE 📚';
        
        return reply(`╔══════════════════════════════════════════════════════════════╗
║                   📈 *STATISTIK TRADING* 📉                   ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  🏆 *KEMENANGAN:* ${statWin} kali                                    ║
║  [${barWin}]                                            ║
║                                                              ║
║  💀 *KEKALAHAN:* ${statLoss} kali                                   ║
║  [${barLoss}]                                            ║
║                                                              ║
║  📊 *TOTAL TRADING:* ${total} kali                                  ║
║  📈 *WINRATE:* ${winrate}%                                           ║
║  💰 *PROFIT TOTAL:* ${formatRp(profitTotal)}                               ║
║                                                              ║
║  🎖️ *RATING:* ${rating}                                     ║
║                                                              ║
║  💡 *SARAN:*                                                 ║
║  ${winrate < 50 ? 'Perbanyak analisa dan gunakan Fibonacci levels!' : 'Pertahankan konsistensi trading Anda!'}         ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝`);
    }
    
    // ========== BUY/SELL DENGAN TP/SL ==========
    if (!['buy', 'sell'].includes(cmd)) {
        return reply(`❌ *PERINTAH TIDAK DIKENAL!*\n\n📌 *Perintah yang tersedia:*\n.trading analisa\n.trading buy/sell [jumlah]\n.trading position\n.trading close\n.trading saldo\n.trading stat\n.trading claim`);
    }
    
    // Cek apakah sudah analisa dulu
    if (!global.analisaSession || !global.analisaSession[m.sender]) {
        return reply(`⚠️ *ANALISA DULU SEBELUM TRADING!*\n\n📌 Ketik .trading analisa untuk melihat kondisi pasar terlebih dahulu.\n\n💡 Ini penting untuk menentukan entry point yang tepat!`);
    }
    
    // Cek apakah sudah ada posisi aktif
    if (global.tradingPosition[m.sender]) {
        return reply(`⚠️ *MASIH ADA POSISI AKTIF!*\n\n📌 Tutup posisi dulu dengan .trading close sebelum membuka posisi baru.\n\n📍 Cek posisi: .trading position`);
    }
    
    // Parse jumlah
    let jumlahInput = args[1];
    let jumlah = 0;
    
    if (!jumlahInput) {
        return reply(`❌ *MASUKKAN JUMLAH!*\n\n📌 Contoh:\n.trading buy 100000\n.trading buy 100rb\n.trading sell 50000`);
    }
    
    if (jumlahInput.toLowerCase().includes('rb')) {
        jumlah = parseInt(jumlahInput) * 1000;
    } else if (jumlahInput.toLowerCase().includes('k')) {
        jumlah = parseInt(jumlahInput) * 1000;
    } else if (jumlahInput.toLowerCase().includes('jt')) {
        jumlah = parseInt(jumlahInput) * 1000000;
    } else {
        jumlah = parseInt(jumlahInput);
    }
    
    if (isNaN(jumlah) || jumlah <= 0) {
        return reply(`❌ *JUMLAH TIDAK VALID!*\n\n📌 Contoh: .trading buy 100000 atau .trading buy 100rb`);
    }
    
    if (jumlah < 10000) {
        return reply(`❌ *MINIMAL TRADING Rp 10.000!*`);
    }
    
    if (jumlah > global.tradingSaldo[m.sender]) {
        return reply(`❌ *SALDO TIDAK CUKUP!*\n\n💵 Saldo: ${formatRp(global.tradingSaldo[m.sender])}\n📌 Yang ingin ditradingkan: ${formatRp(jumlah)}`);
    }
    
    const assetData = global.analisaSession[m.sender].asset;
    const currentPrice = assetData.harga;
    
    // Hitung TP dan SL berdasarkan Fibonacci
    let tp = 0;
    let sl = 0;
    
    if (cmd === 'buy') {
        // BUY: TP di Resistance 1, SL di Fibonacci 0.382
        tp = Math.floor(currentPrice * 1.03); // +3%
        sl = Math.floor(currentPrice * 0.97); // -3%
    } else {
        // SELL: TP di Support 1, SL di Resistance 2
        tp = Math.floor(currentPrice * 0.97); // -3%
        sl = Math.floor(currentPrice * 1.03); // +3%
    }
    
    // Kurangi saldo
    global.tradingSaldo[m.sender] -= jumlah;
    
    // Simpan posisi
    global.tradingPosition[m.sender] = {
        asset: assetData,
        type: cmd,
        jumlah: jumlah,
        entryPrice: currentPrice,
        tp: tp,
        sl: sl,
        openTime: Date.now()
    };
    
    await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    
    let posisiText = cmd === 'buy' ? 'BUY (LONG)' : 'SELL (SHORT)';
    let posisiIcon = cmd === 'buy' ? '🟢' : '🔴';
    
    return reply(`╔══════════════════════════════════════════════════════════════╗
║                   ✅ *POSISI TERBUKA* ✅                    ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  ${posisiIcon} POSISI: ${posisiText}                                      ║
║  🪙 ASET: ${assetData.emoji} ${assetData.nama}                                 ║
║  💰 NOMINAL: ${formatRp(jumlah)}                                   ║
║                                                              ║
║  📊 *HARGA ENTRY:* ${formatRp(currentPrice)}                            ║
║                                                              ║
║  🎯 *TAKE PROFIT (TP):* ${formatRp(tp)}                               ║
║  🛑 *STOP LOSS (SL):* ${formatRp(sl)}                                ║
║                                                              ║
║  📌 *RISK/REWARD RATIO:* 1:1                                ║
║                                                              ║
║  💡 *CARA TUTUP POSISI:*                                    ║
║  ▸ Ketik .trading position untuk cek posisi                 ║
║  ▸ Ketik .trading close untuk tutup posisi                  ║
║                                                              ║
║  ⚠️ *PERINGATAN:*                                           ║
║  Harga bisa mencapai TP atau SL secara otomatis!            ║
║  Pantau terus posisi Anda!                                  ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝`);
}
break;
case 'tebakkarturemi': {
    await satanic.sendMessage(m.chat, { react: { text: '🃏', key: m.key } });
    
    let msg = await satanic.sendMessage(m.chat, { text: `🃏 *TEBAK KARTU* 🃏\n\n🎴 MENGOCOK KARTU...\n⏰ 3` }, { quoted: fkontak });
    
    for (let i = 3; i > 0; i--) {
        await satanic.sendMessage(m.chat, { text: `🃏 *TEBAK KARTU* 🃏\n\n🎴 MENGOCOK KARTU...\n⏰ ${i}`, edit: msg.key });
        await new Promise(r => setTimeout(r, 800));
    }
    
    const kartu = [
        '♠️ AS', '♠️ 2', '♠️ 3', '♠️ 4', '♠️ 5', '♠️ 6', '♠️ 7', '♠️ 8', '♠️ 9', '♠️ 10', '♠️ J', '♠️ Q', '♠️ K',
        '♥️ AS', '♥️ 2', '♥️ 3', '♥️ 4', '♥️ 5', '♥️ 6', '♥️ 7', '♥️ 8', '♥️ 9', '♥️ 10', '♥️ J', '♥️ Q', '♥️ K',
        '♦️ AS', '♦️ 2', '♦️ 3', '♦️ 4', '♦️ 5', '♦️ 6', '♦️ 7', '♦️ 8', '♦️ 9', '♦️ 10', '♦️ J', '♦️ Q', '♦️ K',
        '♣️ AS', '♣️ 2', '♣️ 3', '♣️ 4', '♣️ 5', '♣️ 6', '♣️ 7', '♣️ 8', '♣️ 9', '♣️ 10', '♣️ J', '♣️ Q', '♣️ K'
    ];
    
    const kartuTerpilih = kartu[Math.floor(Math.random() * kartu.length)];
    const tebakanUser = text.toLowerCase();
    
    if (!tebakanUser) {
        await satanic.sendMessage(m.chat, { 
            text: `🃏 *KARTU TELAH DIPILIH!* 🃏\n\nTebak kartunya! Contoh: .kartu ♠️ AS\n💰 Hadiah 500 koin!`,
            edit: msg.key 
        });
        
        global.kartuGame = { aktif: true, kartu: kartuTerpilih, timeout: setTimeout(() => {
            if (global.kartuGame?.aktif) {
                satanic.sendMessage(m.chat, { text: `⏰ Waktu habis! Kartunya adalah ${kartuTerpilih}` });
                global.kartuGame.aktif = false;
            }
        }, 30000) };
        return;
    }
    
    if (!global.kartuGame?.aktif) return reply('Tidak ada game tebak kartu! Ketik .kartu');
    
    if (tebakanUser === kartuTerpilih) {
        clearTimeout(global.kartuGame.timeout);
        global.kartuGame.aktif = false;
        await satanic.sendMessage(m.chat, { 
            text: `🎉 *BENAR!* 🎉\n\nKartunya adalah ${kartuTerpilih}\n💰 +500 KOIN!`,
            edit: msg.key 
        });
    } else {
        await satanic.sendMessage(m.chat, { text: `❌ *SALAH!* ❌\n\nKartunya BUKAN ${tebakanUser}\nCoba lagi!` });
    }
}
break;
case 'tariktambang': {

    if (!text) return reply(`🪢 *TARIK TAMBANG* 🪢\n\n📌 Cara main:\n.tarik tim1, tim2\n\n🏆 Tim siapa yang paling kuat?`);
    
    let tim = text.split(',');
    if (tim.length < 2) return reply('Masukkan 2 tim! Contoh: .tarik Andi,Budi , Caca,Dedi');
    
    let tim1 = tim[0].trim().split(' ').filter(v=>v);
    let tim2 = tim[1].trim().split(' ').filter(v=>v);
    
    if (tim1.length < 1 || tim2.length < 1) return reply('Setiap tim minimal 1 orang!');
    
    await satanic.sendMessage(m.chat, { react: { text: '🪢', key: m.key } });
    
    let msg = await satanic.sendMessage(m.chat, { text: `🪢 *TARIK TAMBANG* 🪢\n\n🎬 SIAP...\n⏰ 3` }, { quoted: fkontak });
    
    for (let i = 3; i > 0; i--) {
        await satanic.sendMessage(m.chat, { text: `🪢 *TARIK TAMBANG* 🪢\n\n🎬 SIAP...\n⏰ ${i}`, edit: msg.key });
        await new Promise(r => setTimeout(r, 800));
    }
    
    let posisi = 0; // 0 = tengah, - = tim1 menang, + = tim2 menang
    let finishLine = 15;
    let step = 0;
    
    while (Math.abs(posisi) < finishLine) {
        step++;
        
        let kekuatan1 = 0;
        let kekuatan2 = 0;
        
        for (let i = 0; i < tim1.length; i++) {
            kekuatan1 += Math.floor(Math.random() * 10) + 1;
        }
        for (let i = 0; i < tim2.length; i++) {
            kekuatan2 += Math.floor(Math.random() * 10) + 1;
        }
        
        let selisih = Math.floor((kekuatan1 - kekuatan2) / Math.max(tim1.length, tim2.length));
        posisi += selisih;
        
        if (posisi > finishLine) posisi = finishLine;
        if (posisi < -finishLine) posisi = -finishLine;
        
        let visual = '';
        for (let i = -finishLine; i <= finishLine; i++) {
            if (i === 0) visual += '⚪';
            else if (i === posisi) visual += '🪢';
            else if (i < posisi) visual += '🔴';
            else visual += '🔵';
        }
        
        let display = `🪢 *TARIK TAMBANG* 🪢\n\n`;
        display += `📊 RONDE ${step}\n`;
        display += `💪 TIM1: ${kekuatan1} | TIM2: ${kekuatan2}\n`;
        display += `\n${' '.repeat(10)}${visual}\n\n`;
        display += `🔴 ${tim1.join(', ')} ${' '.repeat(10)} ${tim2.join(', ')} 🔵`;
        
        await satanic.sendMessage(m.chat, { text: display, edit: msg.key });
        
        let delay = Math.abs(posisi) > finishLine - 5 ? 800 : 300;
        await new Promise(r => setTimeout(r, delay));
    }
    
    let winner = posisi > 0 ? 'TIM 1' : 'TIM 2';
    let winnerTeam = posisi > 0 ? tim1 : tim2;
    
    await satanic.sendMessage(m.chat, { 
        text: `🏆 *HASIL TARIK TAMBANG* 🏆\n\n🎉 ${winner} MENANG!\n👥 ${winnerTeam.join(', ')}\n\n💥 Total ronde: ${step}`,
        edit: msg.key 
    });
}
break;
case 'renang': {
    if (!text) return reply(`🏊 *RENANG* 🏊\n\n.renang Andi, Budi, Caca\n\n🏊‍♂️ Lomba renang seru!`);
    
    let peserta = text.includes(',') ? text.split(',').map(v=>v.trim()) : text.split(' ').map(v=>v.trim());
    if (peserta.length < 2) return reply('Minimal 2 peserta!');
    
    await satanic.sendMessage(m.chat, { react: { text: '🏊', key: m.key } });
    
    let msg = await satanic.sendMessage(m.chat, { text: `🏊 *RENANG* 🏊\n\n🎬 SIAP...\n⏰ 3` }, { quoted: fkontak });
    
    for (let i = 3; i > 0; i--) {
        await satanic.sendMessage(m.chat, { text: `🏊 *RENANG* 🏊\n\n🎬 SIAP...\n⏰ ${i}`, edit: msg.key });
        await new Promise(r => setTimeout(r, 800));
    }
    
    let positions = new Array(peserta.length).fill(0);
    let finished = [];
    let finishLine = 35;
    let step = 0;
    
    while (finished.length < peserta.length) {
        step++;
        
        for (let i = 0; i < peserta.length; i++) {
            if (!finished.includes(i)) {
                let renang = Math.floor(Math.random() * 6) + 1;
                positions[i] += renang;
                if (positions[i] >= finishLine) {
                    positions[i] = finishLine;
                    finished.push(i);
                }
            }
        }
        
        let raceDisplay = `🏊 *RENANG* 🏊\n\n`;
        for (let i = 0; i < peserta.length; i++) {
            let track = '';
            let pos = positions[i];
            for (let j = 0; j <= finishLine; j++) {
                if (j === pos) track += '🏊';
                else if (j === finishLine) track += '🏁';
                else track += '🌊';
            }
            raceDisplay += `${i+1}. ${peserta[i].padEnd(10)} │${track}│ ${finished.includes(i) ? '✅' : ''}\n`;
        }
        raceDisplay += `\n💨 LANGKAH KE-${step}`;
        
        await satanic.sendMessage(m.chat, { text: raceDisplay, edit: msg.key });
        
        let delay = finished.length < 2 ? 250 : 450;
        await new Promise(r => setTimeout(r, delay));
    }
    
    let result = `🏆 *HASIL RENANG* 🏆\n\n`;
    for (let i = 0; i < finished.length; i++) {
        let medal = i === 0 ? '🥇' : (i === 1 ? '🥈' : (i === 2 ? '🥉' : `${i+1}.`));
        result += `${medal} ${peserta[finished[i]]}\n`;
    }
    
    await satanic.sendMessage(m.chat, { text: result, edit: msg.key });
}
break;
case 'tebakbendera': {
  if (!m.isGroup) return reply("⚠️ Perintah ini hanya bisa digunakan di grup!");
  
  let userId = m.sender.split('@')[0];
  
  // Cek apakah user sedang dalam sesi game
  if (satanic.tebakbendera && satanic.tebakbendera.hasOwnProperty(userId)) {
    return reply("⚠️ Masih ada sesi game yang belum selesai!\nKetik *nyerah* untuk mengakhiri.");
  }
  
  // Fetch data dari API
  let apiUrl = 'https://api.siputzx.my.id/api/games/tebakbendera';
  let response = await fetch(apiUrl);
  let result = await response.json();
  
  if (!result.status) {
    return reply("❌ Gagal mengambil data. Coba lagi nanti.");
  }
  
  let countryName = result.data.name;
  let flagUrl = result.data.img;
  
  // Kirim gambar bendera
  await satanic.sendMessage(m.chat, {
    image: { url: flagUrl },
    caption: `🏳️ *TEBAK BENDERA* 🏳️\n\nTebak nama negara dari bendera di atas!\n\n⏰ *Waktu:* 60 detik\n💡 *Hint:* Ketik *hint* (2x kesempatan)\n🏳️ *Nyerah:* Ketik *nyerah*\n\nBalas dengan nama negara yang benar!`
  }, { quoted: m });
  
  // Simpan sesi game
  satanic.tebakbendera = satanic.tebakbendera ? satanic.tebakbendera : {};
  satanic.tebakbendera[userId] = countryName.toLowerCase();
  
  // Set timeout 60 detik
  setTimeout(async () => {
    if (satanic.tebakbendera && satanic.tebakbendera.hasOwnProperty(userId)) {
      await reply(`⏰ *Waktu habis!*\nJawaban: *${countryName}*`);
      delete satanic.tebakbendera[userId];
      if (satanic.tebakbendera_hint) delete satanic.tebakbendera_hint[userId];
    }
  }, 60000);
  
  break;
}
//==================================================================
case 'tebakbenderav2': {
  if (!m.isGroup) return 
 if (tebakbendera.hasOwnProperty(m.sender.split('@')[0])) return reply("Masih Ada Sesi Yang Belum Diselesaikan!")
let anu = await axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakbendera.json')
let result = anu.data[Math.floor(Math.random() * anu.data.length)]
satanic.sendMessage(m.chat, {
    image: {
        url: result.img
    },
    caption: `Silahkan Jawab Gambar Berikut\n\nClue : ${result.flag}\nWaktu : 60s`
}, {
    quoted: m
}).then(() => {
    tebakbendera[m.sender.split('@')[0]] = result.name.toLowerCase()
})
await sleep(60000)
if (tebakbendera.hasOwnProperty(m.sender.split('@')[0])) {
    console.log("Jawaban: " + result.name)
    satanic.sendText(m.chat, `Waktu Habis\nJawaban:  ${tebakbendera[m.sender.split('@')[0]]}`, m)
    delete tebakbendera[m.sender.split('@')[0]]
}
}
break

//==================================================================
case 'tebakkimia': {
  if (!m.isGroup) return 
if (tebakkimia.hasOwnProperty(m.sender.split('@')[0])) return reply("Masih Ada Sesi Yang Belum Diselesaikan!")
let anu = await axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkimia.json')
let result = anu.data[Math.floor(Math.random() * anu.data.length)]
satanic.sendText(m.chat, `Silahkan Jawab Pertanyaan Berikut\n\nUnsur : ${result.unsur}\nWaktu : 60s`, m).then(() => {
    tebakkimia[m.sender.split('@')[0]] = result.lambang.toLowerCase()
})
await sleep(60000)
if (tebakkimia.hasOwnProperty(m.sender.split('@')[0])) {
    console.log("Jawaban: " + result.lambang)
    satanic.sendText(m.chat, `Waktu Habis\nJawaban:  ${tebakkimia[m.sender.split('@')[0]]}`, m)
    delete tebakkimia[m.sender.split('@')[0]]
}
}
break
//==================================================================
case 'asahotak': {
  if (!m.isGroup) return 
if (tebakasahotak.hasOwnProperty(m.sender.split('@')[0])) return reply("Masih Ada Sesi Yang Belum Diselesaikan!")
let anu = await axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/asahotak.json')
let result = anu.data[Math.floor(Math.random() * anu.data.length)]
satanic.sendText(m.chat, `Silahkan Jawab Pertanyaan Berikut\n\nSoal : ${result.soal}\nWaktu : 60s`, m).then(() => {
    tebakasahotak[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
})
await sleep(60000)
if (tebakasahotak.hasOwnProperty(m.sender.split('@')[0])) {
    console.log("Jawaban: " + result.jawaban)
    satanic.sendText(m.chat, `Waktu Habis\nJawaban:  ${tebakasahotak[m.sender.split('@')[0]]}`, m)
    delete tebakasahotak[m.sender.split('@')[0]]
}}
break
//==================================================================
case 'siapaaku':{
  if (!m.isGroup) return 
  let users = global.db.users[m.sender]
	let timeout = 60000 
	let poin = 10000
	 
	if (id in satanic.siapaaku) return reply('Masih ada soal belum terjawab di chat ini')
	let src = await axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/siapakahaku.json')
	let json = src.data[Math.floor(Math.random() * src.data.length)]
	let caption = `
	Soal: ${json.soal}
	 
	
	Waktu: *${(timeout / 1000).toFixed(2)} detik*
	Hadiah: ${poin} Money
	`.trim()
	satanic.siapaaku[id] = [
	await reply(`${caption}`),
	json, poin,
	setTimeout(() => {
	if (satanic.siapaaku[id]) 
users.money -= 200
reply(`*GAME SIAPAKAH AKU*\n\nWaktu habis!\n𖦹 Jawabannya adalah; *${json.jawaban}*\n𖦹 Saldo kamu dikurangi 200\n𖦹 Sisa Saldo kamu: *${db.data.users[sender].money.toLocaleString()}*`)
	delete satanic.siapaaku[id]
	 }, timeout)
	 ]
	}
	break
//==================================================================
case 'susunkata':{
  if (!m.isGroup) return 
	let timeout = 60000
	let poin = 10000
	
	if (id in satanic.susunkata) return reply('Masih ada soal belum terjawab di chat ini')
	let src = await axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/susunkata.json')
	let json = src.data[Math.floor(Math.random() * src.data.length)]
	let caption = `
	Soal: ${json.soal}
Tipe: ${json.tipe}
	
	Waktu: *${(timeout / 1000).toFixed(2)} detik*
	Hadiah: ${poin} Money
	`.trim()
	satanic.susunkata[id] = [
	await reply(`${caption}`),
	json, poin,
	setTimeout(() => {
reply(`*GAME SUSUN KATA*\n\nWaktu habis!\n𖦹 Jawabannya adalah; *${json.jawaban}*\n𖦹 Saldo kamu dikurangi 200\n𖦹 Sisa Saldo kamu: *${db.data.users[sender].money.toLocaleString()}*`)
	delete satanic.susunkata[id]
	 }, timeout)
	 ]
	}
	break
//==================================================================
case 'tekateki':{
  if (!m.isGroup) return 
	let timeout = 60000
	let users = global.db.users[m.sender]
	let poin = 10000
	
	if (id in satanic.tekateki) return reply('Masih ada soal belum terjawab di chat ini')
	let src = await axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/tekateki.json')
	let json = src.data[Math.floor(Math.random() * src.data.length)]
	let caption = `
	Soal: ${json.soal}
	
	
	Waktu: *${(timeout / 1000).toFixed(2)} detik*
	Bonus: ${poin} XP
	Hadiah: ${poin} Money 💸
	`.trim()
	satanic.tekateki[id] = [
	await reply(`${caption}`),
	json, poin,
	setTimeout(() => {
	if (satanic.tekateki[id]) 
users.money -= 200
reply(`*GAME TEKA-TEKI*\n\nWaktu habis!\n𖦹 Jawabannya adalah; *${json.jawaban}*\n𖦹 Saldo kamu dikurangi 200\n𖦹 Sisa Saldo kamu: *${db.users[sender].money.toLocaleString()}*`)
	delete satanic.tekateki[id]
	 }, timeout)
	 ]
	}
	break


// LOGIKA HINT & JAWABAN (di luar case)

case 'family100': {
  if (!m.isGroup) return 
  let winScore = 10000
	if (id in satanic.family100) return reply('Masih Ada Sesi Yang Belum Diselesaikan!')
 let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/family100.json')).json()
	let json = src[Math.floor(Math.random() * src.length)]
 let hasil = `*Jawablah Pertanyaan Berikut :*\n\nSoal : ${json.soal}\n\nHadiah : 10.000 money\n\nTerdapat *${json.jawaban.length}* Jawaban ${json.jawaban.find(v => v.includes(' ')) ? `(beberapa Jawaban Terdapat Spasi)` : ''}`.trim()
 satanic.family100[id] = {
			id,
			msg: await reply(`${hasil}`),
			...json,
			terjawab: Array.from(json.jawaban, () => false),
      winScore,  
        }
}
break
case 'tebakgambar': {
  if (!m.isGroup) return
let timeout = 60000
let id = m.chat
if (id in satanic.tebakkata) return reply("Masih Ada Sesi Yang Belum Diselesaikan!")
async function tebakgambar() {
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 return {
      img: result.img,
      jawaban: result.jawaban,
      deskripsi: result.deskripsi
    }}
  let tos = await tebakgambar ()
  console.log(tos)
 let caption = `Silahkan Jawab Soal Di Atas Ini\n\nDeskripsi : ${tos.deskripsi}\nWaktu : 60s\nHadiah : 10.000 money`
 satanic.tebakgambar[id] = [
    await satanic.sendMessage(from, {caption: caption, image: {url: tos.img}}, {quoted: m}),
    tos,
 setTimeout(() => {
	if (satanic.tebakgambar[id])
 reply(`Waktu Habis\nJawaban:  ${tos.jawaban}\n\nIngin bermain? Ketik tebakgambar`)
 delete satanic.tebakgambar[id]
 }, 60000)
	 ]
}
break
case 'tebakheroml': {
  if (!m.isGroup) return reply("⚠️ Perintah ini hanya bisa digunakan di grup!");
  
  let userId = m.sender.split('@')[0];
  
  // Cek apakah user sedang dalam sesi game
  if (satanic.tebakheroml && satanic.tebakheroml.hasOwnProperty(userId)) {
    return reply("⚠️ Masih ada sesi game yang belum selesai!\nKetik *nyerah* untuk mengakhiri.");
  }
  
  // Fetch data dari API
  let apiUrl = 'https://api.siputzx.my.id/api/games/tebakheroml';
  let response = await fetch(apiUrl);
  let result = await response.json();
  
  if (!result.status) {
    return reply("❌ Gagal mengambil data. Coba lagi nanti.");
  }
  
  let heroName = result.data.name;
  let heroAudio = result.data.audio;
  
  // Kirim audio hero
  await satanic.sendMessage(m.chat, {
    audio: { url: heroAudio },
    mimetype: 'audio/mpeg',
    ptt: true
  }, { quoted: m });
  
  // Kirim pesan game
  let caption = `🎮 *TEBAK HERO ML* 🎮\n\n` +
    `Dengar audio di atas, tebak nama hero tersebut!\n\n` +
    `⏰ *Waktu:* 60 detik\n` +
    `💡 *Hint:* Ketik *hint* (2x kesempatan)\n` +
    `🏳️ *Nyerah:* Ketik *nyerah*\n\n` +
    `Balas dengan nama hero yang benar!`;
  
  await satanic.sendMessage(m.chat, { text: caption }, { quoted: m });
  
  // Simpan sesi game (style seperti game lain)
  satanic.tebakheroml = satanic.tebakheroml ? satanic.tebakheroml : {};
  satanic.tebakheroml[userId] = heroName.toLowerCase();
  
  // Set timeout 60 detik
  setTimeout(async () => {
    if (satanic.tebakheroml && satanic.tebakheroml.hasOwnProperty(userId)) {
      await reply(`⏰ *Waktu habis!*\nJawaban: *${heroName}*`);
      delete satanic.tebakheroml[userId];
    }
  }, 60000);
  
  break;
}
//===================================================================
case 'tebaklagu': {
    if (!m.isGroup) return m.reply('❌ Hanya bisa digunakan di grup!')
    let timeout = 60000
    

    try {
        let res = await fetch('https://api.siputzx.my.id/api/games/tebaklagu')
        let result = await res.json()

        if (!result.status) return m.reply('❌ Gagal mengambil soal, coba lagi nanti.')

        let json = result.data  // { lagu, judul, artis }
        let clue = json.judul.replace(/[AIUEO]/gi, '_')
        let caption = `🎵 *Tebak Lagu* 🎵\n\nClue: ${clue}\nArtis: ${json.artis.replace(/[AIUEO]/gi, '_')}\n\nWaktu: 60 detik\nHadiah: 5000 XP\n\nKetik *nyerah* untuk menyerah`

        // Kirim audio lagu
        await satanic.sendMessage(m.chat, { 
            audio: { url: json.lagu }, 
            mimetype: 'audio/mpeg', 
            ptt: false 
        }, { quoted: m })

        // Kirim juga caption sebagai pesan teks
        await m.reply(caption)

        satanic.tebaklagu[id] = [
            json,
            setTimeout(() => {
                if (satanic.tebaklagu[id]) {
                    m.reply(`⏳ Waktu habis!\nJawaban: *${json.judul} - ${json.artis}*`)
                    delete satanic.tebaklagu[id]
                }
            }, timeout)
        ]
    } catch (e) {
        m.reply('❌ Error: ' + e.message)
    }
}
break
case 'tebaksurah': {
satanic.tebaksurah = satanic.tebaksurah ? satanic.tebaksurah : {}
    
    let users = global.db.users[m.sender]
            if (!m.isGroup) return reply('❌ Hanya bisa digunakan di grup!')
            let timeout = 120000
            let poin = 4999
            let ranSurah = Math.floor(Math.random() * 6236) + 1 // Total 6236 ayat
            
            let res = await fetch(`https://api.alquran.cloud/v1/ayah/${ranSurah}/ar.alafasy`)
            if (res.status !== 200) return reply('❌ Gagal mengambil ayat, coba lagi!')
            
            let result = await res.json()
            if (result.code === 404) return reply(`❌ Ayah tidak ditemukan, ketik *${prefix}tebaksurah* lagi`)
            
            let json = result.data
            let caption = `
🎮 *Tebak Surah* 🎮

Dengarkan audio ayat berikut dan tebak nama Surahnya!

🕑 Waktu: 120 detik
💥 Bonus: ${poin} XP

Ketik *${prefix}nyerah* untuk menyerah
            `.trim()
            
            let answerInfo = `
📖 *Informasi Surah*
Nama: ${json.surah.englishName} (${json.surah.name})
Nomor Surah: ${json.surah.number}
Jumlah Ayat: ${json.surah.numberOfAyahs}
Tipe: ${json.surah.revelationType}
            `.trim()
            
            satanic.tebaksurah[id] = [
                await reply(caption),
                json,
                setTimeout(async () => {
                    if (satanic.tebaksurah[id]) {
                        await satanic.sendMessage(m.chat, { audio: { url: json.audio }, mimetype: 'audio/mpeg', ptt: true }, { quoted: satanic.tebaksurah[id][0] })
                        reply(`⏳ Waktu habis!\n${answerInfo}`, satanic.tebaksurah[id][0])
                        delete satanic.tebaksurah[id]
                    }
                }, timeout)
            ]
            
            // Kirim audio setelah 3 detik
            setTimeout(async () => {
                await satanic.sendMessage(m.chat, { audio: { url: json.audio }, mimetype: 'audio/mpeg', ptt: true }, { quoted: satanic.tebaksurah[id][0] })
            }, 3000)
        }   
break

case 'tebaktebakan': {
  if (!m.isGroup) return 
if (tebaktebakan.hasOwnProperty(m.sender.split('@')[0])) return reply("Masih Ada Sesi Yang Belum Diselesaikan!")
let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaktebakan.json')
let result = anu[Math.floor(Math.random() * anu.length)]
satanic.sendText(m.chat, `Jawablah Pertanyaan Berikut : *${result.soal}*?\nWaktu : 60s`, m).then(() => {
    tebaktebakan[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
})
await sleep(60000)
if (tebaktebakan.hasOwnProperty(m.sender.split('@')[0])) {
    console.log("Jawaban: " + result.jawaban)
    satanic.sendText(m.chat, `Waktu Habis\nJawaban:  ${tebaktebakan[m.sender.split('@')[0]]}`, m)
    delete tebaktebakan[m.sender.split('@')[0]]
}}
break
case 'tebaklogo': {
    if (!m.isGroup) return m.reply('❌ Hanya bisa digunakan di grup!')
    let timeout = 60000
    
    try {
        let res = await fetch('https://api.siputzx.my.id/api/games/tebaklogo')
        let result = await res.json()
        
        if (!result.status) return m.reply('❌ Gagal mengambil soal, coba lagi nanti.')
        
        let soal = result.data.data
        let clue = soal.jawaban.replace(/[AIUEO]/gi, '_')
        
        let caption = `🎮 *Tebak Logo* 🎮\n\nClue: ${clue}\n\nWaktu: 60 detik\nHadiah: 5000 XP\n\nKetik *nyerah* untuk menyerah`
        
        await satanic.sendMessage(m.chat, { image: { url: soal.image }, caption: caption }, { quoted: m })
        
        satanic.tebaklogo[m.chat] = [
            soal,
            setTimeout(() => {
                if (satanic.tebaklogo[m.chat]) {
                    m.reply(`⏳ Waktu habis!\nJawaban: *${soal.jawaban}*`)
                    delete satanic.tebaklogo[m.chat]
                }
            }, timeout)
        ]
    } catch (e) {
        m.reply('❌ Error: ' + e.message)
    }
}
break
case 'tebakgame': {
    if (!m.isGroup) return m.reply('❌ Hanya bisa digunakan di grup!')
    let timeout = 60000
    

    try {
        let res = await fetch('https://api.siputzx.my.id/api/games/tebakgame')
        let result = await res.json()

        if (!result.status) return m.reply('❌ Gagal mengambil soal, coba lagi nanti.')

        let json = result.data  // langsung ambil data { img, jawaban }
        let clue = json.jawaban.replace(/[AIUEO]/gi, '_')

        let caption = `🎮 *Tebak Game* 🎮\n\nClue: ${clue}\n\nWaktu: 60 detik\nHadiah: 5000 XP\n\nKetik *nyerah* untuk menyerah`

        await satanic.sendMessage(m.chat, { image: { url: json.img }, caption: caption }, { quoted: m })

        satanic.tebakgame[id] = [
            json,
            setTimeout(() => {
                if (satanic.tebakgame[id]) {
                    m.reply(`⏳ Waktu habis!\nJawaban: *${json.jawaban}*`)
                    delete satanic.tebakgame[id]
                }
            }, timeout)
        ]
    } catch (e) {
        m.reply('❌ Error: ' + e.message)
    }
}
break
case 'tebakwarna': {
    if (!m.isGroup) return m.reply('❌ Hanya bisa digunakan di grup!')
    let timeout = 60000
    

    try {
        let res = await fetch('https://api.siputzx.my.id/api/games/tebakwarna')
        let result = await res.json()

        if (!result.status) return m.reply('❌ Gagal mengambil soal, coba lagi nanti.')

        let json = result.data  // { plate, correct, image }
        let clue = '???'

        let caption = `🎨 *Tebak Warna (Buta Warna)* 🎨\n\nAngka berapa yang kamu lihat?\n\nClue: ${clue}\nWaktu: 60 detik\nHadiah: 5000 XP\n\nKetik *nyerah* untuk menyerah`

        await satanic.sendMessage(m.chat, { image: { url: json.image }, caption: caption }, { quoted: m })

        satanic.tebakwarna[id] = [
            json,
            setTimeout(() => {
                if (satanic.tebakwarna[id]) {
                    m.reply(`⏳ Waktu habis!\nJawaban: *${json.correct}*`)
                    delete satanic.tebakwarna[id]
                }
            }, timeout)
        ]
    } catch (e) {
        m.reply('❌ Error: ' + e.message)
    }
}
break
case 'tebakkartun': {
    if (!m.isGroup) return m.reply('❌ Hanya bisa digunakan di grup!')
    let timeout = 60000
    

    try {
        let res = await fetch('https://api.siputzx.my.id/api/games/tebakkartun')
        let result = await res.json()

        if (!result.status) return m.reply('❌ Gagal mengambil soal, coba lagi nanti.')

        let json = result.data  // { name, img }
        let clue = json.name.replace(/[AIUEO]/gi, '_')

        let caption = `🎭 *Tebak Kartun* 🎭\n\nClue: ${clue}\n\nWaktu: 60 detik\nHadiah: 5000 XP\n\nKetik *nyerah* untuk menyerah`

        await satanic.sendMessage(m.chat, { image: { url: json.img }, caption: caption }, { quoted: m })

        satanic.tebakkartun[id] = [
            json,
            setTimeout(() => {
                if (satanic.tebakkartun[id]) {
                    m.reply(`⏳ Waktu habis!\nJawaban: *${json.name}*`)
                    delete satanic.tebakkartun[id]
                }
            }, timeout)
        ]
    } catch (e) {
        m.reply('❌ Error: ' + e.message)
    }
}
break
case 'tebakkata': {
if (!m.isGroup) return 
  let timeout = 60000
  
	if (id in satanic.tebakkata) return reply("Masih Ada Sesi Yang Belum Diselesaikan!")
 let src = await axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkata.json')
	let json = src.data[Math.floor(Math.random() * src.data.length)]
 let caption = `Silahkan Jawab Pertanyaan Berikut\n\nSoal : ${json.soal}\nWaktu : 60s\nHadiah : 10.000 money`
 satanic.tebakkata[id] = [
	await reply(`${caption}`),
	json,
 setTimeout(() => {
 if (satanic.tebakkata[id]) 
 console.log("Jawaban: " + json.jawaban)
 reply(`Waktu Habis\nJawaban:  ${json.jawaban}\n\nIngin bermain? Ketik tebakkata`) 
 delete satanic.tebakkata[id]
 }, 60000)
 ]
}
break
//==================================================================
case 'tebakkalimat': {
  if (!m.isGroup) return
if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) return reply("Masih Ada Sesi Yang Belum Diselesaikan!")
 let anu = await axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkalimat.json')
 let result = anu.data[Math.floor(Math.random() * anu.data.length)]
 satanic.sendText(from, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s`, m).then(() => {
 tebakkalimat[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 satanic.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/96bb6ca28d6ef7fea479f.jpg' }, caption:`Waktu Habis\nJawaban:  ${tebakkalimat[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik tebak kalimat`}, {quoted:m}) 
 delete tebakkalimat[m.sender.split('@')[0]]
 }
}
break
//==================================================================
case 'tebaklirik':{
  if (!m.isGroup) return
let users = global.db.users[m.sender]
	let timeout = 60000
	let poin = 10000
	
	if (id in satanic.tebaklirik) return reply('Masih ada soal belum terjawab di chat ini')
	let src = await axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaklirik.json')
	let json = src.data[Math.floor(Math.random() * src.data.length)]
	let caption = `
	Soal: ${json.soal}
	
	
	Waktu: *${(timeout / 1000).toFixed(2)} detik*
	Bonus: ${poin} XP
	Hadiah: ${poin} Money
	`.trim()
	satanic.tebaklirik[id] = [
	await reply(`${caption}`),
	json, poin,
	setTimeout(() => {
	if (satanic.tebaklirik[id]) 
users.money -= 200
reply(`*GAME TEBAK LIRIK*\n\nWaktu habis!\n𖦹 Jawabannya adalah; *${json.jawaban}*\n𖦹 Saldo kamu dikurangi 200\n𖦹 Sisa Saldo kamu: *${db.data.users[sender].balance.toLocaleString()}*`)
	delete satanic.tebaklirik[id]
	 }, timeout)
	 ]
	}
	break
//==================================================================
case 'caklontong': {
  if (!m.isGroup) return
if (caklontong.hasOwnProperty(m.sender.split('@')[0])) return reply("Masih Ada Sesi Yang Belum Diselesaikan!")
 let anu = await axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/caklontong.json')
 let result = anu.data[Math.floor(Math.random() * anu.data.length)]
 satanic.sendText(from, `*Jawablah Pertanyaan Berikut :*\n${result.soal}*\nWaktu : 60s`, m).then(() => {
 caklontong[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
caklontong_desk[m.sender.split('@')[0]] = result.deskripsi
 })
 await sleep(60000)
 if (caklontong.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 satanic.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/96bb6ca28d6ef7fea479f.jpg' }, caption:`Waktu Habis\nJawaban:  ${caklontong[m.sender.split('@')[0]]}\nDeskripsi : ${caklontong_desk[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik tebak lontong`}, {quoted:m}) 
 delete caklontong[m.sender.split('@')[0]]
delete caklontong_desk[m.sender.split('@')[0]]
 }
}
break
//==================================================================
case 'math': {
    if (!m.isGroup) return m.reply('❌ Hanya bisa digunakan di grup!')
    

    try {
        let res = await fetch('https://api.siputzx.my.id/api/games/math')
        let result = await res.json()

        if (!result.status) return m.reply('❌ Gagal mengambil soal, coba lagi nanti.')

        let json = result.data  // { str, mode, time, bonus, result }
        let timeout = json.time || 20000

        let caption = `🧮 *Math Game* 🧮\n\nSoal: ${json.str} = ?\n\nMode: ${json.mode}\nWaktu: ${timeout/1000} detik\nHadiah: ${json.bonus} XP\n\nKetik *nyerah* untuk menyerah`

        m.reply(caption)

        satanic.math[id] = [
            json,
            setTimeout(() => {
                if (satanic.math[id]) {
                    m.reply(`⏳ Waktu habis!\nJawaban: *${json.result}*`)
                    delete satanic.math[id]
                }
            }, timeout)
        ]
    } catch (e) {
        m.reply('❌ Error: ' + e.message)
    }
}
break
// ==================== CASE CERDAS CERMAT ====================
case 'cerdascermat': {
    if (!m.isGroup) return m.reply('❌ Hanya bisa digunakan di grup!')
    
    let args = m.text.split(' ')
    let mapel = args[1] || 'matematika'
    
    let mapelValid = ['matematika', 'penjas', 'pai', 'pkn', 'bing', 'tik', 'ipa', 'ips', 'bindo']
    if (!mapelValid.includes(mapel.toLowerCase())) {
        return m.reply(`❌ Mata pelajaran tidak valid!\n\nPilihan: ${mapelValid.join(', ')}\n\nContoh: *cerdascermat matematika*`)
    }
    
    try {
        let res = await fetch(`https://api.siputzx.my.id/api/games/cc-sd?matapelajaran=${mapel}&jumlahsoal=5`)
        let result = await res.json()
        
        if (!result.status) return m.reply('❌ Gagal mengambil soal, coba lagi nanti.')
        
        let data = result.data
        
        satanic.cerdascermat[m.chat] = {
            mapel: data.matapelajaran,
            soal: data.soal,
            index: 0,
            skor: 0
        }
        
        let soalSaatIni = satanic.cerdascermat[m.chat].soal[0]
        let pilihan = ''
        for (let opt of soalSaatIni.semua_jawaban) {
            let huruf = Object.keys(opt)[0]
            let teks = opt[huruf]
            pilihan += `${huruf.toUpperCase()}. ${teks}\n`
        }
        
        m.reply(`📚 *Cerdas Cermat - ${mapel.toUpperCase()}* 📚\n\nSoal 1/5:\n${soalSaatIni.pertanyaan}\n\n${pilihan}\n\nKetik *nyerah* untuk menyerah`)
        
    } catch (e) {
        m.reply('❌ Error: ' + e.message)
    }
}
break




case 'balapkarung': {
    if (!text) return reply(`🪢 *LARI KARUNG* 🪢\n\n.karung Andi, Budi, Caca\n\n🎒 Lomba lari pakai karung!`);
    
    let peserta = text.includes(',') ? text.split(',').map(v=>v.trim()) : text.split(' ').map(v=>v.trim());
    if (peserta.length < 2) return reply('Minimal 2 peserta!');
    
    await satanic.sendMessage(m.chat, { react: { text: '🪢', key: m.key } });
    
    let msg = await satanic.sendMessage(m.chat, { text: `🪢 *LARI KARUNG* 🪢\n\n🎬 SIAP...\n⏰ 3` }, { quoted: fkontak });
    
    for (let i = 3; i > 0; i--) {
        await satanic.sendMessage(m.chat, { text: `🪢 *LARI KARUNG* 🪢\n\n🎬 SIAP...\n⏰ ${i}`, edit: msg.key });
        await new Promise(r => setTimeout(r, 800));
    }
    
    let positions = new Array(peserta.length).fill(0);
    let finished = [];
    let finishLine = 30;
    let step = 0;
    
    while (finished.length < peserta.length) {
        step++;
        
        for (let i = 0; i < peserta.length; i++) {
            if (!finished.includes(i)) {
                let lompat = Math.floor(Math.random() * 4) + 1;
                positions[i] += lompat;
                if (positions[i] >= finishLine) {
                    positions[i] = finishLine;
                    finished.push(i);
                }
            }
        }
        
        let raceDisplay = `🪢 *LARI KARUNG* 🪢\n\n`;
        for (let i = 0; i < peserta.length; i++) {
            let track = '';
            let pos = positions[i];
            for (let j = 0; j <= finishLine; j++) {
                if (j === pos) track += '🪢';
                else if (j === finishLine) track += '🏁';
                else track += '░';
            }
            raceDisplay += `${i+1}. ${peserta[i].padEnd(10)} │${track}│ ${finished.includes(i) ? '✅' : ''}\n`;
        }
        raceDisplay += `\n🎒 LANGKAH KE-${step}`;
        
        await satanic.sendMessage(m.chat, { text: raceDisplay, edit: msg.key });
        
        let delay = finished.length < 2 ? 350 : 550;
        await new Promise(r => setTimeout(r, delay));
    }
    
    let result = `🏆 *HASIL LARI KARUNG* 🏆\n\n`;
    for (let i = 0; i < finished.length; i++) {
        let medal = i === 0 ? '🥇' : (i === 1 ? '🥈' : (i === 2 ? '🥉' : `${i+1}.`));
        result += `${medal} ${peserta[finished[i]]}\n`;
    }
    
    await satanic.sendMessage(m.chat, { text: result, edit: msg.key });
}
break;

case 'confess': case 'confes': case 'menfes': case 'menfess': {
    satanic.menfes = satanic.menfes ?? {};
    const session = Object.values(satanic.menfes).find(v => v.state === 'CHATTING' && [v.a, v.b].includes(m.sender));
    if (session) {
        const target = session.a === m.sender ? session.b : session.a;
        await satanic.sendMessage(target, {
            text: `📩 Pesan baru dari @${m.sender.split('@')[0]}:\n\n${m.text}`,
            mentions: [m.sender],
        });
        reply("Pesan diteruskan.");
        return;
    }
    const roof = Object.values(satanic.menfes).find(menpes => [menpes.a, menpes.b].includes(m.sender));
    if (roof) return reply("Kamu masih berada dalam sesi menfess");
    if (m.isGroup) return reply("Fitur hanya tersedia di private chat!");
    if (!text) return reply(`Kirim perintah ${prefix + command} nama|nomor|pesan\n\nContoh:\n${prefix + command} ${pushname}|628xxx|Menfess nih`);
    if (!text.includes('|')) return reply("Format salah! Gunakan format: nama|nomor|pesan");

    let [namaNya, nomorNya, pesanNya] = text.split('|');
    nomorNya = nomorNya.replace(/^0/, '62');
    if (isNaN(nomorNya)) return reply("Nomor tidak valid! Pastikan hanya menggunakan angka.");

    const yoi = `Hi ada menfess nih buat kamu\n\nDari: ${namaNya}\nPesan: ${pesanNya}\n\nKetik:\n${prefix}balasmenfess -- Untuk menerima menfess\n${prefix}tolakmenfess -- Untuk menolak menfess\n\n_Pesan ini dikirim oleh bot._`;
    const tod = await getBuffer('https://telegra.ph/file/c8fdfc8426f5f60b48cca.jpg');

    const id = Date.now().toString(); // ✅ PASTIKAN ID UNIK
    satanic.menfes[id] = {
        id: id, // ✅ SIMPAN ID
        a: m.sender,
        b: `${nomorNya}@s.whatsapp.net`,
        state: 'WAITING',
    };

    await satanic.sendMessage(`${nomorNya}@s.whatsapp.net`, { image: tod, caption: yoi });
    reply("Pesan berhasil dikirim ke nomor tujuan. Semoga dibalas ya!");
}
break;
case 'balasmenfess': {
    satanic.menfes = satanic.menfes ?? {};
    const roof = Object.values(satanic.menfes).find(menpes => [menpes.a, menpes.b].includes(m.sender));
    if (!roof) return reply("Belum ada sesi menfess");

    const room = Object.values(satanic.menfes).find(room => [room.a, room.b].includes(m.sender) && room.state === 'WAITING');
    if (!room) return reply("Tidak ada sesi menfess yang sedang menunggu");

    const other = [room.a, room.b].find(user => user !== m.sender);
    room.b = m.sender;
    room.state = 'CHATTING';
    satanic.menfes[room.id] = { ...room };

    await satanic.sendMessage(other, {
        text: `_@${m.sender.split("@")[0]} telah menerima menfess kamu, sekarang kamu bisa chat lewat bot ini._\n\n*NOTE:* Ketik .stopmenfess untuk berhenti.`,
        mentions: [m.sender],
    });
    reply("Menfess diterima, sekarang kamu bisa chat!");
    reply("Silakan balas pesan langsung di chat ini. Semua pesan akan diteruskan.");
}
break;

case 'stopmenfess': {
    satanic.menfes = satanic.menfes ?? {};
    let foundId = null;
    let foundData = null;
    
    for (const [key, val] of Object.entries(satanic.menfes)) {
        if ([val.a, val.b].includes(m.sender)) {
            foundId = key;
            foundData = val;
            break;
        }
    }
    
    if (!foundData) return reply("Belum ada sesi menfess");

    const to = foundData.a === m.sender ? foundData.b : foundData.a;
    await satanic.sendMessage(to, {
        text: "_Sesi menfess ini telah dihentikan._",
        mentions: [m.sender],
    });
    reply("Sesi menfess dihentikan.");
    delete satanic.menfes[foundId]; // ✅ HAPUS PAKAI KEY YANG BENAR
    return;
}
break;
case 'tolakmenfess': {
    satanic.menfes = satanic.menfes ?? {};
    let foundId = null;
    let foundData = null;
    
    for (const [key, val] of Object.entries(satanic.menfes)) {
        if ([val.a, val.b].includes(m.sender)) {
            foundId = key;
            foundData = val;
            break;
        }
    }
    
    if (!foundData) return reply("Belum ada sesi menfess");

    const other = foundData.a === m.sender ? foundData.b : foundData.a;
    await satanic.sendMessage(other, {
        text: `_Maaf, @${m.sender.split("@")[0]} menolak menfess kamu._`,
        mentions: [m.sender],
    });
    reply("Menfess berhasil ditolak.");
    delete satanic.menfes[foundId];
    return;
}
break;

case 'mancing': {
    const cooldown = 30;
    const now = Date.now();
    if (!global.mancingCooldown) global.mancingCooldown = {};
    if (global.mancingCooldown[m.sender] && now - global.mancingCooldown[m.sender] < cooldown * 1000) {
        const remaining = Math.ceil((cooldown * 1000 - (now - global.mancingCooldown[m.sender])) / 1000);
        return reply(`⏱️ *Cooldown!* Tunggu ${remaining} detik lagi untuk mancing lagi.`);
    }
    
    // DAFTAR IKAN
    const ikanList = [
        { nama: '🐟 Vintage Damsel', rarity: 'Common', nilai: 50, emoji: '🐟' },
        { nama: '🐠 Darwin Clownfish', rarity: 'Uncommon', nilai: 100, emoji: '🐠' },
        { nama: '🐡 Jewel Tang', rarity: 'Uncommon', nilai: 120, emoji: '🐡' },
        { nama: '🎣 King Mackerel', rarity: 'Rare', nilai: 200, emoji: '🎣' },
        { nama: '🦄 Narwhal', rarity: 'Epic', nilai: 400, emoji: '🦄' },
        { nama: '🐬 Yellowfin Tuna', rarity: 'Legendary', nilai: 800, emoji: '🐬' },
        { nama: '🔥 Ruby Tuna', rarity: 'Legendary', nilai: 900, emoji: '🔥' },
        { nama: '✨ Chrome Tuna', rarity: 'Legendary', nilai: 900, emoji: '✨' },
        { nama: '🌋 Lavafin Tuna', rarity: 'Legendary', nilai: 1000, emoji: '🌋' },
        { nama: '✨ Enchanted Angelfish', rarity: 'Legendary', nilai: 1100, emoji: '✨' },
        { nama: '🦈 Hammerhead Shark', rarity: 'Mythic', nilai: 2000, emoji: '🦈' },
        { nama: '🔥 Blueflame Ray', rarity: 'Mythic', nilai: 2200, emoji: '🔥' },
        { nama: '🌊 Abyss Seahorse', rarity: 'Mythic', nilai: 2500, emoji: '🌊' },
        { nama: '😱 Blob Fish', rarity: 'Mythic', nilai: 3000, emoji: '😱' },
        { nama: '🦋 Dotted Stingray', rarity: 'Mythic', nilai: 2800, emoji: '🦋' },
        { nama: '🐋 Orca', rarity: 'Secret', nilai: 10000, emoji: '🐋' },
        { nama: '🦀 Crystal Crab', rarity: 'Secret', nilai: 8000, emoji: '🦀' },
        { nama: '🦈 Monster Shark', rarity: 'Secret', nilai: 15000, emoji: '🦈' },
        { nama: '👻 Eerie Shark', rarity: 'Secret', nilai: 12000, emoji: '👻' },
        { nama: '🐋 Great Whale', rarity: 'Secret', nilai: 20000, emoji: '🐋' },
        { nama: '🤖 Robot Kraken', rarity: 'Secret', nilai: 25000, emoji: '🤖' },
        { nama: '👑 King Crab', rarity: 'Secret', nilai: 18000, emoji: '👑' },
        { nama: '👑 Queen Crab', rarity: 'Secret', nilai: 18000, emoji: '👑' }
    ];
    
    const weights = [25, 15, 12, 10, 8, 5, 3, 3, 2, 2, 1.5, 1.2, 1.2, 0.8, 1, 0.3, 0.4, 0.2, 0.3, 0.1, 0.2, 0.3, 0.3];
    
    let totalWeight = weights.reduce((a, b) => a + b, 0);
    let random = Math.random() * totalWeight;
    let cumulative = 0;
    let hasilIkan = ikanList[0];
    
    for (let i = 0; i < ikanList.length; i++) {
        cumulative += weights[i];
        if (random <= cumulative) {
            hasilIkan = ikanList[i];
            break;
        }
    }
    
    global.mancingCooldown[m.sender] = Date.now();
    await satanic.sendMessage(m.chat, { react: { text: '🎣', key: m.key } });
    
    // PESAN 1: Mulai mancing
    let msg = await satanic.sendMessage(m.chat, { 
        text: `╔════════════════════════════╗
║       🎣 *MANCING* 🎣         ║
╠════════════════════════════╣
║                            ║
║         🎣💨               ║
║       MELEMPAR KAIL...      ║
║                            ║
║         🌊🌊🌊             ║
╚════════════════════════════╝`
    }, { quoted: fkontak });
    
    await new Promise(r => setTimeout(r, 2000));
    
    // JEDA MENUNGGU LAMA (8 detik) dengan animasi titik
    for (let i = 1; i <= 8; i++) {
        let dot = '.'.repeat(i % 4);
        let waterWave = '🌊'.repeat(Math.min(i, 5));
        
        await satanic.sendMessage(m.chat, { 
            text: `╔════════════════════════════╗
║       🎣 *MANCING* 🎣         ║
╠════════════════════════════╣
║                            ║
║         ${waterWave}               ║
║       MENUNGGU${dot}          ║
║                            ║
║         🎣                 ║
║       ${i} DETIK...          ║
╚════════════════════════════╝`, 
            edit: msg.key 
        });
        await new Promise(r => setTimeout(r, 1000));
    }
    
    // Ada yang menggigit
    await satanic.sendMessage(m.chat, { 
        text: `╔════════════════════════════╗
║       🎣 *MANCING* 🎣         ║
╠════════════════════════════╣
║                            ║
║         ⚡⚡⚡              ║
║     ADA YANG MENGGIGIT!     ║
║         !!!                 ║
║                            ║
║       MENARIK KAIL...       ║
╚════════════════════════════╝`, 
        edit: msg.key 
    });
    await new Promise(r => setTimeout(r, 2000));
    
    // HASIL TANGKAPAN
    const rarityIcon = {
        'Common': '🟫', 'Uncommon': '🟤', 'Rare': '🔵',
        'Epic': '🟣', 'Legendary': '⭐', 'Mythic': '💎', 'Secret': '👑'
    };
    
    const rarityText = {
        'Common': 'COMMON', 'Uncommon': 'UNCOMMON', 'Rare': 'RARE',
        'Epic': 'EPIC', 'Legendary': 'LEGENDARY', 'Mythic': 'MYTHIC', 'Secret': 'SECRET'
    };
    
    let resultText = `╔════════════════════════════╗
║     🎣 *HASIL MANCING* 🎣      ║
╠════════════════════════════╣
║                            ║
║   ${hasilIkan.emoji} ${hasilIkan.nama} ${hasilIkan.emoji}   ║
║                            ║
║   📊 ${rarityIcon[hasilIkan.rarity]} ${rarityText[hasilIkan.rarity]}    ║
║                            ║
║   💰 +${hasilIkan.nilai} KOIN    ║
║                            ║
╚════════════════════════════╝`;
    
    await satanic.sendMessage(m.chat, { text: resultText, edit: msg.key });
    
    // Efek reaction
    if (hasilIkan.rarity === 'Secret') {
        await satanic.sendMessage(m.chat, { react: { text: '👑', key: m.key } });
        await satanic.sendMessage(m.chat, { 
            text: `🎉✨ *WOW! SECRET CATCH!* ✨🎉\n@${m.sender.split('@')[0]} mendapatkan ${hasilIkan.nama} langka!`,
            mentions: [m.sender]
        }, { quoted: fkontak });
    } else if (hasilIkan.rarity === 'Mythic') {
        await satanic.sendMessage(m.chat, { react: { text: '💎', key: m.key } });
    } else if (hasilIkan.rarity === 'Legendary') {
        await satanic.sendMessage(m.chat, { react: { text: '⭐', key: m.key } });
    } else {
        await satanic.sendMessage(m.chat, { react: { text: '🐟', key: m.key } });
    }
}
break;
case 'aduayam': {
    if (!text) return reply(`🐔 *ADU AYAM* 🐔\n\n📌 *Cara main:*\n.aduan Ayam1, Ayam2\n\n📌 *Contoh:*\n.aduayam Si Jago, si item\n\n🏆 Pemenang ditentukan secara random dengan animasi seru!`);
    
    let ayams = [];
    
    // Parse peserta
    if (text.includes(',')) {
        ayams = text.split(',').map(p => p.trim()).filter(p => p);
    } else if (text.includes('|')) {
        ayams = text.split('|').map(p => p.trim()).filter(p => p);
    } else {
        ayams = text.split(' ').filter(p => p);
    }
    
    if (ayams.length < 2) return reply('Minimal 2 ayam! Contoh: .aduayam Jago, Item, Bangkok');
    if (ayams.length > 4) return reply('Maksimal 4 ayam biar ga rame!');
    
    await satanic.sendMessage(m.chat, { react: { text: '🐔', key: m.key } });
    
    // Generate stat ayam
    let ayamStats = [];
    for (let i = 0; i < ayams.length; i++) {
        ayamStats.push({
            nama: ayams[i],
            power: Math.floor(Math.random() * 50) + 50, // 50-100
            speed: Math.floor(Math.random() * 50) + 50,
            health: 100
        });
    }
    
    // SATU PESAN UNTUK SEMUA
    let msg = await satanic.sendMessage(m.chat, { 
        text: `╔══════════════════════════════════╗
║       🐔 *ADU AYAM ARENA* 🐔        ║
╠══════════════════════════════════╣
║                                      ║
║     🎬 MEMBUKA ARENA...              ║
║     ⏰ 3                              ║
╚══════════════════════════════════════╝` 
    }, { quoted: fkontak });
    
    // Countdown 3,2,1
    for (let i = 3; i > 0; i--) {
        await satanic.sendMessage(m.chat, { 
            text: `╔══════════════════════════════════╗
║       🐔 *ADU AYAM ARENA* 🐔        ║
╠══════════════════════════════════╣
║                                      ║
║     🎬 MEMBUKA ARENA...              ║
║     ⏰ ${i}                              ║
╚══════════════════════════════════════╝`, 
            edit: msg.key 
        });
        await new Promise(r => setTimeout(r, 800));
    }
    
    // Tampilkan stat ayam
    let statText = `╔══════════════════════════════════╗
║       🐔 *STATISTIK AYAM* 🐔        ║
╠══════════════════════════════════╣
║                                      ║\n`;
    
    for (let i = 0; i < ayamStats.length; i++) {
        let powerBar = '█'.repeat(Math.floor(ayamStats[i].power / 10)) + '░'.repeat(10 - Math.floor(ayamStats[i].power / 10));
        let speedBar = '█'.repeat(Math.floor(ayamStats[i].speed / 10)) + '░'.repeat(10 - Math.floor(ayamStats[i].speed / 10));
        
        statText += `║  ${i+1}. ${ayamStats[i].nama.padEnd(12)}          ║
║     💪 Power: ${powerBar} ${ayamStats[i].power} ║
║     ⚡ Speed: ${speedBar} ${ayamStats[i].speed} ║
║                                      ║\n`;
    }
    
    statText += `╚══════════════════════════════════════╝`;
    
    await satanic.sendMessage(m.chat, { text: statText, edit: msg.key });
    await new Promise(r => setTimeout(r, 2000));
    
    // SIMULASI PERTARUNGAN
    let healths = ayamStats.map(a => a.health);
    let alive = ayamStats.map((_, i) => i);
    let winner = null;
    let round = 0;
    let battleLog = [];
    
    while (alive.length > 1 && round < 20) {
        round++;
        
        // Pilih 2 ayam random yang masih hidup
        let fighter1 = alive[Math.floor(Math.random() * alive.length)];
        let fighter2 = alive[Math.floor(Math.random() * alive.length)];
        
        while (fighter1 === fighter2 && alive.length > 1) {
            fighter2 = alive[Math.floor(Math.random() * alive.length)];
        }
        
        // Hitung damage
        let damage1 = Math.floor(Math.random() * ayamStats[fighter1].power / 10) + 5;
        let damage2 = Math.floor(Math.random() * ayamStats[fighter2].power / 10) + 5;
        
        healths[fighter2] -= damage1;
        healths[fighter1] -= damage2;
        
        battleLog.push({
            round: round,
            attacker: fighter1,
            defender: fighter2,
            damage: damage1
        });
        
        // Cek kematian
        if (healths[fighter2] <= 0) {
            alive = alive.filter(i => i !== fighter2);
            battleLog.push({
                round: round,
                dead: fighter2,
                message: `${ayamStats[fighter2].nama} 💀 K.O!`
            });
        }
        
        if (healths[fighter1] <= 0) {
            alive = alive.filter(i => i !== fighter1);
            battleLog.push({
                round: round,
                dead: fighter1,
                message: `${ayamStats[fighter1].nama} 💀 K.O!`
            });
        }
        
        // Animasi pertarungan
        let battleFrame = `╔══════════════════════════════════╗
║       🐔 *RONDE ${round}* 🐔               ║
╠══════════════════════════════════╣
║                                      ║
║  💥 ${ayamStats[fighter1].nama.padEnd(10)} vs ${ayamStats[fighter2].nama.padEnd(10)} 💥  ║
║                                      ║
║  🩸 ${ayamStats[fighter1].nama} menyerang!     ║
║  ⚔️ Damage: ${damage1}                    ║
║  🩸 ${ayamStats[fighter2].nama} menyerang!     ║
║  ⚔️ Damage: ${damage2}                    ║
║                                      ║
║  ❤️ ${ayamStats[fighter1].nama}: ${Math.max(0, healths[fighter1])} HP     ║
║  ❤️ ${ayamStats[fighter2].nama}: ${Math.max(0, healths[fighter2])} HP     ║
╚══════════════════════════════════════╝`;
        
        await satanic.sendMessage(m.chat, { text: battleFrame, edit: msg.key });
        await new Promise(r => setTimeout(r, 1500));
        
        if (alive.length === 1) {
            winner = alive[0];
            break;
        }
    }
    
    // PENENTUAN PEMENANG
    if (winner === null && alive.length === 0) {
        winner = Math.floor(Math.random() * ayamStats.length);
    } else if (winner === null) {
        winner = alive[0];
    }
    
    // HASIL AKHIR
    let resultText = `╔══════════════════════════════════╗
║       🏆 *HASIL ADU AYAM* 🏆        ║
╠══════════════════════════════════╣
║                                      ║
║     🐔 *JUARA: ${ayamStats[winner].nama}* 🐔   ║
║                                      ║
║     📊 TOTAL RONDE: ${round}                 ║
║                                      ║
║     🎉 SELAMAT! ${ayamStats[winner].nama} MENANG! 🎉 ║
╚══════════════════════════════════════╝`;
    
    await satanic.sendMessage(m.chat, { text: resultText, edit: msg.key });
    await satanic.sendMessage(m.chat, { react: { text: '🏆', key: m.key } });
}
break;
case 'tebakangkatogel': {
    if (!text) return reply(`🎰 *TEBAK ANGKA TOTOBET* 🎰\n\n📌 *Cara main:*\n.tebakangka 4D 1234\n.tebakangka 3D 123\n.tebakangka 2D 12`);
    
    const args = text.split(' ');
    if (args.length < 2) return reply('Format: .tebakangka [2D/3D/4D] [angka]');
    
    const jenis = args[0].toUpperCase();
    const tebakan = args[1];
    
    if (!['2D', '3D', '4D'].includes(jenis)) return reply('Pilih 2D, 3D, atau 4D');
    
    let panjangBenar = jenis === '2D' ? 2 : (jenis === '3D' ? 3 : 4);
    if (!/^\d+$/.test(tebakan)) return reply('Masukkan angka 0-9');
    if (tebakan.length !== panjangBenar) return reply(`${jenis} harus ${panjangBenar} digit!`);
    
    await satanic.sendMessage(m.chat, { react: { text: '🎰', key: m.key } });
    
    // Generate angka result
    let angkaResult = '';
    if (jenis === '2D') {
        angkaResult = Math.floor(Math.random() * 90 + 10).toString();
    } else if (jenis === '3D') {
        angkaResult = Math.floor(Math.random() * 900 + 100).toString();
    } else {
        angkaResult = Math.floor(Math.random() * 9000 + 1000).toString();
    }
    
    // PESAN 1: KIRIM PESAN AWAL (akan diedit terus)
    let msg = await satanic.sendMessage(m.chat, { 
        text: `╔══════════════════════════════════╗
║         🎰 *T O T O B E T* 🎰         ║
╠══════════════════════════════════╣
║                                      ║
║     ┌───┐ ┌───┐ ┌───┐ ┌───┐          ║
║     │ ? │ │ ? │ │ ? │ │ ? │          ║
║     └───┘ └───┘ └───┘ └───┘          ║
║                                      ║
║     📌 ${jenis}: ${tebakan}                    ║
║                                      ║
║     🎲 MENGOCAK ANGKA...              ║
║     ⏰ 3                              ║
╚══════════════════════════════════════╝` 
    }, { quoted: fkontak });
    
    // EDIT: Countdown 3,2,1
    for (let i = 3; i > 0; i--) {
        await satanic.sendMessage(m.chat, { 
            text: `╔══════════════════════════════════╗
║         🎰 *T O T O B E T* 🎰         ║
╠══════════════════════════════════╣
║                                      ║
║     ┌───┐ ┌───┐ ┌───┐ ┌───┐          ║
║     │ ? │ │ ? │ │ ? │ │ ? │          ║
║     └───┘ └───┘ └───┘ └───┘          ║
║                                      ║
║     📌 ${jenis}: ${tebakan}                    ║
║                                      ║
║     🎲 MENGOCAK ANGKA...              ║
║     ⏰ ${i}                              ║
╚══════════════════════════════════════╝`, 
            edit: msg.key 
        });
        await new Promise(r => setTimeout(r, 800));
    }
    
    // EDIT: Animasi rolling 20x
    for (let i = 0; i <= 20; i++) {
        let fakeNum = '';
        if (jenis === '2D') {
            fakeNum = Math.floor(Math.random() * 90 + 10).toString();
        } else if (jenis === '3D') {
            fakeNum = Math.floor(Math.random() * 900 + 100).toString();
        } else {
            fakeNum = Math.floor(Math.random() * 9000 + 1000).toString();
        }
        
        let persen = Math.floor((i / 20) * 100);
        let barLength = Math.floor(persen / 5);
        let progressBar = '█'.repeat(barLength) + '░'.repeat(20 - barLength);
        
        let fakeDigits = fakeNum.split('');
        let kotakDigits = '';
        
        if (jenis === '4D') {
            kotakDigits = `┌───┐ ┌───┐ ┌───┐ ┌───┐\n║     │ ${fakeDigits[0]} │ │ ${fakeDigits[1]} │ │ ${fakeDigits[2]} │ │ ${fakeDigits[3]} │\n║     └───┘ └───┘ └───┘ └───┘`;
        } else if (jenis === '3D') {
            kotakDigits = `┌───┐ ┌───┐ ┌───┐\n║     │ ${fakeDigits[0]} │ │ ${fakeDigits[1]} │ │ ${fakeDigits[2]} │\n║     └───┘ └───┘ └───┘`;
        } else {
            kotakDigits = `┌───┐ ┌───┐\n║     │ ${fakeDigits[0]} │ │ ${fakeDigits[1]} │\n║     └───┘ └───┘`;
        }
        
        let rollingText = `╔══════════════════════════════════╗
║         🎰 *T O T O B E T* 🎰         ║
╠══════════════════════════════════╣
║                                      ║
║     ${kotakDigits}          ║
║                                      ║
║     📌 ${jenis}: ${tebakan}                    ║
║                                      ║
║     🎲 ROLLING...                     ║
║     [${progressBar}] ${persen}%                  ║
╚══════════════════════════════════════╝`;
        
        await satanic.sendMessage(m.chat, { text: rollingText, edit: msg.key });
        
        let delay = i < 12 ? 100 : (i < 17 ? 250 : 500);
        await new Promise(r => setTimeout(r, delay));
    }
    
    // EDIT: HASIL AKHIR
    let isWin = (tebakan === angkaResult);
    let hadiah = isWin ? (jenis === '2D' ? 500 : (jenis === '3D' ? 1000 : 5000)) : 0;
    
    let resultDigits = angkaResult.split('');
    let resultKotak = '';
    
    if (jenis === '4D') {
        resultKotak = `┌───┐ ┌───┐ ┌───┐ ┌───┐\n║     │ ${resultDigits[0]} │ │ ${resultDigits[1]} │ │ ${resultDigits[2]} │ │ ${resultDigits[3]} │\n║     └───┘ └───┘ └───┘ └───┘`;
    } else if (jenis === '3D') {
        resultKotak = `┌───┐ ┌───┐ ┌───┐\n║     │ ${resultDigits[0]} │ │ ${resultDigits[1]} │ │ ${resultDigits[2]} │\n║     └───┘ └───┘ └───┘`;
    } else {
        resultKotak = `┌───┐ ┌───┐\n║     │ ${resultDigits[0]} │ │ ${resultDigits[1]} │\n║     └───┘ └───┘`;
    }
    
    let winIcon = isWin ? '🎉' : '❌';
    let winText = isWin ? 'SELAMAT!' : 'KURANG BERUNTUNG';
    
    let resultText = `╔══════════════════════════════════╗
║         🎰 *H A S I L* 🎰            ║
╠══════════════════════════════════╣
║                                      ║
║     ${resultKotak}          ║
║                                      ║
║     📌 ${jenis}: ${tebakan}                    ║
║                                      ║
║     ${winIcon} ${winText} ${winIcon}                       ║`;
    
    if (isWin) {
        resultText += `\n║     💰 HADIAH: ${hadiah} KOIN        ║`;
    } else {
        resultText += `\n║     😔 COBA LAGI lain kali          ║`;
    }
    
    resultText += `\n╚══════════════════════════════════════╝`;
    
    await satanic.sendMessage(m.chat, { text: resultText, edit: msg.key });
    await satanic.sendMessage(m.chat, { react: { text: isWin ? '🎉' : '💀', key: m.key } });
}
break;
case 'balaplari': {
    if (!text) return reply(`🏃 *BALAP LARI* 🏃\n\n📌 *Cara penggunaan:*\n.balaplari Andi, Budi, Caca, Dedi`);
    
    let peserta = [];
    
    if (text.includes(',')) {
        peserta = text.split(',').map(p => p.trim()).filter(p => p);
    } else if (text.includes('|')) {
        peserta = text.split('|').map(p => p.trim()).filter(p => p);
    } else {
        peserta = text.split(' ').filter(p => p);
    }
    
    if (peserta.length < 2) return reply('Minimal 2 peserta!');
    if (peserta.length > 8) return reply('Maksimal 8 peserta!');
    
    await satanic.sendMessage(m.chat, { react: { text: '🏁', key: m.key } });
    
    // SATU PESAN UNTUK SEMUA (countdown + balapan + hasil)
    let msg = await satanic.sendMessage(m.chat, { 
        text: `🏁 *BALAP LARI* 🏁\n\n👥 *PESERTA:*\n${peserta.map((p,i) => `   ${i+1}. ${p}`).join('\n')}\n\n🎬 Hitung mundur...` 
    }, { quoted: fkontak });
    
    // Countdown 3,2,1 (edit terus)
    await satanic.sendMessage(m.chat, { text: `🏁 *BALAP LARI* 🏁\n\n👥 *PESERTA:*\n${peserta.map((p,i) => `   ${i+1}. ${p}`).join('\n')}\n\n⏰ 3`, edit: msg.key });
    await new Promise(r => setTimeout(r, 800));
    
    await satanic.sendMessage(m.chat, { text: `🏁 *BALAP LARI* 🏁\n\n👥 *PESERTA:*\n${peserta.map((p,i) => `   ${i+1}. ${p}`).join('\n')}\n\n⏰ 2`, edit: msg.key });
    await new Promise(r => setTimeout(r, 800));
    
    await satanic.sendMessage(m.chat, { text: `🏁 *BALAP LARI* 🏁\n\n👥 *PESERTA:*\n${peserta.map((p,i) => `   ${i+1}. ${p}`).join('\n')}\n\n⏰ 1`, edit: msg.key });
    await new Promise(r => setTimeout(r, 800));
    
    await satanic.sendMessage(m.chat, { text: `🏃 *GO!* 🏃\n\n━━━━━━━━━━━━━━━━━━━━`, edit: msg.key });
    await new Promise(r => setTimeout(r, 500));
    
    // Setup balapan
    let positions = new Array(peserta.length).fill(0);
    let finished = new Array(peserta.length).fill(false);
    let ranking = [];
    const finishLine = 35;
    let step = 0;
    
    while (ranking.length < peserta.length) {
        step++;
        
        for (let i = 0; i < peserta.length; i++) {
            if (!finished[i]) {
                let langkah = Math.floor(Math.random() * 6) + 1;
                positions[i] += langkah;
                if (positions[i] >= finishLine) {
                    positions[i] = finishLine;
                    finished[i] = true;
                    ranking.push({ index: i, name: peserta[i] });
                }
            }
        }
        
        let raceDisplay = `🏃 *BALAP LARI* 🏃\n\n━━━━━━━━━━━━━━━━━━━━\n\n`;
        
        for (let i = 0; i < peserta.length; i++) {
            let track = '';
            let pos = Math.min(positions[i], finishLine);
            
            for (let j = 0; j <= finishLine; j++) {
                if (j === pos) track += '🏃';
                else if (j === finishLine) track += '🏁';
                else track += '░';
            }
            
            let status = finished[i] ? ' ✅' : '';
            raceDisplay += `${(i+1).toString().padStart(2)}. ${peserta[i].padEnd(12)} │${track}│${status}\n`;
        }
        
        raceDisplay += `\n━━━━━━━━━━━━━━━━━━━━\n⏱️ LANGKAH KE-${step}`;
        
        await satanic.sendMessage(m.chat, { text: raceDisplay, edit: msg.key });
        
        let delay = ranking.length < 2 ? 200 : (ranking.length < peserta.length - 1 ? 350 : 550);
        await new Promise(r => setTimeout(r, delay));
    }
    
    // Hasil akhir (edit pesan yang sama)
    let resultText = `🏆 *HASIL BALAPAN* 🏆\n\n━━━━━━━━━━━━━━━━━━━━\n\n`;
    
    for (let i = 0; i < ranking.length; i++) {
        let medal = i === 0 ? '🥇' : (i === 1 ? '🥈' : (i === 2 ? '🥉' : `${i+1}.`));
        resultText += `${medal} ${ranking[i].name}\n`;
    }
    
    resultText += `\n━━━━━━━━━━━━━━━━━━━━\n🎉 *JUARA 1: ${ranking[0].name}* 🎉`;
    
    await satanic.sendMessage(m.chat, { text: resultText, edit: msg.key });
    await satanic.sendMessage(m.chat, { react: { text: '🏆', key: m.key } });
    
    let winner = ranking[0].name;
    let tagWinner = winner.replace(/[^0-9]/g, '');
    if (tagWinner.length > 5 && tagWinner.length < 15) {
        await satanic.sendMessage(m.chat, {
            text: `🏆 SELAMAT! @${tagWinner} jadi juara! 🏆`,
            mentions: [tagWinner + '@s.whatsapp.net']
        }, { quoted: fkontak });
    }
}
break;
case 'dare':
              const dare =[
"Makan 2 sendok makan nasi tanpa lauk apapun, jika terasa berat, kamu bisa minum.",
"Sebutkan orang yang membuatmu terdiam",
"Telepon gebetan/pacar sekarang dan kirim tangkapan layar di sini",
"Kirim emot hanya setiap kali kamu mengetik di grup obrolan/obrolan pribadi selama 1 hari.",
"Ucapkan 'Selamat datang di Who Wants To Be a Millionaire!' ke semua grup yang kamu punya",
"Telepon mantan dengan mengatakan rindu",
"nyanyikan chorus dari lagu terakhir yang kamu mainkan",
"Rekam suara untuk mantan/pacar/gebemmu, katakan 'Hai (nama), ingin menelepon, tunggu sebentar. Aku sangat merindukanmu'",
"Pukul meja (yang ada di rumah) sampai kamu dimarahi karena berisik",
"Katakan pada orang asing 'Aku baru saja diberitahu bahwa aku adalah saudaramu yang pertama, kami berpisah, lalu aku melakukan operasi plastik. Dan ini hal paling 'ciyusss'",
"Sebutkan nama mantan",
"buat 1 sajak untuk anggota grup!",
"Kirim daftar percakapan WhatsAppmu",
"Obrol dengan orang asing dengan bahasa ghetto lalu tangkap layar di sini",
"Ceritakan versimu sendiri tentang hal-hal memalukan",
"Tag orang yang kamu benci",
"Pura-pura seperti terkena pengaruh, misalnya: terkena pengaruh anjing, terkena pengaruh belalang, terkena pengaruh lemari es, dll.",
"Ubah nama menjadi *I AM DONKEY* selama 24 jam",
"Teriak *ma chuda ma chuda ma chuda* di depan rumahmu",
"Ambil foto/potret pacar atau gebetanmu dan kirimkan di sini",
"Ceritakan tipe pacar yang kamu sukai!",
"Ucapkan *aku naksir kamu, maukah kamu menjadi pacarku?* kepada lawan jenis, terakhir kali kamu berbicara dengannya (kirim di WA/Telegram), tunggu sampai dia membalas, jika sudah, berikan di sini",
"Rekam suaramu yang membaca *titar ke age do titar, titar ke piche do titar*",
"Chatingan lelucon dengan mantan dan katakan *aku mencintaimu, tolong kembalilah.* tanpa menyebutkan bahwa itu adalah tantangan!",
"Obrol dengan kontak WhatsApp berurutan sesuai dengan persentase baterai ponselmu, lalu katakan 'Aku beruntung memiliki kamu!'",
"Ubah nama menjadi *I am a child of randi* selama 5 jam",
"Ketik dalam bahasa Bengali selama 24 jam",
"Gunakan foto Selmon Bhoi selama 3 hari",
"Kirim kutipan lagu lalu tag anggota yang cocok untuk kutipan tersebut",
"Kirim pesan suara dengan ucapan 'Bolehkah aku memanggilmu sayang?'",
"Tangkapan layar percakapan terakhir di WhatsAppmu",
"Ucapkan *KAMU SANGAT CANTIK, JANGAN BERBOHONG* kepada teman pria!",
"Telepon salah satu anggota grup dan katakan kata kasar kepada mereka",
"Berlakulah seperti ayam di depan orangtua kamu",
"Ambil sebuah buku secara acak dan bacakan satu halaman secara keras dan rekam suara lalu kirimkan di sini",
"Buka pintu depan rumahmu dan menyalak seperti serigala selama 10 detik",
"Ambil foto selfie yang memalukan dan jadikan sebagai foto profilmu",
"Biar grup memilih sebuah kata dan lagu yang dikenal. Kamu harus menyanyikan lagu tersebut dan kirim dalam bentuk pesan suara di sini",
"Berjalanlah dengan menopang dengan siku dan lutut selama yang kamu bisa",
"nyanyikan lagu kebangsaan dalam pesan suara",
"Lakukan breakdance selama 30 detik di ruang tamu",
"Ceritakan cerita sedih yang kamu ketahui",
"Buat video tari twerk singkat dan unggah sebagai status selama 5 menit",
"Makan sepotong bawang putih mentah",
"Tunjukkan lima orang terakhir yang kamu kirim pesan dan isi pesan mereka",
"Jadikan nama lengkapmu sebagai status selama 5 jam",
"Buat video tari singkat tanpa filter hanya dengan musik dan unggah sebagai status selama 5 jam",
"Telepon sahabatmu, omong kosong",
"Jadikan foto dirimu tanpa filter sebagai status selama 10 menit",
"Ucapkan 'aku cinta Oli London' dalam pesan suara 😄",
"Kirim pesan kepada mantanmu dan katakan bahwa kamu masih menyukainya",
"Telepon gebetan/pacar/sahabatmu sekarang dan tangkapan layar di sini",
"Berkata kasar pada salah satu anggota grup di percakapan pribadi dan katakan 'kamu jelek, beban'",
"Ucapkan 'KAMU CANTIK/GANTENG' pada salah satu orang yang ada di atas pinlistmu atau orang pertama di daftar percakapanmu",
"Kirim pesan suara dan katakan 'Bisakah aku memanggilmu sayang?'. Jika kamu seorang pria, sebutkan nama seorang wanita. Jika kamu seorang wanita, sebutkan nama seorang pria",
"Tulis 'Aku mencintaimu (nama anggota grup acak yang sedang online) dalam percakapan pribadi (jika kamu pria, tulis nama wanita; jika kamu wanita, tulis nama pria), ambil tangkapan layar dan kirimkan di sini",
"Gunakan foto aktor Bollywood sebagai foto profilmu selama 3 hari",
"Jadikan foto crushmu sebagai status dengan caption 'Ini adalah crushku'",
"Ubah nama menjadi *I AM GAY* selama 5 jam",
"Obrol dengan salah satu kontak di WhatsApp dan katakan 'Aku akan menjadi pacarmu selama 5 jam'",
"Kirim pesan suara dan katakan 'Aku naksir kamu, maukah kamu menjadi pacarku?' kepada orang acak dari grup (jika kamu perempuan, pilih nama laki-laki; jika kamu laki-laki, pilih nama perempuan)",
"Pukul pantatmu dengan keras dan kirim suara tamparan melalui pesan suara 😂",
"Sebutkan tipe pacarmu dan kirim fotonya di sini dengan keterangan 'Perempuan/laki-laki paling jelek di dunia'",
"Teriak 'bravooooooooo' dan kirimkan melalui pesan suara di sini",
"Ambil foto wajahmu dan kirim di sini",
"Kirim foto dirimu dengan keterangan 'Aku lesbian'",
"Teriak dengan menggunakan kata-kata kasar dan kirim melalui pesan suara",
"Teriak 'kamu bajingan' di depan ibu atau ayahmu",
"Ubah nama menjadi *aku bodoh selama 24 jam*",
"Pukul dirimu sendiri dengan mantap dan kirim suara pukulan melalui pesan suara 😂",
"Ucapkan 'aku cinta pemilik bot alya' melalui pesan suara",
"Kirim foto pacar atau gebetanmu di sini",
"Buat video tantangan tarian TikTok apa pun dan unggah sebagai status, kamu bisa menghapusnya setelah 5 jam",
"Putuskan pertemanan dengan sahabatmu selama 5 jam tanpa memberitahunya bahwa itu adalah tantangan",
"Katakan pada salah satu temanmu bahwa kamu mencintainya dan ingin menikahinya, tanpa memberitahunya bahwa itu adalah tantangan",
"Ucapkan 'aku cinta Depak Kalal' melalui pesan suara",
"Tulis 'aku merasa horny' dan unggah sebagai status, kamu hanya bisa menghapusnya setelah 5 jam",
"Tulis 'aku lesbian' dan unggah sebagai status, kamu hanya bisa menghapusnya setelah 5 jam",
"Cium ibu atau ayahmu dan katakan 'aku mencintaimu' 😌",
"Jadikan nama ayahmu sebagai status selama 5 jam",
"Kirim kata-kata kasar dalam grup manapun, kecuali grup ini, dan kirim bukti tangkapan layarnya di sini"
]
              const xeondare = dare[Math.floor(Math.random() * dare.length)]
              bufferdare = await getBuffer(`https://i.ibb.co/305yt26/bf84f20635dedd5dde31e7e5b6983ae9.jpg`)
              satanic.sendMessage(from, { image: bufferdare, caption: '_You choose DARE_\n'+ xeondare }, {quoted:fkontak})
              break
        break
       case 'truth':
              const truth =[
"Pernahkah kamu menyukai seseorang? Berapa lama?",
    "Jika kamu bisa atau jika kamu mau, grup obrolan atau grup di luar mana yang ingin kamu jadikan teman? (bisa berbeda/jenis yang sama)",
    "Apa ketakutan terbesar kamu?",
    "Pernahkah kamu menyukai seseorang dan merasa bahwa orang tersebut juga menyukaimu?",
    "Siapa nama mantan pacar temanmu yang dulu pernah kamu sukai diam-diam?",
    "Pernahkah kamu mengambil uang dari ayah atau ibumu? Alasannya?",
    "Apa yang membuatmu bahagia saat sedang sedih?",
    "Pernahkah kamu memiliki perasaan cinta satu arah? jika ya kepada siapa? bagaimana perasaannya, bro?",
    "Pernah menjadi selingkuhan seseorang?",
    "Hal paling ditakuti?",
    "Siapa orang yang paling berpengaruh dalam hidupmu?",
    "Prestasi apa yang berhasil kamu raih tahun ini?",
    "Siapa orang yang bisa membuatmu keren?",
    "Siapa orang yang pernah membuatmu sangat bahagia?",
    "Siapa yang paling mendekati tipe pasangan idamanmu di sini?",
    "Dengan siapa kamu suka bermain?",
    "Pernahkah kamu menolak seseorang? alasan mengapa?",
    "Sebutkan insiden yang pernah menyakiti perasaanmu yang masih kamu ingat",
    "Prestasi apa yang sudah kamu capai tahun ini?",
    "Kebiasaan terburukmu di sekolah?",
    "Lagu apa yang paling sering kamu nyanyikan di dalam kamar mandi?",
    "Pernahkah kamu mengalami pengalaman dekat dengan kematian?",
    "Kapan terakhir kali kamu sangat marah? Mengapa?",
    "Siapa orang terakhir yang meneleponmu?",
    "Apakah kamu memiliki bakat tersembunyi? Apa sajakah itu?",
    "Kata apa yang paling kamu benci?",
    "Video YouTube terakhir apa yang kamu tonton?",
    "Hal terakhir apa yang kamu cari di Google?",
    "Dalam grup ini, dengan siapa yang ingin kamu tukar kehidupan selama seminggu?",
    "Apa hal paling menakutkan yang pernah terjadi padamu?",
    "Pernahkah kamu kentut dan menyalahkannya kepada orang lain?",
    "Kapan terakhir kali kamu membuat orang lain menangis?",
    "Pernahkah kamu menghilangkan jejak dari seorang teman?",
    "Pernahkah kamu melihat mayat?",
    "Anggota keluargamu yang paling mengganggumu dan mengapa?",
    "Jika kamu harus menghapus satu aplikasi dari ponselmu, aplikasi mana yang akan kamu hapus?",
    "Aplikasi apa yang paling sering kamu buang-buang waktu di dalamnya?",
    "Pernahkah kamu berpura-pura sakit untuk pulang dari sekolah?",
    "Apa barang paling memalukan di dalam kamar kamarmu?",
    "Jika terdampar di pulau terpencil, lima barang apa yang akan kamu bawa?",
    "Pernahkah kamu tertawa begitu keras hingga pipismu basah?",
    "Apakah kamu mencium bau kentutmu sendiri?",
    "Pernahkah kamu kencing di tempat tidur saat tidur?",
    "Apa kesalahan terbesar yang pernah kamu buat?",
    "Pernahkah kamu mencontek dalam ujian?",
    "Apa hal terburuk yang pernah kamu lakukan?",
    "Kapan terakhir kali kamu menangis?",
    "Di antara orang tua kamu, siapa yang kamu cintai paling?",
    "Apakah kamu kadang-kadang memasukkan jari ke dalam lubang hidungmu?",
    "Siapa pujaan hati kamu saat masa sekolah dulu?",
    "Berbicara jujur, apakah kamu menyukai seorang anak laki-laki dalam grup ini?",
    "Pernahkah kamu menyukai seseorang? Berapa lama?",
    "Apakah kamu punya pacar? Apa ketakutan terbesarmu?",
    "Pernahkah kamu menyukai seseorang dan merasa bahwa orang tersebut juga menyukaimu?",
    "Siapa nama mantan pacar temanmu yang pernah kamu sukai diam-diam?",
    "Pernahkah kamu mengambil uang milik ibu atau ayahmu? Apa alasannya?",
    "Apa yang membuatmu bahagia saat sedang sedih?",
    "Apakah kamu menyukai seseorang dalam grup ini? Jika ya, siapa?",
    "Pernahkah kamu ditipu oleh seseorang?",
    "Siapa orang yang paling penting dalam hidupmu?",
    "Prestasi apa yang telah kamu capai tahun ini?",
    "Siapa orang yang bisa membuatmu bahagia saat sedang sedih?",
    "Siapa orang yang pernah membuatmu merasa tidak nyaman?",
    "Pernahkah kamu berbohong kepada orang tua?",
    "Apakah kamu masih menyukai mantan pacarmu?",
    "Siapa yang ingin kamu ajak bermain bersama?",
    "Pernahkah kamu mencuri sesuatu yang besar? Alasannya apa?",
    "Sebutkan insiden yang pernah membuatmu terluka dan masih kamu ingat?",
    "Prestasi apa yang sudah kamu raih tahun ini?",
    "Apa kebiasaan terburukmu saat di sekolah?",
    "Apakah kamu mencintai pencipta bot ini, Dani 😄",
    "Pernahkah kamu berpikir untuk membalas dendam pada guru?",
    "Apakah kamu menyukai perdana menteri saat ini di negaramu?",
    "Apakah kamu vegetarian atau non-vegetarian?",
    "Jika kamu bisa menjadi tak terlihat, apa yang pertama kali akan kamu lakukan?",
    "Apa rahasia yang kamu simpan dari orang tua kamu?",
    "Siapa pujaan hati rahasiamu?",
    "Siapa orang terakhir yang kamu intip di media sosial?",
    "Jika seorang jin memberimu tiga permintaan, apa yang akan kamu minta?",
    "Apa penyesalan terbesarmu?",
    "Hewan seperti apa menurutmu yang paling mirip denganmu?",
    "Berapa banyak foto selfie yang kamu ambil dalam sehari?",
    "Apa acara favoritmu saat masa kanak-kanak?",
    "Jika kamu bisa menjadi karakter fiksi dalam satu hari, siapa yang akan kamu pilih?",
    "Dengan siapa kamu paling sering mengirim pesan?",
    "Apa kebohongan terbesar yang pernah kamu ceritakan kepada orang tua kamu?",
    "Siapa selebriti yang menjadi pujaan hatimu?",
    "Mimpi paling aneh yang pernah kamu alami?",
    "Apakah kamu bermain PUBG? Jika ya, berikan nomor ID-mu."
]
              const alyaTruth = truth[Math.floor(Math.random() * truth.length)]
              buffertruth = await getBuffer(`https://i.ibb.co/305yt26/bf84f20635dedd5dde31e7e5b6983ae9.jpg`)
              satanic.sendMessage(from, { image: buffertruth, caption: '_You choose TRUTH_\n'+ alyaTruth }, {quoted:fkontak})
              break
case 'ceksifat':              
case 'checkme': {
    const bet = m.sender
    const name = m.pushname || 'User'

    // helper random persen
    const rand100 = () => Math.floor(Math.random() * 101)

    const sifat = [
        "Baik", "Tidak ramah", "pembangkang", "Chapri", "Nibba/Nibbi", "Mengganggu",
        "Rusak", "Orang marah", "Sopan", "Beban", "Hebat",
        "Cringe", "Pembohong"
    ]

    const hobi = [
        "Memasak","Menari","Bermain","Bermain game","Melukis",
        "Membantu Orang Lain","Menonton anime","Membaca",
        "Bersepeda","Bernyanyi", "maling","rampok","maling ayam","berak","begal","Berbincang-bincang",
        "Berbagi Meme","Menggambar","Menghabiskan Uang Orang Tua",
        "Bermain Truth or Dare","Menghabiskan Waktu Sendirian"
    ]

    const cakep = ["Ya", "Tidak", "Sangat jelek", "Sangat tampan"]

    const watak = [
        "Peduli","Murah hati","Pemarah","Tunduk","Baik",
        "Berhati baik","Sabar","UwU","Terbaik","Membantu"
    ]

    // random hasil
    const result = {
        sifat: sifat[Math.floor(Math.random() * sifat.length)],
        hobi: hobi[Math.floor(Math.random() * hobi.length)],
        bucin: rand100(),
        great: rand100(),
        ganteng: cakep[Math.floor(Math.random() * cakep.length)],
        watak: watak[Math.floor(Math.random() * watak.length)],
        baik: rand100(),
        buruk: rand100(),
        cerdas: rand100(),
        berani: rand100(),
        penakut: rand100()
    }

    // ambil PP user
    let ppuser
    try {
        ppuser = await satanic.profilePictureUrl(bet, 'image')
    } catch {
        ppuser = defaultpp // fallback kalau PP private
    }

    const profile = `*≡══《 Check @${bet.split('@')[0]} 》══≡*

*Nama :* ${name}
*Karakteristik :* ${result.sifat}
*Hobi :* ${result.hobi}
*Bucin :* ${result.bucin}%
*Great :* ${result.great}%
*Ganteng :* ${result.ganteng}
*Watak :* ${result.watak}
*Moral Baik :* ${result.baik}%
*Moral Buruk :* ${result.buruk}%
*Kecerdasan :* ${result.cerdas}%
*Keberanian :* ${result.berani}%
*Penakut :* ${result.penakut}%

*≡═══《 CHECK PROPERTIES 》═══≡*`

    satanic.sendMessage(
        from,
        {
            image: { url: ppuser },
            caption: profile,
            mentions: [bet]
        },
        { quoted: fkontak }
    )
}
break   
case 'yatim':
case 'piatu':
case 'jomblo':
case 'waria':
case 'koruptor':
case 'psikopat':
case 'pedofil':
case 'miskin':
case 'tukangjajan':
case 'jelek':
case 'mokondo':
case 'penipu':
case 'tukangcopet':
case 'tukangbo':
case 'tukangcoli':
case 'ganteng':
case 'cantik':
case 'tobrut':
case 'kurus':
case 'gemuk':
case 'kontolgede':
case 'tepos':
case 'jomblo':
case 'korbanhts':
case 'badut':
case 'tukangselingkuh':
case 'palkon':
case 'perawantua':
case 'duda':
case 'botolyakult':
case 'sasimo':
case 'jelek':
case 'mukakontol':
case 'mukamemek':
case 'tukangkawin':
case 'maling':
case 'pelakor':
case 'perampok':
case 'begal':
case 'wibu':
case 'janda':
case 'jodohku': {
    if (!m.isGroup) return reply('only group')
    
    // Ambil participants dari store.groupMetadata
    let groupMeta = store.groupMetadata[m.chat]
    if (!groupMeta) {
        groupMeta = await satanic.groupMetadata(m.chat)
        store.groupMetadata[m.chat] = groupMeta
    }
    
    let member = groupMeta.participants.map(u => u.id)
    let me = m.sender
    let jodoh = member[Math.floor(Math.random() * member.length)]
    while (jodoh === me) {
        jodoh = member[Math.floor(Math.random() * member.length)]
    }
    
    let text = ` Anjayy ${command}\n\n@${jodoh.split('@')[0]}\n\n`
    
    satanic.sendMessage(m.chat, {
        text: text,
        mentions: [jodoh]
    }, { quoted: fkontak })
}
break
case 'cekyatim':
case 'cekjelek':
case 'cekjodoh':
case 'cekmiskin':
case 'cekpedofil':
case 'cekwibu':
case 'ceksange':
case 'cektolol':
case 'cekkaya':
case 'cekwibu': {

    if (!text && (!m.mentionedJid || m.mentionedJid.length === 0)) {
        return reply(`*CARA PAKAI:*\n\n${prefix}${command} @user\n${prefix}${command} nama orang\n\n*Contoh:*\n${prefix}${command} @${m.sender.split('@')[0]}\n${prefix}${command} budi`)
    }
    
    let target = 'kamu'
    let persen = Math.floor(Math.random()  * 100) + 1
    
    if (m.mentionedJid && m.mentionedJid.length > 0) {
        return satanic.sendMessage(m.chat, {
            text: `*${persen}%*`,
            mentions: [m.mentionedJid[0]]
        }, { quoted: fkontak })
    }
    
    if (text) {
        target = text
    }
    
    reply(`${target} *${persen}%*`)
}
break
case 'ceknamabapak':
case 'namabapak':
case 'cekbapak': {
    if (!text && (!m.mentionedJid || m.mentionedJid.length === 0)) {
        return reply(`*CARA PAKAI:*\n\n${prefix}${command} @user\n${prefix}${command} nama orang\n\n*Contoh:*\n${prefix}${command} @${m.sender.split('@')[0]}\n${prefix}${command} Budi`)
    }
    
    let target = ''
    let isMention = false
    let mentionId = ''
    
    if (m.mentionedJid && m.mentionedJid.length > 0) {
        target = `@${m.mentionedJid[0].split('@')[0]}`
        isMention = true
        mentionId = m.mentionedJid[0]
    } else if (text) {
        target = text.trim()
    }
    
    let namaBapak = [
        'Paijo', 'Tukul', 'Ucup', 'Bambang', 'Sule', 'Komeng', 'udin', 'yatno', 'ucok', 'agus', 'bahlil',
        'Somad', 'Jarwo', 'Bejo', 'Kasino', 'Dono', 'Indro',
        'Rambo', 'Joni', 'Agus', 'Budi', 'Joko', 'Mamat'
    ]
    
    let namaRandom = namaBapak[Math.floor(Math.random() * namaBapak.length)]
    
    let hasil = `Bapaknya *${target}* namanya *${namaRandom}* 🤣`
    
    if (isMention) {
        satanic.sendMessage(m.chat, {
            text: hasil,
            mentions: [mentionId]
        }, { quoted: fkontak })
    } else {
        reply(hasil)
    }
}
break
case "cekkontol": {

if (!text) return reply("nama nya mana pea")

let who = m.mentionedJid[0] 
? m.mentionedJid[0] 
: m.quoted 
? m.quoted.sender 
: m.sender;

// data random
let warnaList = ["hitam", "coklat", "pink", "abu-abu", "merah", "orange,", "kuning", "biru", "titanium", "silver", "black white"]
let ukuranList = ["kecil", "sedang", "besar", "sangat kecil", " sangat besar", "oversize"]
let kondisiList = ["belom sunat", "sudah sunat"," hitam berdaki", "miring kesamping", " biji nya ga simetris ", "ga bisa ngaceng", "bengkok", "mungil"]

let pickRandom = (list) => list[Math.floor(Math.random() * list.length)]

let warna = pickRandom(warnaList)
let ukuran = pickRandom(ukuranList)
let kondisi = pickRandom(kondisiList)

reply(
`*Hasil Pengecekan Kontol*
-------------------------------------------
- *Warna*   : ${warna}
- *Ukuran*  : ${ukuran}
- *Kondisi* : ${kondisi}

> © satanic haxor`,
{ mentions: [who] }
)
}
break
case "cekiqotak": {
  if (!text) return reply("namanya mana pea");

  let who = m.mentionedJid[0] 
    ? m.mentionedJid[0] 
    : m.quoted 
      ? m.quoted.sender 
      : m.sender;

  who = String(who || m.sender || '');

  let username = 'Tidak diketahui';
  try {
    // Ambil pushName dari message
    if (m.quoted) {
      username = m.quoted.pushName || m.quoted.name || m.quoted.notifyName || 'Tidak diketahui';
    } else if (m.mentionedJid[0]) {
      // Kalo mention, coba ambil dari pushName di message atau dari kontak
      username = m.pushName || m.name || m.notifyName || 'Tidak diketahui';
    } else {
      username = m.pushName || m.name || m.notifyName || 'Tidak diketahui';
    }
  } catch (err) {
    console.error('Error getting username:', err);
    username = 'Tidak diketahui';
  }

  let iq = Math.floor(Math.random() * (140 - 50 + 1) + 50);
  
  let kategori;
  if (iq >= 130) kategori = "Genius / Jenius";
  else if (iq >= 115) kategori = "Cerdas Sekali";
  else if (iq >= 100) kategori = "Cerdas";
  else if (iq >= 85) kategori = "Normal";
  else if (iq >= 70) kategori = "Batas Rendah";
  else kategori = "Rendah";

  let saran;
  if (iq >= 115) saran = "Pertahankan dan asah terus kemampuannya!";
  else if (iq >= 85) saran = "Masih normal, rajin belajar ya!";
  else saran = "Perlu banyak latihan dan belajar lebih giat!";

  reply(
    `HASIL TEST IQ UNTUK ${username}
===========================================

IQ Score : ${iq}
Kategori : ${kategori}
Saran    : ${saran}
===========================================
> satanic haxor`,
    { mentions: [who].filter(Boolean) }
  );
}
break;
case "cektete": {
  if (!text) return reply("namanya mana pea");

  let who = m.mentionedJid[0] 
    ? m.mentionedJid[0] 
    : m.quoted 
      ? m.quoted.sender 
      : m.sender;

  let ukuranBHList = ["30A", "30B", "30C", "30D", "32A", "32B", "32C", "32D", "32DD", "34A", "34B", "34C", "34D", "34DD", "36B", "36C", "36D", "36DD", "38C", "38D", "40D"];
  let ukuranList = ["Sangat Kecil (AAA)", "Kecil (AA)", "Sedang (A)", "Agak Besar (B)", "Besar (C)", "Cukup Besar (D)", "Besar Sekali (DD/E)", "Montok (F)", "Super Besar (G)"];
  let bentukList = ["Bulat Sempurna", "Lonjong", "Air Terjun (Ptosis)", "Timur Barat (East-West)", "Berjauhan (Wide Set)", "Berdekatan (Close Set)", "Asimetris", "Kendur", "Tegak Muda"];
  let kondisiList = ["Kencang & Kenyal", "Mulai Kendur", "Lembut", "Padat Berisi", "Longgar", "Firm", "Perky", "Sagging Ringan", "Sagging Berat"];
  let putingList = ["Kecil Mungil", "Sedang", "Besar", "Menonjol", "Rata", "Terbalik (Inverted)", "Kehitaman", "Merah Muda", "Coklat", "Berbulu Halus"];
  let teksturList = ["Mulus", "Berurat", "Berbintik", "Kasar", "Halus Seperti Sutra"];
  let elastisitasList = ["Sangat Elastis", "Elastis", "Kurang Elastis", "Tidak Elastis"];

  let pickRandom = (list) => list[Math.floor(Math.random() * list.length)];

  let ukuranBH = pickRandom(ukuranBHList);
  let ukuran = pickRandom(ukuranList);
  let bentuk = pickRandom(bentukList);
  let kondisi = pickRandom(kondisiList);
  let puting = pickRandom(putingList);
  let tekstur = pickRandom(teksturList);
  let elastisitas = pickRandom(elastisitasList);

  // Random score
  let score = Math.floor(Math.random() * (100 - 50 + 1) + 50);
  let rating = score >= 85 ? "Premium" : score >= 70 ? "Good" : score >= 55 ? "Standard" : "Kurang";

  reply(
    `HASIL PENGECEKAN TETE
===========================================

Ukuran BH : ${ukuranBH}
Ukuran    : ${ukuran}
Bentuk    : ${bentuk}
Kondisi   : ${kondisi}
Puting    : ${puting}
Tekstur   : ${tekstur}
Elastisitas : ${elastisitas}
===========================================
Score     : ${score}/100
Rating    : ${rating}
===========================================
> satanic haxor `,
    { mentions: [who] }
  );
}
break;
        
case "cekmemek": {

if (!text) return reply("namanya mana pea")

let who = m.mentionedJid[0] 
? m.mentionedJid[0] 
: m.quoted 
? m.quoted.sender 
: m.sender;

// data random
let warnaList = ["pink", "merah muda", "kehitaman", "putih", "kuning", "hijau muda"," biru muda"]
let ukuranList = ["sempit", "sedang", "lebar", "oversize", "sangat lebar", "sangat sempit"]
let kondisiList = ["masih fresh", "sudah berpengalaman", "perawan", "butuh perhatian", "udah longgar", "berkurap", "berjamur"]

let pickRandom = (list) => list[Math.floor(Math.random() * list.length)]

let warna = pickRandom(warnaList)
let ukuran = pickRandom(ukuranList)
let kondisi = pickRandom(kondisiList)

reply(
`*Hasil Pengecekan Meki*
-------------------------------------------
- *Warna*   : ${warna}
- *Ukuran*  : ${ukuran}
- *Kondisi* : ${kondisi}

> © satanic haxor`,
{ mentions: [who] }
)
}
break

case 'cekkodam':
case 'kodam':
case 'cekkodamku': {
    let target = ''
    let isMention = false
    let mentionId = ''
    let persen = Math.floor(Math.random() * 100) + 1
    
    if (m.mentionedJid && m.mentionedJid.length > 0) {
        target = `@${m.mentionedJid[0].split('@')[0]}`
        isMention = true
        mentionId = m.mentionedJid[0]
    } else if (text) {
        target = text.trim()
    } else {
        target = `@${m.sender.split('@')[0]}`
        isMention = true
        mentionId = m.sender
    }
    
    let kodam = [
        'Kodam Tuyul Ngamen', 'Kodam Tuyul London', 'Kodam Tuyul Dubai', 'Kodam Tuyul Jepang',
        'Kodam Genderuwo Baper', 'Kodam Genderuwo Galau', 'Kodam Genderuwo Mikir', 'Kodam Genderuwo Ngoding',
        'Kodam Pocong Kece', 'Kodam Pocong Badung', 'Kodam Pocong Gaul', 'Kodam Pocong Mewing',
        'Kodam Kuntilanak Cantik', 'Kodam Kuntilanak Modus', 'Kodam Kuntilanak Baper', 'Kodam Kuntilanak Jomblo',
        'Kodam Sundel Bolong Lari', 'Kodam Sundel Bolong Ngamen', 'Kodam Sundel Bolong Opo', 'Kodam Sundel Bolong Joget',
        'Kodam Leak Bali', 'Kodam Leak Sakti', 'Kodam Leak Ngamuk', 'Kodam Leak Nangis',
        'Kodam Wewe Gombel Jomblo', 'Kodam Wewe Gombel Galau', 'Kodam Wewe Gombel Baper', 'Kodam Wewe Gombel Mikir',
        'Kodam Jerangkong Ngegas', 'Kodam Jerangkong Baper', 'Kodam Jerangkong Ngopi', 'Kodam Jerangkong Nonton',
        'Kodam Hantu Boneka', 'Kodam Hantu TV', 'Kodam Hantu Kulkas', 'Kodam Hantu AC',
        'Kodam Pocong Merah', 'Kodam Pocong Hijau', 'Kodam Pocong Biru', 'Kodam Pocong Pink',
        'Kodam Kuyang Joget', 'Kodam Kuyang Ngamen', 'Kodam Kuyang Baper', 'Kodam Kuyang Nangis',
        'Kodam Sundel Galau', 'Kodam Sundel Baper', 'Kodam Sundel Mikir', 'Kodam Sundel Joget',
        'Kodam Genderuwo Opo', 'Kodam Genderuwo Wes', 'Kodam Genderuwo Kok', 'Kodam Genderuwo Lah',
        'Kodam Banaspati Ngamuk', 'Kodam Banaspati Galau', 'Kodam Banaspati Baper', 'Kodam Banaspati Mikir',
        'Kodam Tongkat Mbah', 'Kodam Tongkat Sakti', 'Kodam Tongkat Maut', 'Kodam Tongkat Petir',
        'Kodam Sapu Terbang', 'Kodam Sapu Lidi', 'Kodam Sapu Jagad', 'Kodam Sapu Tua',
        'Kodam Karpet Terbang', 'Kodam Karpet Sakti', 'Kodam Karpet Rusak', 'Kodam Karpet Basah',
        'Kodam Jubah Hitam', 'Kodam Jubah Putih', 'Kodam Jubah Sakti', 'Kodam Jubah Kotor',
        'Kodam Keris Pusaka', 'Kodam Keris Sakti', 'Kodam Keris Maut', 'Kodam Keris Tua',
        'Kodam Mustika Kecubung', 'Kodam Mustika Merah', 'Kodam Mustika Hitam', 'Kodam Mustika Putih',
        'Kodam Jimat Sakti', 'Kodam Jimat Maut', 'Kodam Jimat Tua', 'Kodam Jimat Pusaka',
        'Kodam Pelet Jawa', 'Kodam Pelet Sakti', 'Kodam Pelet Maut', 'Kodam Pelet Ampuh',
        'Kodam Susuk', 'Kodam Susuk Sakti', 'Kodam Susuk Maut', 'Kodam Susuk Emas',
        'Kodam Sendal Jepit', 'Kodam Sendal Swal', 'Kodam Sendal Hotel', 'Kodam Sendal Bolong',
        'Kodam Ember Bocor', 'Kodam Ember Plastik', 'Kodam Ember Besi', 'Kodam Ember Tua',
        'Kodam Gayung Nyleneh', 'Kodam Gayung Plastik', 'Kodam Gayung Besi', 'Kodam Gayung Tua',
        'Kodam Sapu Lidi', 'Kodam Sapu Ijuk', 'Kodam Sapu Tua', 'Kodam Sapu Baru',
        'Kodam Keset Muka', 'Kodam Keset Kaki', 'Kodam Keset Basah', 'Kodam Keset Kering',
        'Kodam Kipas Angin', 'Kodam Kipas Tangan', 'Kodam Kipas Rusak', 'Kodam Kipas Baru',
        'Kodam Lampu Bohlam', 'Kodam Lampu LED', 'Kodam Lampu Minyak', 'Kodam Lampu Petromak',
        'Kodam Kasur Busa', 'Kodam Kasur Kapuk', 'Kodam Kasur Bocor', 'Kodam Kasur Baru',
        'Kodam Bantal Guling', 'Kodam Bantal Busa', 'Kodam Bantal Kapuk', 'Kodam Bantal Bau',
        'Kodam Selimut', 'Kodam Selimut Basah', 'Kodam Selimut Kering', 'Kodam Selimut Baru',
        'Kodam Karpet', 'Kodam Karpet Basah', 'Kodam Karpet Kering', 'Kodam Karpet Baru',
        'Kodam Hape Jadul', 'Kodam Hape Batrey', 'Kodam Hape Error', 'Kodam Hape Lemot',
        'Kodam TV Tabung', 'Kodam TV Digital', 'Kodam TV Rusak', 'Kodam TV Butut'
    ]
    
    let randomKodam = kodam[Math.floor(Math.random() * kodam.length)]
    
    let hasil = `🔮 *CEK KODAM* 🔮\n\n👤 ${target}\n🎲 Kodam: ${randomKodam}\n📊 Level: ${persen}%\n\n🤣🤣🤣`
    
    if (isMention) {
        satanic.sendMessage(m.chat, {
            text: hasil,
            mentions: [mentionId]
        }, { quoted: fkontak })
    } else {
        reply(hasil)
    }
}
break
case 'dapatkah': {
    if (!text) return reply(`Ajukan pertanyaan\n\nContoh: ${prefix + command} aku bisa menari?`);
    let bisa = [`Bisa`, `Tidak Bisa`, `Tidak Mungkin`, `Tentu Saja Bisa!!!`];
    let keh = bisa[Math.floor(Math.random() * bisa.length)];
    let jawab = `*Bisa ${text}*\nJawaban: ${keh}`;
    await reply(jawab);
}
break;
case 'apakah': {
    if (!text) return reply(`Ajukan pertanyaan\n\nContoh: ${prefix + command} dia masih perawan?`);
    let apa = [`Ya`, `Tidak`, `Mungkin Saja`, `Benar Sekali`, `yo ndak tau`, `tidak tahu`, `lu pikir gw dukun`, `hem`];
    let kah = apa[Math.floor(Math.random() * apa.length)];
    let jawab = `*[ Apakah ${text} ]*\nJawaban: ${kah}`;
    await reply(jawab);
}
break;
case 'when': {
    if (!text) return reply(`Ajukan pertanyaan\n\nContoh: ${prefix + command} kapan aku menikah?`);
    let kapan = [
        '5 Hari Lagi', '10 Hari Lagi', '15 Hari Lagi', '20 Hari Lagi', '25 Hari Lagi', '30 Hari Lagi',
        '35 Hari Lagi', '40 Hari Lagi', '45 Hari Lagi', '50 Hari Lagi', '55 Hari Lagi', '60 Hari Lagi',
        '65 Hari Lagi', '70 Hari Lagi', '75 Hari Lagi', '80 Hari Lagi', '85 Hari Lagi', '90 Hari Lagi',
        '100 Hari Lagi', '5 Bulan Lagi', '10 Bulan Lagi', '15 Bulan Lagi', '20 Bulan Lagi', '25 Bulan Lagi',
        '30 Bulan Lagi', '35 Bulan Lagi', '40 Bulan Lagi', '45 Bulan Lagi', '50 Bulan Lagi', '55 Bulan Lagi',
        '60 Bulan Lagi', '65 Bulan Lagi', '70 Bulan Lagi', '75 Bulan Lagi', '80 Bulan Lagi', '85 Bulan Lagi',
        '90 Bulan Lagi', '100 Bulan Lagi', '1 Tahun Lagi', '2 Tahun Lagi', '3 Tahun Lagi', '4 Tahun Lagi',
        '5 Tahun Lagi', 'Besok', 'Lusa'
    ];
    let koh = kapan[Math.floor(Math.random() * kapan.length)];
    let jawab = `*Kapan ${text}*\nJawaban: ${koh}`;
    await reply(jawab);
}
break
case 'apa':
case 'what': {
    if (!text) return reply(`Ajukan pertanyaan\n\nContoh: ${prefix + command} namamu?`);
    let lel = [`Tanya Pacarmu`, `Aku Tidak Tahu`, `Aku Tidak Tahu, Tanya Ayahmu`];
    let kah = lel[Math.floor(Math.random() * lel.length)];
    let jawab = `*Apa ${text}*\nJawaban: ${kah}`;
    await reply(jawab);
}
break;
case 'where': {
    if (!text) return reply(`Ajukan pertanyaan\n\nContoh: ${prefix + command} kamu berada?`);
    let lokasi = [`Di gunung`, `Di Mars`, `Di Bulan`, `Di hutan`, `Aku tidak tahu, tanya ibumu`, `Mungkin di suatu tempat`, `di kuburan`, `di neraka`, `yo ndak tahu`, `di arab`];
    let kah = lokasi[Math.floor(Math.random() * lokasi.length)];
    let jawab = `*Dimana ${text}*\nJawaban: ${kah}`;
    await reply(jawab);
}
break;
case 'rate': {
    if (!text) return reply(`Contoh: ${prefix + command} profilku`);
    let nilai = Array.from({ length: 100 }, (_, i) => (i + 1).toString());
    let kah = nilai[Math.floor(Math.random() * nilai.length)];
    let jawab = `*Nilai ${text}*\nJawaban: ${kah}%`;
    await reply(jawab);
}
break;
case 'ulartangga': {
    if (!m.isGroup) return reply('❌ Hanya bisa digunakan di grup!')

class GameSession {
    constructor(id, sMsg) {
        this.id = id
        this.players = []
        this.game = new SnakeAndLadderGame(sMsg)
    }
}
class SnakeAndLadderGame {
    constructor(sMsg) {
        this.sendMsg = sMsg
        this.players = []
        this.boardSize = 100
        this.snakesAndLadders = [
            { start: 29, end: 7 }, { start: 24, end: 12 }, { start: 15, end: 37 },
            { start: 23, end: 41 }, { start: 72, end: 36 }, { start: 49, end: 86 },
            { start: 90, end: 56 }, { start: 75, end: 64 }, { start: 74, end: 95 },
            { start: 91, end: 72 }, { start: 97, end: 78 }
        ]
        this.currentPositions = {}
        this.currentPlayerIndex = 0
        this.bgImageUrl = 'https://i.pinimg.com/originals/2f/68/a7/2f68a7e1eee18556b055418f7305b3c0.jpg'
        this.player1ImageUrl = 'https://i.pinimg.com/originals/75/33/22/7533227c53f6c270a96d364b595d6dd5.jpg'
        this.player2ImageUrl = 'https://i.pinimg.com/originals/be/68/13/be6813a6086681070b0f886d33ca4df9.jpg'
        this.bgImage = null
        this.player1Image = null
        this.player2Image = null
        this.cellWidth = 40
        this.cellHeight = 40
        this.keyId = null
        this.started = false
    }

    initializeGame() {
        for (const player of this.players) {
            this.currentPositions[player] = 1
        }
        this.currentPlayerIndex = 0
        this.started = true
    }

    rollDice() {
        return Math.floor(Math.random() * 6) + 1
    }

    async movePlayer(player, steps) {
        if (this.players.length === 0) return
        const currentPosition = this.currentPositions[player]
        let newPosition = currentPosition + steps
        for (const otherPlayer of this.players) {
            if (otherPlayer !== player && this.currentPositions[otherPlayer] === newPosition) {
                const message = `😱 *Oh tidak!* ${player.split('@')[0]} *diinjak oleh* ${otherPlayer.split('@')[0]}.* Kembali ke awal cell.*`
                await reply(message)
                newPosition = 1
            }
        }
        const snakeOrLadder = this.snakesAndLadders.find(s => s.start === newPosition)
        if (snakeOrLadder) newPosition = snakeOrLadder.end
        newPosition = Math.min(newPosition, this.boardSize)
        this.currentPositions[player] = newPosition
    }

    async fetchImage(url) {
        try {
            const response = await axios.get(url, { responseType: 'arraybuffer' })
            return await jimp.read(Buffer.from(response.data, 'binary'))
        } catch (error) {
            console.error(`Error fetching image from ${url}:`, error)
            throw error
        }
    }

    async getBoardBuffer() {
        const board = new jimp(420, 420)
        this.bgImage.resize(420, 420)
        board.composite(this.bgImage, 0, 0)
        for (const player of this.players) {
            const playerPosition = this.currentPositions[player]
            const playerImage = player === this.players[0] ? this.player1Image : this.player2Image
            const playerX = ((playerPosition - 1) % 10) * this.cellWidth + 10
            const playerY = (9 - Math.floor((playerPosition - 1) / 10)) * this.cellHeight + 10
            board.composite(playerImage.clone().resize(this.cellWidth, this.cellHeight), playerX, playerY)
        }
        return board.getBufferAsync(jimp.MIME_PNG)
    }

    async startGame(m, player1Name, player2Name) {
        await reply(`🐍🎲 *Selamat datang di Permainan Ular Tangga!* 🎲🐍 \n\n${player1Name.split('@')[0]} vs ${player2Name.split('@')[0]}`)
        this.players = [player1Name, player2Name]
        this.initializeGame()
        if (!this.bgImage) this.bgImage = await this.fetchImage(this.bgImageUrl)
        if (!this.player1Image) this.player1Image = await this.fetchImage(this.player1ImageUrl)
        if (!this.player2Image) this.player2Image = await this.fetchImage(this.player2ImageUrl)
        const boardBuffer = await this.getBoardBuffer()
        const { key } = await satanic.sendMessage(m.chat, { image: boardBuffer }, { quoted: fkontak })
        this.keyId = key
    }

    async playTurn(m, player) {
        if (!this.players.length) {
            await reply('🛑 *Tidak ada permainan aktif.* Gunakan ".ulartangga start" untuk memulai permainan baru.')
            return
        }
        if (player !== this.players[this.currentPlayerIndex]) {
            await reply(`🕒 *Bukan giliranmu.* \n\nSekarang giliran ${this.players[this.currentPlayerIndex].split('@')[0]}`)
            return
        }
        const diceRoll = this.rollDice()
        await reply(`🎲 ${player.split('@')[0]} *melempar dadu.*\n\n  - Dadu: *${diceRoll}*\n  - Dari kotak: *${this.currentPositions[player]}*\n  - Ke kotak: *${this.currentPositions[player] + diceRoll}*`)
        if (diceRoll !== 6) {
            this.movePlayer(player, diceRoll)
            const snakeOrLadder = this.snakesAndLadders.find(s => s.start === this.currentPositions[player])
            if (snakeOrLadder) {
                const action = snakeOrLadder.end < snakeOrLadder.start ? 'Mundur' : 'Maju'
                await reply(`🐍 ${player.split('@')[0]} menemukan ${action === 'Mundur' ? 'ular' : 'tangga'}! ${action} *ke kotak ${snakeOrLadder.end}.*`)
                this.currentPositions[player] = snakeOrLadder.end
            }
        }
        if (diceRoll !== 6) {
            this.switchPlayer()
        } else {
            await reply('🎲 Anda mendapat 6, jadi giliran Anda masih berlanjut.')
            this.movePlayer(player, diceRoll)
        }
        if (this.currentPositions[player] === this.boardSize) {
            await reply(`🎉 ${player.split('@')[0]} menang! Selamat!`)
            this.resetSession()
        }
        const boardBuffer = await this.getBoardBuffer()
        const sendMsg = this.sendMsg
        await sendMsg.sendMessage(m.chat, { delete: this.keyId })
        const { key } = await satanic.sendMessage(m.chat, { image: boardBuffer }, { quoted: fkontak })
        this.keyId = key
        return
    }

    addPlayer(player) {
        if (this.players.length < 2 && !this.players.includes(player) && player !== '') {
            this.players.push(player)
            return true
        } else {
            return false
        }
    }

    switchPlayer() {
        this.currentPlayerIndex = 1 - this.currentPlayerIndex
    }

    resetSession() {
        this.players = []
        this.currentPositions = {}
        this.currentPlayerIndex = 0
        this.started = false
    }

    isGameStarted() {
        return this.started
    }
}
    // Inisialisasi objek game jika belum ada
    satanic.ulartangga = satanic.ulartangga || {}
    const sessions = satanic.ulartangga_ = satanic.ulartangga_ || {}
    const sessionId = m.chat
    const session = sessions[sessionId] || (sessions[sessionId] = new GameSession(sessionId, satanic))
    const game = session.game
    const { state } = satanic.ulartangga[m.chat] || { state: false }

    switch (args[0]) {
        case 'join':
            if (state) return reply('🛑 *Permainan sudah dimulai.* Tidak dapat bergabung.')
            const playerName = m.sender
            const joinSuccess = game.addPlayer(playerName)
            joinSuccess
                ? reply(`👋 ${playerName.split('@')[0]} *bergabung ke dalam permainan.*`)
                : reply('*Anda sudah bergabung atau permainan sudah penuh.* Tidak dapat bergabung.')
            break

        case 'start':
            if (state) return reply('🛑 *Permainan sudah dimulai.* Tidak dapat memulai ulang.')
            satanic.ulartangga[m.chat] = { ...satanic.ulartangga[m.chat], state: true }
            if (game.players.length === 2) {
                await game.startGame(m, game.players[0], game.players[1])
            } else {
                reply('👥 *Tidak cukup pemain untuk memulai permainan.* Diperlukan minimal 2 pemain.')
            }
            break

        case 'roll':
            if (!state) return reply('🛑 *Permainan belum dimulai.* Ketik ".ulartangga start" untuk memulai.')
            if (game.isGameStarted()) {
                const currentPlayer = game.players[game.currentPlayerIndex]
                if (m.sender !== currentPlayer) {
                    reply(`🕒 *Bukan giliranmu.* \n\nSekarang giliran ${currentPlayer.split('@')[0]}`)
                } else {
                    await game.playTurn(m, currentPlayer)
                }
            } else {
                reply('🛑 *Permainan belum dimulai.* Ketik ".ulartangga start" untuk memulai.')
            }
            break

        case 'reset':
            satanic.ulartangga[m.chat] = { ...satanic.ulartangga[m.chat], state: false }
            session.game.resetSession()
            delete sessions[sessionId]
            reply('🔄 *Sesi permainan direset.*')
            break

        case 'help':
            reply(`🎲🐍 *Permainan Ular Tangga* 🐍🎲\n\n*Commands:*\n- ${prefix + command} join : Bergabung ke dalam permainan.\n- ${prefix + command} start : Memulai permainan.\n- ${prefix + command} roll : Melempar dadu untuk bergerak.\n- ${prefix + command} reset : Mereset sesi permainan.`)
            break

        default:
            reply(`❓ *Perintah tidak valid.* Gunakan ${prefix + command} help untuk melihat daftar perintah.`)
    }
}
break;
case 'ttc': case 'ttt': case 'tictactoe': {
            let TicTacToe = require("./lib/tictactoe")
            this.game = this.game ? this.game : {}
            if (Object.values(this.game).find(room13 => room13.id.startsWith('tictactoe') && [room13.game.playerX, room13.game.playerO].includes(m.sender))) return reply(`You Are Still In The Game`)
            let room13 = Object.values(this.game).find(room13 => room13.state === 'WAITING' && (text ? room13.name === text : true))
            if (room13) {
            room13.o = m.chat
            room13.game.playerO = m.sender
            room13.state = 'PLAYING'
            let arr = room13.game.render().map(v => {
            return {
            X: '❌',
            O: '⭕',
            1: '1️⃣',
            2: '2️⃣',
            3: '3️⃣',
            4: '4️⃣',
            5: '5️⃣',
            6: '6️⃣',
            7: '7️⃣',
            8: '8️⃣',
            9: '9️⃣',
            }[v]
            })
            let str = `room13 ID: ${room13.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

Waiting @${room13.game.currentTurn.split('@')[0]}

Type *surrender* to surrender and admit defeat`
            if (room13.x !== room13.o) await satanic.sendText(room13.x, str, m, { mentions: parseMention(str) } )
            await satanic.sendText(room13.o, str, m, { mentions: parseMention(str) } )
            } else {
            room13 = {
            id: 'tictactoe-' + (+new Date),
            x: m.chat,
            o: '',
            game: new TicTacToe(m.sender, 'o'),
            state: 'WAITING'
            }
            if (text) room13.name = text
            reply('Waiting For Partner' + (text ? ` Type The Command Below ${prefix}${command} ${text}` : ''))
            this.game[room13.id] = room13
            }
            }
            break
            case 'delttc': case 'delttt': {
            this.game = this.game ? this.game : {}
            try {
            if (this.game) {
            delete this.game
            satanic.sendText(m.chat, `Successfully deleted TicTacToe session`, m)
            } else if (!this.game) {
            reply(`Session TicTacToe🎮 does not exist`)
            } else throw '?'
            } catch (e) {
            reply('damaged')
            }
            }
            break
         
            case 'tebakbom': {
    if (!m.isGroup) return reply('❌ Hanya bisa digunakan di grup!')

    satanic.bomb = satanic.bomb || {}
    
    let timeout = 180000

    // Cek apakah user kirim angka langsung atau nyerah saat game aktif
    if (id in satanic.bomb) {
        let body = args[0]
        let sender = m.sender.split('@')[0]
        
        // Cek nyerah
        let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(body)
        if (isSurrender) {
            reply(`🚩 ${sender} menyerah!`)
            clearTimeout(satanic.bomb[id][2])
            delete satanic.bomb[id]
            return
        }

        // Cek angka
        if (!isNaN(body)) {
            let pick = satanic.bomb[id][1].find(v => v.pos == Number(body))
            if (!pick) return reply('Kirim angka 1 - 9')

            if (pick.open)
                return reply(`Kotak ${pick.number} sudah dibuka`)

            pick.open = true
            let grids = satanic.bomb[id][1]

            let render = () => {
                let t = `乂  *B O M B*\n\n`
                for (let i = 0; i < grids.length; i += 3)
                    t += grids.slice(i, i + 3).map(v => v.open ? v.emot : v.number).join('') + '\n'
                return t
            }

            if (pick.emot === '💥') {
                let teks2 = render()
                teks2 += `\n\n💥 BOM MELEDAK!\n${sender} kalah!`

                reply(teks2)
                clearTimeout(satanic.bomb[id][2])
                delete satanic.bomb[id]
                return
            }

            let safeOpen = grids.filter(v => v.open && v.emot !== '💥').length
            if (safeOpen >= 8) {
                let teks2 = render()
                teks2 += `\n\n🎉 MENANG!\nSemua kotak aman terbuka!`

                reply(teks2)
                clearTimeout(satanic.bomb[id][2])
                delete satanic.bomb[id]
                return
            }

            let teks2 = render()
            teks2 += `\n\n✨ Aman! Lanjutkan!`

            reply(teks2)
            return
        }
    }

    // Command untuk start game
    if (id in satanic.bomb)
        return reply('*^ sesi ini belum selesai!*')

    const bom = ['💥','✅','✅','✅','✅','✅','✅','✅','✅']
        .sort(() => Math.random() - 0.5)

    const number = ['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣']

    const grid = bom.map((v, i) => ({
        emot: v,
        number: number[i],
        pos: i + 1,
        open: false
    }))

    let teks = `乂  *B O M B*\n\nKirim angka *1 - 9* untuk membuka kotak:\n\n`
    for (let i = 0; i < grid.length; i += 3)
        teks += grid.slice(i, i + 3).map(v => v.open ? v.emot : v.number).join('') + '\n'

    teks += `\n⏳ Timeout : ${timeout/60000} menit`
    teks += `\n💣 Jika kena bom, kamu kalah!`
    teks += `\n\nKetik .tebakbom nyerah untuk menyerah\n\n untuk membuka kotak bom ketik .tebakbom 1`

    let msg = await reply(teks)

    satanic.bomb[id] = [
        msg,
        grid,
        setTimeout(() => {
            let b = grid.find(v => v.emot === '💥')
            if (satanic.bomb[id])
                reply(`⏰ Waktu habis!\nBom di kotak ${b.pos}`, msg)
            delete satanic.bomb[id]
        }, timeout)
    ]
}
break

case 'onlyfans': {
    try {
        await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        const response = await fetch('https://api.theresav.biz.id/asupan/onlyfans?apikey=${global.thesera}');
        
        if (!response.ok) {
            throw new Error(`HTTP Error ${response.status}`);
        }
        
        const buffer = await response.arrayBuffer();
        const imageBuffer = Buffer.from(buffer);
        
        const sentMsg = await satanic.sendMessage(m.chat, {
            image: imageBuffer,
            caption: `📸 *OnlyFans*\n🔥 Random Content`,
            viewOnce: true
        }, { quoted: fkontak });
        
        setTimeout(() => {
            satanic.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: true,
                    id: sentMsg.key.id,
                    participant: m.sender
                }
            }).catch(() => {})
        }, 30000);
        
        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (e) {
        console.error('Error in onlyfans case:', e);
        await satanic.sendMessage(m.chat, {
            text: '❌ *Error:* ' + (e.message || 'Gagal mengambil data')
        }, { quoted: fkontak });
    }
}
break;
case 'randomwaifu':
case 'randomhentai': {
    if (!isPrem) return reply('❌ Fitur premium only');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const response = await fetch("https://api.waifu.im/images?IsNsfw=All");
        const data = await response.json();
        const imageUrl = data.items[Math.floor(Math.random() * data.items.length)].url;
        
        // Kirim gambar dengan viewOnce
const sentMsg = await satanic.sendMessage(m.chat, {
    image: { url: imageUrl },
    caption: '🌸 Random Waifu 🌸',
    viewOnce: true
}, { quoted: fkontak });

// Opsional: Hapus pesan setelah 10 detik
setTimeout(() => {
    satanic.sendMessage(m.chat, {
        delete: {
            remoteJid: m.chat,
            fromMe: true,
            id: sentMsg.key.id,
            participant: m.sender
        }
    }).catch(() => {})
}, 30000);
        
        await satanic.sendMessage(m.chat, { react: { text: '🌸', key: m.key } });
    } catch (err) {
        reply('❌ Gagal ambil waifu');
    }
}
break;
case 'paptt': {
    if (!isPrem) return reply('❌ Fitur premium only');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const response = await axios.get(`https://free-restapi.biz.id/api/paptt?apikey=${global.sakey}`, {
            responseType: 'arraybuffer'
        });
        
        await satanic.sendMessage(m.chat, {
            image: Buffer.from(response.data),
            caption: '🌸 pap tt 🌸',
            viewOnce: false
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '🌸', key: m.key } });
    } catch (err) {
        console.error('Error paptt2:', err);
        reply('❌ Gagal ambil pap tt');
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'pap': {
    if (!isPrem) return reply('❌ Fitur premium only');
    
    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        const response = await axios.get(`https://free-restapi.biz.id/api/randompap?apikey=${global.sakey}`, {
            responseType: 'arraybuffer'
        });
        
        await satanic.sendMessage(m.chat, {
            image: Buffer.from(response.data),
            caption: '🌸 cantik ni🌸',
            viewOnce: false
        }, { quoted: fkontak });
        
        await satanic.sendMessage(m.chat, { react: { text: '🌸', key: m.key } });
    } catch (err) {
        console.error('Error paptt2:', err);
        reply('❌ Gagal ambil pap tt');
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'animepat':{
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/pat`)       
            await satanic.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:fkontak }).catch(err => {
return('Error!')
})
}
break
case 'animeslap':{
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/slap`)       
            await satanic.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:fkontak }).catch(err => {
return('Error!')
})
}
break
case 'animecuddle':{
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/cuddle`)       
            await satanic.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:fkontak }).catch(err => {
return('Error!')
})
}
break
case 'animewaifu':{
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/waifu`)       
            await satanic.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:fkontak }).catch(err => {
return('Error!')
})
}
break
case 'animenom':{
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/nom`)       
            await satanic.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:fkontak }).catch(err => {
return('Error!')
})
}
break
case 'animefoxgirl':{
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/fox_girl`)       
            await satanic.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:fkontak }).catch(err => {
return('Error!')
})
}
break
case 'animetickle': {
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/tickle`)     
            await satanic.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:fkontak }).catch(err => {
return('Error!')
})
}
break
case 'animegecg': {
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/gecg`)     
            await satanic.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:fkontak }).catch(err => {
return('Error!')
})
}
break
case 'dogwoof': {
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/woof`)     
            await satanic.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:fkontak }).catch(err => {
return('Error!')
})
}
break
case '8ballpool': {
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/8ball`)     
            await satanic.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:fkontak }).catch(err => {
return('Error!')
})
}
break
case 'goosebird': {
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/goose`)     
            await satanic.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:fkontak }).catch(err => {
return('Error!')
})
}
break
case 'animefeed': {
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/feed`)     
            await satanic.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:fkontak }).catch(err => {
return('Error!')
})
}
break
case 'animeavatar': {
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/avatar`)     
            await satanic.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:fkontak }).catch(err => {
return('Error!')
})
}
break
case 'lizardpic': {
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/lizard`)     
            await satanic.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:fkontak }).catch(err => {
return('Error!')
})
}
break
case 'catmeow': {
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/meow`)     
            await satanic.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:fkontak }).catch(err => {
return('Error!')
})
}
break
case 'animewlp':{
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/wallpaper`)       
            await satanic.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:fkontak }).catch(err => {
return('Error!')
})
}
break
case 'animekiss':{
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/kiss`)       
            await satanic.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:fkontak }).catch(err => {
return('Error!')
})
}
break
case 'animehug':{
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/hug`)       
            await satanic.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:fkontak }).catch(err => {
return('Error!')
})
}
break
case 'apakah': {
              if (!text) return reply(`Contoh: ${command} saya ganteng?`)
              const jawaban = ['Iya', 'Mungkin iya', 'Mungkin', 'Gak', 'Mungkin gak', 'Gak tau']
              const coli = jawaban[Math.floor(Math.random() * jawaban.length)]
              reply(`*Pertanyaan:* Apakah ${text}\n*Jawaban:* ${coli}`)
            }
            break

            case 'bisakah': {
              if (!text) return reply(`Contoh: ${command} saya jadi kaya?`)
              const jawaban = ['Bisa banget', 'Bisa', 'Mungkin bisa', 'Mungkin', 'Gak bisa', 'Mungkin gak bisa', 'Gak bisa lah', 'Gak tau']
              const coli = jawaban[Math.floor(Math.random() * jawaban.length)]
              reply(`*Pertanyaan:* Bisakah ${text}\n*Jawaban:* ${coli}`)
            }
            break

            case 'kapankah': {
              if (!text) return reply(`Contoh: ${command} saya kaya?`)
              const jawabanWaktu = [
                'Bentar lagi',
                'Nunggu kiamat dulu',
                'Kapan-kapan',
                'Besok',
                'yo ndak tau',
                'Pas lu tidur',
                'Gw juga gak tau kapan'
              ]
              const waktuRandom = Math.floor(Math.random() * 10) + 1
              const unitWaktu = ['minggu', 'bulan', 'tahun']
              const unitWaktuRandom = unitWaktu[Math.floor(Math.random() * unitWaktu.length)]
              const jawaban = [...jawabanWaktu, `${waktuRandom} ${unitWaktuRandom} lagi`]
              const hasilJawaban = jawaban[Math.floor(Math.random() * jawaban.length)]
              reply(`*Pertanyaan:* Kapankah ${text}\n*Jawaban:* ${hasilJawaban}`)
            }
            break

case "randomchina":
case "china": {

    const data = "https://api.siputzx.my.id/api/r/cecan/china";
    await satanic.sendMessage(m.chat, {
        image: { url: data },
        caption: ""
    }, { quoted: fkontak });
}
break;
case "randomindo":
case "indo": {

    const data = "https://api.siputzx.my.id/api/r/cecan/indonesia";
    await satanic.sendMessage(m.chat, {
        image: { url: data },
        caption: ""
    }, { quoted: fkontak });
}
break;
case "waifu": {
    const data = "https://api.siputzx.my.id/api/r/waifu";
    await satanic.sendMessage(m.chat, {
        image: { url: data },
        caption: ""
    }, { quoted: fkontak });
}
break;
case "randomneko":
case "neko": {

    const data = "https://api.siputzx.my.id/api/r/neko";
    await satanic.sendMessage(m.chat, {
        image: { url: data },
        caption: ""
    }, { quoted: fkontak });
}
break;
case "randomvietnam":
case "vietnam": {

    const data = "https://api.siputzx.my.id/api/r/cecan/vietnam";
    await satanic.sendMessage(m.chat, {
        image: { url: data },
        caption: ""
    }, { quoted: fkontak });
}
break;
case "randomthailand":
case "thailand": {

    const data = "https://api.siputzx.my.id/api/r/cecan/thailand";
    await satanic.sendMessage(m.chat, {
        image: { url: data },
        caption: ""
    }, { quoted: fkontak });
}
break;
case "randomkorea":
case "korea": {

    const data = "https://api.siputzx.my.id/api/r/cecan/korea";
    await satanic.sendMessage(m.chat, {
        image: { url: data },
        caption: ""
    }, { quoted: fkontak });
}
break;
case "randomjapan":
case "japan": {

    const data = "https://api.siputzx.my.id/api/r/cecan/japan";
    await satanic.sendMessage(m.chat, {
        image: { url: data },
        caption: ""
    }, { quoted: fkontak });
}
break;
case 'artimimpi': case 'tafsirmimpi': {

if (!text) return reply(`Contoh : ${cmd} belanja`)
let anu = await primbon.tafsir_mimpi(text)
if (anu.status == false) return reply(anu.message)
reply(`• *Mimpi :* ${anu.message.mimpi}\n• *Arti :* ${anu.message.arti}\n• *Solusi :* ${anu.message.solusi}`)
}
break
case 'ramalanjodoh': case 'ramaljodoh': {

if (!text) return reply(`Contoh : ${cmd} Dika, 7, 7, 2005, Novia, 16, 11, 2004`)
let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
let anu = await primbon.ramalan_jodoh(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
if (anu.status == false) return reply(anu.message)
reply(`• *Nama Anda :* ${anu.message.nama_anda.nama}\n• *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n• *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n• *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'ramalanjodohbali': case 'ramaljodohbali': {

if (!text) return reply(`Contoh : ${cmd} Dika, 7, 7, 2005, Novia, 16, 11, 2004`)
let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
let anu = await primbon.ramalan_jodoh_bali(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
if (anu.status == false) return reply(anu.message)
reply(`• *Nama Anda :* ${anu.message.nama_anda.nama}\n• *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n• *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n• *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'suamiistri': {

if (!text) return reply(`Contoh : ${cmd} Dika, 7, 7, 2005, Novia, 16, 11, 2004`)
let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
let anu = await primbon.suami_istri(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
if (anu.status == false) return reply(anu.message)
reply(`• *Nama Suami :* ${anu.message.suami.nama}\n• *Lahir Suami :* ${anu.message.suami.tgl_lahir}\n• *Nama Istri :* ${anu.message.istri.nama}\n• *Lahir Istri :* ${anu.message.istri.tgl_lahir}\n• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'ramalancinta': case 'ramalcinta': {

if (!text) return reply(`Contoh : ${cmd} Dika, 7, 7, 2005, Novia, 16, 11, 2004`)
let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
let anu = await primbon.ramalan_cinta(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
if (anu.status == false) return reply(anu.message)
reply(`• *Nama Anda :* ${anu.message.nama_anda.nama}\n• *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n• *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n• *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n• *Sisi Positif :* ${anu.message.sisi_positif}\n• *Sisi Negatif :* ${anu.message.sisi_negatif}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'artinama': {

if (!text) return reply(`Contoh : ${cmd} Dika Ardianta`)
let anu = await primbon.arti_nama(text)
if (anu.status == false) return reply(anu.message)
reply(`• *Nama :* ${anu.message.nama}\n• *Arti :* ${anu.message.arti}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'kecocokannama': case 'cocoknama': {

if (!text) return reply(`Contoh : ${cmd} Dika, 7, 7, 2005`)
let [nama, tgl, bln, thn] = text.split`,`
let anu = await primbon.kecocokan_nama(nama, tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Nama :* ${anu.message.nama}\n• *Lahir :* ${anu.message.tgl_lahir}\n• *Life Path :* ${anu.message.life_path}\n• *Destiny :* ${anu.message.destiny}\n• *Destiny Desire :* ${anu.message.destiny_desire}\n• *Personality :* ${anu.message.personality}\n• *Persentase :* ${anu.message.persentase_kecocokan}`)
}
break
case 'kecocokanpasangan': case 'cocokpasangan': case 'pasangan': {

if (!text) return reply(`Contoh : ${cmd} Dika|Novia`)
let [nama1, nama2] = text.split`|`
let anu = await primbon.kecocokan_nama_pasangan(nama1, nama2)
if (anu.status == false) return reply(anu.message)
sock.sendImage(m.chat,  anu.message.gambar, `• *Nama Anda :* ${anu.message.nama_anda}\n• *Nama Pasangan :* ${anu.message.nama_pasangan}\n• *Sisi Positif :* ${anu.message.sisi_positif}\n• *Sisi Negatif :* ${anu.message.sisi_negatif}`)
}
break
case 'jadianpernikahan': case 'jadiannikah': {

if (!text) return reply(`Contoh : ${cmd} 6, 12, 2020`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.tanggal_jadian_pernikahan(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Tanggal Pernikahan :* ${anu.message.tanggal}\n• *karakteristik :* ${anu.message.karakteristik}`)
}
break
case 'sifatusaha': {

if (!ext)return reply(`Contoh : ${prefix+ command} 28, 12, 2021`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.sifat_usaha_bisnis(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Lahir :* ${anu.message.hari_lahir}\n• *Usaha :* ${anu.message.usaha}`)
}
break
case  ' rejeki': case 'rezeki': {

if (!text) return reply(`Contoh : ${cmd} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.rejeki_hoki_weton(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Lahir :* ${anu.message.hari_lahir}\n• *Rezeki :* ${anu.message.rejeki}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'pekerjaan': {

if (!text) return reply(`Contoh : ${cmd} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.pekerjaan_weton_lahir(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Lahir :* ${anu.message.hari_lahir}\n• *Pekerjaan :* ${anu.message.pekerjaan}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'ramalannasib': case 'ramalnasib': case 'nasib': {

if (!text) return reply(`Contoh : 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.ramalan_nasib(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Analisa :* ${anu.message.analisa}\n• *Angka Akar :* ${anu.message.angka_akar}\n• *Sifat :* ${anu.message.sifat}\n• *Elemen :* ${anu.message.elemen}\n• *Angka Keberuntungan :* ${anu.message.angka_keberuntungan}`)
}
break
case 'potensipenyakit': case 'penyakit': {

if (!text) return reply(`Contoh : ${cmd} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.cek_potensi_penyakit(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Analisa :* ${anu.message.analisa}\n• *Sektor :* ${anu.message.sektor}\n• *Elemen :* ${anu.message.elemen}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'artitarot': case 'tarot': {

if (!text) return reply(`Contoh : ${cmd} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.arti_kartu_tarot(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
sock.sendImage(m.chat, anu.message.image, `• *Lahir :* ${anu.message.tgl_lahir}\n• *Simbol Tarot :* ${anu.message.simbol_tarot}\n• *Arti :* ${anu.message.arti}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'fengshui': {

if (!text) return `Contoh : ${cmd} Dika, 1, 2005\n\nNote : ${cmd} Nama, gender, tahun lahir\nGender : 1 untuk laki-laki & 2 untuk perempuan`
let [nama, gender, tahun] = text.split`,`
let anu = await primbon.perhitungan_feng_shui(nama, gender, tahun)
if (anu.status == false) return reply(anu.message)
reply(`• *Nama :* ${anu.message.nama}\n• *Lahir :* ${anu.message.tahun_lahir}\n• *Gender :* ${anu.message.jenis_kelamin}\n• *Angka Kua :* ${anu.message.angka_kua}\n• *Kelompok :* ${anu.message.kelompok}\n• *Karakter :* ${anu.message.karakter}\n• *Sektor Baik :* ${anu.message.sektor_baik}\n• *Sektor Buruk :* ${anu.message.sektor_buruk}`)
}
break
case 'haribaik': {

if (!text) return reply(`Contoh : ${cmd} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.petung_hari_baik(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Lahir :* ${anu.message.tgl_lahir}\n• *Kala Tinantang :* ${anu.message.kala_tinantang}\n• *Info :* ${anu.message.info}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'harisangar': case 'taliwangke': {

if (!text) return reply(`Contoh : ${cmd} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.hari_sangar_taliwangke(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Lahir :* ${anu.message.tgl_lahir}\n• *Hasil :* ${anu.message.result}\n• *Info :* ${anu.message.info}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'harinaas': case 'harisial': {

if (!text) return reply(`Contoh : ${cmd} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.primbon_hari_naas(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Hari Lahir :* ${anu.message.hari_lahir}\n• *Tanggal Lahir :* ${anu.message.tgl_lahir}\n• *Hari Naas :* ${anu.message.hari_naas}\n• *Info :* ${anu.message.catatan}\n• *Catatan :* ${anu.message.info}`)
}
break
case 'nagahari': case 'harinaga': {

if (!text) return reply(`Contoh : ${cmd} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.rahasia_naga_hari(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Hari Lahir :* ${anu.message.hari_lahir}\n• *Tanggal Lahir :* ${anu.message.tgl_lahir}\n• *Arah Naga Hari :* ${anu.message.arah_naga_hari}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'arahrejeki': case 'arahrezeki': {

if (!text) return reply(`Contoh : ${cmd} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.primbon_arah_rejeki(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Hari Lahir :* ${anu.message.hari_lahir}\n• *tanggal Lahir :* ${anu.message.tgl_lahir}\n• *Arah Rezeki :* ${anu.message.arah_rejeki}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'peruntungan': {

if (!text) return reply(`Contoh : ${cmd} DIka, 7, 7, 2005, 2022\n\nNote : ${cmd} Nama, tanggal lahir, bulan lahir, tahun lahir, untuk tahun`)
let [nama, tgl, bln, thn, untuk] = text.split`,`
let anu = await primbon.ramalan_peruntungan(nama, tgl, bln, thn, untuk)
if (anu.status == false) return reply(anu.message)
reply(`• *Nama :* ${anu.message.nama}\n• *Lahir :* ${anu.message.tgl_lahir}\n• *Peruntungan Tahun :* ${anu.message.peruntungan_tahun}\n• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'weton': case 'wetonjawa': {

if (!text) return reply(`Contoh : ${cmd} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.weton_jawa(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Tanggal :* ${anu.message.tanggal}\n• *Jumlah Neptu :* ${anu.message.jumlah_neptu}\n• *Watak Hari :* ${anu.message.watak_hari}\n• *Naga Hari :* ${anu.message.naga_hari}\n• *Jam Baik :* ${anu.message.jam_baik}\n• *Watak Kelahiran :* ${anu.message.watak_kelahiran}`)
}
break
case 'sifat': case 'karakter': {

if (!text) return reply(`Contoh : ${cmd} Dika, 7, 7, 2005`)
let [nama, tgl, bln, thn] = text.split`,`
let anu = await primbon.sifat_karakter_tanggal_lahir(nama, tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Nama :* ${anu.message.nama}\n• *Lahir :* ${anu.message.tgl_lahir}\n• *Garis Hidup :* ${anu.message.garis_hidup}`)
}
break
case 'keberuntungan': {

if (!text) return reply(`Contoh : ${cmd} Dika, 7, 7, 2005`)
let [nama, tgl, bln, thn] = text.split`,`
let anu = await primbon.potensi_keberuntungan(nama, tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Nama :* ${anu.message.nama}\n• *Lahir :* ${anu.message.tgl_lahir}\n• *Hasil :* ${anu.message.result}`)
}
break
case 'memancing': {

if (!text) return reply(`Contoh : ${cmd} 12, 1, 2022`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.primbon_memancing_ikan(tgl, bln, thn)
if (anu.status == false) return reply(anu.message)
reply(`• *Tanggal :* ${anu.message.tgl_memancing}\n• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`)
}
break

case 'masasubur': {

if (!text) return reply(`Contoh : ${cmd} 12, 1, 2022, 28\n\nNote : ${cmd} hari pertama menstruasi, siklus`)
let [tgl, bln, thn, siklus] = text.split`,`
let anu = await primbon.masa_subur(tgl, bln, thn, siklus)
if (anu.status == false) return reply(anu.message)
reply(`• *Hasil :* ${anu.message.result}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'zodiak': case 'zodiac': {

if (!text) return reply(`Contoh : ${prefix+ command} 7 7 2005`)
let zodiak = [
["capricorn", new Date(1970, 0, 1)],
["aquarius", new Date(1970, 0, 20)],
["pisces", new Date(1970, 1, 19)],
["aries", new Date(1970, 2, 21)],
["taurus", new Date(1970, 3, 21)],
["gemini", new Date(1970, 4, 21)],
["cancer", new Date(1970, 5, 22)],
["leo", new Date(1970, 6, 23)],
["virgo", new Date(1970, 7, 23)],
["libra", new Date(1970, 8, 23)],
["scorpio", new Date(1970, 9, 23)],
["sagittarius", new Date(1970, 10, 22)],
["capricorn", new Date(1970, 11, 22)]
].reverse()

function getZodiac(month, day) {
let d = new Date(1970, month - 1, day)
return zodiak.find(([_,_d]) => d >= _d)[0]
}
let date = new Date(text)
if (date == 'Invalid Date') return date
let d = new Date()
let [tahun, bulan, tanggal] = [d.getFullYear(), d.getMonth() + 1, d.getDate()]
let birth = [date.getFullYear(), date.getMonth() + 1, date.getDate()]

let zodiac = await getZodiac(birth[1], birth[2])

let anu = await primbon.zodiak(zodiac)
if (anu.status == false) return reply(anu.message)
reply(`• *Zodiak :* ${anu.message.zodiak}\n• *Nomor :* ${anu.message.nomor_keberuntungan}\n• *Aroma :* ${anu.message.aroma_keberuntungan}\n• *Planet :* ${anu.message.planet_yang_mengitari}\n• *Bunga :* ${anu.message.bunga_keberuntungan}\n• *Warna :* ${anu.message.warna_keberuntungan}\n• *Batu :* ${anu.message.batu_keberuntungan}\n• *Elemen :* ${anu.message.elemen_keberuntungan}\n• *Pasangan Zodiak :* ${anu.message.pasangan_zodiak}\n• *Catatan :* ${anu.message.catatan}`)
}
break
case 'shio': {

if (!text) return reply(`Contoh : ${cmd} tikus\n\nNote : For Detail https://primbon.com/shio.htm`)
let anu = await primbon.shio(text)
if (anu.status == false) return reply(anu.message)
reply(`• *Hasil :* ${anu.message}`)
}
break
case 'bokep':
case 'bkp': {
    return reply(`*🚫 DILARANG!*

*Surah An-Nur (24:30):*

قُلْ لِلْمُؤْمِنِينَ يَغُضُّوا مِنْ أَبْصَارِهِمْ وَيَحْفَظُوا فُرُوجَهُمْ ۚ ذَٰلِكَ أَزْكَىٰ لَهُمْ ۗ إِنَّ اللَّهَ خَبِيرٌ بِمَا يَصْنَعُونَ

*"Katakanlah kepada orang laki-laki yang beriman, 'Hendaklah mereka menahan pandangannya, dan memelihara kemaluannya; yang demikian itu adalah lebih suci bagi mereka. Sesungguhnya Allah Maha Mengetahui apa yang mereka perbuat.'"*

*Surah An-Nur (24:31):*

وَقُلْ لِلْمُؤْمِنَاتِ يَغْضُضْنَ مِنْ أَبْصَارِهِنَّ وَيَحْفَظْنَ فُرُوجَهُنَّ

*"Katakanlah kepada wanita yang beriman, 'Hendaklah mereka menahan pandangannya, dan memelihara kemaluannya.'"*

━━━━━━━━━━━━━━━━━━━

⚠️ *PERINGATAN:*

Menonton atau mencari konten porno adalah *DOSA BESAR* dan melanggar perintah Allah untuk menjaga pandangan dan kemaluan.

💀 *Ancaman:*
• Dosa yang terus mengalir
• Hati menjadi gelap
• Jauh dari rahmat Allah
• Merusak otak dan mental

🛑 *HENTIKAN!*
Bertaubatlah sebelum terlambat. Allah Maha Pengampun lagi Maha Penyayang.

*"Dan bertobatlah kamu sekalian kepada Allah, hai orang-orang yang beriman supaya kamu beruntung."* (QS. An-Nur: 31)

━━━━━━━━━━━━━━━━━━━
✨ *Jaga pandanganmu, selamatkan imanmu!*`);
}
break;

case 'randomasupan':
case 'asupan': {
    function pickRandom(list) {
        return list[Math.floor(list.length * Math.random())];
    }

    const asupan = [
        "https://b.top4top.io/m_1931yxodg0.mp4",
        "https://k.top4top.io/m_193161p380.mp4",
        "https://l.top4top.io/m_1931i4g3p1.mp4",
        "https://a.top4top.io/m_1931tjlio2.mp4",
        "https://g.top4top.io/m_1931z2mc40.mp4",
        "https://h.top4top.io/m_1931auyof1.mp4",
        "https://i.top4top.io/m_19315hrle2.mp4",
        "https://j.top4top.io/m_1931xul5a3.mp4",
        "https://l.top4top.io/m_1931o92nr0.mp4",
        "https://a.top4top.io/m_1931j1rh21.mp4",
        "https://b.top4top.io/m_1931iaqpg2.mp4",
        "https://c.top4top.io/m_1931s5zlj3.mp4",
        "https://d.top4top.io/m_1931x0g5a4.mp4",
        "https://i.top4top.io/m_1931oj76n0.mp4",
        "https://j.top4top.io/m_19319gl3d1.mp4",
        "https://k.top4top.io/m_1931u52cq2.mp4",
        "https://l.top4top.io/m_1931mvgj73.mp4",
        "https://a.top4top.io/m_1931u07oz4.mp4",
        "https://j.top4top.io/m_1931h1fo60.mp4",
        "https://k.top4top.io/m_1931mro3u1.mp4",
        "https://l.top4top.io/m_1931kx0ac2.mp4",
        "https://a.top4top.io/m_1931g9ezq3.mp4",
        "https://b.top4top.io/m_1931plin14.mp4",
        "https://c.top4top.io/m_1931aaxri5.mp4",
        "https://d.top4top.io/m_1931ijzzn6.mp4",
        "https://e.top4top.io/m_1931ugycd7.mp4",
        "https://f.top4top.io/m_1931l14nk8.mp4",
        "https://g.top4top.io/m_1931crgqt9.mp4",
        "https://l.top4top.io/m_1931ufrul0.mp4",
        "https://a.top4top.io/m_1931jbdpk1.mp4",
        "https://c.top4top.io/m_1931aj9nm2.mp4",
        "https://d.top4top.io/m_1931cnsal3.mp4",
        "https://e.top4top.io/m_1931d4kc74.mp4",
        "https://f.top4top.io/m_1931bih8q5.mp4",
        "https://g.top4top.io/m_1931xx7aa6.mp4",
        "https://h.top4top.io/m_1931g3zsq7.mp4",
        "https://a.top4top.io/m_1931m74wd0.mp4",
        "https://b.top4top.io/m_1931p8tfm1.mp4",
        "https://e.top4top.io/m_1931aj8iv0.mp4",
        "https://f.top4top.io/m_1931szguy1.mp4",
        "https://g.top4top.io/m_1931l73ry2.mp4",
        "https://h.top4top.io/m_1931yhznj3.mp4",
        "https://i.top4top.io/m_1931kmtp34.mp4",
        "https://j.top4top.io/m_1931snhdg5.mp4",
        "https://k.top4top.io/m_1931ay1jz6.mp4",
        "https://l.top4top.io/m_1931x70mk7.mp4",
        "https://a.top4top.io/m_19319mvvf8.mp4",
        "https://b.top4top.io/m_1931icmzd9.mp4",
        "https://h.top4top.io/m_19316oo0s0.mp4",
        "https://i.top4top.io/m_1931cvvpt1.mp4"
    ];

    await satanic.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        const randomUrl = pickRandom(asupan);
        
        await satanic.sendMessage(m.chat, {
            video: { url: randomUrl },
            caption: `🎬 *RANDOM ASUPAN*`
        }, { quoted: m });

        await satanic.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (err) {
        console.error('[RANDOMASUPAN]', err);
        await satanic.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply(`❌ Gagal: ${err.message || 'Coba lagi nanti'}`);
    }
}
break;
/////// BATAS AKHIR IMAGE EDITOR ////////
default:
// Tambahkan method ini di class utama bot
if (m.chat.endsWith('@s.whatsapp.net') && !m.fromMe) {
    const isCommand = m.text && m.text.startsWith(prefix);
    if (!isCommand) {
        satanic.menfes = satanic.menfes ?? {};
        const session = Object.values(satanic.menfes).find(room => room.state === 'CHATTING' && [room.a, room.b].includes(m.sender));
        if (session) {
            const target = session.a === m.sender ? session.b : session.a;
            await m.copyNForward(target, true, m.quoted && m.quoted.fromMe ? {
                contextInfo: {
                    ...m.msg.contextInfo,
                    forwardingScore: 0,
                    isForwarded: true,
                    participant: target
                }
            } : {});
            return;
        }
    }
}	    
    
if (budy.startsWith('vv')) {
if (!isCreator) return
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
}
                
if (budy.startsWith('>/')) {
if (!isCreator) return;
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = util.inspect(evaled);
await reply(evaled);
} catch (err) {
reply(String(err));
}
}
                
if (budy.startsWith('=>')) {
if (!isCreator) return;
let teks;
try {
teks = await eval(`(async () => { ${budy.slice(2)}})()`);
} catch (e) {
teks = e;
} finally {
await reply(util.format(teks));
}
}
break;
}
} catch (err) {
console.error("Error:", err);
console.log(util.format(err));
}
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(chalk.redBright(`Update ${__filename}`));
    delete require.cache[file];
    require(file);
});
