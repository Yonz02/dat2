// Plugin: tess.js
// Dibuat: 7/6/2026, 6:34:04 AM
// Format: CommonJS

module.exports = {
    name: 'tess',
    description: 'Plugin tess.js',
    category: 'custom',
    execute: async (satanic, m, args, fkontak, namaBot, global, prefix) => {
        try {
            const text = args.join(' ');
            const name = args.join(' ') || 'World';
await m.reply('Hello ' + name + '! Ini adalah plugin test! ✅');
        } catch (e) {
            console.error('Error:', e);
            await m.reply('❌ Error: ' + e.message);
        }
    }
};