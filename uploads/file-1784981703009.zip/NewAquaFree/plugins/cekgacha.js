// Plugin: cekgacha.js
// Dibuat: 7/9/2026, 3:44:48 AM
// Format: CommonJS

module.exports = {
  name: 'cekgacha',
  description: 'Plugin cekgacha.js',
  category: 'custom',
  execute: async (satanic, m, args) => {
    try {
      const percent = Math.floor(Math.random() * 101)
    const mentioned = m.mentionedJid[0] || m.sender
                    
    let desc = ''
    if (percent >= 90) desc = 'HOKI PARAH! SSR GUARANTEED! ✨💎'
    else if (percent >= 70) desc = 'Lucky! Pasti dapet SR keatas! 🍀'
    else if (percent >= 50) desc = 'Hoki-hoki dikit 😊'
    else if (percent >= 30) desc = 'Hmm... pray harder! 🙏'
    else desc = 'SIAL! Nanti aja gachanya! 💔'
    
    let txt = mentioned === m.sender ? `Hai @${mentioned.split('@')[0]}
    
Tingkat kegachaan kamu *${percent}%*
\`\`\`${desc}\`\`\`` : `Kamu ingin ngecek tingkat kegachaan @${mentioned.split('@')[0]} yak? 
    
Tingkat kegachaan dia sebesar *${percent}%*
\`\`\`${desc}\`\`\``
    
    await m.reply(txt, { mentions: [mentioned] })
    } catch (e) {
      console.error('Error:', e);
      await m.reply('❌ Error: ' + e.message);
    }
  }
};