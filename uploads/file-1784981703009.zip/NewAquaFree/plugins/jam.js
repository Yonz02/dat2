// Plugin: jam.js
// Dibuat: 7/8/2026, 8:54:13 PM
// Format: CommonJS

const axios = require('axios');
const cheerio = require('cheerio');

module.exports = {
  name: 'jam',
  description: 'Cek waktu Jakarta sekarang',
  category: 'tools',
  handler: {
    help: ['timeis'],
    tags: ['tools'],
    command: ['timeis', 'jam'],
  },
  execute: async (satanic, m) => {
    try {
      const msg = await m.reply('⏳ Mengambil waktu dari https://time.is/id/Jakarta ...');

      try {
        const { data } = await axios.get('https://time.is/id/Jakarta');
        const $ = cheerio.load(data);

        const lokasi = $('#msgdiv b').text().trim();
        const tanggal = $('#dd').text().trim();
        const jam = $('#clock0_bg').text().trim();

        const now = new Date();
        const jamFallback = now.toLocaleTimeString('id-ID', { 
          hour12: false, 
          timeZone: 'Asia/Jakarta' 
        });

        const teks = `*Waktu di Jakarta Sekarang*\n\n` +
          `*Lokasi:* ${lokasi || 'Jakarta'}\n` +
          `*Tanggal:* ${tanggal || 'Tidak ditemukan'}\n` +
          `*Jam:* ${jam || jamFallback}`;

        await m.reply(teks);

      } catch (err) {
        console.error('Error scraping:', err);
        await m.reply('❌ Gagal mengambil data dari time.is Jakarta');
      }

    } catch (e) {
      console.error('Error:', e);
      await m.reply('❌ Error: ' + e.message);
    }
  }
};