// Plugin: dongeng.js
// Dibuat: 8/7/2026
// Format: CommonJS

const axios = require('axios');
const cheerio = require('cheerio');

const dongeng = {
  list: async () => {
    const posts = [];
    
    try {
      const { data } = await axios.get('https://www.1000dongeng.com/', {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
      });
      
      const $ = cheerio.load(data);
      
      $('.post-outer').each((i, el) => {
        const titleEl = $(el).find('.post-title a, .entry-title a, h3 a');
        const title = titleEl.text().trim();
        const link = titleEl.attr('href');
        
        if (title && link) {
          const author = $(el).find('.post-author .fn, .post-author a').text().trim() || 'Tidak diketahui';
          const date = $(el).find('.post-timestamp .published, .post-date, .date-outer').text().trim() || 'Tidak diketahui';
          
          let image = $(el).find('.post-thumbnail amp-img, .post-thumbnail img').attr('src');
          if (!image) {
            image = $(el).find('img').first().attr('src');
          }
          if (!image) {
            image = 'https://via.placeholder.com/300x200?text=No+Image';
          }
          
          posts.push({ title, link, author, date, image });
        }
      });
      
      return { total: posts.length, posts };
    } catch (error) {
      console.error('Error:', error.message);
      return { total: 0, posts: [] };
    }
  },

  getDongeng: async (url) => {
    try {
      const { data } = await axios.get(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
      });
      
      const $ = cheerio.load(data);
      
      const title = $('.post-title.entry-title, h1.post-title, .entry-title').first().text().trim() || 'Judul tidak tersedia';
      const author = $('.post-author .fn, .post-author a').first().text().trim() || 'Penulis tidak diketahui';
      
      let content = $('.post-body.entry-content, .post-body, .entry-content, .superarticle').html() || '';
      
      content = content
        .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
        .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '')
        .replace(/<a\b[^>]*>(.*?)<\/a>/gi, '$1')
        .replace(/<img\b[^>]*>/gi, '')
        .replace(/<br\s*\/?>/gi, '\n')
        .replace(/<p\b[^>]*>/gi, '\n')
        .replace(/<\/p>/gi, '\n')
        .replace(/<[^>]+>/g, '')
        .replace(/&nbsp;/g, ' ')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
      
      if (!content) {
        content = $('article .content, .post-content, .entry-content').html() || '';
        content = content.replace(/<[^>]+>/g, '').trim();
      }
      
      return { title, author, storyContent: content || 'Konten tidak tersedia' };
    } catch (error) {
      console.error('Error:', error.message);
      return null;
    }
  }
};

module.exports = {
  name: 'dongeng',
  description: 'Cari dongeng dari 1000dongeng.com',
  category: 'internet',
  handler: {
    help: ['dongeng <judul>'],
    tags: ['internet'],
    command: ['dongeng'],
  },
  execute: async (satanic, m, args, text) => {
    try {
      // Cek jika text kosong
      if (!text) {
        return m.reply('📖 Masukkan judul dongeng yang ingin dicari.\n\n📌 *Contoh:* .dongeng Pahlawan');
      }

      // Pastikan text adalah string
      const searchText = String(text).trim();
      
      // Ambil daftar dongeng
      const result = await dongeng.list();
      
      if (!result || !result.posts.length) {
        return m.reply('❌ Gagal mengambil daftar dongeng. Coba lagi nanti.');
      }

      // Cari dongeng yang cocok
      const searchLower = searchText.toLowerCase();
      const foundStory = result.posts.find(story => 
        story.title && story.title.toLowerCase().includes(searchLower)
      );

      if (!foundStory) {
        // Tampilkan beberapa judul yang mirip
        const suggestions = result.posts
          .filter(story => story.title && story.title.toLowerCase().includes(searchLower.substring(0, 3)))
          .slice(0, 3)
          .map(story => `• ${story.title}`)
          .join('\n');
          
        let reply = `❌ Dongeng dengan judul "*${searchText}*" tidak ditemukan.\n\n`;
        if (suggestions) {
          reply += `💡 *Mungkin maksud Anda:*\n${suggestions}`;
        } else {
          reply += '💡 Coba kata kunci lain atau gunakan judul yang lebih spesifik.';
        }
        return m.reply(reply);
      }

      // Ambil isi dongeng
      const story = await dongeng.getDongeng(foundStory.link);
      
      if (!story || !story.storyContent) {
        return m.reply('❌ Gagal mengambil isi dongeng. Coba lagi nanti.');
      }

      // Format pesan
      const caption = `📖 *Judul:* ${story.title}\n✍️ *Penulis:* ${story.author}\n\n📝 *Cerita:*\n${story.storyContent.substring(0, 2000)}${story.storyContent.length > 2000 ? '\n\n... (cerita terlalu panjang)' : ''}`;

      // Kirim dengan gambar jika ada
      try {
        if (foundStory.image && foundStory.image !== 'https://via.placeholder.com/300x200?text=No+Image') {
          await satanic.sendMessage(m.chat, {
            image: { url: foundStory.image },
            caption: caption
          }, { quoted: m });
        } else {
          await m.reply(caption);
        }
      } catch (err) {
        console.error('Gagal kirim gambar:', err.message);
        await m.reply(caption);
      }

    } catch (error) {
      console.error('Error:', error);
      await m.reply('❌ Terjadi kesalahan saat mengambil data. Pastikan koneksi internet stabil.');
    }
  }
};